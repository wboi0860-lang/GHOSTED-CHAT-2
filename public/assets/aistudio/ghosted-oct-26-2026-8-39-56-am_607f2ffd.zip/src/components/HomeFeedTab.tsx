import React, { useState, useEffect, useRef } from 'react';
import {
  UserProfile,
  GhostPost,
  GhostPostComment,
  GhostStatus,
  GhostRevealNotice,
  LiveStreamSession,
  LiveAgreement,
} from '../types';
import { db, auth, ensureAuthenticated } from '../firebase';
import {
  collection,
  doc,
  setDoc,
  getDocs,
  onSnapshot,
  updateDoc,
  addDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  increment,
} from 'firebase/firestore';
import { uploadMedia, cancelActiveUpload } from '../utils/mediaUpload';
import { enhanceImageFree } from '../utils/imageEnhancer';
import { permanentlyDeletePost } from '../utils/postManager';
import { getLocalMediaBlob } from '../utils/localMediaStore';
import {
  Search,
  Bell,
  Plus,
  Heart,
  ThumbsUp,
  MessageCircle,
  Share2,
  Image,
  Video,
  Sparkles,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Trash2,
  X,
  Volume2,
  ChevronRight,
  ChevronLeft,
  Pause,
  ShieldAlert,
  Send,
  Eye,
  Flame,
  Radio,
  Coins,
  MoreVertical,
  Globe,
  Lock,
  User,
  ShieldCheck,
  Check,
  Camera,
  Play,
  Copy,
  Bookmark,
  VolumeX,
  Link2,
  Type,
  Download,
  Maximize2,
} from 'lucide-react';
import { shouldShowAd } from '../utils/adManager';
import { SmartAdInterstitial } from './SmartAdInterstitial';
import { checkBadWords } from '../utils/textFilter';
import { LiveRoomModal } from './LiveRoomModal';
import { CoinStoreModal } from './CoinStoreModal';
import { downloadLikeTikTok, TikTokDownloadProgress } from '../utils/tiktokDownloader';
import { TikTokDownloadModal } from './TikTokDownloadModal';
import { CommentBottomSheet } from './CommentBottomSheet';
import { FullscreenMediaViewer } from './FullscreenMediaViewer';
import { SearchHauntingModal } from './SearchHauntingModal';
import { isUserTeen, canUserGoLive, isCurrentlySleepModeHours } from '../utils/teenProtection';
import { useTheme } from '../context/ThemeContext';

interface HomeFeedTabProps {
  user: UserProfile;
  isNigeria: boolean;
  onUpdateUser: (updated: UserProfile) => void;
  onNavigateToTab?: (tabId: string) => void;
  goLiveTrigger?: number;
}

const INITIAL_INSTAGRAM_POSTS: GhostPost[] = [];

export const HomeFeedTab: React.FC<HomeFeedTabProps> = ({
  user,
  isNigeria,
  onUpdateUser,
  onNavigateToTab,
  goLiveTrigger,
}) => {
  const { currentTheme, isWhite, isBlack, isGhost } = useTheme();
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [isSearchPageOpen, setIsSearchPageOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const [isNotificationsOpen, setIsNotificationsOpen] = useState<boolean>(false);
  const [revealNotices, setRevealNotices] = useState<GhostRevealNotice[]>([]);

  const [statuses, setStatuses] = useState<GhostStatus[]>([]);
  const [isAddStatusOpen, setIsAddStatusOpen] = useState<boolean>(false);
  const [viewingStatus, setViewingStatus] = useState<GhostStatus | null>(null);
  const [statusText, setStatusText] = useState<string>('');
  const [statusMediaUrl, setStatusMediaUrl] = useState<string>('');
  const [originalStatusMedia, setOriginalStatusMedia] = useState<string>('');
  const [isEnhancedStatus, setIsEnhancedStatus] = useState<boolean>(false);
  const [isEnhancingStatus, setIsEnhancingStatus] = useState<boolean>(false);
  const [enhancedStatusMedia, setEnhancedStatusMedia] = useState<string | null>(null);
  const [storySliderSplitPos, setStorySliderSplitPos] = useState<number>(50);
  const [statusType, setStatusType] = useState<'text' | 'image' | 'video'>('text');
  const [statusBgColor, setStatusBgColor] = useState<string>('from-[#2a0845] to-[#6441a5]');

  const handleToggleEnhanceStatus = async () => {
    const baseSource = originalStatusMedia || statusMediaUrl;
    if (!baseSource) return;

    if (isEnhancedStatus) {
      setIsEnhancedStatus(false);
      setStatusMediaUrl(baseSource);
    } else {
      setIsEnhancingStatus(true);
      try {
        let enhanced = enhancedStatusMedia;
        if (!enhanced) {
          enhanced = await enhanceImageFree(baseSource);
          setEnhancedStatusMedia(enhanced);
        }
        setStatusMediaUrl(enhanced);
        setIsEnhancedStatus(true);
      } catch (err) {
        console.warn('Enhancement error:', err);
      } finally {
        setIsEnhancingStatus(false);
      }
    }
  };

  const [liveSessions, setLiveSessions] = useState<LiveStreamSession[]>([]);
  const [activeLiveRoom, setActiveLiveRoom] = useState<{
    session: LiveStreamSession;
    isHost: boolean;
  } | null>(null);
  const [isLiveRulesModalOpen, setIsLiveRulesModalOpen] = useState<boolean>(false);
  const [liveStreamTitle, setLiveStreamTitle] = useState<string>('Late Night Spectral Chill 🎙️');
  const [isAgreed18Plus, setIsAgreed18Plus] = useState<boolean>(false);

  const [isCoinStoreOpen, setIsCoinStoreOpen] = useState<boolean>(false);

  const [posts, setPosts] = useState<GhostPost[]>(() => {
    try {
      const cached = localStorage.getItem('ghosted_cached_feed_posts');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return INITIAL_INSTAGRAM_POSTS;
  });
  const [newPostText, setNewPostText] = useState<string>('');
  const [newPostMedia, setNewPostMedia] = useState<string>('');
  const [newPostMediaType, setNewPostMediaType] = useState<'image' | 'video' | 'none'>('none');
  const [newPostAudience, setNewPostAudience] = useState<'public' | 'private'>(() =>
    isUserTeen(user) ? 'private' : 'public'
  );
  const [isSubmittingPost, setIsSubmittingPost] = useState<boolean>(false);
  const [activeCommentsPostId, setActiveCommentsPostId] = useState<string | null>(null);
  const [activeCommentSheetPost, setActiveCommentSheetPost] = useState<GhostPost | null>(null);
  const [active3DotsPostId, setActive3DotsPostId] = useState<string | null>(null);
  const [fullscreenMediaPost, setFullscreenMediaPost] = useState<GhostPost | null>(null);
  const [deleteSheetPost, setDeleteSheetPost] = useState<GhostPost | null>(null);

  const [doubleTapHearts, setDoubleTapHearts] = useState<{ [postId: string]: boolean }>({});
  const [poppedHeartIds, setPoppedHeartIds] = useState<{ [postId: string]: boolean }>({});
  const [savedPostIds, setSavedPostIds] = useState<{ [postId: string]: boolean }>({});
  const [isPlayingVideoMap, setIsPlayingVideoMap] = useState<Record<string, boolean>>({});
  const [mutedVideoMap, setMutedVideoMap] = useState<Record<string, boolean>>({});
  const [followingIds, setFollowingIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(`ghosted_following_${user.id}`);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // TikTok-Style Download State
  const [tiktokProgress, setTiktokProgress] = useState<TikTokDownloadProgress | null>(null);
  const [isTikTokModalOpen, setIsTikTokModalOpen] = useState<boolean>(false);
  const [downloadingAuthorName, setDownloadingAuthorName] = useState<string>('');
  const lastTapRef = useRef<{ [postId: string]: number }>({});

  const isVideoUrl = (url?: string): boolean => {
    if (!url) return false;
    const clean = url.toLowerCase();
    return (
      clean.includes('.mp4') ||
      clean.includes('.webm') ||
      clean.includes('.mov') ||
      clean.includes('.m4v') ||
      clean.startsWith('data:video/')
    );
  };

  const togglePlayVideo = (postId: string) => {
    const videoEl = document.getElementById(`post-video-${postId}`) as HTMLVideoElement | null;
    if (!videoEl) return;
    if (videoEl.paused) {
      videoEl.play().catch(() => {});
      setIsPlayingVideoMap((prev) => ({ ...prev, [postId]: true }));
    } else {
      videoEl.pause();
      setIsPlayingVideoMap((prev) => ({ ...prev, [postId]: false }));
    }
  };

  const toggleMuteVideo = (postId: string) => {
    const videoEl = document.getElementById(`post-video-${postId}`) as HTMLVideoElement | null;
    setMutedVideoMap((prev) => {
      const isCurrentlyMuted = prev[postId] ?? true;
      const nextMuted = !isCurrentlyMuted;
      if (videoEl) videoEl.muted = nextMuted;
      return { ...prev, [postId]: nextMuted };
    });
  };



  const handlePostDoubleTapLike = (post: GhostPost) => {
    if (!post.likedBy?.includes(user.id)) {
      handleToggleLike(post);
    }
    setDoubleTapHearts((prev) => ({ ...prev, [post.id]: true }));
    setTimeout(() => {
      setDoubleTapHearts((prev) => ({ ...prev, [post.id]: false }));
    }, 900);
  };

  // Status viewer hold-to-pause state
  const [isStatusHeld, setIsStatusHeld] = useState<boolean>(false);
  const statusVideoRef = useRef<HTMLVideoElement | null>(null);

  const handlePostMediaTap = (post: GhostPost) => {
    const now = Date.now();
    const lastTap = lastTapRef.current[post.id] || 0;
    if (now - lastTap < 350) {
      handlePostDoubleTapLike(post);
      lastTapRef.current[post.id] = 0;
    } else {
      lastTapRef.current[post.id] = now;
      setTimeout(() => {
        if (Date.now() - (lastTapRef.current[post.id] || 0) >= 330 && lastTapRef.current[post.id] === now) {
          window.history.pushState({ modal: 'fullscreen_media', postId: post.id }, '');
          setFullscreenMediaPost(post);
        }
      }, 340);
    }
  };

  const [commentInputs, setCommentInputs] = useState<Record<string, string>>({});
  const [isGhostToggled, setIsGhostToggled] = useState<Record<string, boolean>>({});
  const [timerSelections, setTimerSelections] = useState<Record<string, number>>({});
  const [commentsMap, setCommentsMap] = useState<Record<string, GhostPostComment[]>>({});
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [activeAdModal, setActiveAdModal] = useState<boolean>(false);
  const [, setTimerTick] = useState<number>(Date.now());

  useEffect(() => {
    const interval = setInterval(() => {
      setTimerTick(Date.now());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4500);
  };

  useEffect(() => {
    const colRef = collection(db, 'status');
    const unsub = onSnapshot(
      colRef,
      (snapshot) => {
        const now = Date.now();
        const list: GhostStatus[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data() as GhostStatus;
          if (data.expiresAt > now) {
            list.push({ ...data, id: docSnap.id });
          }
        });
        list.sort((a, b) => b.createdAt - a.createdAt);
        setStatuses(list);
      },
      (err) => console.warn('status snapshot error:', err)
    );
    return () => unsub();
  }, []);

  useEffect(() => {
    const colRef = collection(db, 'live_streams');
    const unsub = onSnapshot(
      colRef,
      (snapshot) => {
        const list: LiveStreamSession[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data() as LiveStreamSession;
          if (data.status === 'active') {
            list.push({ ...data, id: docSnap.id });
          }
        });
        list.sort((a, b) => (b.viewersCount || 0) - (a.viewersCount || 0));
        setLiveSessions(list);
      },
      (err) => console.warn('live_streams snapshot error:', err)
    );
    return () => unsub();
  }, []);

  useEffect(() => {
    const handlePostDeleted = (e: any) => {
      const deletedId = e.detail?.postId;
      if (deletedId) {
        setPosts((prev) => prev.filter((p) => p.id !== deletedId));
      }
    };
    window.addEventListener('ghosted_post_deleted', handlePostDeleted);
    return () => window.removeEventListener('ghosted_post_deleted', handlePostDeleted);
  }, []);

  useEffect(() => {
    let unsub = () => {};
    try {
      const deletedIds: string[] = JSON.parse(
        localStorage.getItem(`ghosted_deleted_posts_${user.id}`) || '[]'
      );
      const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'));
      unsub = onSnapshot(
        q,
        (snapshot) => {
          const list: GhostPost[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            if (data.isDeleted) return;
            if (deletedIds.includes(docSnap.id)) return;
            const createdAtVal = data.createdAt?.toMillis
              ? data.createdAt.toMillis()
              : typeof data.createdAt === 'number'
              ? data.createdAt
              : Date.now();
            list.push({
              ...data,
              id: docSnap.id,
              createdAt: createdAtVal,
              likesCount: data.likedBy?.length ?? data.likesCount ?? data.likes ?? 0,
              commentsCount: data.commentsCount ?? 0,
              sharesCount: data.shares_count ?? data.sharesCount ?? 0,
              shares_count: data.shares_count ?? data.sharesCount ?? 0,
            } as GhostPost);
          });
          setPosts((prev) => {
            const prevMap = new Map(prev.map((p) => [p.id, p]));
            return list.map((item) => {
              const existing = prevMap.get(item.id);
              return {
                ...item,
                mediaUrl: item.mediaUrl || existing?.mediaUrl || item.imageUrl,
              };
            });
          });
          try {
            localStorage.setItem('ghosted_cached_feed_posts', JSON.stringify(list));
          } catch {}
        },
        (err) => {
          console.warn('posts ordered snapshot warning, using base collection fallback:', err);
          const unsubBase = onSnapshot(
            collection(db, 'posts'),
            (snapshot) => {
              const list: GhostPost[] = [];
              snapshot.forEach((docSnap) => {
                const data = docSnap.data();
                if (data.isDeleted) return;
                if (deletedIds.includes(docSnap.id)) return;
                const createdAtVal = data.createdAt?.toMillis
                  ? data.createdAt.toMillis()
                  : typeof data.createdAt === 'number'
                  ? data.createdAt
                  : Date.now();
                list.push({
                  ...data,
                  id: docSnap.id,
                  createdAt: createdAtVal,
                  likesCount: data.likedBy?.length ?? data.likesCount ?? data.likes ?? 0,
                  commentsCount: data.commentsCount ?? 0,
                  sharesCount: data.shares_count ?? data.sharesCount ?? 0,
                  shares_count: data.shares_count ?? data.sharesCount ?? 0,
                } as GhostPost);
              });
              list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
              setPosts((prev) => {
                const prevMap = new Map(prev.map((p) => [p.id, p]));
                return list.map((item) => {
                  const existing = prevMap.get(item.id);
                  return {
                    ...item,
                    mediaUrl: item.mediaUrl || existing?.mediaUrl || item.imageUrl,
                  };
                });
              });
              try {
                localStorage.setItem('ghosted_cached_feed_posts', JSON.stringify(list));
              } catch {}
            },
            (err2) => {
              console.warn('posts base snapshot warning:', err2);
              try {
                const cached = localStorage.getItem('ghosted_cached_feed_posts');
                if (cached) {
                  const parsed = JSON.parse(cached);
                  if (Array.isArray(parsed) && parsed.length > 0) {
                    setPosts(parsed.filter((p) => !p.isDeleted && !deletedIds.includes(p.id)));
                  }
                }
              } catch {}
            }
          );
          unsub = unsubBase;
        }
      );
    } catch (e) {
      console.warn('Error establishing posts snapshot:', e);
    }
    return () => unsub();
  }, [user.id]);

  // Ensure any local video posts have their full media blobs restored from IndexedDB
  useEffect(() => {
    posts.forEach((p) => {
      if ((p.mediaType === 'video' || isVideoUrl(p.mediaUrl)) && (!p.mediaUrl || p.mediaUrl.length < 100)) {
        getLocalMediaBlob(p.id).then((blob) => {
          if (blob) {
            setPosts((prev) =>
              prev.map((item) => (item.id === p.id && !item.mediaUrl ? { ...item, mediaUrl: blob } : item))
            );
          }
        });
      }
    });
  }, [posts.length]);

  useEffect(() => {
    if (!user?.id) return;
    const colRef = collection(db, 'ghost_reveals');
    const unsub = onSnapshot(
      colRef,
      (snapshot) => {
        const list: GhostRevealNotice[] = [];
        snapshot.forEach((docSnap) => {
          const data = docSnap.data() as GhostRevealNotice;
          if (data.recipientId === user.id) {
            list.push({ ...data, id: docSnap.id });
          }
        });
        list.sort((a, b) => b.timestamp - a.timestamp);
        setRevealNotices(list);
      },
      (err) => console.warn('ghost_reveals snapshot error:', err)
    );
    return () => unsub();
  }, [user?.id]);

  useEffect(() => {
    if (!activeCommentsPostId) return;
    const colRef = collection(db, 'post_comments');
    const unsub = onSnapshot(
      colRef,
      (snapshot) => {
        const list: GhostPostComment[] = [];
        const now = Date.now();
        snapshot.forEach((docSnap) => {
          const comment = { ...docSnap.data(), id: docSnap.id } as GhostPostComment;
          if (comment.postId === activeCommentsPostId) {
            if (comment.isGhost && !comment.revealed && comment.revealAt && comment.revealAt <= now) {
              updateDoc(doc(db, 'post_comments', comment.id), {
                revealed: true,
              }).catch(() => {});
            }
            list.push(comment);
          }
        });
        list.sort((a, b) => a.createdAt - b.createdAt);
        setCommentsMap((prev) => ({ ...prev, [activeCommentsPostId]: list }));
      },
      (err) => console.warn('post_comments snapshot error:', err)
    );
    return () => unsub();
  }, [activeCommentsPostId]);

  const handleCreateStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!statusText.trim() && !statusMediaUrl) {
      showToast('Please add text, an image, or a video to your story.');
      return;
    }
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      showToast('You appear offline. Please check your internet connection.');
      return;
    }

    setIsSubmittingPost(true);
    try {
      // 1. Ensure user authentication
      await ensureAuthenticated();
      const uid = (auth.currentUser?.uid || user.id || 'ghost_user') as string;

      // 2. Upload media FIRST to stories/$uid/$fileName with 30s timeout
      let url = '';
      if (statusMediaUrl) {
        try {
          url = (await uploadMedia(statusMediaUrl, 'stories', uid)) ?? '';
        } catch (mediaErr) {
          console.warn('Media upload warning, using local source:', mediaErr);
          url = statusMediaUrl;
        }
      }

      const now = Date.now();
      const storyId = `story-${now}-${Math.random().toString(36).slice(2, 6)}`;
      let effectiveType: 'text' | 'image' | 'video' = 'text';
      if (url || statusMediaUrl) {
        effectiveType = statusType === 'video' || (url || statusMediaUrl).startsWith('data:video') ? 'video' : 'image';
      } else if (statusText.trim().startsWith('http://') || statusText.trim().startsWith('https://')) {
        effectiveType = /\.(mp4|webm|mov)(\?.*)?$/i.test(statusText.trim()) ? 'video' : 'image';
      }

      // Safe cloud URL that stays within Firestore 1MB limits
      const isCloudSafeUrl = url && (!url.startsWith('data:') || url.length < 350000);
      const safeCloudUrl = isCloudSafeUrl ? url : '';

      // 3. Payload strictly adheres to firestore.rules for /stories/{storyId}:
      // Required: userId (matching auth.uid), createdAt
      const storyPayload = {
        id: storyId,
        userId: uid,
        imageUrl: (safeCloudUrl || '') as string,
        createdAt: serverTimestamp(),
        type: effectiveType,
        content: (safeCloudUrl || statusText.trim() || (effectiveType === 'video' ? '🎬 Video Story' : '🖼️ Photo Story')) as string,
        caption: statusText.trim() ? (statusText.trim() as string) : undefined,
        backgroundColor: statusBgColor ?? '#000000',
        expiresAt: now + 24 * 60 * 60 * 1000,
        authorId: user.id as string,
        authorName: (user.name || user.ghostedId || 'Ghost User') as string,
        authorAvatar: (user.avatarUrl || '👻') as string,
        authorGhostedId: (user.ghostedId ?? '') as string,
        seenBy: [user.id],
        isEnhanced: isEnhancedStatus,
      };

      // 4. Save to collection('stories') & fallback to 'status'
      try {
        await setDoc(doc(db, 'stories', storyId), storyPayload);
        setDoc(doc(db, 'status', storyId), storyPayload).catch(() => {});
      } catch (writeErr: any) {
        console.warn('Firestore write warning:', writeErr);
      }

      // 5. In all cases, immediately add to local statuses state so user can view right away
      const localStory: GhostStatus = {
        ...storyPayload,
        id: storyId,
        content: url || statusText.trim(),
        createdAt: now,
        isEnhanced: isEnhancedStatus,
      } as any;
      setStatuses((prev) => [localStory, ...prev.filter((s) => s.id !== storyId)]);

      showToast(effectiveType === 'video' ? 'Video story posted!' : effectiveType === 'image' ? 'Photo story posted!' : 'Story thought posted!');
      setStatusText('');
      setStatusMediaUrl('');
      setOriginalStatusMedia('');
      setEnhancedStatusMedia(null);
      setIsEnhancedStatus(false);
      setStatusType('text');
      setIsAddStatusOpen(false);
    } catch (e: any) {
      console.error('PUBLISH ERROR FULL (Story):', e);
      showToast(`Failed: ${e?.message || String(e)}`);
    } finally {
      setIsSubmittingPost(false);
    }
  };

  const handleToggleAudience = async (post: GhostPost, newAudience: 'public' | 'private') => {
    if (post.authorId !== user.id) return;
    try {
      await updateDoc(doc(db, 'posts', post.id), {
        audience: newAudience,
      });
      showToast(`Audience updated to ${newAudience === 'public' ? 'Public (Everyone)' : 'Private (Connections Only)'}`);
    } catch {}
    setActive3DotsPostId(null);
  };

  const handleToggleLike = async (post: GhostPost) => {
    setPoppedHeartIds((prev) => ({ ...prev, [post.id]: true }));
    setTimeout(() => {
      setPoppedHeartIds((prev) => ({ ...prev, [post.id]: false }));
    }, 400);
    const isLiked = post.likedBy?.includes(user.id);
    const updatedLikedBy = isLiked
      ? (post.likedBy || []).filter((id) => id !== user.id)
      : [...(post.likedBy || []), user.id];
    const updatedCount = updatedLikedBy.length;
    setPosts((prev) =>
      prev.map((p) =>
        p.id === post.id
          ? { ...p, likedBy: updatedLikedBy, likesCount: updatedCount }
          : p
      )
    );
    try {
      await updateDoc(doc(db, 'posts', post.id), {
        likedBy: updatedLikedBy,
        likesCount: updatedCount,
      });
    } catch (err) {
      console.warn('Like toggle error:', err);
    }
  };

  const handleSharePost = async (post: GhostPost) => {
    const shareText = post.text
      ? `${post.text}\nShared from THE VOID on GHOSTED`
      : 'Check out this whisper on GHOSTED';
    const shareUrl = post.mediaUrl || window.location.href;

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Ghosted Whisper',
          text: shareText,
          url: shareUrl,
        });
        // User tapped Share > App and completed: increment shares count
        const updatedShares = (post.shares_count ?? post.sharesCount ?? 0) + 1;
        setPosts((prev) =>
          prev.map((p) =>
            p.id === post.id
              ? { ...p, sharesCount: updatedShares, shares_count: updatedShares }
              : p
          )
        );
        try {
          await updateDoc(doc(db, 'posts', post.id), {
            shares_count: increment(1),
            sharesCount: increment(1),
          });
        } catch (err) {
          console.warn('Share increment error:', err);
        }
        showToast('Shared via app! 🚀');
      } catch (err: any) {
        if (err?.name !== 'AbortError') {
          console.warn('Share error:', err);
        }
      }
    } else {
      navigator.clipboard.writeText(`${shareText}\n${shareUrl}`);
      showToast('Share link copied to clipboard 📋');
    }
  };

  const handleToggleFollowUser = async (targetAuthorId: string, authorName: string) => {
    if (targetAuthorId === user.id) return;
    const isCurrentlyFollowing = followingIds.includes(targetAuthorId);
    const updated = isCurrentlyFollowing
      ? followingIds.filter((id) => id !== targetAuthorId)
      : [...followingIds, targetAuthorId];
    setFollowingIds(updated);
    try {
      localStorage.setItem(`ghosted_following_${user.id}`, JSON.stringify(updated));
    } catch {}
    showToast(isCurrentlyFollowing ? `Unfollowed ${authorName}` : `Following ${authorName} ✨`);
    try {
      await updateDoc(doc(db, 'users', user.id), { following: updated });
    } catch {}
  };

  const handleDownloadPost = async (post: GhostPost) => {
    setDownloadingAuthorName(post.authorName || 'ghost_user');
    setIsTikTokModalOpen(true);
    setTiktokProgress({
      status: 'preparing',
      progress: 5,
      message: 'Preparing download...',
    });

    await downloadLikeTikTok(
      {
        id: post.id,
        text: post.text,
        mediaUrl: post.mediaUrl,
        mediaType: post.mediaType,
        authorName: post.authorName,
        authorId: post.authorId,
        createdAt: post.createdAt,
      },
      (progress) => {
        setTiktokProgress(progress);
        if (progress.status === 'completed') {
          showToast('Saved to device with TikTok watermark! 🎬');
          setTimeout(() => {
            setIsTikTokModalOpen(false);
          }, 2000);
        }
      }
    );
  };

  const handleSendComment = async (
    postId: string,
    explicitText?: string,
    explicitIsGhost?: boolean,
    explicitHours?: number,
    attachments?: {
      imageUrl?: string;
      stickerUrl?: string;
      stickerType?: 'ghost' | 'custom_image' | 'live';
      stickerTitle?: string;
      mentionedProfileId?: string;
      mentionedVideoUrl?: string;
    }
  ) => {
    const rawText = (explicitText !== undefined ? explicitText : commentInputs[postId])?.trim() || '';
    if (!rawText && !attachments?.imageUrl && !attachments?.stickerUrl && !attachments?.mentionedVideoUrl) return;

    const check = rawText ? checkBadWords(rawText) : { isBlocked: false, flaggedWords: [], cleanText: '' };
    if (check.isBlocked) {
      showToast(`Comment blocked: prohibited words (${check.flaggedWords.join(', ')}).`);
      return;
    }

    const isGhost = explicitIsGhost !== undefined ? explicitIsGhost : (isGhostToggled[postId] ?? true);
    const selectedHours = isGhost ? (explicitHours !== undefined ? explicitHours : (timerSelections[postId] ?? 24)) : undefined;
    const now = Date.now();
    const commentId = `comm-${now}-${Math.random().toString(36).slice(2, 6)}`;

    const commentExpiresAt = isGhost && selectedHours ? now + selectedHours * 60 * 60 * 1000 : undefined;
    const randomDelaySeconds = Math.floor(86400 + Math.random() * 86400);
    const revealAt = isGhost ? now + randomDelaySeconds * 1000 : undefined;
    const randomDigits = Math.floor(1000 + Math.random() * 9000);

    const newComment: GhostPostComment = {
      id: commentId,
      postId,
      isGhost,
      ghostMode: isGhost,
      realUserId: user.id,
      realUsername: user.name || user.ghostedId || 'Ghoster',
      realUserAvatar: user.avatarUrl || '👻',
      originalText: check.cleanText,
      displayName: isGhost ? 'Ghost User' : user.name || 'Anonymous',
      ghostName: isGhost ? `Ghost #${randomDigits}` : undefined,
      revealAt,
      revealed: !isGhost,
      isDeleted: false,
      createdAt: now,
      commentExpiresAt,
      timerDurationHours: selectedHours,
      imageUrl: attachments?.imageUrl,
      stickerUrl: attachments?.stickerUrl,
      stickerType: attachments?.stickerType,
      stickerTitle: attachments?.stickerTitle,
      mentionedProfileId: attachments?.mentionedProfileId,
      mentionedVideoUrl: attachments?.mentionedVideoUrl,
    };

    try {
      await setDoc(doc(db, 'post_comments', commentId), newComment);
      const targetPost = posts.find((p) => p.id === postId);
      if (targetPost) {
        await updateDoc(doc(db, 'posts', postId), {
          commentsCount: (targetPost.commentsCount || 0) + 1,
        });
      }
    } catch (err) {
      console.warn('Comment write error:', err);
    }

    setCommentInputs((prev) => ({ ...prev, [postId]: '' }));
    if (isGhost) {
      showToast(`Posted as 👻 (Ghost me). Vanishes in ${selectedHours}h.`);
    } else {
      showToast('Comment posted as (Real me) 👤 (permanent).');
    }
  };

  const handleDeleteComment = async (postId: string, commentId: string) => {
    try {
      await updateDoc(doc(db, 'post_comments', commentId), { isDeleted: true });
      showToast('Comment deleted. Owner will be privately notified upon timer reveal.');
    } catch {
      await deleteDoc(doc(db, 'post_comments', commentId)).catch(() => {});
    }
  };

  const handleDeletePost = async (postId: string) => {
    const targetPost = posts.find((p) => p.id === postId);
    const isPostMine =
      targetPost &&
      (targetPost.authorId === user.id ||
        targetPost.userId === user.id ||
        (targetPost.authorGhostedId && targetPost.authorGhostedId === user.ghostedId) ||
        (auth.currentUser?.uid && (targetPost.userId === auth.currentUser.uid || targetPost.authorId === auth.currentUser.uid)) ||
        (user.uid && (targetPost.userId === user.uid || targetPost.authorId === user.uid)));
    if (targetPost && !isPostMine) {
      showToast('Only the author can delete this post');
      setActive3DotsPostId(null);
      return;
    }
    try {
      await permanentlyDeletePost(postId, user.id);
      setPosts((prev) => prev.filter((p) => p.id !== postId));
      showToast('Post deleted permanently everywhere 🗑️');
      setActive3DotsPostId(null);
    } catch (err) {
      console.warn('Error deleting post:', err);
      setPosts((prev) => prev.filter((p) => p.id !== postId));
      showToast('Post deleted');
      setActive3DotsPostId(null);
    }
  };

  const handleConfirmDeletePost = async () => {
    if (!deleteSheetPost) return;
    const postId = deleteSheetPost.id;
    try {
      await permanentlyDeletePost(postId, user.id);
      setPosts((prev) => prev.filter((p) => p.id !== postId));
      showToast('Post deleted permanently everywhere 🗑️');
    } catch (err) {
      console.warn('Delete post error:', err);
      setPosts((prev) => prev.filter((p) => p.id !== postId));
      showToast('Post deleted');
    } finally {
      setDeleteSheetPost(null);
    }
  };

  const handleOpenGoLiveModal = () => {
    if (!canUserGoLive(user)) {
      showToast('Live streaming is reserved for 16+ accounts under Teen Safety Protection.');
      return;
    }
    if (user.isLiveBanned) {
      showToast('Your live streaming privileges are suspended due to a previous safety violation.');
      return;
    }
    setIsLiveRulesModalOpen(true);
  };

  useEffect(() => {
    if (goLiveTrigger && goLiveTrigger > 0) {
      handleOpenGoLiveModal();
    }
  }, [goLiveTrigger]);

  const handleConfirmStartLive = async () => {
    if (!isAgreed18Plus) {
      showToast('You must confirm you are 18+ and agree to Ghosted Live rules.');
      return;
    }
    const now = Date.now();
    const liveId = `live-${now}-${Math.random().toString(36).slice(2, 6)}`;

    const agreement: LiveAgreement = {
      userId: user.id,
      agreedAt: now,
      is18Plus: true,
      version: 'v15',
    };
    await addDoc(collection(db, 'live_agreements'), agreement).catch(() => {});

    const session: LiveStreamSession = {
      id: liveId,
      hostId: user.id,
      hostName: user.name || user.ghostedId || 'Ghost Creator',
      hostAvatar: user.avatarUrl || '👻',
      hostGhostedId: user.ghostedId,
      title: liveStreamTitle.trim() || 'Late Night Spectral Chill 🎙️',
      status: 'active',
      viewersCount: 1,
      likesCount: 0,
      createdAt: now,
      violationsCount: 0,
    };
    try {
      await setDoc(doc(db, 'live_streams', liveId), session);
      setIsLiveRulesModalOpen(false);
      setActiveLiveRoom({ session, isHost: true });
    } catch (err) {
      console.warn('Start live error:', err);
    }
  };

  const filteredPosts = searchQuery.trim()
    ? posts.filter((p) => {
        const q = searchQuery.toLowerCase().trim();
        const matchesText = Boolean(p.text && p.text.toLowerCase().includes(q));
        const matchesAuthor = Boolean(p.authorName && p.authorName.toLowerCase().includes(q));
        const matchesGhostId = Boolean(p.authorGhostedId && p.authorGhostedId.toLowerCase().includes(q));
        return matchesText || matchesAuthor || matchesGhostId;
      })
    : posts;

  function formatTimeAgo(timestamp: number) {
    const diff = Math.max(0, Date.now() - timestamp);
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'Just now';
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  }

  function renderUserAvatar(avatarUrl?: string, name?: string, fallbackEmoji: string = '👻') {
    if (
      avatarUrl &&
      !avatarUrl.includes('dicebear') &&
      (avatarUrl.startsWith('http') || avatarUrl.startsWith('data:'))
    ) {
      return (
        <img
          src={avatarUrl}
          alt=""
          className="w-full h-full object-cover"
          onError={(e) => {
            e.currentTarget.style.display = 'none';
          }}
        />
      );
    }
    const initial = name && name.trim() ? name.trim()[0].toUpperCase() : fallbackEmoji;
    return <span>{initial}</span>;
  }

  return (
    <div className="w-full space-y-4 pb-6">
      <div className="max-w-2xl mx-auto px-4 space-y-4">
        {toastMessage && (
          <div className="p-3 rounded-xl bg-[#1877F2] text-white text-xs font-bold flex items-center space-x-2 animate-in fade-in duration-200 shadow-md">
            <Sparkles className="w-4 h-4 text-amber-300 flex-shrink-0" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* SEARCH BAR: Tapping opens full-screen What's Haunting You search page */}
        <div
          onClick={() => setIsSearchPageOpen(true)}
          className="p-2 sm:p-2.5 rounded-2xl border shadow-xs transition-all duration-300 cursor-pointer hover:border-cyan-500/40 active:scale-[0.99]"
          style={{
            backgroundColor: currentTheme.card,
            borderColor: currentTheme.border,
          }}
        >
          <div className="relative flex items-center">
            <Search
              className="w-4 h-4 absolute left-3.5 opacity-60 pointer-events-none"
              style={{ color: currentTheme.cardText }}
            />
            <input
              type="text"
              readOnly
              value={searchQuery}
              onFocus={() => setIsSearchPageOpen(true)}
              placeholder="What's haunting you?..."
              className="w-full pl-10 pr-20 py-2 rounded-xl text-xs sm:text-sm focus:outline-none transition border font-medium cursor-pointer"
              style={{
                backgroundColor: isBlack ? '#18191A' : isGhost ? '#0A0A0F' : '#F0F2F5',
                borderColor: currentTheme.border,
                color: currentTheme.cardText,
              }}
            />
            <div className="absolute right-3 flex items-center space-x-2">
              {searchQuery && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSearchQuery('');
                  }}
                  className="p-1 rounded-full hover:opacity-75 transition cursor-pointer"
                  style={{ color: currentTheme.cardText }}
                  title="Clear search"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
              <span
                className="text-xs font-bold px-2 py-0.5 rounded-md"
                style={{ color: isGhost ? '#00F5FF' : isBlack ? '#FF2A55' : '#1877F2' }}
              >
                Search
              </span>
            </div>
          </div>
          {searchQuery.trim() && (
            <div
              className="flex items-center justify-between pt-2 px-1 text-[11px]"
              style={{ color: currentTheme.cardSubtext }}
            >
              <span>
                Found <strong>{filteredPosts.length}</strong> {filteredPosts.length === 1 ? 'whisper' : 'whispers'} in the void for "<strong>{searchQuery}</strong>"
              </span>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setSearchQuery('');
                }}
                className="hover:underline cursor-pointer font-bold text-xs"
                style={{ color: isGhost ? '#00F5FF' : '#1877F2' }}
              >
                Clear filter
              </button>
            </div>
          )}
        </div>

        {/* 24H STORIES BAR */}
        <div
          className="p-3.5 rounded-2xl border shadow-sm space-y-2.5 theme-card transition-colors duration-300"
          style={{
            backgroundColor: currentTheme.card,
            color: currentTheme.cardText,
            borderColor: currentTheme.border,
          }}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold" style={{ color: currentTheme.cardText }}>
              Stories
            </span>
            <span className="text-[10px]" style={{ color: currentTheme.cardSubtext }}>
              24h ephemeral
            </span>
          </div>
          <div className="flex items-center space-x-2.5 overflow-x-auto pb-1 scrollbar-none">
            <button
              type="button"
              onClick={() => setIsAddStatusOpen(true)}
              className="flex flex-col items-center flex-shrink-0 space-y-1 cursor-pointer group"
            >
              <div
                className="w-12 h-12 rounded-full border-2 border-dashed flex items-center justify-center transition"
                style={{
                  borderColor: isGhost ? '#00F5FF' : '#1877F2',
                  backgroundColor: isBlack ? '#F3F4F6' : '#141414',
                  color: isGhost ? '#00F5FF' : '#1877F2',
                }}
              >
                <Plus className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-bold" style={{ color: currentTheme.cardText }}>
                Add Story
              </span>
            </button>
            {statuses.map((s) => {
              const isSeen = s.seenBy?.includes(user.id);
              return (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setViewingStatus(s)}
                  className="flex flex-col items-center flex-shrink-0 space-y-1 cursor-pointer"
                >
                  <div
                    className="w-12 h-12 rounded-full p-0.5 transition border-2"
                    style={{
                      borderColor: isSeen
                        ? currentTheme.border
                        : isGhost
                        ? '#00F5FF'
                        : '#1877F2',
                    }}
                  >
                    <div
                      className="w-full h-full rounded-full flex items-center justify-center text-sm font-bold overflow-hidden relative border"
                      style={{
                        backgroundColor: isBlack ? '#F3F4F6' : '#141414',
                        borderColor: currentTheme.border,
                        color: currentTheme.cardText,
                      }}
                    >
                      {s.type === 'video' ? (
                        <div className="w-full h-full relative flex items-center justify-center bg-black">
                          <video src={s.content} className="w-full h-full object-cover" muted />
                          <span className="absolute inset-0 bg-black/30 flex items-center justify-center">
                            <Video className="w-3.5 h-3.5 text-white" />
                          </span>
                        </div>
                      ) : s.type === 'image' ? (
                        <img src={s.content} alt="" className="w-full h-full object-cover" />
                      ) : (
                        renderUserAvatar(s.authorAvatar, s.authorName, '👻')
                      )}
                    </div>
                  </div>
                  <span
                    className="text-[10px] font-bold truncate max-w-[52px]"
                    style={{ color: currentTheme.cardText }}
                  >
                    {s.authorName}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* FACEBOOK FEED STREAM */}
      <div className="w-full flex flex-col gap-3 max-w-2xl mx-auto px-4">
        {filteredPosts.length === 0 ? (
          <div className="w-full">
            <div
              className="py-12 text-center rounded-3xl p-6 space-y-3.5 theme-card shadow-lg border transition-colors duration-300"
              style={{
                backgroundColor: currentTheme.card,
                color: currentTheme.cardText,
                borderColor: currentTheme.border,
              }}
            >
              <span className="text-4xl block">{searchQuery.trim() ? '🔍' : '👻'}</span>
              <h4 className="text-base font-bold" style={{ color: currentTheme.cardText }}>
                {searchQuery.trim() ? 'No matching whispers or users found' : 'No posts yet'}
              </h4>
              <p className="text-xs max-w-xs mx-auto leading-relaxed" style={{ color: currentTheme.cardSubtext }}>
                {searchQuery.trim()
                  ? `We couldn't find any content matching "${searchQuery}". Try another keyword, username, or Ghost ID.`
                  : "Be the first to whisper or share what's on your mind into THE VOID!"}
              </p>
              {searchQuery.trim() && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="px-4 py-2 rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
                  style={{
                    backgroundColor: currentTheme.btnPrimaryBg,
                    color: currentTheme.btnPrimaryText,
                  }}
                >
                  Clear Search
                </button>
              )}
            </div>
          </div>
        ) : (
          filteredPosts.map((post, postIndex) => {
            const isLiked = post.likedBy?.includes(user.id);
            const isCommentsOpen = activeCommentsPostId === post.id;
            const isOwner =
              post.authorId === user.id ||
              post.userId === user.id ||
              (post.authorGhostedId && post.authorGhostedId === user.ghostedId) ||
              (auth.currentUser?.uid && (post.userId === auth.currentUser.uid || post.authorId === auth.currentUser.uid)) ||
              (user.uid && (post.userId === user.uid || post.authorId === user.uid));
            const isVipUser = Boolean(
              user.isVIP && (!user.vipExpiry || new Date(user.vipExpiry).getTime() > Date.now())
            );
            const showAdBefore = !isVipUser && postIndex > 0 && postIndex % 4 === 0;

            return (
              <React.Fragment key={post.id}>
                {showAdBefore && (
                  <div className="max-w-2xl mx-auto w-full px-4">
                    <div className="p-4 rounded-2xl bg-gradient-to-r from-zinc-950 via-purple-950/40 to-black border border-amber-500/30 space-y-2.5 shadow-xl relative overflow-hidden">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <span className="text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-400/40 px-2.5 py-0.5 rounded-full">
                            ADS
                          </span>
                          <span className="text-[10px] text-zinc-400 font-mono">Sponsored</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => onNavigateToTab && onNavigateToTab('premium')}
                          className="text-[10px] text-amber-300 hover:text-amber-200 font-bold underline cursor-pointer"
                        >
                          Stop ADS (VIP)
                        </button>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-purple-600 flex items-center justify-center text-xl flex-shrink-0 shadow-md">
                          {postIndex % 8 === 0 ? '👑' : '✨'}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="text-xs font-bold text-white truncate">
                            {postIndex % 8 === 0
                              ? 'Stop ADS with Ghosted VIP'
                              : 'Ad-Free Stealth Browsing in THE VOID'}
                          </h4>
                          <p className="text-[11px] text-zinc-400 line-clamp-1">
                            {isNigeria
                              ? 'Only ₦300/day to permanently stop all ads.'
                              : 'Only $0.50/day to permanently stop all ads.'}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => onNavigateToTab && onNavigateToTab('premium')}
                          className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-purple-600 hover:from-amber-400 hover:to-purple-500 text-white font-bold text-xs shadow-md transition cursor-pointer flex-shrink-0"
                        >
                          Stop ADS
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                <div
                  id={`post-${post.id}`}
                  className="w-full border shadow-sm rounded-2xl overflow-hidden my-2.5 theme-card transition-all duration-300"
                  style={{
                    backgroundColor: currentTheme.card,
                    color: currentTheme.cardText,
                    borderColor: currentTheme.border,
                  }}
                >
                  {/* POST HEADER */}
                  <div
                    className="px-4 py-3 flex items-center justify-between border-b"
                    style={{ borderColor: currentTheme.border }}
                  >
                    <div className="flex items-center space-x-2.5">
                      <div className="relative">
                        <div
                          className="w-10 h-10 rounded-full overflow-hidden flex items-center justify-center font-bold text-xs border"
                          style={{
                            backgroundColor: isBlack ? '#F3F4F6' : '#141414',
                            borderColor: currentTheme.border,
                            color: currentTheme.cardText,
                          }}
                        >
                          {renderUserAvatar(post.authorAvatar, post.authorName, '👻')}
                        </div>
                        <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-current" />
                      </div>
                      <div className="flex flex-col min-w-0">
                        <span
                          className="text-sm font-bold tracking-tight truncate hover:underline cursor-pointer"
                          style={{ color: currentTheme.cardText }}
                        >
                          {post.authorName}
                        </span>
                        <div
                          className="flex items-center space-x-1.5 text-xs font-medium"
                          style={{ color: currentTheme.cardSubtext }}
                        >
                          <span>{formatTimeAgo(post.createdAt)}</span>
                          <span>•</span>
                          <span className="flex items-center space-x-1">
                            {post.audience === 'private' ? <Lock className="w-3 h-3" /> : <Globe className="w-3 h-3" />}
                            <span>{post.audience === 'private' ? 'Private' : 'Public'}</span>
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      {post.authorId !== user.id && (
                        <button
                          type="button"
                          onClick={() => handleToggleFollowUser(post.authorId, post.authorName)}
                          className="px-3 py-1.5 rounded-xl text-xs font-bold transition active:scale-95 cursor-pointer border"
                          style={{
                            backgroundColor: followingIds.includes(post.authorId)
                              ? (isBlack ? '#F3F4F6' : '#141414')
                              : currentTheme.btnPrimaryBg,
                            color: followingIds.includes(post.authorId)
                              ? currentTheme.cardText
                              : currentTheme.btnPrimaryText,
                            borderColor: currentTheme.border,
                          }}
                        >
                          {followingIds.includes(post.authorId) ? 'Following' : 'Follow'}
                        </button>
                      )}
                      <div className="relative">
                        <button
                          type="button"
                          onClick={() =>
                            setActive3DotsPostId(active3DotsPostId === post.id ? null : post.id)
                          }
                          className="p-1.5 rounded-full transition cursor-pointer hover:opacity-80"
                          style={{ color: currentTheme.cardSubtext }}
                          title="Post options"
                        >
                          <MoreVertical className="w-4 h-4" />
                        </button>
                        {active3DotsPostId === post.id && (
                          <div
                            className="absolute right-0 top-8 z-30 w-48 rounded-2xl border p-1.5 shadow-2xl space-y-1 text-xs"
                            style={{
                              backgroundColor: currentTheme.card,
                              color: currentTheme.cardText,
                              borderColor: currentTheme.border,
                            }}
                          >
                            {isOwner && (
                              <button
                                type="button"
                                onClick={() => {
                                  setDeleteSheetPost(post);
                                  setActive3DotsPostId(null);
                                }}
                                className="w-full text-left p-2 rounded-xl hover:bg-rose-500/10 text-rose-500 flex items-center space-x-2 cursor-pointer transition font-bold"
                              >
                                <Trash2 className="w-3.5 h-3.5 text-rose-500" />
                                <span>Delete Post</span>
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => {
                                const postContent = post.mediaUrl ? `${post.text ? post.text + '\n' : ''}${post.mediaUrl}` : post.text;
                                navigator.clipboard.writeText(postContent);
                                showToast('Post copied to clipboard');
                                setActive3DotsPostId(null);
                              }}
                              className="w-full text-left p-2 rounded-xl hover:opacity-80 flex items-center space-x-2 cursor-pointer transition font-medium"
                              style={{ color: currentTheme.cardText }}
                            >
                              <Copy className="w-3.5 h-3.5 text-[#1877F2]" />
                              <span>Copy Post</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                if (navigator.share) {
                                  navigator.share({ title: 'Ghosted Whisper', text: post.text });
                                } else {
                                  navigator.clipboard.writeText(post.text);
                                  showToast('Share link copied to clipboard');
                                }
                                setActive3DotsPostId(null);
                              }}
                              className="w-full text-left p-2 rounded-xl hover:opacity-80 flex items-center space-x-2 cursor-pointer transition font-medium"
                              style={{ color: currentTheme.cardText }}
                            >
                              <Send className="w-3.5 h-3.5 text-[#1877F2] -rotate-12" />
                              <span>Share Post</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                handleDownloadPost(post);
                                setActive3DotsPostId(null);
                              }}
                              className="w-full text-left p-2 rounded-xl hover:opacity-80 text-emerald-400 flex items-center space-x-2 cursor-pointer transition font-medium"
                            >
                              <Download className="w-3.5 h-3.5 text-emerald-400" />
                              <span>Save to Gallery</span>
                            </button>
                            {isOwner && (
                              <button
                                type="button"
                                onClick={() => {
                                  handleToggleAudience(post, post.audience === 'public' ? 'private' : 'public');
                                  setActive3DotsPostId(null);
                                }}
                                className="w-full text-left p-2 rounded-xl hover:opacity-80 text-amber-400 flex items-center space-x-2 cursor-pointer transition border-t pt-2 font-medium"
                                style={{ borderColor: currentTheme.border }}
                              >
                                {post.audience === 'public' ? (
                                  <>
                                    <Lock className="w-3.5 h-3.5 text-amber-500" />
                                    <span>Make Private</span>
                                  </>
                                ) : (
                                  <>
                                    <Globe className="w-3.5 h-3.5 text-[#1877F2]" />
                                    <span>Make Public</span>
                                  </>
                                )}
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* POST TEXT (IF ANY) */}
                  {post.text && (
                    <div
                      className="px-4 py-2.5 text-sm sm:text-base leading-relaxed whitespace-pre-wrap select-text font-normal"
                      style={{ color: currentTheme.cardText }}
                    >
                      {post.text}
                    </div>
                  )}

                  {/* MEDIA VIEW */}
                  {post.mediaType === 'video' || isVideoUrl(post.mediaUrl) ? (
                    <div
                      style={{ height: '380px', width: '100%', margin: 0 }}
                      className="relative w-full h-[380px] bg-black overflow-hidden flex items-center justify-center select-none cursor-pointer group"
                      onClick={() => togglePlayVideo(post.id)}
                      onDoubleClick={() => handlePostDoubleTapLike(post)}
                    >
                      <video
                        id={`post-video-${post.id}`}
                        src={post.mediaUrl}
                        autoPlay
                        loop
                        playsInline
                        muted={mutedVideoMap[post.id] ?? true}
                        style={{ height: '380px', width: '100%', objectFit: 'cover' }}
                        className="w-full h-[380px] object-cover"
                      />

                      {/* Double tap heart animation */}
                      {doubleTapHearts[post.id] && (
                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-30 animate-in zoom-in-50 fade-in duration-200">
                          <div className="p-4 rounded-full bg-black/40 backdrop-blur-xs">
                            <Heart className="w-16 h-16 text-rose-500 fill-rose-500 drop-shadow-[0_0_25px_rgba(244,63,94,0.9)] scale-125 transition-transform" />
                          </div>
                        </div>
                      )}

                      {!isPlayingVideoMap[post.id] && (
                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                          <div className="w-14 h-14 rounded-full bg-black/60 backdrop-blur-xs border border-white/20 flex items-center justify-center text-white shadow-xl transition group-hover:scale-110">
                            <Play className="w-6 h-6 fill-white ml-0.5 text-white" />
                          </div>
                        </div>
                      )}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          window.history.pushState({ modal: 'fullscreen_media', postId: post.id }, '');
                          setFullscreenMediaPost(post);
                        }}
                        className="absolute top-3 right-3 p-2 rounded-full bg-black/60 text-white hover:bg-black/80 transition shadow-md z-10 cursor-pointer"
                        title="Open in Fullscreen Player"
                      >
                        <Maximize2 className="w-3.5 h-3.5 text-white" />
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleMuteVideo(post.id);
                        }}
                        className="absolute bottom-3 right-3 p-2 rounded-full bg-black/60 text-white hover:bg-black/80 transition shadow-md z-10 cursor-pointer"
                        title={mutedVideoMap[post.id] ?? true ? 'Unmute' : 'Mute'}
                      >
                        {mutedVideoMap[post.id] ?? true ? (
                          <VolumeX className="w-4 h-4 text-white" />
                        ) : (
                          <Volume2 className="w-4 h-4 text-[#1877F2]" />
                        )}
                      </button>
                    </div>
                  ) : post.mediaUrl ? (
                    <div
                      style={{ height: '380px', width: '100%', margin: 0 }}
                      className="relative w-full h-[380px] bg-black overflow-hidden flex items-center justify-center cursor-pointer select-none"
                      onDoubleClick={() => handlePostDoubleTapLike(post)}
                      onClick={() => handlePostMediaTap(post)}
                    >
                      <img
                        src={post.mediaUrl}
                        alt="Post media"
                        style={{ height: '380px', width: '100%', objectFit: 'cover' }}
                        className="w-full h-[380px] object-cover"
                      />
                      {/* Small purple badge ✨ HD top right of image */}
                      {post.isEnhanced && (
                        <div className="absolute top-3 right-3 px-2 py-0.5 rounded-md bg-purple-600/90 text-white font-extrabold text-[10px] tracking-wide shadow-lg border border-purple-300/40 flex items-center space-x-1 backdrop-blur-md z-20 pointer-events-none animate-in fade-in">
                          <span>✨ HD</span>
                        </div>
                      )}
                      {/* Double tap heart animation */}
                      {doubleTapHearts[post.id] && (
                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-30 animate-in zoom-in-50 fade-in duration-200">
                          <div className="p-4 rounded-full bg-black/40 backdrop-blur-xs">
                            <Heart className="w-16 h-16 text-rose-500 fill-rose-500 drop-shadow-[0_0_25px_rgba(244,63,94,0.9)] scale-125 transition-transform" />
                          </div>
                        </div>
                      )}
                    </div>
                  ) : null}

                  {/* STATS ROW */}
                  <div
                    className="px-4 py-2 flex items-center justify-between text-xs border-t transition-colors duration-300"
                    style={{
                      borderColor: currentTheme.border,
                      color: currentTheme.cardSubtext,
                    }}
                  >
                    <div className="flex items-center space-x-1.5">
                      <span className="w-5 h-5 rounded-full bg-[#1877F2] text-white flex items-center justify-center text-[10px] shadow-xs">
                        👍
                      </span>
                      <span className="font-semibold" style={{ color: currentTheme.cardText }}>
                        {(post.likedBy?.length ?? post.likesCount ?? 0).toLocaleString()} likes
                      </span>
                    </div>

                    <div className="flex items-center space-x-3 font-medium">
                      <button
                        type="button"
                        onClick={() => setActiveCommentSheetPost(post)}
                        className="hover:underline cursor-pointer transition"
                        style={{ color: currentTheme.cardSubtext }}
                      >
                        {post.commentsCount || 0} comments
                      </button>
                      <span>• {(post.shares_count ?? post.sharesCount ?? 0)} shares</span>
                    </div>
                  </div>

                  {/* 3-BUTTON ACTION BAR */}
                  <div
                    className="px-2 py-1 grid grid-cols-3 gap-1 border-t transition-colors duration-300"
                    style={{ borderColor: currentTheme.border }}
                  >
                    <button
                      type="button"
                      onClick={() => handleToggleLike(post)}
                      className="flex items-center justify-center space-x-2 py-2 rounded-xl text-xs font-bold transition cursor-pointer hover:opacity-80 active:scale-95"
                      style={{
                        color: isLiked ? '#1877F2' : currentTheme.cardSubtext,
                      }}
                    >
                      <ThumbsUp className={`w-4 h-4 ${isLiked ? 'fill-[#1877F2]' : ''}`} />
                      <span>Like</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setActiveCommentSheetPost(post)}
                      className="flex items-center justify-center space-x-2 py-2 rounded-xl text-xs font-bold transition cursor-pointer hover:opacity-80 active:scale-95"
                      style={{ color: currentTheme.cardSubtext }}
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>Comment</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSharePost(post)}
                      className="flex items-center justify-center space-x-2 py-2 rounded-xl text-xs font-bold transition cursor-pointer hover:opacity-80 active:scale-95"
                      style={{ color: currentTheme.cardSubtext }}
                    >
                      <Share2 className="w-4 h-4" />
                      <span>Share</span>
                    </button>
                  </div>
                </div>
              </React.Fragment>
            );
          })
        )}
      </div>

      {activeCommentSheetPost && (
        <CommentBottomSheet
          isOpen={!!activeCommentSheetPost}
          onClose={() => setActiveCommentSheetPost(null)}
          post={activeCommentSheetPost}
          user={user}
          comments={commentsMap[activeCommentSheetPost.id] || []}
          onAddComment={(postId, text, isGhost, expiryHours, attachments) =>
            handleSendComment(postId, text, isGhost, expiryHours, attachments)
          }
          onDeleteComment={(postId, commentId) => handleDeleteComment(postId, commentId)}
          onLikeToggle={(postId) => {
            const target = posts.find((p) => p.id === postId);
            if (target) handleToggleLike(target);
          }}
          onSharePost={(p) => {
            if (navigator.share) {
              navigator.share({ title: 'Ghosted Post', text: p.text });
            } else {
              navigator.clipboard.writeText(p.text);
              showToast('Post copied to clipboard.');
            }
          }}
        />
      )}

      {/* MODAL: LIVE RULES */}
      {isLiveRulesModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-3xl bg-[#140b2b] border border-rose-500/40 p-6 shadow-2xl space-y-4 text-white">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center space-x-2">
                <span className="w-3 h-3 rounded-full bg-rose-500 animate-ping" />
                <h3 className="text-base font-black tracking-tight">Ghosted Live Rules</h3>
              </div>
              <button
                type="button"
                data-back-dismissible="true"
                onClick={() => setIsLiveRulesModalOpen(false)}
                className="p-1 rounded-xl text-purple-300 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-2.5 text-xs text-purple-200/90 leading-relaxed">
              <p className="font-bold text-rose-300">Strict Safety Protocol enforced by Ghosted AI 24/7:</p>
              <ul className="space-y-1.5 list-disc list-inside">
                <li><strong className="text-white">NO nudity / sexual content</strong></li>
                <li><strong className="text-white">NO drugs / smoking / illegal substances</strong></li>
                <li><strong className="text-white">NO violence / weapons / physical fighting</strong></li>
                <li><strong className="text-white">Must be 18+ years of age</strong></li>
              </ul>
              <div className="p-3 rounded-2xl bg-rose-950/40 border border-rose-500/40 text-[11px] text-rose-300 space-y-1">
                <p>• AI inspects video stream continuously. Violations terminate live stream + 7 day ban. 3x strikes = permanent ban.</p>
              </div>
              <div className="p-2.5 rounded-2xl bg-purple-950/40 border border-purple-500/30 text-[11px] text-purple-200 flex items-center space-x-2">
                <Camera className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>Live camera enabled. You can flip camera, toggle video or mic during broadcast.</span>
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-white">Live Stream Title</label>
              <input
                type="text"
                value={liveStreamTitle}
                onChange={(e) => setLiveStreamTitle(e.target.value)}
                placeholder="Give your stream a title..."
                className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/15 text-xs text-white placeholder-purple-300/40 focus:outline-none focus:border-rose-400"
              />
            </div>
            <label className="flex items-start space-x-2.5 pt-1 cursor-pointer">
              <input
                type="checkbox"
                checked={isAgreed18Plus}
                onChange={(e) => setIsAgreed18Plus(e.target.checked)}
                className="mt-0.5 rounded border-purple-400 text-rose-600 focus:ring-rose-500"
              />
              <span className="text-xs text-white font-bold">
                I agree to the Ghosted Live Rules and confirm I am 18+
              </span>
            </label>
            <button
              type="button"
              onClick={handleConfirmStartLive}
              disabled={!isAgreed18Plus}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white font-bold text-xs shadow-lg shadow-rose-600/30 transition cursor-pointer disabled:opacity-50 flex items-center justify-center space-x-2"
            >
              <Radio className="w-4 h-4" />
              <span>Start Live Broadcast</span>
            </button>
          </div>
        </div>
      )}

      {/* MODAL: ADD 24H STATUS */}
      {isAddStatusOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-sm sm:max-w-md rounded-3xl bg-[#140b2b] border border-purple-500/40 p-4 sm:p-5 shadow-2xl space-y-3.5 text-white flex flex-col max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center space-x-2">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse" />
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">Post 24h Story</h3>
              </div>
              <button
                type="button"
                data-back-dismissible="true"
                onClick={() => setIsAddStatusOpen(false)}
                className="p-1 rounded-xl text-purple-300 hover:text-white transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Format Selector: Text, Photos, Videos */}
            <div className="grid grid-cols-3 gap-1.5 p-1 bg-black/50 rounded-2xl border border-white/10 text-xs font-bold">
              <button
                type="button"
                onClick={() => {
                  setStatusType('text');
                  setStatusMediaUrl('');
                }}
                className={`py-2 rounded-xl flex items-center justify-center space-x-1.5 transition cursor-pointer ${
                  statusType === 'text' && !statusMediaUrl
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'text-purple-300 hover:text-white'
                }`}
              >
                <Type className="w-3.5 h-3.5" />
                <span>Text</span>
              </button>
              <label className={`py-2 rounded-xl flex items-center justify-center space-x-1.5 transition cursor-pointer ${
                statusType === 'image' && statusMediaUrl
                  ? 'bg-pink-600 text-white shadow-md'
                  : 'text-purple-300 hover:text-white'
              }`}>
                <Camera className="w-3.5 h-3.5" />
                <span>Photos</span>
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = () => {
                        const dataUrl = reader.result as string;
                        setStatusMediaUrl(dataUrl);
                        setOriginalStatusMedia(dataUrl);
                        setEnhancedStatusMedia(null);
                        setIsEnhancedStatus(false);
                        setStorySliderSplitPos(50);
                        setStatusType('image');
                        showToast('Photo attached to story');
                      };
                      reader.readAsDataURL(file);
                    }
                  }}
                />
              </label>
              <label className={`py-2 rounded-xl flex items-center justify-center space-x-1.5 transition cursor-pointer ${
                statusType === 'video' && statusMediaUrl
                  ? 'bg-cyan-600 text-white shadow-md'
                  : 'text-purple-300 hover:text-white'
              }`}>
                <Video className="w-3.5 h-3.5" />
                <span>Videos</span>
                <input
                  type="file"
                  accept="video/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = () => {
                        setStatusMediaUrl(reader.result as string);
                        setOriginalStatusMedia('');
                        setEnhancedStatusMedia(null);
                        setIsEnhancedStatus(false);
                        setStatusType('video');
                        showToast('Video attached to story');
                      };
                      reader.readAsDataURL(file);
                    }
                  }}
                />
              </label>
            </div>

            <form onSubmit={handleCreateStatus} className="space-y-3">
              {/* Media / Canvas Preview covering full story frame */}
              {statusMediaUrl ? (
                <div className="space-y-2.5">
                  {statusType === 'image' && (
                    <div className="flex items-center justify-between p-2.5 rounded-2xl bg-gradient-to-r from-purple-950/70 via-indigo-950/50 to-black border border-purple-500/40 shadow-md">
                      <div className="flex items-center space-x-2">
                        <Sparkles className="w-4 h-4 text-purple-300 animate-pulse flex-shrink-0" />
                        <div className="flex items-center space-x-1.5">
                          <span className="text-xs font-extrabold text-white">✨ Ghosted Enhance (Free)</span>
                          <span className="text-[9px] px-1.5 py-0.2 rounded-md bg-purple-500/30 text-purple-200 font-mono font-bold border border-purple-400/30">HD</span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={handleToggleEnhanceStatus}
                        disabled={isEnhancingStatus}
                        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                          isEnhancedStatus ? 'bg-gradient-to-r from-purple-500 to-cyan-400' : 'bg-zinc-700'
                        }`}
                        title="Toggle Free AI HD Enhancement"
                      >
                        <span
                          className={`inline-block h-4 w-4 transform rounded-full bg-white shadow-md transition-transform ${
                            isEnhancedStatus ? 'translate-x-6' : 'translate-x-1'
                          }`}
                        />
                      </button>
                    </div>
                  )}

                  <div className="relative rounded-2xl overflow-hidden border border-purple-500/30 bg-black h-64 sm:h-80 flex items-center justify-center select-none">
                    {/* Enhancing shimmer overlay */}
                    {isEnhancingStatus && (
                      <div className="absolute inset-0 bg-black/80 backdrop-blur-xs flex flex-col items-center justify-center space-y-2 z-30 animate-in fade-in">
                        <div className="w-8 h-8 border-3 border-purple-400 border-t-transparent rounded-full animate-spin" />
                        <p className="text-xs font-bold text-purple-200 animate-pulse tracking-wide">
                          ✨ Enhancing... Making it HD
                        </p>
                        <span className="text-[10px] text-zinc-400">Sharpening, auto-contrast & clarity</span>
                      </div>
                    )}

                    {statusType === 'video' ? (
                      <video
                        src={statusMediaUrl}
                        controls
                        playsInline
                        className="w-full h-full object-cover"
                      />
                    ) : isEnhancedStatus && !isEnhancingStatus ? (
                      /* Before/After Split Slider for Story */
                      <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
                        <img
                          src={enhancedStatusMedia || statusMediaUrl}
                          alt="Enhanced preview"
                          className="w-full h-full object-cover"
                        />
                        <div
                          className="absolute inset-0 overflow-hidden pointer-events-none flex items-center justify-center"
                          style={{ clipPath: `inset(0 ${100 - storySliderSplitPos}% 0 0)` }}
                        >
                          <img
                            src={originalStatusMedia || statusMediaUrl}
                            alt="Original preview"
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div
                          className="absolute top-0 bottom-0 w-0.5 bg-white shadow-[0_0_8px_rgba(255,255,255,0.9)] z-20 pointer-events-none"
                          style={{ left: `${storySliderSplitPos}%` }}
                        >
                          <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-black/85 border border-white text-[10px] text-white flex items-center justify-center font-bold shadow-lg">
                            ↔
                          </div>
                        </div>
                        <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-md text-[10px] text-zinc-300 font-bold z-20 pointer-events-none">
                          Original
                        </div>
                        <div className="absolute top-2 right-12 px-2 py-0.5 rounded-md bg-purple-600/90 backdrop-blur-md text-[10px] text-purple-100 font-extrabold z-20 pointer-events-none shadow-md">
                          ✨ HD Enhanced
                        </div>
                        <div className="absolute bottom-2 left-3 right-16 z-20 bg-black/60 backdrop-blur-md px-2.5 py-1.5 rounded-xl border border-white/10 flex items-center space-x-2">
                          <span className="text-[9px] text-zinc-400 font-bold whitespace-nowrap">Compare</span>
                          <input
                            type="range"
                            min="0"
                            max="100"
                            value={storySliderSplitPos}
                            onChange={(e) => setStorySliderSplitPos(Number(e.target.value))}
                            className="w-full h-1.5 accent-purple-400 bg-white/20 rounded-lg cursor-ew-resize"
                          />
                        </div>
                      </div>
                    ) : (
                      <img
                        src={statusMediaUrl}
                        alt="Story Attachment"
                        className="w-full h-full object-cover"
                      />
                    )}

                    <button
                      type="button"
                      onClick={() => {
                        setStatusMediaUrl('');
                        setOriginalStatusMedia('');
                        setEnhancedStatusMedia(null);
                        setIsEnhancedStatus(false);
                        setStatusType('text');
                      }}
                      className="absolute top-2.5 right-2.5 p-1.5 rounded-full bg-black/80 hover:bg-rose-600 text-white transition cursor-pointer shadow-md z-20"
                      title="Remove Attachment"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ) : (
                <div className={`p-6 rounded-2xl bg-gradient-to-br ${statusBgColor} border border-white/20 min-h-[180px] sm:min-h-[220px] flex flex-col items-center justify-center text-center shadow-lg relative`}>
                  <textarea
                    value={statusText}
                    onChange={(e) => setStatusText(e.target.value)}
                    placeholder="Type your 24h story thought..."
                    rows={4}
                    className="w-full bg-transparent border-0 text-center text-sm sm:text-base font-extrabold text-white placeholder-white/50 focus:outline-none resize-none leading-relaxed"
                  />
                  <div className="absolute bottom-2.5 inset-x-0 flex items-center justify-center space-x-2">
                    {[
                      { id: 'from-[#2a0845] to-[#6441a5]', label: 'Violet' },
                      { id: 'from-[#0f2027] via-[#203a43] to-[#2c5364]', label: 'Ocean' },
                      { id: 'from-[#8A2387] via-[#E94057] to-[#F27121]', label: 'Sunset' },
                      { id: 'from-[#000428] to-[#004e92]', label: 'Midnight' },
                      { id: 'from-[#11998e] to-[#38ef7d]', label: 'Emerald' },
                    ].map((bg) => (
                      <button
                        key={bg.id}
                        type="button"
                        onClick={() => setStatusBgColor(bg.id)}
                        className={`w-5 h-5 rounded-full bg-gradient-to-tr ${bg.id} transition active:scale-95 ${
                          statusBgColor === bg.id ? 'ring-2 ring-white scale-110' : 'opacity-70 hover:opacity-100'
                        }`}
                        title={bg.label}
                      />
                    ))}
                  </div>
                </div>
              )}

              {statusMediaUrl && (
                <textarea
                  value={statusText}
                  onChange={(e) => setStatusText(e.target.value)}
                  placeholder="Add an optional story caption..."
                  rows={2}
                  className="w-full p-3 rounded-2xl bg-white/5 border border-white/15 text-xs text-white placeholder-purple-300/40 focus:outline-none focus:border-purple-400 resize-none"
                />
              )}

              <div className="flex items-center space-x-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    cancelActiveUpload();
                    setIsSubmittingPost(false);
                    setIsAddStatusOpen(false);
                  }}
                  className="px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingPost || (!statusText.trim() && !statusMediaUrl)}
                  className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-extrabold text-xs disabled:opacity-50 transition cursor-pointer shadow-lg shadow-purple-900/40 flex items-center justify-center space-x-2"
                >
                  {isSubmittingPost ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Publishing...</span>
                    </>
                  ) : (
                    <span>Post 24h Story</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: VIEW STATUS - 90% SCREEN DIALOG WITH ARROWS, HOLD TO PAUSE, & DELETE */}
      {viewingStatus && (() => {
        const currentIndex = statuses.findIndex((s) => s.id === viewingStatus.id);
        const hasPrev = currentIndex > 0;
        const hasNext = currentIndex < statuses.length - 1;

        const goToPrev = () => {
          if (hasPrev) {
            setViewingStatus(statuses[currentIndex - 1]);
          }
        };

        const goToNext = () => {
          if (hasNext) {
            setViewingStatus(statuses[currentIndex + 1]);
          } else {
            setViewingStatus(null);
          }
        };

        const isOwner = viewingStatus.authorId === user.id || viewingStatus.userId === user.id || (user.uid && viewingStatus.userId === user.uid);

        const handleDeleteStatus = async () => {
          try {
            await deleteDoc(doc(db, 'stories', viewingStatus.id));
            await deleteDoc(doc(db, 'status', viewingStatus.id)).catch(() => {});
          } catch (e) {
            console.warn('Delete story firestore warning:', e);
          }
          setStatuses((prev) => prev.filter((s) => s.id !== viewingStatus.id));
          showToast('Story deleted');
          if (hasNext) {
            setViewingStatus(statuses[currentIndex + 1]);
          } else if (hasPrev) {
            setViewingStatus(statuses[currentIndex - 1]);
          } else {
            setViewingStatus(null);
          }
        };

        const handleHoldStatusStart = () => {
          setIsStatusHeld(true);
          if (statusVideoRef.current && !statusVideoRef.current.paused) {
            statusVideoRef.current.pause();
          }
        };

        const handleHoldStatusEnd = () => {
          setIsStatusHeld(false);
          if (statusVideoRef.current && statusVideoRef.current.paused) {
            statusVideoRef.current.play().catch(() => {});
          }
        };

        const rawContent = (viewingStatus.content || '').trim();
        const isUrl = rawContent.startsWith('http://') || rawContent.startsWith('https://') || rawContent.startsWith('data:');
        const isVideo =
          viewingStatus.type === 'video' ||
          rawContent.startsWith('data:video') ||
          /\.(mp4|webm|mov|ogg)(\?.*)?$/i.test(rawContent);
        const isImage =
          !isVideo && (
            viewingStatus.type === 'image' ||
            rawContent.startsWith('data:image') ||
            /\.(jpg|jpeg|png|webp|gif|svg|avif)(\?.*)?$/i.test(rawContent) ||
            isUrl
          );
        const isText = !isVideo && !isImage;

        // Clean caption and text: never display raw https... links to the user
        const cleanCaption = viewingStatus.caption ? viewingStatus.caption.replace(/https?:\/\/[^\s]+/g, '').trim() : '';
        const cleanText = isText ? rawContent.replace(/https?:\/\/[^\s]+/g, '').trim() : '';

        // Dynamic font size calculation so long text shrinks to fit inside 90% container
        const textLength = (cleanText || '').length;
        const dynamicFontSize =
          textLength < 40
            ? 'text-2xl sm:text-3xl font-black'
            : textLength < 100
            ? 'text-lg sm:text-xl font-extrabold'
            : textLength < 220
            ? 'text-sm sm:text-base font-bold'
            : 'text-xs sm:text-sm font-medium';

        return (
          <div
            onClick={() => setViewingStatus(null)}
            className="fixed inset-0 z-50 flex items-center justify-center p-0 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200 cursor-pointer"
          >
            {/* 90% SCREEN WIDTH & HEIGHT CENTERED DIALOG CARD */}
            <div
              onClick={(e) => e.stopPropagation()}
              className="w-[90vw] h-[90vh] max-w-[90vw] max-h-[90vh] border border-white/20 shadow-2xl relative overflow-hidden flex flex-col justify-between cursor-default"
              style={{
                backgroundColor: 'rgba(0, 0, 0, 0.90)',
                borderRadius: '20px',
              }}
            >
              {/* TOP HEADER OVERLAY */}
              <div className="absolute top-0 inset-x-0 z-30 p-4 bg-gradient-to-b from-black/90 via-black/50 to-transparent space-y-2 pointer-events-auto">
                {/* Story progress indicator */}
                <div className="w-full h-1 bg-white/20 rounded-full overflow-hidden">
                  <div
                    className={`h-full bg-[#00F5FF] rounded-full w-full ${isStatusHeld ? '' : 'animate-in fade-in'}`}
                  />
                </div>
                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-center space-x-2.5">
                    <div className="w-9 h-9 rounded-full bg-purple-600/40 border border-purple-400 flex items-center justify-center text-sm font-bold overflow-hidden shadow-sm">
                      {renderUserAvatar(viewingStatus.authorAvatar, viewingStatus.authorName, '👻')}
                    </div>
                    <div>
                      <h3 className="text-xs sm:text-sm font-extrabold text-white leading-tight">
                        {viewingStatus.authorName}
                      </h3>
                      <div className="flex items-center space-x-1.5">
                        <p className="text-[10px] text-zinc-300 font-mono">
                          {formatTimeAgo(viewingStatus.createdAt)} • 24h Story
                        </p>
                        {viewingStatus.isEnhanced && (
                          <span className="text-[9px] px-1.5 py-0.2 rounded-md bg-purple-600/90 text-white font-extrabold border border-purple-300/40 shadow-xs">
                            ✨ HD
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {isOwner && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (window.confirm('Delete this story?')) {
                            handleDeleteStatus();
                          }
                        }}
                        className="p-1.5 rounded-full text-rose-300 hover:text-white bg-rose-500/20 hover:bg-rose-600 transition cursor-pointer flex items-center space-x-1"
                        title="Delete story"
                      >
                        <Trash2 className="w-4 h-4 text-rose-400 hover:text-white" />
                        <span className="text-[10px] font-bold pr-1 hidden sm:inline">Delete</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => setViewingStatus(null)}
                      className="p-1.5 rounded-full text-white/80 hover:text-white bg-black/60 hover:bg-black/90 border border-white/20 transition cursor-pointer"
                      title="Close Story"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>

              {/* MEDIA / TEXT CONTENT: 90% SIZED & CENTERED WITH HOLD TO PAUSE */}
              <div
                className="w-full h-full flex items-center justify-center overflow-hidden relative p-4 select-none cursor-pointer"
                onMouseDown={handleHoldStatusStart}
                onMouseUp={handleHoldStatusEnd}
                onMouseLeave={handleHoldStatusEnd}
                onTouchStart={handleHoldStatusStart}
                onTouchEnd={handleHoldStatusEnd}
                onTouchCancel={handleHoldStatusEnd}
              >
                {/* Hold to pause indicator */}
                {isStatusHeld && (
                  <div className="absolute top-16 left-1/2 -translate-x-1/2 z-40 px-3.5 py-1.5 rounded-full bg-black/80 border border-amber-400/50 text-amber-300 text-xs font-black tracking-wider flex items-center space-x-1.5 shadow-2xl backdrop-blur-md animate-pulse">
                    <Pause className="w-3.5 h-3.5 fill-amber-400" />
                    <span>PAUSED</span>
                  </div>
                )}

                {isVideo ? (
                  <div className="w-full h-full flex items-center justify-center">
                    <video
                      ref={statusVideoRef}
                      src={rawContent}
                      autoPlay
                      controls={false}
                      playsInline
                      loop
                      className="max-w-full max-h-full w-auto h-auto object-contain rounded-xl shadow-lg pointer-events-none"
                    />
                  </div>
                ) : isImage ? (
                  <div className="w-full h-full flex items-center justify-center">
                    <img
                      src={rawContent}
                      alt="Story"
                      className="max-w-full max-h-full w-auto h-auto object-contain rounded-xl shadow-lg pointer-events-none"
                    />
                  </div>
                ) : (
                  <div
                    className={`w-full h-full p-5 rounded-2xl flex flex-col items-center justify-center text-center bg-gradient-to-br ${
                      viewingStatus.backgroundColor || 'from-[#2a0845] via-[#4a154b] to-[#6441a5]'
                    } overflow-y-auto shadow-inner border border-white/10`}
                  >
                    <span className="text-3xl sm:text-4xl mb-3 block">👻</span>
                    <p
                      className={`${dynamicFontSize} text-white leading-relaxed whitespace-pre-wrap max-w-md tracking-wide drop-shadow-md break-words`}
                    >
                      {cleanText || 'Whispering in the void...'}
                    </p>
                  </div>
                )}
              </div>

              {/* BOTTOM NAVIGATION ARROWS & CAPTION */}
              <div className="z-30 px-4 py-3 bg-gradient-to-t from-black/95 via-black/80 to-transparent flex flex-col space-y-2 pointer-events-auto border-t border-white/10">
                {cleanCaption && !isText && (
                  <div className="text-center">
                    <p className="text-xs sm:text-sm text-white font-medium drop-shadow-sm px-3 line-clamp-2">
                      {cleanCaption}
                    </p>
                  </div>
                )}

                <div className="flex items-center justify-between">
                  {/* Previous Video/Story Arrow Button */}
                  <button
                    type="button"
                    disabled={!hasPrev}
                    onClick={(e) => {
                      e.stopPropagation();
                      goToPrev();
                    }}
                    className={`px-3 py-1.5 rounded-full flex items-center space-x-1.5 transition cursor-pointer border ${
                      hasPrev
                        ? 'bg-white/15 text-white hover:bg-white/25 active:scale-95 border-white/20 shadow-md'
                        : 'opacity-20 text-white/40 border-transparent cursor-not-allowed'
                    }`}
                    title="Previous story"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span className="text-[11px] font-bold hidden sm:inline">Prev</span>
                  </button>

                  {/* Hold hint & Counter indicator */}
                  <div className="flex items-center space-x-2">
                    <span className="text-[11px] font-mono text-white/90 font-bold px-2 py-0.5 rounded-md bg-white/10">
                      {currentIndex + 1} / {statuses.length}
                    </span>
                    <span className="text-[10px] text-zinc-400 font-sans hidden sm:inline">
                      (Hold to pause)
                    </span>
                  </div>

                  {/* Next Video/Story Arrow Button */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      goToNext();
                    }}
                    className="px-3 py-1.5 rounded-full flex items-center space-x-1.5 bg-white/15 text-white hover:bg-white/25 active:scale-95 transition cursor-pointer border border-white/20 shadow-md"
                    title={hasNext ? 'Next story' : 'Close stories'}
                  >
                    <span className="text-[11px] font-bold hidden sm:inline">{hasNext ? 'Next' : 'Done'}</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {activeLiveRoom && (
        <LiveRoomModal
          user={user}
          session={activeLiveRoom.session}
          isHost={activeLiveRoom.isHost}
          isOpen={true}
          onClose={() => setActiveLiveRoom(null)}
          onOpenCoinStore={() => setIsCoinStoreOpen(true)}
          onUserCoinsUpdated={(coins) => {
            const updated = { ...user, coins };
            onUpdateUser(updated);
          }}
          onToast={showToast}
        />
      )}

      {isCoinStoreOpen && (
        <CoinStoreModal
          user={user}
          isNigeria={isNigeria}
          isOpen={true}
          onClose={() => setIsCoinStoreOpen(false)}
          onCoinsUpdated={(newCoins) => {
            const updated = { ...user, coins: newCoins };
            onUpdateUser(updated);
          }}
          onDiamondsUpdated={(newDiamonds) => {
            const updated = { ...user, diamonds: newDiamonds };
            onUpdateUser(updated);
          }}
        />
      )}

      {fullscreenMediaPost && (
        <FullscreenMediaViewer
          post={fullscreenMediaPost}
          user={user}
          isOpen={true}
          onClose={() => setFullscreenMediaPost(null)}
          onLikeToggle={(p) => handleToggleLike(p)}
          onDownload={(p) => handleDownloadPost(p)}
          onOpenComments={(p) => {
            setActiveCommentsPostId(p.id);
            setActiveCommentSheetPost(p);
          }}
          onShare={(p) => handleSharePost(p)}
          onDelete={(p) => handleDeletePost(p.id)}
        />
      )}

      {/* TIKTOK STYLE DOWNLOAD PROGRESS & WATERMARK MODAL */}
      <TikTokDownloadModal
        isOpen={isTikTokModalOpen}
        progressState={tiktokProgress}
        onClose={() => setIsTikTokModalOpen(false)}
        postAuthorName={downloadingAuthorName}
      />

      <SmartAdInterstitial
        context="post"
        isOpen={activeAdModal}
        onClose={() => setActiveAdModal(false)}
      />

      {/* WHAT'S HAUNTING YOU SEARCH POPUP */}
      <SearchHauntingModal
        isOpen={isSearchPageOpen}
        onClose={() => setIsSearchPageOpen(false)}
        posts={posts}
        currentUser={user}
        initialQuery={searchQuery}
        onNavigateToTab={onNavigateToTab}
        onSelectPost={(post) => {
          setIsSearchPageOpen(false);
          setActiveCommentSheetPost(post);
          const el = document.getElementById(`post-${post.id}`);
          if (el) {
            el.scrollIntoView({ behavior: 'smooth' });
          }
        }}
      />

      {/* DELETE POST BOTTOM SHEET */}
      {deleteSheetPost && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
          <div
            className="fixed inset-0"
            onClick={() => {
              setDeleteSheetPost(null);
            }}
          />
          <div
            className="w-full max-w-lg rounded-t-3xl border-t border-x border-purple-500/40 p-6 space-y-4 shadow-2xl relative z-10 animate-in slide-in-from-bottom duration-200"
            style={{
              backgroundColor: isBlack ? '#121212' : '#0B0B14',
              color: '#FFFFFF',
            }}
          >
            {/* Drag handle */}
            <div className="w-12 h-1.5 bg-white/20 rounded-full mx-auto -mt-1 mb-2" />

            <div className="flex items-center space-x-3">
              <div className="w-11 h-11 rounded-2xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400 flex-shrink-0">
                <Trash2 className="w-6 h-6" />
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="text-base font-bold text-white">Delete this post?</h3>
                <p className="text-xs text-zinc-400">
                  This whisper and its replies will be permanently deleted from THE VOID.
                </p>
              </div>
            </div>

            {/* Post Snippet */}
            <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-1">
              <span className="text-[10px] text-purple-300 font-mono font-semibold">
                {deleteSheetPost.authorName || 'Anonymous Whisper'} • {formatTimeAgo(deleteSheetPost.createdAt)}
              </span>
              <p className="text-xs text-zinc-300 line-clamp-2">
                {deleteSheetPost.text || (deleteSheetPost.mediaType === 'video' ? '🎬 Video whisper' : '🖼️ Image whisper')}
              </p>
            </div>

            <div className="space-y-2 pt-2">
              <button
                type="button"
                onClick={handleConfirmDeletePost}
                className="w-full py-3 rounded-2xl bg-rose-600 hover:bg-rose-500 active:scale-98 text-white text-xs font-bold shadow-lg shadow-rose-950/60 flex items-center justify-center space-x-2 transition cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                <span>Confirm Delete</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setDeleteSheetPost(null);
                }}
                className="w-full py-2.5 rounded-2xl bg-white/10 hover:bg-white/15 text-zinc-300 text-xs font-semibold cursor-pointer transition"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
