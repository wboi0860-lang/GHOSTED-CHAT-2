import React, { useState, useRef } from 'react';
import { UserProfile, SavedLetter } from '../types';
import { LetterComposer } from './LetterComposer';
import { SentLettersList } from './SentLettersList';
import { shouldShowAd } from '../utils/adManager';
import { SmartAdInterstitial } from './SmartAdInterstitial';
import { Send, Mail, Sparkles } from 'lucide-react';

import { useTheme } from '../context/ThemeContext';

interface DraftFeedTabProps {
  user: UserProfile;
  isNigeria: boolean;
  letters: SavedLetter[];
  dailySendsRemaining: number;
  onLetterCreated: (letter: SavedLetter) => void;
  onPreviewLetter: (id: string) => void;
  onLetterUpdated: (updated: SavedLetter) => void;
}

export const DraftFeedTab: React.FC<DraftFeedTabProps> = ({
  user,
  isNigeria,
  letters,
  dailySendsRemaining,
  onLetterCreated,
  onPreviewLetter,
  onLetterUpdated,
}) => {
  const { currentTheme, isWhite, isBlack, isGhost } = useTheme();

  // Top 2 pills: "Draft" and "Feed" with swipe between them
  const [activePill, setActivePill] = useState<'draft' | 'feed'>('draft');
  const [activeAd, setActiveAd] = useState<boolean>(false);

  // Touch Swipe Handlers (300ms slide animation)
  const touchStartXRef = useRef<number | null>(null);
  const touchStartYRef = useRef<number | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    const target = e.target as HTMLElement;
    if (target.closest('input, textarea, select, button, a, [contenteditable="true"]')) {
      touchStartXRef.current = null;
      touchStartYRef.current = null;
      return;
    }
    touchStartXRef.current = e.touches[0].clientX;
    touchStartYRef.current = e.touches[0].clientY;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartXRef.current === null || touchStartYRef.current === null) return;
    const endX = e.changedTouches[0].clientX;
    const endY = e.changedTouches[0].clientY;
    const deltaX = endX - touchStartXRef.current;
    const deltaY = endY - touchStartYRef.current;

    // Detect horizontal swipe
    if (Math.abs(deltaX) > 40 && Math.abs(deltaX) > Math.abs(deltaY) * 1.3) {
      if (deltaX < 0 && activePill === 'draft') {
        setActivePill('feed');
      } else if (deltaX > 0 && activePill === 'feed') {
        setActivePill('draft');
      }
    }
    touchStartXRef.current = null;
    touchStartYRef.current = null;
  };

  return (
    <div className="max-w-3xl mx-auto space-y-4">
      {/* Top 2 Pills: "Send Anonymous messages" and "Feed" */}
      <div
        className="flex items-center justify-center space-x-2 p-1.5 rounded-2xl max-w-sm mx-auto border transition-colors duration-300 shadow-md"
        style={{
          backgroundColor: currentTheme.card,
          borderColor: currentTheme.border,
        }}
      >
        <button
          type="button"
          onClick={() => setActivePill('draft')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition duration-200 flex items-center justify-center space-x-1.5 cursor-pointer border ${
            activePill === 'draft' ? 'shadow-sm scale-102' : 'border-transparent opacity-80 hover:opacity-100'
          }`}
          style={{
            backgroundColor: activePill === 'draft'
              ? (isGhost ? '#00F5FF' : isBlack ? '#FFFFFF' : '#000000')
              : 'transparent',
            color: activePill === 'draft'
              ? (isGhost ? '#000000' : isBlack ? '#000000' : '#FFFFFF')
              : currentTheme.cardSubtext,
            borderColor: activePill === 'draft' ? currentTheme.border : 'transparent',
          }}
        >
          <Send className="w-3.5 h-3.5" />
          <span className="truncate">Send Anonymous messages 🤫</span>
        </button>
        <button
          type="button"
          onClick={() => setActivePill('feed')}
          className={`flex-1 py-2 px-4 rounded-xl text-xs font-bold transition duration-200 flex items-center justify-center space-x-1.5 cursor-pointer border ${
            activePill === 'feed' ? 'shadow-sm scale-102' : 'border-transparent opacity-80 hover:opacity-100'
          }`}
          style={{
            backgroundColor: activePill === 'feed'
              ? (isGhost ? '#00F5FF' : isBlack ? '#FFFFFF' : '#000000')
              : 'transparent',
            color: activePill === 'feed'
              ? (isGhost ? '#000000' : isBlack ? '#000000' : '#FFFFFF')
              : currentTheme.cardSubtext,
            borderColor: activePill === 'feed' ? currentTheme.border : 'transparent',
          }}
        >
          <Mail className="w-3.5 h-3.5" />
          <span>Feed 📬</span>
          {letters.length > 0 && (
            <span
              className="text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold border ml-0.5"
              style={{
                backgroundColor: activePill === 'feed'
                  ? (isGhost ? '#000000' : isBlack ? '#000000' : '#FFFFFF')
                  : (isBlack ? '#F3F4F6' : '#141414'),
                color: activePill === 'feed'
                  ? (isGhost ? '#00F5FF' : isBlack ? '#FFFFFF' : '#000000')
                  : currentTheme.cardText,
                borderColor: currentTheme.border,
              }}
            >
              {letters.length}
            </span>
          )}
        </button>
      </div>

      {/* Swipeable 300ms Sliding Carousel Container */}
      <div
        className="w-full overflow-hidden relative touch-pan-y"
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        <div
          className="flex w-full items-start transition-transform duration-300 ease-out will-change-transform"
          style={{
            transform: activePill === 'draft' ? 'translateX(0%)' : 'translateX(-100%)',
          }}
        >
          {/* SLIDE 1: DRAFT (RECONNECT LETTER COMPOSER) */}
          <div className="w-full flex-shrink-0 min-w-full space-y-4">
            <LetterComposer
              user={user}
              dailySendsRemaining={dailySendsRemaining}
              onLetterCreated={(newLetter) => {
                onLetterCreated(newLetter);
                if (shouldShowAd(user, isNigeria)) {
                  setActiveAd(true);
                } else {
                  setActivePill('feed');
                }
              }}
              onPreviewLetter={onPreviewLetter}
            />
          </div>

          {/* SLIDE 2: FEED (SENT RECONNECT LETTERS OUTBOX) */}
          <div className="w-full flex-shrink-0 min-w-full space-y-4">
            <SentLettersList
              letters={letters}
              onPreviewLetter={onPreviewLetter}
              onComposeClick={() => setActivePill('draft')}
              onLetterUpdated={onLetterUpdated}
            />
          </div>
        </div>
      </div>

      {/* Post-creation Smart Ad Interstitial */}
      <SmartAdInterstitial
        context="post"
        isOpen={activeAd}
        onClose={() => {
          setActiveAd(false);
          setActivePill('feed');
        }}
      />
    </div>
  );
};
