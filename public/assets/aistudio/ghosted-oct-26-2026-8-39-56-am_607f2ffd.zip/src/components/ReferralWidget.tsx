import React, { useState, useEffect } from 'react';
import { UserProfile, ReferralInfo } from '../types';
import {
  Gift,
  Users,
  Copy,
  Check,
  Share2,
  Sparkles,
  Crown,
  ArrowRight,
  UserPlus,
  MessageCircle,
  ExternalLink,
  PartyPopper,
  ShieldCheck,
} from 'lucide-react';

interface ReferralWidgetProps {
  user: UserProfile;
  onRewardClaimed?: (updatedUser: UserProfile) => void;
  compact?: boolean;
}

export const ReferralWidget: React.FC<ReferralWidgetProps> = ({
  user,
  onRewardClaimed,
  compact = false,
}) => {
  const [referralInfo, setReferralInfo] = useState<ReferralInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [friendNameInput, setFriendNameInput] = useState('');
  const [isInviting, setIsInviting] = useState(false);
  const [isClaiming, setIsClaiming] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);
  const [celebrationSuccess, setCelebrationSuccess] = useState(false);

  // Fetch referral status from server
  const fetchReferralStatus = async () => {
    try {
      const res = await fetch(`/api/referral/${user.id}?code=${user.ghostedId}`);
      if (res.ok) {
        const data = await res.json();
        setReferralInfo(data);
      }
    } catch (err) {
      console.warn('Failed to fetch referral status:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReferralStatus();
  }, [user.id, user.ghostedId]);

  const referralCode = referralInfo?.referralCode || `GH-${user.ghostedId || 'VIP'}`;
  const shareUrl = typeof window !== 'undefined'
    ? `${window.location.origin}/?ref=${encodeURIComponent(referralCode)}`
    : `https://ghosted.internal/?ref=${referralCode}`;
  const shareText = `Join me on Ghosted — the safe, anonymous reconnection app. Use my invite code: ${referralCode} to connect securely: ${shareUrl}`;

  // Copy Link
  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  // Copy Code
  const handleCopyCode = () => {
    navigator.clipboard.writeText(referralCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2500);
  };

  // WhatsApp share
  const handleShareWhatsApp = () => {
    const waUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`;
    window.open(waUrl, '_blank');
  };

  // SMS share
  const handleShareSMS = () => {
    window.location.href = `sms:?body=${encodeURIComponent(shareText)}`;
  };

  // Invite / Simulate friend joining
  const handleInviteFriend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!friendNameInput.trim()) return;
    setIsInviting(true);
    setFeedbackMsg(null);
    try {
      const res = await fetch('/api/referral/invite-friend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          friendName: friendNameInput.trim(),
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setFriendNameInput('');
        setFeedbackMsg(data.message || `Friend invited successfully!`);
        fetchReferralStatus();
      } else {
        setFeedbackMsg(data.error || 'Failed to record referral.');
      }
    } catch {
      setFeedbackMsg('Network error while inviting friend.');
    } finally {
      setIsInviting(false);
    }
  };

  // Claim 1 free VIP week
  const handleClaimReward = async () => {
    setIsClaiming(true);
    setFeedbackMsg(null);
    try {
      const res = await fetch('/api/referral/claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id }),
      });
      const data = await res.json();
      if (res.ok) {
        setCelebrationSuccess(true);
        setFeedbackMsg(data.message || '1 VIP Week Free claimed!');
        fetchReferralStatus();
        if (onRewardClaimed) {
          const updated: UserProfile = {
            ...user,
            isPremium: true,
            subscriptionPlan: 'premium',
            dailySendsRemaining: 999,
            premiumExpiresAt: data.expiresAt,
          };
          onRewardClaimed(updated);
        }
      } else {
        setFeedbackMsg(data.error || 'Could not claim reward yet.');
      }
    } catch {
      setFeedbackMsg('Network error while claiming reward.');
    } finally {
      setIsClaiming(false);
    }
  };

  const count = referralInfo?.referralCount ?? 1;
  const currentTarget = 3;
  const progressRatio = Math.min(100, Math.round(((count % currentTarget || (count >= currentTarget ? currentTarget : 0)) / currentTarget) * 100));
  const friendsNeeded = Math.max(0, currentTarget - (count % currentTarget || (count >= currentTarget && !referralInfo?.isEligibleForReward ? currentTarget : 0)));
  const isEligible = referralInfo?.isEligibleForReward || count >= 3;

  if (compact) {
    return (
      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-950/70 via-indigo-950/60 to-amber-950/50 border border-amber-400/30 text-white space-y-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-7 h-7 rounded-lg bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-300">
              <Gift className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-white">Invite 3 friends, get 1 VIP week free</div>
              <div className="text-[10px] text-purple-200">
                {count}/3 friends joined • {friendsNeeded > 0 ? `${friendsNeeded} more needed` : 'Ready to claim!'}
              </div>
            </div>
          </div>
          {isEligible ? (
            <button
              type="button"
              onClick={handleClaimReward}
              disabled={isClaiming}
              className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-amber-400 to-orange-500 text-gray-950 text-[10px] font-bold shadow animate-pulse hover:brightness-110"
            >
              {isClaiming ? 'Claiming...' : 'Claim VIP Week'}
            </button>
          ) : (
            <button
              type="button"
              onClick={handleCopyLink}
              className="px-2 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white text-[10px] font-semibold flex items-center space-x-1"
            >
              {copiedLink ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-amber-300" />}
              <span>{copiedLink ? 'Copied' : 'Share'}</span>
            </button>
          )}
        </div>
        {/* Progress bar */}
        <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-amber-400 to-emerald-400 transition-all duration-500"
            style={{ width: `${progressRatio}%` }}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#21174d] via-[#1d1645] to-[#141030] border-2 border-amber-400/50 p-6 sm:p-8 shadow-2xl text-white space-y-6">
      {/* Decorative ambient glows */}
      <div className="absolute top-0 right-0 -mt-10 -mr-10 w-48 h-48 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 -mb-10 -ml-10 w-48 h-48 bg-purple-500/20 rounded-full blur-3xl pointer-events-none" />

      {/* Header Pill & Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 relative z-10">
        <div className="space-y-1">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-gradient-to-r from-amber-400/20 to-purple-500/20 border border-amber-400/40 text-[11px] font-bold uppercase tracking-wider text-amber-300">
            <Gift className="w-3.5 h-3.5 text-amber-400 animate-bounce" />
            <span>VIP REFERRAL PROGRAM</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <span>Invite 3 friends, get 1 VIP week free</span>
            <Sparkles className="w-5 h-5 text-amber-300" />
          </h3>
          <p className="text-xs sm:text-sm text-purple-200/80 max-w-xl leading-relaxed">
            Share your unique Ghosted code with friends. For every 3 friends that join, unlock <strong>7 days of unlimited VIP letters, vanity handles, and HD calling</strong> completely free.
          </p>
        </div>

        {/* Big Badge for Claim or Status */}
        {isEligible ? (
          <button
            type="button"
            onClick={handleClaimReward}
            disabled={isClaiming}
            className="px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-400 via-orange-500 to-amber-500 hover:from-amber-500 hover:to-orange-600 text-gray-950 font-black text-xs shadow-xl shadow-amber-500/30 flex items-center space-x-2 animate-bounce cursor-pointer active:scale-95"
          >
            <Crown className="w-4 h-4" />
            <span>{isClaiming ? 'Unlocking 1 Week...' : 'CLAIM 1 FREE VIP WEEK!'}</span>
          </button>
        ) : (
          <div className="p-3 bg-black/40 rounded-2xl border border-white/10 text-center min-w-[130px]">
            <div className="text-[10px] uppercase font-bold text-purple-300">Progress</div>
            <div className="text-xl font-black text-amber-300 font-mono">
              {count % 3 || (count >= 3 ? 3 : 0)} / 3
            </div>
            <div className="text-[10px] text-purple-200">
              {friendsNeeded} more to go
            </div>
          </div>
        )}
      </div>

      {/* 3 Step Milestone Visual Tracker */}
      <div className="space-y-2 relative z-10">
        <div className="flex justify-between items-center text-xs font-semibold text-purple-200">
          <span>Referral Goal (3 Friends)</span>
          <span className="text-amber-300 font-mono font-bold">
            {count} Friends Joined • {referralInfo?.rewardedWeeks ? `${referralInfo.rewardedWeeks} Week(s) Earned` : '0 Weeks Claimed'}
          </span>
        </div>

        {/* 3 Step Node Pills */}
        <div className="grid grid-cols-3 gap-2 sm:gap-4 pt-1">
          {[1, 2, 3].map((step) => {
            const currentStepProgress = count % 3 || (count >= 3 ? 3 : 0);
            const isCompleted = currentStepProgress >= step || count >= 3;
            const isCurrent = currentStepProgress === step - 1;
            return (
              <div
                key={step}
                className={`p-3 rounded-2xl border transition-all text-center space-y-1.5 ${
                  isCompleted
                    ? 'bg-gradient-to-b from-amber-400/20 to-emerald-500/10 border-amber-400/60 text-white shadow-md'
                    : isCurrent
                    ? 'bg-purple-900/40 border-purple-400/40 text-purple-200'
                    : 'bg-black/30 border-white/10 text-white/50'
                }`}
              >
                <div className="flex items-center justify-center">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                      isCompleted
                        ? 'bg-amber-400 text-gray-950 font-black'
                        : isCurrent
                        ? 'bg-purple-500/30 border border-purple-300 text-purple-200'
                        : 'bg-white/10 text-white/40'
                    }`}
                  >
                    {isCompleted ? <Check className="w-4 h-4 stroke-[3]" /> : step}
                  </div>
                </div>
                <div className="text-xs font-bold">
                  {step === 3 ? '1 Week VIP Free' : `Friend #${step}`}
                </div>
                <div className="text-[10px] text-purple-300">
                  {isCompleted ? 'Joined ✓' : isCurrent ? 'Next invite' : 'Pending'}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Share & Code Box */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 relative z-10">
        {/* Box A: Referral Code */}
        <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-2">
          <div className="text-[11px] font-bold uppercase tracking-wider text-purple-300">
            Your Unique Invite Code
          </div>
          <div className="flex items-center justify-between bg-black/60 p-2.5 rounded-xl border border-white/10">
            <span className="font-mono text-base font-bold text-amber-300 tracking-wider">
              {referralCode}
            </span>
            <button
              type="button"
              onClick={handleCopyCode}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center space-x-1 ${
                copiedCode ? 'bg-emerald-500 text-white' : 'bg-amber-400 hover:bg-amber-500 text-gray-950'
              }`}
            >
              {copiedCode ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedCode ? 'Copied!' : 'Copy Code'}</span>
            </button>
          </div>
          <p className="text-[10px] text-purple-300/70">
            Friends enter this code during onboarding to credit your 1-week free VIP reward.
          </p>
        </div>

        {/* Box B: One-Click Share Buttons */}
        <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-2">
          <div className="text-[11px] font-bold uppercase tracking-wider text-purple-300">
            Quick Share Link
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={handleCopyLink}
              className="flex-1 py-2 px-3 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10 text-xs font-bold text-white transition flex items-center justify-center space-x-1.5"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-amber-300" />}
              <span>{copiedLink ? 'Link Copied!' : 'Copy Link'}</span>
            </button>
            <button
              type="button"
              onClick={handleShareWhatsApp}
              className="py-2 px-3.5 rounded-xl bg-emerald-600/80 hover:bg-emerald-600 text-white text-xs font-bold transition flex items-center justify-center space-x-1.5"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>WhatsApp</span>
            </button>
            <button
              type="button"
              onClick={handleShareSMS}
              className="py-2 px-3.5 rounded-xl bg-indigo-600/80 hover:bg-indigo-600 text-white text-xs font-bold transition flex items-center justify-center space-x-1.5"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>SMS</span>
            </button>
          </div>
          <p className="text-[10px] text-purple-300/70">
            Auto-fills message: &quot;Join me on Ghosted...&quot;
          </p>
        </div>
      </div>

      {/* Direct Friend Invite Simulator / Field */}
      <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3 relative z-10">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <UserPlus className="w-4 h-4 text-amber-300" />
            <span className="text-xs font-bold text-white">Direct Invite / Record Friend</span>
          </div>
          <span className="text-[10px] text-purple-300">Simulate or record invited friend</span>
        </div>
        <form onSubmit={handleInviteFriend} className="flex gap-2">
          <input
            type="text"
            value={friendNameInput}
            onChange={(e) => setFriendNameInput(e.target.value)}
            placeholder="Friend's Name or Handle"
            className="flex-1 px-4 py-2 bg-black/40 border border-white/15 rounded-xl text-white text-xs placeholder-purple-300/40 focus:outline-none focus:ring-2 focus:ring-amber-400"
          />
          <button
            type="submit"
            disabled={isInviting || !friendNameInput.trim()}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700 disabled:opacity-50 text-white text-xs font-bold transition flex items-center space-x-1.5 shadow"
          >
            {isInviting ? (
              <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <UserPlus className="w-3.5 h-3.5" />
            )}
            <span>Invite</span>
          </button>
        </form>
        {feedbackMsg && (
          <div className="text-xs p-2.5 rounded-xl bg-amber-400/10 border border-amber-400/30 text-amber-200 flex items-center space-x-2 animate-in fade-in">
            <Sparkles className="w-3.5 h-3.5 text-amber-300 flex-shrink-0" />
            <span>{feedbackMsg}</span>
          </div>
        )}
      </div>

      {/* List of Referred Friends */}
      {referralInfo?.referredFriends && referralInfo.referredFriends.length > 0 && (
        <div className="p-4 rounded-2xl bg-black/30 border border-white/5 space-y-2 relative z-10">
          <div className="text-[11px] font-bold text-purple-300 uppercase tracking-wider flex items-center justify-between">
            <span>Referred Friends ({referralInfo.referredFriends.length})</span>
            <span className="text-emerald-400 font-mono text-[10px]">Verified Joined</span>
          </div>
          <div className="divide-y divide-white/5 max-h-32 overflow-y-auto">
            {referralInfo.referredFriends.map((f, i) => (
              <div key={f.id || i} className="py-1.5 flex items-center justify-between text-xs text-purple-200">
                <div className="flex items-center space-x-2">
                  <div className="w-5 h-5 rounded-full bg-amber-400/20 text-amber-300 text-[10px] font-bold flex items-center justify-center">
                    {i + 1}
                  </div>
                  <span className="font-semibold text-white">{f.name}</span>
                </div>
                <span className="text-[10px] text-purple-400">
                  {new Date(f.joinedAt).toLocaleDateString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Success Modal / Toast */}
      {celebrationSuccess && (
        <div className="p-4 rounded-2xl bg-emerald-950/70 border border-emerald-400 text-white flex items-center justify-between animate-in zoom-in-95 duration-200">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
              <PartyPopper className="w-6 h-6 animate-bounce" />
            </div>
            <div>
              <div className="text-sm font-bold text-white">1 VIP Week Free Activated! 🎉</div>
              <div className="text-xs text-emerald-200/90">
                Enjoy 7 days of unrestricted letters, custom VIP handles, and WebRTC calling.
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setCelebrationSuccess(false)}
            className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold"
          >
            Awesome!
          </button>
        </div>
      )}
    </div>
  );
};
