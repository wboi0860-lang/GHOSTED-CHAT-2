import React, { useState, useRef } from 'react';
import { UserSticker } from '../types';
import { X, Image as ImageIcon, Sparkles, Wand2, Camera, Check } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface StickerCreatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStickerCreated: (sticker: UserSticker) => void;
}

const LIVE_ANIMATION_STYLES = [
  { id: 'pulse', label: 'Neon Pulse', effect: 'animate-pulse' },
  { id: 'bounce', label: 'Spectral Float', effect: 'animate-bounce' },
  { id: 'spin-slow', label: 'Mystic Spin', effect: 'animate-spin' },
  { id: 'glow', label: 'Ghost Glow', effect: 'ghost-glow-pulse' },
];

const PRESET_EMOJIS = ['👻', '🕯️', '🌌', '💔', '🔮', '🪽', '⚡', '🕊️', '🎭', '🛡️', '🌙', '✨'];

export const StickerCreatorModal: React.FC<StickerCreatorModalProps> = ({
  isOpen,
  onClose,
  onStickerCreated,
}) => {
  const { isDark, isGhost } = useTheme();
  const [activeTab, setActiveTab] = useState<'image' | 'live'>('image');
  const [stickerTitle, setStickerTitle] = useState('');
  const [imageUrl, setImageUrl] = useState<string | null>(null);

  // Live Sticker state
  const [selectedEmoji, setSelectedEmoji] = useState('👻');
  const [liveCaption, setLiveCaption] = useState('Whispering...');
  const [animationStyle, setAnimationStyle] = useState('glow');

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setImageUrl(reader.result as string);
        if (!stickerTitle) {
          setStickerTitle(file.name.replace(/\.[^/.]+$/, '').slice(0, 20));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCreateSticker = () => {
    const now = Date.now();
    let finalImageUrl = imageUrl;
    let isLive = false;

    if (activeTab === 'live') {
      isLive = true;
      // Generate SVG data URL for the live sticker
      const svg = `
        <svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200">
          <defs>
            <radialGradient id="grad" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stop-color="#7C3AED" stop-opacity="0.8"/>
              <stop offset="100%" stop-color="#00F5FF" stop-opacity="0"/>
            </radialGradient>
          </defs>
          <circle cx="100" cy="100" r="90" fill="url(#grad)" />
          <text x="50%" y="45%" text-anchor="middle" font-size="70" dominant-baseline="central">${selectedEmoji}</text>
          <text x="50%" y="80%" text-anchor="middle" font-size="18" font-family="sans-serif" font-weight="bold" fill="#FFFFFF">${liveCaption}</text>
        </svg>
      `;
      finalImageUrl = `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
    }

    if (!finalImageUrl) return;

    const newSticker: UserSticker = {
      id: `stk-${now}-${Math.random().toString(36).slice(2, 6)}`,
      title: stickerTitle.trim() || (activeTab === 'live' ? `${selectedEmoji} ${liveCaption}` : 'Custom Sticker'),
      imageUrl: finalImageUrl,
      isLive,
      type: activeTab === 'live' ? 'live' : 'custom_image',
      createdAt: now,
    };

    onStickerCreated(newSticker);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[10020] flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className={`w-full max-w-md rounded-3xl p-5 shadow-2xl border space-y-4 relative overflow-hidden transition-colors ${
          isGhost
            ? 'bg-[#15151F] border-[#2A2A3F] text-[#E0E0FF] shadow-[0_0_35px_rgba(124,58,237,0.3)]'
            : isDark
            ? 'bg-[#242526] border-[#3E4042] text-[#E4E6EB]'
            : 'bg-white border-[#E4E6EB] text-[#050505]'
        }`}
      >
        {/* Modal Header */}
        <div
          className={`flex items-center justify-between pb-3 border-b ${
            isGhost ? 'border-[#2A2A3F]' : isDark ? 'border-[#3E4042]' : 'border-gray-200'
          }`}
        >
          <div className="flex items-center space-x-2">
            <div className="w-9 h-9 rounded-xl bg-[#0866FF]/15 text-[#0866FF] flex items-center justify-center font-bold">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold tracking-tight">Create Ghost Sticker</h3>
              <p className="text-xs opacity-70">Design an image or live spectral sticker</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className={`p-1.5 rounded-full transition cursor-pointer ${
              isDark ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-gray-100 hover:bg-gray-200 text-black'
            }`}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* 2 Tabs: Image Sticker vs Live Sticker */}
        <div className={`p-1 rounded-xl flex items-center space-x-1 border ${
          isGhost ? 'bg-[#0A0A0F] border-[#2A2A3F]' : isDark ? 'bg-[#18191A] border-[#3E4042]' : 'bg-[#F0F2F5] border-gray-200'
        }`}>
          <button
            type="button"
            onClick={() => setActiveTab('image')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition flex items-center justify-center space-x-1.5 cursor-pointer ${
              activeTab === 'image'
                ? 'bg-[#0866FF] text-white shadow-xs'
                : 'opacity-70 hover:opacity-100'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>Image Sticker</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('live')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition flex items-center justify-center space-x-1.5 cursor-pointer ${
              activeTab === 'live'
                ? 'bg-[#7C3AED] text-white shadow-xs'
                : 'opacity-70 hover:opacity-100'
            }`}
          >
            <Wand2 className="w-3.5 h-3.5" />
            <span>Live Animated</span>
          </button>
        </div>

        {/* TAB 1: IMAGE STICKER */}
        {activeTab === 'image' && (
          <div className="space-y-3.5">
            <div
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition flex flex-col items-center justify-center space-y-2 group ${
                imageUrl
                  ? 'border-emerald-500/60 bg-emerald-500/5'
                  : isDark
                  ? 'border-zinc-700 hover:border-[#0866FF] bg-zinc-900/40'
                  : 'border-gray-300 hover:border-[#0866FF] bg-gray-50'
              }`}
            >
              {imageUrl ? (
                <div className="relative w-28 h-28 rounded-2xl overflow-hidden shadow-lg border border-white/20 group-hover:scale-105 transition">
                  <img src={imageUrl} alt="Sticker preview" className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition text-white text-[11px] font-bold">
                    Change Photo
                  </div>
                </div>
              ) : (
                <>
                  <div className="w-12 h-12 rounded-full bg-[#0866FF]/10 text-[#0866FF] flex items-center justify-center">
                    <Camera className="w-6 h-6" />
                  </div>
                  <span className="text-xs font-bold">Upload photo or icon</span>
                  <span className="text-[10px] opacity-60">PNG, JPG or WebP (transparent works best)</span>
                </>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-bold mb-1">Sticker Name</label>
              <input
                type="text"
                value={stickerTitle}
                onChange={(e) => setStickerTitle(e.target.value)}
                placeholder="e.g. Spectral Wink"
                className={`w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-medium border focus:outline-none ${
                  isGhost
                    ? 'bg-[#0A0A0F] border-[#2A2A3F] text-white focus:border-[#00F5FF]'
                    : isDark
                    ? 'bg-[#18191A] border-[#3E4042] text-white focus:border-[#0866FF]'
                    : 'bg-[#F0F2F5] border-gray-300 text-black focus:border-[#0866FF]'
                }`}
              />
            </div>
          </div>
        )}

        {/* TAB 2: LIVE ANIMATED STICKER */}
        {activeTab === 'live' && (
          <div className="space-y-3.5">
            {/* Live Preview Card */}
            <div className="p-4 rounded-2xl bg-gradient-to-b from-[#181028] to-[#0A0A0F] border border-purple-500/40 flex flex-col items-center justify-center space-y-2 relative overflow-hidden shadow-inner">
              <div
                className={`w-24 h-24 rounded-full flex flex-col items-center justify-center text-4xl shadow-2xl relative ${
                  animationStyle === 'pulse'
                    ? 'animate-pulse'
                    : animationStyle === 'bounce'
                    ? 'animate-bounce'
                    : animationStyle === 'spin-slow'
                    ? 'animate-spin'
                    : 'ghost-glow-pulse'
                }`}
                style={{
                  background: 'radial-gradient(circle, rgba(124,58,237,0.6) 0%, rgba(0,245,255,0.2) 100%)',
                }}
              >
                <span>{selectedEmoji}</span>
                <span className="text-[10px] font-black text-white uppercase tracking-wider drop-shadow-md">
                  LIVE
                </span>
              </div>
              <span className="text-xs font-bold text-white tracking-wide">
                "{liveCaption || 'Spectral Voice'}"
              </span>
            </div>

            {/* Emoji Selection Grid */}
            <div>
              <label className="block text-xs font-bold mb-1">Select Spirit Icon</label>
              <div className="grid grid-cols-6 gap-2">
                {PRESET_EMOJIS.map((emoji) => (
                  <button
                    key={emoji}
                    type="button"
                    onClick={() => setSelectedEmoji(emoji)}
                    className={`p-2 rounded-xl text-lg flex items-center justify-center transition border cursor-pointer ${
                      selectedEmoji === emoji
                        ? 'border-[#00F5FF] bg-[#7C3AED]/30 scale-105 shadow-[0_0_10px_rgba(0,245,255,0.4)]'
                        : isDark
                        ? 'border-zinc-800 bg-zinc-900/60 hover:bg-zinc-800'
                        : 'border-gray-200 bg-white hover:bg-gray-100'
                    }`}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Glowing Caption */}
            <div>
              <label className="block text-xs font-bold mb-1">Glowing Live Caption</label>
              <input
                type="text"
                value={liveCaption}
                onChange={(e) => setLiveCaption(e.target.value)}
                maxLength={24}
                placeholder="e.g. In The Void"
                className={`w-full px-3 py-2 rounded-xl text-xs sm:text-sm font-medium border focus:outline-none ${
                  isGhost
                    ? 'bg-[#0A0A0F] border-[#2A2A3F] text-white focus:border-[#00F5FF]'
                    : isDark
                    ? 'bg-[#18191A] border-[#3E4042] text-white focus:border-[#7C3AED]'
                    : 'bg-[#F0F2F5] border-gray-300 text-black focus:border-[#7C3AED]'
                }`}
              />
            </div>

            {/* Animation Effect Selector */}
            <div>
              <label className="block text-xs font-bold mb-1">Live Motion Effect</label>
              <div className="grid grid-cols-2 gap-2">
                {LIVE_ANIMATION_STYLES.map((style) => (
                  <button
                    key={style.id}
                    type="button"
                    onClick={() => setAnimationStyle(style.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition border text-left flex items-center justify-between cursor-pointer ${
                      animationStyle === style.id
                        ? 'border-[#00F5FF] bg-[#7C3AED]/25 text-[#00F5FF]'
                        : isDark
                        ? 'border-zinc-800 bg-zinc-900/60 text-zinc-400 hover:text-white'
                        : 'border-gray-200 bg-white text-gray-700 hover:text-black'
                    }`}
                  >
                    <span>{style.label}</span>
                    {animationStyle === style.id && <Check className="w-3.5 h-3.5" />}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* CREATE BUTTON */}
        <div className="pt-2">
          <button
            type="button"
            onClick={handleCreateSticker}
            disabled={activeTab === 'image' && !imageUrl}
            className={`w-full py-2.5 px-4 rounded-xl font-bold text-xs sm:text-sm transition shadow-md cursor-pointer disabled:opacity-40 active:scale-95 ${
              activeTab === 'live' || isGhost
                ? 'bg-gradient-to-r from-[#7C3AED] to-[#00F5FF] text-white shadow-[0_0_15px_rgba(124,58,237,0.3)]'
                : 'bg-[#0866FF] hover:bg-[#0055E0] text-white'
            }`}
          >
            <span>Save & Use Sticker</span>
          </button>
        </div>
      </div>
    </div>
  );
};
