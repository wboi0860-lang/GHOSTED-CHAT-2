import React, { useState, useEffect } from 'react';
import { ShieldAlert, Heart, Flame, Eye, Lock, Unlock, MapPin, UserCheck, CheckCircle2, AlertOctagon, X, Volume2, Video, Bell, EyeOff } from 'lucide-react';

interface RecipientViewProps {
  letterId: string;
  onClose: () => void;
  onReportClick: (targetGhostedId?: string, letterId?: string) => void;
}

export const RecipientViewModal: React.FC<RecipientViewProps> = ({
  letterId,
  onClose,
  onReportClick,
}) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [letterData, setLetterData] = useState<any>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [declinedSuccess, setDeclinedSuccess] = useState(false);
  const [activeMediaPreview, setActiveMediaPreview] = useState<string | null>(null);
  const [requestedReveal, setRequestedReveal] = useState(false);
  const [isRequestingReveal, setIsRequestingReveal] = useState(false);

  // Load letter teaser or unlocked content
  useEffect(() => {
    let isMounted = true;
    async function fetchLetter() {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(`/api/letters/${letterId}`);
        if (!res.ok) {
          const data = await res.json();
          throw new Error(data.error || 'Unable to retrieve message.');
        }
        const data = await res.json();
        if (isMounted) {
          setLetterData(data);
          if (data.sender?.recipientRequestedReveal) {
            setRequestedReveal(true);
          }
        }
      } catch (err: any) {
        if (isMounted) setError(err.message);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    fetchLetter();
    return () => {
      isMounted = false;
    };
  }, [letterId]);

  // Handle Response: 'view' or 'decline'
  const handleRespond = async (action: 'view' | 'decline') => {
    setIsProcessing(true);
    try {
      const res = await fetch(`/api/letters/${letterId}/respond`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });
      const json = await res.json();
      if (!res.ok) {
        throw new Error(json.error || 'Failed to submit response.');
      }
      if (action === 'decline') {
        setDeclinedSuccess(true);
        setLetterData(null);
      } else {
        // Unlock full content
        setLetterData(json.letter);
      }
    } catch (err: any) {
      alert(err.message || 'Error processing response');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRequestReveal = async () => {
    setIsRequestingReveal(true);
    try {
      const res = await fetch(`/api/letters/${letterId}/request-reveal`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!res.ok) throw new Error('Failed to send reveal request.');
      const data = await res.json();
      setRequestedReveal(true);
      if (data.sender) {
        setLetterData((prev: any) => ({
          ...prev,
          sender: data.sender,
        }));
      }
    } catch (err: any) {
      alert(err.message || 'Error requesting reveal');
    } finally {
      setIsRequestingReveal(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-xl my-8 bg-gradient-to-b from-[#1b173e] via-[#24204c] to-[#161332] border border-white/20 rounded-3xl p-6 sm:p-8 shadow-2xl text-white overflow-hidden">
        {/* Glow ambient background rings */}
        <div className="absolute -top-20 -left-20 w-52 h-52 bg-purple-600/30 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -right-20 w-52 h-52 bg-rose-600/20 rounded-full blur-3xl pointer-events-none" />

        {/* Top header navigation */}
        <div className="flex items-center justify-between pb-4 mb-6 border-b border-white/10">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-semibold uppercase tracking-wider text-purple-300">
              Recipient Consent Portal
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={() => onReportClick(letterData?.sender?.ghostedId, letterId)}
              className="text-[11px] text-rose-300 hover:text-rose-200 bg-rose-950/40 hover:bg-rose-900/50 px-2.5 py-1 rounded-lg border border-rose-500/30 flex items-center space-x-1 transition"
            >
              <AlertOctagon className="w-3 h-3 text-rose-400" />
              <span>Block / Report</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-white/10 text-white/70 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Loading state */}
        {loading && (
          <div className="py-16 text-center space-y-3">
            <div className="w-8 h-8 border-2 border-purple-400 border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-xs text-purple-300">Retrieving encrypted reconnect message...</p>
          </div>
        )}

        {/* Error or Expired state */}
        {error && (
          <div className="py-10 text-center space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-rose-950/70 border border-rose-500/40 flex items-center justify-center mx-auto text-rose-400">
              <Flame className="w-7 h-7" />
            </div>
            <h3 className="font-bold text-lg text-white">Message Unavailable</h3>
            <p className="text-xs text-purple-200/80 max-w-sm mx-auto leading-relaxed">
              {error}
            </p>
            <button
              type="button"
              onClick={onClose}
              className="py-2.5 px-6 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white transition"
            >
              Close
            </button>
          </div>
        )}

        {/* Successfully Declined & Burned Screen */}
        {declinedSuccess && (
          <div className="py-12 text-center space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-3xl bg-rose-500/20 border border-rose-400/40 flex items-center justify-center mx-auto text-rose-400">
              <Flame className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-white">Message Permanently Erased</h3>
            <p className="text-xs text-purple-200/80 max-w-md mx-auto leading-relaxed">
              You chose to decline. In alignment with Ghosted's zero-harassment pledge, the letter text and all media files have been completely incinerated from our servers.
            </p>
            <div className="p-3 bg-white/5 rounded-2xl border border-white/10 text-[11px] text-purple-300 max-w-sm mx-auto">
              The sender will only receive an expiration notice without your personal information.
            </div>
            <button
              type="button"
              onClick={onClose}
              className="py-2.5 px-6 rounded-xl bg-purple-600 hover:bg-purple-700 text-xs font-semibold text-white transition"
            >
              Done
            </button>
          </div>
        )}

        {/* STEP 1: CONSENT GATE (PENDING STATUS) */}
        {!loading && !error && !declinedSuccess && letterData && letterData.status === 'pending' && (
          <div className="space-y-6 text-center animate-in fade-in duration-200">
            <div className="w-20 h-20 mx-auto rounded-3xl bg-gradient-to-tr from-purple-500/30 to-indigo-500/40 border border-purple-400/40 flex items-center justify-center shadow-xl shadow-purple-950/50">
              <Heart className="w-10 h-10 text-purple-300 animate-pulse" />
            </div>
            <div className="space-y-2">
              <span className="text-xs uppercase tracking-wider text-purple-400 font-semibold">
                Incoming Reconnection Request
              </span>
              <h2 className="text-2xl font-bold text-white">
                Someone who misses you left a message.
              </h2>
              <p className="text-xs sm:text-sm text-purple-200/80 max-w-md mx-auto">
                Do you want to view it? You have complete autonomy. You can read it safely, or decline and burn it forever.
              </p>
            </div>

            {/* Context Badge Cards */}
            <div className="p-4 rounded-2xl bg-black/30 border border-white/10 text-left space-y-2.5 text-xs text-purple-200">
              <div className="flex items-center justify-between">
                <span className="text-purple-300">Mood / Tone:</span>
                <span className="font-semibold bg-purple-600/40 px-2.5 py-0.5 rounded-full border border-purple-400/30 text-white">
                  {letterData.mood}
                </span>
              </div>
              {letterData.senderTeaser?.city && (
                <div className="flex items-center justify-between">
                  <span className="text-purple-300 flex items-center space-x-1">
                    <MapPin className="w-3.5 h-3.5 text-purple-400" />
                    <span>Origin:</span>
                  </span>
                  <span className="text-white font-medium">
                    {letterData.senderTeaser.city}, {letterData.senderTeaser.country}
                  </span>
                </div>
              )}
              <div className="flex items-center justify-between">
                <span className="text-purple-300">Relationship:</span>
                <span className="text-white font-medium">{letterData.relationship}</span>
              </div>
              {letterData.hasMemories && (
                <div className="flex items-center justify-between">
                  <span className="text-purple-300">Attached Memories:</span>
                  <span className="text-purple-200 font-medium">
                    {letterData.memoryCount} photo/video memory included
                  </span>
                </div>
              )}
            </div>

            {/* Two Action Buttons: [View] & [Decline] */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                disabled={isProcessing}
                onClick={() => handleRespond('decline')}
                className="py-3.5 px-4 rounded-2xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 font-bold text-xs sm:text-sm border border-rose-500/40 shadow-lg shadow-rose-950/40 transition flex items-center justify-center space-x-2 active:scale-[0.98] disabled:opacity-50"
              >
                <Flame className="w-4 h-4 text-rose-400" />
                <span>Decline & Delete</span>
              </button>
              <button
                type="button"
                disabled={isProcessing}
                onClick={() => handleRespond('view')}
                className="py-3.5 px-4 rounded-2xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700 text-white font-bold text-xs sm:text-sm border border-purple-400/30 shadow-xl shadow-purple-950/60 transition flex items-center justify-center space-x-2 active:scale-[0.98] disabled:opacity-50"
              >
                <Eye className="w-4 h-4" />
                <span>View Message</span>
              </button>
            </div>

            <p className="text-[11px] text-purple-300/60">
              Sender remains anonymous until you view. If you decline, neither side can read it again.
            </p>
          </div>
        )}

        {/* STEP 2: VIEW MESSAGE (UNLOCKED) */}
        {!loading && !error && !declinedSuccess && letterData && letterData.status === 'viewed' && (
          <div className="space-y-6 animate-in fade-in duration-300">
            {/* Sender identity banner */}
            <div className="p-4 sm:p-5 rounded-2xl bg-white/5 border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-purple-400 uppercase font-semibold tracking-wider">
                    Sender Identity
                  </span>
                  <h3 className="font-bold text-base text-white">
                    {letterData.sender?.isRevealed
                      ? letterData.sender.name
                      : 'Anonymous Reconnector'}
                  </h3>
                  <p className="text-xs text-purple-300/80 flex items-center space-x-1.5 mt-0.5">
                    <span className="font-mono">
                      {letterData.sender?.isRevealed
                        ? letterData.sender.ghostedId
                        : 'Ghosted Protected ID (Hidden)'}
                    </span>
                    {letterData.sender?.city && (
                      <span> • {letterData.sender.city}, {letterData.sender.country}</span>
                    )}
                  </p>
                </div>
                <div className="text-right">
                  {letterData.sender?.isRevealed ? (
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2.5 py-1 rounded-full border border-emerald-400/30 flex items-center space-x-1">
                      <Unlock className="w-3 h-3" />
                      <span>Identity Revealed</span>
                    </span>
                  ) : (
                    <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2.5 py-1 rounded-full border border-amber-400/30 flex items-center space-x-1">
                      <Lock className="w-3 h-3" />
                      <span>Anonymous (Locked)</span>
                    </span>
                  )}
                </div>
              </div>

              {!letterData.sender?.isRevealed ? (
                <div className="p-3.5 rounded-xl bg-purple-950/40 border border-purple-400/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                  <div className="space-y-0.5">
                    <p className="font-semibold text-white flex items-center space-x-1.5">
                      <Lock className="w-3.5 h-3.5 text-purple-400" />
                      <span>Receiver's Exclusive Right: Identity Reveal</span>
                    </p>
                    <p className="text-[11px] text-purple-200/80 leading-relaxed">
                      Only you, the receiver, have the authority to request who sent this reconnection letter. The sender is not permitted to unmask themselves without your explicit request.
                    </p>
                  </div>
                  <button
                    type="button"
                    disabled={isRequestingReveal}
                    onClick={handleRequestReveal}
                    className="py-2 px-3.5 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700 text-white font-bold text-xs shadow-md transition flex items-center space-x-1.5 flex-shrink-0 disabled:opacity-50"
                  >
                    <Unlock className="w-3.5 h-3.5" />
                    <span>{isRequestingReveal ? 'Unlocking...' : "Request Sender's Identity"}</span>
                  </button>
                </div>
              ) : (
                <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-400/30 flex items-center space-x-2 text-xs text-emerald-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span>
                    Sender identity successfully unveiled upon your request as the recipient.
                  </span>
                </div>
              )}
            </div>

            {/* Letter Body */}
            <div className="p-5 sm:p-6 rounded-2xl bg-black/40 border border-white/15 space-y-4">
              <div className="flex items-center space-x-2 text-xs text-purple-300/80 border-b border-white/10 pb-2">
                <span>Letter regarding:</span>
                <span className="font-semibold text-white">{letterData.relationship}</span>
              </div>
              <div className="text-sm sm:text-base text-purple-100 leading-relaxed whitespace-pre-wrap font-sans">
                {letterData.letter}
              </div>
            </div>

            {/* Memory Attachments if present */}
            {letterData.memories && letterData.memories.length > 0 && (
              <div className="space-y-2.5">
                <h4 className="text-xs font-semibold text-purple-300 uppercase tracking-wider">
                  Attached Memories ({letterData.memories.length})
                </h4>
                <div className="grid grid-cols-3 gap-2.5">
                  {letterData.memories.map((m: any) => (
                    <div
                      key={m.id}
                      onClick={() => setActiveMediaPreview(m.dataUrl)}
                      className="cursor-pointer group relative rounded-xl overflow-hidden bg-black/50 border border-white/20 aspect-video flex items-center justify-center hover:border-purple-400 transition"
                    >
                      {m.type === 'video' ? (
                        <div className="w-full h-full relative flex items-center justify-center">
                          <video src={m.dataUrl} className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                            <Video className="w-5 h-5 text-white" />
                          </div>
                        </div>
                      ) : (
                        <img src={m.dataUrl} alt={m.name} className="w-full h-full object-cover group-hover:scale-105 transition" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Actions for recipient */}
            <div className="p-4 rounded-2xl bg-purple-950/40 border border-purple-500/30 flex flex-wrap items-center justify-between gap-3">
              <div className="text-xs text-purple-200">
                <span className="font-semibold text-white">Ghosted Protection Guarantee: </span>
                You are under no obligation to reply. If you wish to reach out, use their Ghosted ID.
              </div>
              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={() => onReportClick(letterData.sender?.ghostedId, letterId)}
                  className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-xs font-medium border border-rose-500/30 flex items-center space-x-1.5 transition"
                >
                  <AlertOctagon className="w-3.5 h-3.5" />
                  <span>Block Sender</span>
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold transition"
                >
                  Done
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Media Preview Modal if clicking photo/video */}
        {activeMediaPreview && (
          <div
            className="fixed inset-0 z-60 bg-black/90 flex items-center justify-center p-4"
            onClick={() => setActiveMediaPreview(null)}
          >
            <div className="max-w-2xl max-h-[80vh] relative">
              <img src={activeMediaPreview} alt="Preview" className="max-w-full max-h-[80vh] object-contain rounded-2xl" />
              <button
                type="button"
                onClick={() => setActiveMediaPreview(null)}
                className="absolute top-2 right-2 p-1.5 bg-black/70 rounded-full text-white hover:bg-black"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
