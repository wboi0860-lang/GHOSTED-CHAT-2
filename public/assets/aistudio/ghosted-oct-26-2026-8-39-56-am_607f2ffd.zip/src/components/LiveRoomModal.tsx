import React, { useState, useEffect, useRef } from 'react';
import {
  UserProfile,
  LiveStreamSession,
  LiveComment,
  GiftType,
  GhostGiftDoc,
} from '../types';
import { db } from '../firebase';
import {
  collection,
  doc,
  setDoc,
  updateDoc,
  onSnapshot,
  addDoc,
  increment,
} from 'firebase/firestore';
import {
  X,
  Heart,
  Volume2,
  VolumeX,
  Send,
  Sparkles,
  AlertTriangle,
  Gift,
  Coins,
  ShieldCheck,
  Eye,
  Radio,
  Flame,
  User,
  Layers,
  Camera,
  CameraOff,
  Mic,
  MicOff,
  RotateCcw,
  Activity,
  Play,
  Pause,
  Music,
  Disc,
  SkipForward,
} from 'lucide-react';
import { Lottie } from 'lottie-react';
import { LOTTIE_DATA } from '../utils/lottieData';
import { GHOST_GIFTS, getGiftDefinition } from '../utils/giftDefinitions';
import {
  playGiftSound,
  playSmokeFadeSound,
  setSoundsMuted,
  getSoundsMuted,
} from '../utils/giftSoundManager';
import { checkBadWords } from '../utils/textFilter';

interface LiveRoomModalProps {
  user: UserProfile;
  session: LiveStreamSession;
  isHost: boolean;
  isOpen: boolean;
  onClose: () => void;
  onOpenCoinStore: () => void;
  onUserCoinsUpdated: (newCoins: number) => void;
  onToast: (msg: string) => void;
}

interface FloatingHeart {
  id: string;
  left: number;
  color: string;
}

interface ActivePlayingGift {
  doc: GhostGiftDoc;
  stage: 'solid' | 'smoke'; // 0-6s = solid, 6-9s = smoke
}

export const LiveRoomModal: React.FC<LiveRoomModalProps> = ({
  user,
  session,
  isHost,
  isOpen,
  onClose,
  onOpenCoinStore,
  onUserCoinsUpdated,
  onToast,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [isMuted, setIsMutedState] = useState<boolean>(getSoundsMuted());
  const [liveStats, setLiveStats] = useState<{ viewers: number; likes: number }>({
    viewers: session.viewersCount,
    likes: session.likesCount,
  });

  const [comments, setComments] = useState<LiveComment[]>([]);
  const [commentInput, setCommentInput] = useState<string>('');
  const [floatingHearts, setFloatingHearts] = useState<FloatingHeart[]>([]);
  const [isGiftsOpen, setIsGiftsOpen] = useState<boolean>(false);

  const [giftQueue, setGiftQueue] = useState<GhostGiftDoc[]>([]);
  const [currentPlayingGift, setCurrentPlayingGift] = useState<ActivePlayingGift | null>(null);
  const isPlayingRef = useRef<boolean>(false);
  const lastProcessedGiftIdRef = useRef<string | null>(null);
  const recentGiftsMapRef = useRef<Map<string, number>>(new Map());

  const [violationCount, setViolationCount] = useState<number>(0);
  const moderationTimerRef = useRef<NodeJS.Timeout | null>(null);

  const [isCameraActive, setIsCameraActive] = useState<boolean>(true);
  const [isMicActive, setIsMicActive] = useState<boolean>(true);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [cameraError, setCameraError] = useState<string | null>(null);

  const ANIMATION_PLAY_TRACKS = [
    { id: 0, title: 'Track 01: Spectral Euphoria', duration: 8, bpm: '72 BPM', chord: [220, 261.63, 329.63, 440] },
    { id: 1, title: 'Track 02: Ethereal Whispers', duration: 8, bpm: '68 BPM', chord: [261.63, 329.63, 392, 523.25] },
    { id: 2, title: 'Track 03: Midnight Mirage', duration: 8, bpm: '75 BPM', chord: [196, 246.94, 293.66, 392] },
    { id: 3, title: 'Track 04: Cyber Phantom', duration: 8, bpm: '85 BPM', chord: [293.66, 369.99, 440, 587.33] },
  ];
  const [selectedTrackIndex, setSelectedTrackIndex] = useState<number>(0);
  const [isPlayTrackPlaying, setIsPlayTrackPlaying] = useState<boolean>(false);
  const [trackProgress, setTrackProgress] = useState<number>(0);
  const audioSynthRef = useRef<{ ctx: AudioContext | null; oscs: OscillatorNode[]; gain: GainNode | null }>({
    ctx: null,
    oscs: [],
    gain: null,
  });

  const stopPlayTrackAudio = () => {
    try {
      if (audioSynthRef.current.gain && audioSynthRef.current.ctx) {
        audioSynthRef.current.gain.gain.exponentialRampToValueAtTime(0.0001, audioSynthRef.current.ctx.currentTime + 0.2);
      }
      setTimeout(() => {
        audioSynthRef.current.oscs.forEach((osc) => {
          try {
            osc.stop();
            osc.disconnect();
          } catch {}
        });
        audioSynthRef.current.oscs = [];
        if (audioSynthRef.current.ctx && audioSynthRef.current.ctx.state !== 'closed') {
          audioSynthRef.current.ctx.close().catch(() => {});
        }
        audioSynthRef.current.ctx = null;
      }, 250);
    } catch {}
    setIsPlayTrackPlaying(false);
  };

  const startPlayTrackAudio = (trackIndex: number) => {
    if (isMuted) return;
    try {
      stopPlayTrackAudio();
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const gainNode = ctx.createGain();
      gainNode.gain.setValueAtTime(0.001, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + 0.3);
      gainNode.connect(ctx.destination);

      const track = ANIMATION_PLAY_TRACKS[trackIndex % ANIMATION_PLAY_TRACKS.length];
      const oscs: OscillatorNode[] = [];
      track.chord.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(freq, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(freq * 1.015, ctx.currentTime + 3);
        osc.frequency.exponentialRampToValueAtTime(freq, ctx.currentTime + 6);
        osc.connect(gainNode);
        osc.start();
        oscs.push(osc);
      });
      audioSynthRef.current = { ctx, oscs, gain: gainNode };
      setIsPlayTrackPlaying(true);
    } catch (err) {
      console.warn('Play track synthesizer error:', err);
    }
  };

  const togglePlayTrack = () => {
    if (isPlayTrackPlaying) {
      stopPlayTrackAudio();
    } else {
      startPlayTrackAudio(selectedTrackIndex);
    }
  };

  const handleNextTrack = () => {
    const nextIdx = (selectedTrackIndex + 1) % ANIMATION_PLAY_TRACKS.length;
    setSelectedTrackIndex(nextIdx);
    setTrackProgress(0);
    if (isPlayTrackPlaying || currentPlayingGift) {
      startPlayTrackAudio(nextIdx);
    }
  };

  useEffect(() => {
    if (!currentPlayingGift) {
      if (isPlayTrackPlaying && !currentPlayingGift) {
        stopPlayTrackAudio();
      }
      setTrackProgress(0);
      return;
    }
    startPlayTrackAudio(selectedTrackIndex);
    const interval = setInterval(() => {
      setTrackProgress((prev) => {
        if (prev >= 100) {
          stopPlayTrackAudio();
          return 100;
        }
        return prev + 2.5;
      });
    }, 200);
    return () => {
      clearInterval(interval);
      stopPlayTrackAudio();
    };
  }, [currentPlayingGift]);

  const startCamera = async (mode: 'user' | 'environment' = facingMode) => {
    try {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((t) => t.stop());
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: mode, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: true,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }
      setIsCameraActive(true);
      setCameraError(null);
    } catch (err: any) {
      console.warn('Camera access error:', err);
      setCameraError('Camera access required. Tap Enable Camera to start.');
      setIsCameraActive(false);
    }
  };

  const toggleCamera = () => {
    if (isCameraActive) {
      if (streamRef.current) {
        streamRef.current.getVideoTracks().forEach((t) => (t.enabled = false));
      }
      setIsCameraActive(false);
    } else {
      if (streamRef.current && streamRef.current.getVideoTracks().length > 0) {
        streamRef.current.getVideoTracks().forEach((t) => (t.enabled = true));
        setIsCameraActive(true);
      } else {
        startCamera(facingMode);
      }
    }
  };

  const toggleMic = () => {
    if (streamRef.current) {
      const next = !isMicActive;
      streamRef.current.getAudioTracks().forEach((t) => (t.enabled = next));
      setIsMicActive(next);
    }
  };

  const flipCamera = () => {
    const nextMode = facingMode === 'user' ? 'environment' : 'user';
    setFacingMode(nextMode);
    startCamera(nextMode);
  };

  useEffect(() => {
    if (!isOpen) return;
    if (isHost) {
      startCamera(facingMode);
    }
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
      }
    };
  }, [isOpen, isHost]);

  useEffect(() => {
    if (!isOpen || !session.id) return;
    const unsub = onSnapshot(doc(db, 'live_streams', session.id), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data() as LiveStreamSession;
        setLiveStats({
          viewers: data.viewersCount || 1,
          likes: data.likesCount || 0,
        });
        if (data.status === 'ended') {
          onToast('Live stream has ended.');
          onClose();
        }
      }
    });
    return () => unsub();
  }, [isOpen, session.id]);

  useEffect(() => {
    if (!isOpen || !session.id) return;
    const unsub = onSnapshot(collection(db, 'live_streams', session.id, 'comments'), (snapshot) => {
      const list: LiveComment[] = [];
      snapshot.forEach((snap) => {
        list.push({ ...snap.data(), id: snap.id } as LiveComment);
      });
      list.sort((a, b) => a.timestamp - b.timestamp);
      setComments(list.slice(-40));
    });
    return () => unsub();
  }, [isOpen, session.id]);

  useEffect(() => {
    if (!isOpen || !session.id) return;
    const unsub = onSnapshot(collection(db, 'ghost_gifts'), (snapshot) => {
      const incomingGifts: GhostGiftDoc[] = [];
      snapshot.forEach((snap) => {
        const gift = { ...snap.data(), id: snap.id } as GhostGiftDoc;
        if (gift.liveId === session.id) {
          incomingGifts.push(gift);
        }
      });
      incomingGifts.sort((a, b) => a.timestamp - b.timestamp);
      incomingGifts.forEach((g) => {
        if (!recentGiftsMapRef.current.has(g.id)) {
          recentGiftsMapRef.current.set(g.id, Date.now());
          setGiftQueue((prev) => [...prev, g]);
        }
      });
    });
    return () => unsub();
  }, [isOpen, session.id]);

  useEffect(() => {
    if (giftQueue.length === 0 || isPlayingRef.current) return;
    const nextGift = giftQueue[0];
    isPlayingRef.current = true;
    lastProcessedGiftIdRef.current = nextGift.id;
    setGiftQueue((prev) => prev.slice(1));

    setCurrentPlayingGift({ doc: nextGift, stage: 'solid' });
    playGiftSound(nextGift.giftType);

    const smokeTimer = setTimeout(() => {
      setCurrentPlayingGift({ doc: nextGift, stage: 'smoke' });
      playSmokeFadeSound();
    }, 6000);

    const endTimer = setTimeout(() => {
      setCurrentPlayingGift(null);
      isPlayingRef.current = false;
    }, 9000);

    return () => {
      clearTimeout(smokeTimer);
      clearTimeout(endTimer);
    };
  }, [giftQueue, currentPlayingGift]);

  useEffect(() => {
    if (!isOpen || !isHost) return;
    const runFrameAnalysis = async () => {
      if (!videoRef.current || !canvasRef.current) return;
      const video = videoRef.current;
      const canvas = canvasRef.current;
      if (video.videoWidth === 0 || video.videoHeight === 0) return;
      canvas.width = 320;
      canvas.height = 240;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.6);
      try {
        const res = await fetch('/api/live/moderate-frame', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            frameBase64: dataUrl,
            liveId: session.id,
            hostId: user.id,
          }),
        });
        const data = await res.json();
        if (data.isViolation) {
          setViolationCount((prev) => {
            const nextCount = prev + 1;
            addDoc(collection(db, 'live_violations'), {
              liveId: session.id,
              hostId: user.id,
              reasons: data.reasons || ['AI Vision flagged illicit material'],
              timestamp: Date.now(),
            }).catch(() => {});
            if (nextCount >= 2) {
              updateDoc(doc(db, 'live_streams', session.id), {
                status: 'ended',
                isBanned: true,
              }).catch(() => {});
              updateDoc(doc(db, 'users', user.id), {
                isLiveBanned: true,
                liveBanExpiresAt: new Date(Date.now() + 7 * 86400000).toISOString(),
              }).catch(() => {});
              onToast('Live ended - violation detected by Ghosted AI 24/7 filter (7 day ban).');
              onClose();
            } else {
              onToast('⚠️ Warning: AI detected prohibited content. Another strike will terminate stream.');
            }
            return nextCount;
          });
        }
      } catch (err) {
        console.warn('Frame moderation poll failed:', err);
      }
    };
    moderationTimerRef.current = setInterval(runFrameAnalysis, 10000);
    return () => {
      if (moderationTimerRef.current) clearInterval(moderationTimerRef.current);
    };
  }, [isOpen, isHost, session.id, user.id]);

  if (!isOpen) return null;

  const handleToggleMute = () => {
    const nextVal = !isMuted;
    setIsMutedState(nextVal);
    setSoundsMuted(nextVal);
  };

  const handleSendHeart = async () => {
    const newHeart: FloatingHeart = {
      id: `hrt-${Date.now()}-${Math.random()}`,
      left: 15 + Math.random() * 70,
      color: ['#EC4899', '#A855F7', '#F43F5E', '#8B5CF6'][Math.floor(Math.random() * 4)],
    };
    setFloatingHearts((prev) => [...prev.slice(-15), newHeart]);
    setTimeout(() => {
      setFloatingHearts((prev) => prev.filter((h) => h.id !== newHeart.id));
    }, 2000);
    try {
      await updateDoc(doc(db, 'live_streams', session.id), {
        likesCount: increment(1),
      });
    } catch {}
  };

  const handleSendComment = async (e: React.FormEvent) => {
    e.preventDefault();
    const text = commentInput.trim();
    if (!text) return;
    const check = checkBadWords(text);
    if (check.isBlocked) {
      onToast(`Comment blocked: contains prohibited language (${check.flaggedWords.join(', ')}).`);
      return;
    }
    const newComment: LiveComment = {
      id: `comm-${Date.now()}`,
      liveId: session.id,
      userId: user.id,
      userName: user.name || user.ghostedId || 'Ghoster',
      userAvatar: user.avatarUrl || '👻',
      text: check.cleanText,
      timestamp: Date.now(),
    };
    try {
      await addDoc(collection(db, 'live_streams', session.id, 'comments'), newComment);
    } catch (err) {
      console.warn('Comment write error:', err);
    }
    setCommentInput('');
  };

  const handleSendGift = async (giftType: GiftType) => {
    const def = getGiftDefinition(giftType);
    const userCoins = user.coins ?? 250;
    if (userCoins < def.coins) {
      onToast(`Not enough coins! You need ${def.coins} coins for ${def.name}.`);
      onOpenCoinStore();
      return;
    }

    const updatedCoins = userCoins - def.coins;
    onUserCoinsUpdated(updatedCoins);

    const now = Date.now();
    const giftDoc: GhostGiftDoc = {
      id: `gift-${now}-${Math.random().toString(36).slice(2, 6)}`,
      liveId: session.id,
      senderId: user.id,
      senderName: user.name || 'Anonymous Fan',
      senderAvatar: user.avatarUrl || '👻',
      giftType,
      coins: def.coins,
      timestamp: now,
      comboCount: 1,
    };
    try {
      await setDoc(doc(db, 'ghost_gifts', giftDoc.id), giftDoc);
      const diamondsEarned = Math.floor(def.coins * 0.7);
      await updateDoc(doc(db, 'users', session.hostId), {
        diamonds: increment(diamondsEarned),
      });
      await addDoc(collection(db, 'live_streams', session.id, 'comments'), {
        liveId: session.id,
        userId: user.id,
        userName: user.name || 'Fan',
        userAvatar: user.avatarUrl || '👻',
        text: `Sent ${def.name} ${def.icon} (${def.coins} coins)!`,
        timestamp: now,
        isSystem: true,
      });
      onToast(`Sent ${def.name}! 🎉`);
      setIsGiftsOpen(false);
    } catch (err) {
      console.warn('Gift send error:', err);
    }
  };

  const handleEndOrExit = async () => {
    if (isHost) {
      if (confirm('End this live stream for all viewers?')) {
        await updateDoc(doc(db, 'live_streams', session.id), {
          status: 'ended',
          endedAt: Date.now(),
        }).catch(() => {});
        onClose();
      }
    } else {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black overflow-hidden select-none">
      <canvas ref={canvasRef} className="hidden" />

      {/* BACKGROUND VIDEO / CAMERA STREAM */}
      <div className="absolute inset-0 w-full h-full bg-[#0a0618] overflow-hidden" onDoubleClick={handleSendHeart}>
        {isCameraActive ? (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover transform -scale-x-100"
          />
        ) : (
          <div className="w-full h-full relative flex flex-col items-center justify-center bg-gradient-to-b from-[#190a36] via-[#0d0722] to-[#04010d] p-6 text-center space-y-4">
            <div className="absolute w-[450px] h-[450px] rounded-full bg-purple-600/20 blur-[120px] animate-pulse pointer-events-none" />
            <div className="relative inline-block z-10">
              <div className="w-24 h-24 rounded-full p-1 bg-gradient-to-tr from-rose-500 via-purple-500 to-amber-400 animate-spin duration-3000">
                <div className="w-full h-full rounded-full bg-black/80 flex items-center justify-center text-4xl">
                  {session.hostAvatar || '👻'}
                </div>
              </div>
              <span className="absolute bottom-0 right-0 px-2 py-0.5 rounded-full bg-rose-600 text-white font-black text-[9px] uppercase tracking-wider animate-pulse shadow-md">
                LIVE
              </span>
            </div>
            <div className="z-10 space-y-1">
              <h3 className="text-xl font-bold text-white tracking-tight">{session.hostName}</h3>
              <p className="text-xs text-purple-300/80 font-mono">Ghosted Spectral Broadcast</p>
            </div>
            <button
              type="button"
              onClick={() => startCamera(facingMode)}
              className="z-10 px-5 py-2.5 rounded-2xl bg-gradient-to-r from-rose-600 to-purple-600 hover:from-rose-500 hover:to-purple-500 text-white font-bold text-xs flex items-center space-x-2 shadow-xl shadow-purple-900/40 cursor-pointer active:scale-95 transition"
            >
              <Camera className="w-4 h-4" />
              <span>Enable Live Camera</span>
            </button>
          </div>
        )}
      </div>

      {/* FLOATING HEARTS LAYER */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-20">
        {floatingHearts.map((h) => (
          <div
            key={h.id}
            className="absolute bottom-24 transition-all duration-2000 ease-out transform -translate-y-80 opacity-0"
            style={{
              left: `${h.left}%`,
              animation: 'floatUpHeart 2s ease-out forwards',
            }}
          >
            <Heart className="w-7 h-7 fill-current drop-shadow-[0_0_8px_rgba(236,72,153,0.8)]" style={{ color: h.color }} />
          </div>
        ))}
      </div>

      {/* REALISTIC NON-SQUARED SYNCHRONIZED GIFT OVERLAY */}
      {currentPlayingGift && (
        <div className="absolute inset-0 z-40 pointer-events-none flex flex-col items-center justify-center overflow-hidden">
          <div className="absolute top-20 px-5 py-2.5 rounded-full bg-black/80 border border-amber-400/60 backdrop-blur-md shadow-[0_0_25px_rgba(245,158,11,0.6)] flex items-center space-x-2 animate-in slide-in-from-top-4 duration-300">
            <span className="text-lg">🎁</span>
            <span className="text-xs sm:text-sm font-black text-amber-300 tracking-wide">
              @{currentPlayingGift.doc.senderName} sent {getGiftDefinition(currentPlayingGift.doc.giftType).name} x{currentPlayingGift.doc.comboCount || 1}
            </span>
          </div>

          <div
            className={`relative flex items-center justify-center ${
              currentPlayingGift.stage === 'smoke' ? 'animate-smoke-fade' : 'animate-in zoom-in-75 duration-300'
            }`}
          >
            {currentPlayingGift.doc.giftType === 'little_ghost' ? (
              <div className="relative w-72 h-80 flex items-center justify-center">
                <div className="absolute w-64 h-64 rounded-full bg-gradient-to-tr from-purple-600/30 to-cyan-400/30 blur-3xl animate-pulse" />
                <div className="relative w-48 h-60 animate-bounce duration-3000 filter drop-shadow-[0_0_35px_rgba(255,255,255,0.85)]">
                  <svg viewBox="0 0 100 120" className="w-full h-full">
                    <defs>
                      <linearGradient id="ghostSheetGradLive" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#ffffff" stopOpacity="0.95" />
                        <stop offset="60%" stopColor="#f3e8ff" stopOpacity="0.88" />
                        <stop offset="100%" stopColor="#c084fc" stopOpacity="0.75" />
                      </linearGradient>
                    </defs>
                    <path
                      d="M 50 5 C 24 5, 6 26, 6 58 C 6 86, 2 102, 5 112 C 8 118, 18 118, 23 110 C 28 102, 35 102, 40 110 C 46 118, 54 118, 60 110 C 65 102, 72 102, 77 110 C 82 118, 92 118, 95 112 C 98 102, 94 86, 94 58 C 94 26, 76 5, 50 5 Z"
                      fill="url(#ghostSheetGradLive)"
                      stroke="rgba(255,255,255,0.9)"
                      strokeWidth="2.5"
                    />
                    <ellipse cx="38" cy="44" rx="4.5" ry="7" fill="#180b2b" />
                    <ellipse cx="62" cy="44" rx="4.5" ry="7" fill="#180b2b" />
                    <circle cx="39.5" cy="42" r="1.5" fill="#ffffff" />
                    <circle cx="63.5" cy="42" r="1.5" fill="#ffffff" />
                    <path d="M 44 60 Q 50 66 56 60" stroke="#7e22ce" strokeWidth="2" strokeLinecap="round" fill="none" />
                  </svg>
                </div>
              </div>
            ) : currentPlayingGift.doc.giftType === 'ghost_king' ? (
              <div className="relative w-72 h-72 flex items-center justify-center">
                <div className="absolute w-64 h-64 rounded-full bg-amber-500/25 blur-3xl animate-pulse" />
                <div className="relative animate-bounce duration-2000 filter drop-shadow-[0_0_40px_rgba(245,158,11,0.9)]">
                  <svg viewBox="0 0 120 100" className="w-56 h-48">
                    <defs>
                      <linearGradient id="goldCrownGradLive" x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0%" stopColor="#fef08a" />
                        <stop offset="50%" stopColor="#eab308" />
                        <stop offset="100%" stopColor="#b45309" />
                      </linearGradient>
                    </defs>
                    <path
                      d="M 15 80 L 15 35 L 38 55 L 60 20 L 82 55 L 105 35 L 105 80 Z"
                      fill="url(#goldCrownGradLive)"
                      stroke="#fff"
                      strokeWidth="2"
                    />
                    <circle cx="15" cy="35" r="5" fill="#fef08a" />
                    <circle cx="60" cy="20" r="6" fill="#fef08a" />
                    <circle cx="105" cy="35" r="5" fill="#fef08a" />
                    <circle cx="45" cy="70" r="4" fill="#ef4444" />
                    <circle cx="60" cy="70" r="5" fill="#3b82f6" />
                    <circle cx="75" cy="70" r="4" fill="#10b981" />
                  </svg>
                </div>
              </div>
            ) : (
              <div className="relative w-72 h-72 flex items-center justify-center">
                <div className="absolute w-60 h-60 rounded-full bg-gradient-to-r from-pink-500/30 via-purple-500/30 to-cyan-400/30 blur-3xl animate-spin duration-3000" />
                <div className="text-8xl animate-bounce filter drop-shadow-[0_0_40px_rgba(168,85,247,0.95)]">
                  {getGiftDefinition(currentPlayingGift.doc.giftType).icon}
                </div>
              </div>
            )}

            {currentPlayingGift.stage === 'smoke' && (
              <div className="absolute inset-0 pointer-events-none">
                {Array.from({ length: 18 }).map((_, idx) => (
                  <div
                    key={idx}
                    className="absolute w-4 h-4 rounded-full bg-gradient-to-tr from-purple-400/80 to-cyan-300/80 blur-[4px] animate-float-smoke"
                    style={{
                      left: `${10 + (idx * 5)}%`,
                      bottom: '15%',
                      animationDelay: `${idx * 80}ms`,
                    }}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TOP CONTROLS & HOST HEADER */}
      <div className="absolute top-0 left-0 right-0 z-30 p-4 bg-gradient-to-b from-black/80 via-black/40 to-transparent flex items-center justify-between">
        <div className="flex items-center space-x-2.5 p-1.5 pr-4 rounded-full bg-black/60 border border-white/15 backdrop-blur-md">
          <div className="w-8 h-8 rounded-full bg-purple-600/40 border border-purple-400 flex items-center justify-center text-sm font-bold">
            {session.hostAvatar || '👻'}
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="text-xs font-bold text-white truncate max-w-[110px]">{session.hostName}</span>
              <span className="px-1.5 py-0.2 rounded-full bg-rose-600 text-white font-mono font-bold text-[8px] animate-pulse">
                LIVE
              </span>
            </div>
            <div className="flex items-center space-x-2 text-[10px] text-purple-200/80">
              <span className="flex items-center space-x-0.5">
                <Eye className="w-3 h-3" />
                <span>{liveStats.viewers}</span>
              </span>
              <span>•</span>
              <span className="flex items-center space-x-0.5 text-pink-300">
                <Heart className="w-3 h-3 fill-current" />
                <span>{liveStats.likes}</span>
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-1.5 sm:space-x-2">
          <button
            type="button"
            onClick={flipCamera}
            className="p-2 rounded-full bg-black/60 hover:bg-black/80 text-white border border-white/15 transition cursor-pointer"
            title="Flip Camera (Front/Rear)"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={toggleCamera}
            className="p-2 rounded-full bg-black/60 hover:bg-black/80 text-white border border-white/15 transition cursor-pointer"
            title={isCameraActive ? 'Disable Camera' : 'Enable Camera'}
          >
            {isCameraActive ? <Camera className="w-4 h-4 text-emerald-400" /> : <CameraOff className="w-4 h-4 text-rose-400" />}
          </button>
          <button
            type="button"
            onClick={toggleMic}
            className="p-2 rounded-full bg-black/60 hover:bg-black/80 text-white border border-white/15 transition cursor-pointer"
            title={isMicActive ? 'Mute Mic' : 'Unmute Mic'}
          >
            {isMicActive ? <Mic className="w-4 h-4 text-emerald-400" /> : <MicOff className="w-4 h-4 text-rose-400" />}
          </button>
          <button
            type="button"
            onClick={handleToggleMute}
            className="p-2 rounded-full bg-black/60 hover:bg-black/80 text-white border border-white/15 transition cursor-pointer"
            title={isMuted ? 'Unmute gift sounds' : 'Mute gift sounds'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>
          <button
            type="button"
            data-back-dismissible="true"
            onClick={handleEndOrExit}
            className="p-2 rounded-full bg-rose-600/80 hover:bg-rose-600 text-white transition cursor-pointer border border-rose-400/40"
            title={isHost ? 'End Live Stream' : 'Exit Room'}
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* ANIMATION PLAY TRACK DOCK */}
      <div className="absolute top-20 left-3 right-3 sm:left-4 sm:right-auto sm:w-80 z-30 animate-in slide-in-from-top-2 duration-300 pointer-events-auto">
        <div className="p-2.5 rounded-2xl bg-black/80 border border-purple-500/40 backdrop-blur-md shadow-2xl flex flex-col space-y-2 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className={`p-1.5 rounded-xl ${isPlayTrackPlaying ? 'bg-purple-600/60 text-cyan-300 animate-spin duration-3000' : 'bg-white/10 text-zinc-400'}`}>
                <Disc className="w-4 h-4" />
              </div>
              <div className="text-left">
                <span className="text-[9px] font-mono text-purple-300 block uppercase tracking-wider font-bold">
                  Animation Play Track
                </span>
                <span className="text-xs font-bold text-white block truncate max-w-[150px]">
                  {ANIMATION_PLAY_TRACKS[selectedTrackIndex].title}
                </span>
              </div>
            </div>
            <div className="flex items-center space-x-1.5">
              <button
                type="button"
                onClick={togglePlayTrack}
                className="p-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white transition active:scale-95 shadow-md shadow-purple-900/40"
                title={isPlayTrackPlaying ? 'Pause Animation Track' : 'Play Animation Track'}
              >
                {isPlayTrackPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-white" />}
              </button>
              <button
                type="button"
                onClick={handleNextTrack}
                className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-purple-200 transition active:scale-95"
                title="Next Animation Track"
              >
                <SkipForward className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
          <div className="space-y-1">
            <div className="w-full h-1.5 rounded-full bg-white/15 overflow-hidden relative">
              <div
                className="h-full bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-400 rounded-full transition-all duration-200"
                style={{ width: `${Math.min(100, Math.max(0, trackProgress))}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[9px] font-mono text-purple-300/80">
              <div className="flex items-center space-x-1.5">
                <span className={`inline-block w-1.5 h-1.5 rounded-full ${isPlayTrackPlaying ? 'bg-cyan-400 animate-ping' : 'bg-zinc-500'}`} />
                <span>{isPlayTrackPlaying ? 'TRACK PLAYING' : 'READY TO PLAY'}</span>
              </div>
              <span className="text-zinc-400 font-mono">{ANIMATION_PLAY_TRACKS[selectedTrackIndex].bpm}</span>
            </div>
          </div>
        </div>
      </div>

      {/* BOTTOM COMMENTS & CONTROLS */}
      <div className="absolute bottom-0 left-0 right-0 z-30 p-3 sm:p-4 bg-gradient-to-t from-black via-black/70 to-transparent space-y-3">
        <div className="max-h-48 overflow-y-auto space-y-1.5 scrollbar-none mask-gradient pb-1">
          {comments.map((c) => (
            <div
              key={c.id}
              className={`p-2 rounded-2xl max-w-sm backdrop-blur-md text-xs inline-block mr-auto clear-both ${
                c.isSystem
                  ? 'bg-amber-950/60 border border-amber-400/40 text-amber-300 font-bold'
                  : 'bg-black/50 border border-white/10 text-white'
              }`}
            >
              <div className="flex items-center space-x-1.5">
                <span className="font-bold text-purple-300 text-[11px]">@{c.userName}:</span>
                <span className="text-purple-100">{c.text}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="flex items-center space-x-2">
          <form onSubmit={handleSendComment} className="flex-1 flex items-center space-x-2 p-1.5 rounded-2xl bg-black/60 border border-white/15 backdrop-blur-md">
            <input
              type="text"
              value={commentInput}
              onChange={(e) => setCommentInput(e.target.value)}
              placeholder="Chat as your real profile..."
              className="flex-1 px-3 py-1 bg-transparent text-xs text-white placeholder-purple-300/40 focus:outline-none"
            />
            <button
              type="submit"
              disabled={!commentInput.trim()}
              className="p-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white disabled:opacity-40 transition cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>

          <button
            type="button"
            onClick={() => setIsGiftsOpen(true)}
            className="p-2.5 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white shadow-lg shadow-amber-500/30 transition cursor-pointer active:scale-95 flex items-center space-x-1"
            title="Send Synced Gift"
          >
            <Gift className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={handleSendHeart}
            className="p-2.5 rounded-2xl bg-gradient-to-tr from-pink-600 to-rose-600 text-white shadow-lg shadow-pink-600/30 transition cursor-pointer active:scale-95 animate-pulse"
            title="Tap Heart"
          >
            <Heart className="w-4 h-4 fill-current" />
          </button>
        </div>
      </div>

      {/* GIFTS TRAY MODAL */}
      {isGiftsOpen && (
        <div className="absolute inset-x-0 bottom-0 z-50 p-4 bg-[#120a2e]/95 border-t border-purple-500/40 backdrop-blur-xl rounded-t-3xl shadow-2xl animate-in slide-in-from-bottom-8 duration-200">
          <div className="max-w-md mx-auto space-y-3">
            <div className="flex items-center justify-between border-b border-white/10 pb-2">
              <div className="flex items-center space-x-2">
                <Gift className="w-4 h-4 text-amber-400" />
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">Send Spectral Gifts</h4>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={onOpenCoinStore}
                  className="px-2.5 py-1 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-400/30 text-[10px] font-bold flex items-center space-x-1 cursor-pointer hover:bg-amber-500/30"
                >
                  <Coins className="w-3 h-3 text-amber-400" />
                  <span>{user.coins ?? 250} Coins</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsGiftsOpen(false)}
                  className="p-1 rounded-xl text-purple-300 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 py-1">
              {GHOST_GIFTS.map((g) => {
                const canAfford = (user.coins ?? 250) >= g.coins;
                return (
                  <button
                    key={g.type}
                    type="button"
                    onClick={() => handleSendGift(g.type)}
                    className="p-2.5 rounded-2xl bg-white/5 hover:bg-white/15 border border-white/10 text-center space-y-1 transition cursor-pointer active:scale-95 relative group flex flex-col items-center justify-between"
                  >
                    <span className="text-2xl group-hover:scale-125 transition duration-200">{g.icon}</span>
                    <span className="text-[11px] font-bold text-white block truncate w-full">{g.name}</span>
                    <div className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-mono text-[9px] font-bold flex items-center space-x-1">
                      <span>🪙</span>
                      <span>{g.coins}c</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
