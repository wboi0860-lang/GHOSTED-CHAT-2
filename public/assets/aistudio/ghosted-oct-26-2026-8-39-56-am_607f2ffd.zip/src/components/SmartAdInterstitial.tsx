import React, { useState, useEffect } from 'react';
import {
  AdTriggerContext,
  SPONSOR_BRANDS,
  ADMOB_INTERSTITIAL_UNIT_ID,
  getSponsoredTitle,
  recordAdShown,
} from '../utils/adManager';
import { X, ExternalLink, ShieldCheck, Sparkles, CheckCircle2 } from 'lucide-react';

interface SmartAdInterstitialProps {
  context: AdTriggerContext;
  isOpen: boolean;
  onClose: () => void;
}

export const SmartAdInterstitial: React.FC<SmartAdInterstitialProps> = ({
  context,
  isOpen,
  onClose,
}) => {
  const [countdown, setCountdown] = useState<number>(5);
  const [canSkip, setCanSkip] = useState<boolean>(false);
  const [brandIndex, setBrandIndex] = useState<number>(0);

  useEffect(() => {
    if (!isOpen) {
      setCountdown(5);
      setCanSkip(false);
      return;
    }
    // Pick random brand
    const randomIdx = Math.floor(Math.random() * SPONSOR_BRANDS.length);
    setBrandIndex(randomIdx);
    setCountdown(5);
    setCanSkip(false);

    // 5-second countdown timer
    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setCanSkip(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen]);

  if (!isOpen) return null;

  const brand = SPONSOR_BRANDS[brandIndex];
  const sponsoredTitle = getSponsoredTitle(context, brand.name);

  const handleSkipOrDismiss = () => {
    if (!canSkip) return;
    recordAdShown();
    onClose();
  };

  const handleCtaClick = () => {
    recordAdShown();
    window.open(brand.website, '_blank', 'noopener,noreferrer');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      {/* Native Card Format (Non-blocking, elegant card presentation) */}
      <div className="w-full max-w-md rounded-3xl bg-[#120d2b] border border-purple-500/40 p-5 sm:p-6 shadow-[0_20px_50px_rgba(0,0,0,0.8)] relative overflow-hidden space-y-4">
        {/* Top Header: AdMob badge + Skippable Counter */}
        <div className="flex items-center justify-between gap-2 border-b border-white/10 pb-3">
          <div className="flex items-center space-x-2">
            <span className="text-[10px] font-mono uppercase bg-purple-500/20 text-purple-300 border border-purple-400/30 px-2 py-0.5 rounded-full font-bold flex items-center space-x-1">
              <Sparkles className="w-2.5 h-2.5 text-purple-400" />
              <span>Sponsored</span>
            </span>
            <span className="text-[9px] text-purple-400/70 font-mono hidden sm:inline truncate max-w-[170px]" title={ADMOB_INTERSTITIAL_UNIT_ID}>
              {ADMOB_INTERSTITIAL_UNIT_ID}
            </span>
          </div>

          {/* Skippable Button with 5s countdown */}
          <div>
            {canSkip ? (
              <button
                type="button"
                onClick={handleSkipOrDismiss}
                className="py-1 px-3 rounded-full bg-white/15 hover:bg-white/25 active:scale-95 text-xs text-white font-bold transition flex items-center space-x-1 cursor-pointer border border-white/20 animate-in fade-in"
              >
                <span>Skip Ad</span>
                <X className="w-3.5 h-3.5 text-white/80" />
              </button>
            ) : (
              <div className="py-1 px-3 rounded-full bg-black/40 border border-white/10 text-xs font-mono text-purple-300/80 flex items-center space-x-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                <span>Skip in {countdown}s</span>
              </div>
            )}
          </div>
        </div>

        {/* Sponsored By Brand Headline */}
        <div className="space-y-1">
          <h3 className="text-base sm:text-lg font-bold text-white tracking-tight leading-snug">
            {sponsoredTitle}
          </h3>
          <p className="text-xs text-purple-200/70">
            Ghosted gives everyone private, untraceable communication supported by partners.
          </p>
        </div>

        {/* Native Sponsor Content Card */}
        <div className={`p-4 rounded-2xl bg-gradient-to-br ${brand.accentColor} bg-opacity-20 border border-white/15 space-y-3 relative overflow-hidden text-white shadow-inner`}>
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 rounded-2xl bg-black/40 border border-white/20 flex items-center justify-center text-2xl shadow-lg">
                {brand.logo}
              </div>
              <div>
                <h4 className="text-base font-black text-white">{brand.name}</h4>
                <span className="text-[10px] text-white/80 flex items-center space-x-1 font-medium">
                  <ShieldCheck className="w-3 h-3 text-emerald-300" />
                  <span>Verified Partner Brand</span>
                </span>
              </div>
            </div>
            <span className="text-[9px] bg-black/40 text-white/90 px-2 py-0.5 rounded-full font-mono font-bold border border-white/10">
              Ad
            </span>
          </div>

          <p className="text-xs text-white/90 leading-relaxed font-medium">
            {brand.tagline}
          </p>

          <div className="pt-1 flex items-center justify-between">
            <button
              type="button"
              onClick={handleCtaClick}
              className="py-2.5 px-4 rounded-xl bg-white text-slate-900 font-bold text-xs hover:bg-white/90 transition shadow-md flex items-center space-x-1.5 cursor-pointer active:scale-95"
            >
              <span>{brand.ctaText}</span>
              <ExternalLink className="w-3.5 h-3.5 text-slate-900" />
            </button>
            <span className="text-[10px] text-white/70">
              Opens in new tab
            </span>
          </div>
        </div>

        {/* Bottom guarantee */}
        <div className="flex items-center justify-between text-[10px] text-purple-300/70 pt-1">
          <span className="flex items-center space-x-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            <span>Zero cookies stored • Strict privacy</span>
          </span>
          {canSkip && (
            <button
              type="button"
              onClick={handleSkipOrDismiss}
              className="text-purple-300 hover:text-white underline cursor-pointer"
            >
              Continue to Ghosted
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
