import React from 'react';
import { APP_THEMES, ThemeId, normalizeThemeId } from '../utils/theme';
import { Check, X, Sun, Moon, Sparkles } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface ThemeSelectorModalProps {
  currentThemeId?: string;
  isOpen?: boolean;
  onSelectTheme: (themeId: ThemeId) => void;
  onClose: () => void;
}

export const ThemeSelectorModal: React.FC<ThemeSelectorModalProps> = ({
  currentThemeId,
  isOpen = true,
  onSelectTheme,
  onClose,
}) => {
  const { theme: contextTheme, isWhite, isBlack, isGhost } = useTheme();
  const activeId = normalizeThemeId(currentThemeId || contextTheme);

  if (!isOpen) return null;

  const themeList: Array<{
    id: ThemeId;
    name: string;
    badge: string;
    badgeColor: string;
    description: string;
    iconComponent: React.ReactNode;
    preview: { pageBg: string; cardBg: string; textColor: string };
  }> = [
    {
      id: 'white',
      name: 'White Theme (Light)',
      badge: 'Light',
      badgeColor: 'bg-black text-white',
      description: '#FFFFFF white page, #000000 black cards with #FFFFFF white text',
      iconComponent: <Sun className="w-5 h-5 text-amber-500" />,
      preview: { pageBg: '#FFFFFF', cardBg: '#000000', textColor: '#FFFFFF' },
    },
    {
      id: 'black',
      name: 'Black Theme (Dark)',
      badge: 'Dark',
      badgeColor: 'bg-white text-black border border-gray-300',
      description: '#000000 black page, #FFFFFF white cards with #000000 black text',
      iconComponent: <Moon className="w-5 h-5 text-sky-400" />,
      preview: { pageBg: '#000000', cardBg: '#FFFFFF', textColor: '#000000' },
    },
    {
      id: 'ghost',
      name: 'Ghost Theme (Neon)',
      badge: 'Special',
      badgeColor: 'bg-[#00F5FF] text-black font-bold',
      description: '#5B21B6 deep purple page, #000000 black cards, #00F5FF cyan glow',
      iconComponent: <span className="text-xl">👻</span>,
      preview: { pageBg: '#5B21B6', cardBg: '#000000', textColor: '#FFFFFF' },
    },
  ];

  return (
    <div className="fixed inset-0 z-[10010] flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="w-full max-w-md rounded-3xl p-5 shadow-2xl relative overflow-hidden space-y-4 theme-card"
        style={{
          backgroundColor: isBlack ? '#FFFFFF' : '#000000',
          color: isBlack ? '#000000' : '#FFFFFF',
          borderColor: isBlack ? '#E4E6EB' : isGhost ? '#2A2A3F' : '#1A1A1A',
        }}
      >
        {/* Modal Header */}
        <div
          className="flex items-center justify-between pb-3 border-b"
          style={{ borderColor: isBlack ? '#E4E6EB' : '#2A2A3F' }}
        >
          <div className="flex items-center space-x-2.5">
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center ${
                isGhost
                  ? 'bg-[#00F5FF]/20 text-[#00F5FF]'
                  : isBlack
                  ? 'bg-black text-white'
                  : 'bg-white/10 text-white'
              }`}
            >
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold tracking-tight">Display & Theme</h3>
              <p className="text-xs opacity-70">Pick your style for all pages & cards</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-full transition cursor-pointer opacity-70 hover:opacity-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 3 Theme Options */}
        <div className="space-y-3 pt-1">
          {themeList.map((t) => {
            const isSelected = activeId === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => {
                  onSelectTheme(t.id);
                  onClose();
                }}
                className={`w-full p-3.5 rounded-2xl text-left border-2 transition-all duration-200 flex items-center justify-between cursor-pointer group ${
                  isSelected
                    ? t.id === 'ghost'
                      ? 'border-[#00F5FF] shadow-[0_0_15px_rgba(0,245,255,0.3)]'
                      : t.id === 'black'
                      ? 'border-black ring-2 ring-black/20'
                      : 'border-white ring-2 ring-white/20'
                    : 'border-white/10 hover:border-white/30'
                }`}
                style={{
                  backgroundColor: isBlack ? '#F9FAFB' : '#0A0A0F',
                  color: isBlack ? '#000000' : '#FFFFFF',
                }}
              >
                <div className="flex items-center space-x-3.5">
                  <div
                    className="w-11 h-11 rounded-2xl flex items-center justify-center text-xl flex-shrink-0 shadow-md border"
                    style={{
                      backgroundColor: t.preview.pageBg,
                      borderColor: t.id === 'ghost' ? '#00F5FF' : '#4B5563',
                    }}
                  >
                    <div
                      className="w-7 h-7 rounded-lg flex items-center justify-center text-xs"
                      style={{
                        backgroundColor: t.preview.cardBg,
                        color: t.preview.textColor,
                      }}
                    >
                      {t.iconComponent}
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-sm">{t.name}</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${t.badgeColor}`}>
                        {t.badge}
                      </span>
                    </div>
                    <p className="text-xs mt-0.5 opacity-70 line-clamp-1">{t.description}</p>
                  </div>
                </div>

                <div
                  className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                    isSelected
                      ? t.id === 'ghost'
                        ? 'border-[#00F5FF] bg-[#00F5FF] text-black font-black'
                        : isBlack
                        ? 'border-black bg-black text-white'
                        : 'border-white bg-white text-black'
                      : 'border-gray-500'
                  }`}
                >
                  {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                </div>
              </button>
            );
          })}
        </div>

        {/* Footer info */}
        <div
          className="pt-2 text-center border-t text-xs opacity-70"
          style={{ borderColor: isBlack ? '#E4E6EB' : '#2A2A3F' }}
        >
          <span>Saved to localStorage. Adapts all pages with smooth 0.3s transition.</span>
        </div>
      </div>
    </div>
  );
};
