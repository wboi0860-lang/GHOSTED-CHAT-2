import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, GhostedChatMessage, GhostedConversation, CallSession, SavedLetter, CallLog, FirestoreCallDoc } from '../types';
import {
  Phone,
  Video,
  MessageSquare,
  Copy,
  Check,
  ShieldCheck,
  PhoneCall,
  PhoneOff,
  Mic,
  MicOff,
  VideoOff,
  Send,
  Lock,
  HeartHandshake,
  Radio,
  Flame,
  Delete,
  ExternalLink,
  MessageCircle,
  Volume2,
  Clock,
  Sparkles,
  Inbox,
  Smartphone,
  Zap,
  Users,
  Star,
  Sliders,
  Search,
} from 'lucide-react';
import {
  playDtmfTone,
  PhoneRingTonePlayer,
  playConnectedChime,
  playHangupTone,
  stopAllActiveRingtones,
} from '../utils/audioTones';
import {
  collection,
  doc,
  setDoc,
  updateDoc,
  onSnapshot,
  query,
  where,
  Unsubscribe,
} from 'firebase/firestore';
import { db, requestNotificationPermission, triggerIncomingCallAlert } from '../firebase';
import { DualDeviceCallTester } from './DualDeviceCallTester';
import { ChatHub } from './ChatHub';
import { SmartAdInterstitial } from './SmartAdInterstitial';
import { shouldShowAd } from '../utils/adManager';
import { checkIsNigeria } from '../utils/countryDetection';
import { useTheme } from '../context/ThemeContext';
import {
  subscribeGhostUsers,
  subscribeRealCallHistory,
} from '../services/ghostService';
import { GhostUserDoc, CallRecordDoc } from '../types';

export type CommunicatorTab = 'all' | 'unread' | 'favourites' | 'groups' | 'calls';

interface GhostedCommunicatorProps {
  user: UserProfile;
  initialTargetGhostedId?: string;
  letters?: SavedLetter[];
  initialTab?: CommunicatorTab;
  onSwitchUser?: (newUser: UserProfile) => void;
  externalIncomingCallDoc?: FirestoreCallDoc | null;
  onClearExternalIncomingCall?: () => void;
}

export const GhostedCommunicator: React.FC<GhostedCommunicatorProps> = ({
  user,
  initialTargetGhostedId,
  letters = [],
  initialTab,
  onSwitchUser,
  externalIncomingCallDoc,
  onClearExternalIncomingCall,
}) => {
  const { currentTheme, isWhite, isBlack, isGhost } = useTheme();
  const [copiedNumber, setCopiedNumber] = useState(false);
  const [copiedId, setCopiedId] = useState(false);

  const [hasNotificationPermission, setHasNotificationPermission] = useState<boolean>(() => {
    return typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted';
  });

  const [activeTab, setActiveTab] = useState<CommunicatorTab>(initialTab || 'all');
  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);

  // Real Calls view state: 'users' (Ghosted Peers to call), 'logs' (Call history), 'lab' (Tester)
  const [callsSubView, setCallsSubView] = useState<'users' | 'logs' | 'lab'>('users');
  const [realGhostUsers, setRealGhostUsers] = useState<GhostUserDoc[]>([]);
  const [ghostUserSearch, setGhostUserSearch] = useState('');
  const [realCallHistory, setRealCallHistory] = useState<CallRecordDoc[]>([]);

  useEffect(() => {
    const unsubUsers = subscribeGhostUsers((users) => {
      setRealGhostUsers(users);
    });
    const unsubCalls = subscribeRealCallHistory(user.id, (calls) => {
      setRealCallHistory(calls);
    });
    return () => {
      unsubUsers();
      unsubCalls();
    };
  }, [user.id]);

  const [sharedConversations, setSharedConversations] = useState<GhostedConversation[]>(() => {
    const storageKey = `ghosted_convos_${user.ghostedId}`;
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {}
    return [];
  });

  useEffect(() => {
    const storageKey = `ghosted_convos_${user.ghostedId}`;
    try {
      localStorage.setItem(storageKey, JSON.stringify(sharedConversations));
    } catch {}
  }, [sharedConversations, user.ghostedId]);

  const [sharedMessages, setSharedMessages] = useState<Record<string, GhostedChatMessage[]>>(() => {
    const storageKey = `ghosted_msgs_${user.ghostedId}`;
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') return parsed;
      }
    } catch {}
    return {};
  });

  useEffect(() => {
    const storageKey = `ghosted_msgs_${user.ghostedId}`;
    try {
      localStorage.setItem(storageKey, JSON.stringify(sharedMessages));
    } catch {}
  }, [sharedMessages, user.ghostedId]);

  const [targetId, setTargetId] = useState(initialTargetGhostedId || '');
  const [targetPhone, setTargetPhone] = useState('');
  const [targetName, setTargetName] = useState('');
  const [hasMutualConsent, setHasMutualConsent] = useState(true);
  const [dialerInput, setDialerInput] = useState('');

  const [callSession, setCallSession] = useState<CallSession>({
    isActive: false,
    type: 'voice',
    remoteGhostedId: '',
    remoteName: '',
    isIncoming: false,
    status: 'ended',
    isMuted: false,
    isVideoEnabled: true,
    durationSeconds: 0,
    isConsentGranted: true,
  });

  const [activeFirestoreCallId, setActiveFirestoreCallId] = useState<string | null>(null);
  const [callTimeoutRemaining, setCallTimeoutRemaining] = useState<number>(30);
  const callTimeoutTimerRef = useRef<NodeJS.Timeout | null>(null);

  const [incomingCallDoc, setIncomingCallDoc] = useState<FirestoreCallDoc | null>(null);
  const [incomingTimeoutRemaining, setIncomingTimeoutRemaining] = useState<number>(30);
  const incomingTimeoutTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (externalIncomingCallDoc) {
      setCallSession({
        isActive: true,
        type: externalIncomingCallDoc.callType,
        remoteGhostedId: externalIncomingCallDoc.callerId,
        remoteName: externalIncomingCallDoc.callerName,
        isIncoming: true,
        status: 'connected',
        isMuted: false,
        isVideoEnabled: externalIncomingCallDoc.callType === 'video',
        durationSeconds: 0,
        isConsentGranted: true,
      });
      setActiveFirestoreCallId(externalIncomingCallDoc.id);
      setActiveTab('calls');
      setCallsSubView('users');
      onClearExternalIncomingCall?.();
    }
  }, [externalIncomingCallDoc]);

  const [callLogs, setCallLogs] = useState<CallLog[]>([]);
  const [isCallAdOpen, setIsCallAdOpen] = useState<boolean>(false);
  const [pendingRatingData, setPendingRatingData] = useState<{
    callerName: string;
    callerId: string;
    callType: 'voice' | 'video';
  } | null>(null);
  const [callRatingModal, setCallRatingModal] = useState<{
    isOpen: boolean;
    callerName: string;
    callerId: string;
    callType: 'voice' | 'video';
  }>({
    isOpen: false,
    callerName: '',
    callerId: '',
    callType: 'voice',
  });
  const [callRatingStars, setCallRatingStars] = useState<number>(5);
  const [isCallSupportive, setIsCallSupportive] = useState<boolean>(true);

  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const ringtoneRef = useRef<HTMLAudioElement | null>(null);
  const ringIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const peerConnection = useRef<RTCPeerConnection | null>(null);
  const ringTonePlayerRef = useRef<PhoneRingTonePlayer>(new PhoneRingTonePlayer());
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const [micVolumeLevel, setMicVolumeLevel] = useState<number>(0);

  const [chatInput, setChatInput] = useState('');
  const [burnTimerSeconds, setBurnTimerSeconds] = useState<number | null>(null);
  const [messages, setMessages] = useState<GhostedChatMessage[]>([]);
  const [isSendingMessage, setIsSendingMessage] = useState(false);
  const chatScrollRef = useRef<HTMLDivElement | null>(null);

  const recentContacts = letters
    .filter((l) => l.recipientName && (l.recipientGhostedId || l.recipientPhone))
    .map((l) => ({
      id: l.recipientGhostedId || '',
      name: l.recipientName,
      phone: l.recipientPhone || '',
    }))
    .filter((c) => c.id || c.phone)
    .slice(0, 5);

  const handleRequestPushPermission = async () => {
    const granted = await requestNotificationPermission();
    setHasNotificationPermission(granted);
    if (granted) {
      triggerIncomingCallAlert('Ghosted Test Call', user.ghostedId);
    }
  };

  useEffect(() => {
    if (!user?.ghostedId) return;
    const callsCol = collection(db, 'calls');
    const q = query(
      callsCol,
      where('receiverId', '==', user.ghostedId),
      where('status', '==', 'ringing')
    );
    const unsubscribe: Unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        if (snapshot.empty) {
          if (incomingCallDoc) {
            ringTonePlayerRef.current.stop();
            setIncomingCallDoc(null);
            if (incomingTimeoutTimerRef.current) clearInterval(incomingTimeoutTimerRef.current);
          }
          return;
        }
        const firstDoc = snapshot.docs[0];
        const incomingCall = { ...firstDoc.data(), id: firstDoc.id } as FirestoreCallDoc & { senderId?: string };

        const currentUserId = user.ghostedId;
        const currentUid = user.id;
        const currentUserPhone = user.phone || user.ghostedNumber;
        if (
          incomingCall.senderId === currentUserId ||
          incomingCall.senderId === currentUid ||
          incomingCall.callerId === currentUserId ||
          incomingCall.callerId === currentUid ||
          (currentUserPhone && (incomingCall.senderId === currentUserPhone || incomingCall.callerId === currentUserPhone))
        ) {
          console.warn('[Call Listener] SELF CALL BLOCKED: Ignored own incoming call', {
            incomingSenderId: incomingCall.senderId || incomingCall.callerId,
            currentUserId,
          });
          return;
        }

        const callData = incomingCall;
        if (!incomingCallDoc || incomingCallDoc.id !== callData.id) {
          setIncomingCallDoc(callData);
          setIncomingTimeoutRemaining(30);
          ringTonePlayerRef.current.start();
          triggerIncomingCallAlert(callData.callerName, callData.callerId);

          if (incomingTimeoutTimerRef.current) clearInterval(incomingTimeoutTimerRef.current);
          let remaining = 30;
          incomingTimeoutTimerRef.current = setInterval(() => {
            remaining -= 1;
            setIncomingTimeoutRemaining(remaining);
            if (remaining <= 0) {
              clearInterval(incomingTimeoutTimerRef.current!);
              ringTonePlayerRef.current.stop();
              setIncomingCallDoc(null);
            }
          }, 1000);
        }
      },
      (err) => {
        console.warn('Firestore incoming call listener error:', err);
      }
    );
    return () => {
      unsubscribe();
      stopRingtoneAudio();
    };
  }, [user.ghostedId]);

  useEffect(() => {
    fetch(`/api/chat/messages?userGhostedId=${user.ghostedId}&targetId=${targetId}`)
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data) && data.length > 0) {
          setMessages(data);
        } else {
          setMessages([
            {
              id: 'msg-seed-1',
              senderGhostedId: targetId,
              receiverGhostedId: user.ghostedId,
              text: `Hi ${user.name.split(' ')[0]}, I received your message. Happy to connect here safely via encrypted chat.`,
              timestamp: '10:45 AM',
              isDelivered: true,
              isRead: true,
              channel: 'in_app',
            },
          ]);
        }
      })
      .catch(() => {});

    fetch(`/api/calls/logs?callerGhostedId=${user.ghostedId}`)
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setCallLogs(data);
        }
      })
      .catch(() => {});
  }, [user.ghostedId, targetId, user.name]);

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (callSession.isActive && callSession.status === 'connected') {
      interval = setInterval(() => {
        setCallSession((prev) => ({ ...prev, durationSeconds: prev.durationSeconds + 1 }));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [callSession.isActive, callSession.status]);

  useEffect(() => {
    return () => {
      ringTonePlayerRef.current.stop();
      if (localStream) {
        localStream.getTracks().forEach((track) => track.stop());
      }
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        audioContextRef.current.close().catch(() => {});
      }
    };
  }, [localStream]);

  const setupRealAudioAnalysis = (stream: MediaStream) => {
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx();
      audioContextRef.current = ctx;
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 64;
      analyser.smoothingTimeConstant = 0.8;
      source.connect(analyser);
      analyserRef.current = analyser;
      const dataArray = new Uint8Array(analyser.frequencyBinCount);

      const updateVolume = () => {
        if (!analyserRef.current) return;
        analyserRef.current.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) {
          sum += dataArray[i];
        }
        const avg = sum / dataArray.length;
        setMicVolumeLevel(Math.min(100, Math.round((avg / 255) * 100 * 2.5)));
        animationFrameRef.current = requestAnimationFrame(updateVolume);
      };
      updateVolume();
    } catch {
      // AudioContext unavailable
    }
  };

  const formatDuration = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const remaining = sec % 60;
    return `${mins.toString().padStart(2, '0')}:${remaining.toString().padStart(2, '0')}`;
  };

  const handleKeypadPress = (digit: string) => {
    playDtmfTone(digit);
    setDialerInput((prev) => prev + digit);
  };

  const handleKeypadBackspace = () => {
    setDialerInput((prev) => prev.slice(0, -1));
  };

  const makeRealPhoneCall = (phoneNumber: string) => {
    const cleanNumber = phoneNumber.replace(/[^0-9+]/g, '');
    if (!cleanNumber) {
      alert('Please enter a valid phone number with digits or select a contact.');
      return;
    }
    fetch('/api/calls/log', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        callerGhostedId: user.ghostedId,
        targetNumberOrId: cleanNumber,
        type: 'cellular',
        durationSeconds: 45,
        status: 'connected',
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.log) {
          setCallLogs((prev) => [data.log, ...prev]);
        }
      })
      .catch(() => {});

    window.location.href = `tel:${cleanNumber}`;
  };

  const openWhatsAppCall = (phoneNumber: string) => {
    const cleanNumber = phoneNumber.replace(/[^0-9]/g, '');
    if (!cleanNumber) {
      alert('Please provide a phone number with country code (e.g. +1... or +234...)');
      return;
    }
    window.open(`https://wa.me/${cleanNumber}`, '_blank');
  };

  const sendCall = async (
    targetContactId = targetId,
    contactName = targetName,
    callType: 'voice' | 'video' = 'voice',
    senderToken?: string,
    receiverToken?: string
  ) => {
    const senderId = user.ghostedId;
    const receiverId = (targetContactId || '').trim();
    const resolvedSenderToken = senderToken || localStorage.getItem('ghosted_fcm_token') || undefined;

    if (
      !receiverId ||
      senderId === receiverId ||
      user.id === receiverId ||
      (user.phone && user.phone === receiverId) ||
      (user.ghostedNumber && user.ghostedNumber === receiverId) ||
      (resolvedSenderToken && receiverToken && resolvedSenderToken === receiverToken)
    ) {
      console.warn('SELF CALL BLOCKED: senderId == receiverId OR senderToken == receiverToken', {
        senderId,
        receiverId,
        resolvedSenderToken,
        receiverToken,
      });
      alert('SELF CALL BLOCKED: You cannot call your own device or account.');
      return;
    }

    if (!hasMutualConsent) {
      alert('Mutual Consent Required: Both parties must exchange consent before calling.');
      return;
    }

    try {
      ringTonePlayerRef.current.start();
      let stream: MediaStream | null = null;
      try {
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          stream = await navigator.mediaDevices.getUserMedia({
            audio: true,
            video: callType === 'video',
          });
          setLocalStream(stream);
          if (callType === 'video' && localVideoRef.current) {
            localVideoRef.current.srcObject = stream;
          }
          setupRealAudioAnalysis(stream);
        }
      } catch {
        // microphone permission handled gracefully
      }

      setCallSession({
        isActive: true,
        type: callType,
        remoteGhostedId: targetContactId,
        remoteName: contactName,
        isIncoming: false,
        status: 'ringing',
        isMuted: false,
        isVideoEnabled: callType === 'video',
        durationSeconds: 0,
        isConsentGranted: true,
      });

      const callsCol = collection(db, 'calls');
      const newCallRef = doc(callsCol);
      const callId = newCallRef.id;
      setActiveFirestoreCallId(callId);
      setCallTimeoutRemaining(30);

      const initialCallDoc: FirestoreCallDoc & { senderId: string } = {
        id: callId,
        senderId: user.ghostedId,
        callerId: user.ghostedId,
        callerName: user.name,
        callerPhone: user.phone || user.ghostedNumber,
        receiverId: targetContactId,
        receiverName: contactName,
        status: 'ringing',
        callType,
        createdAt: Date.now(),
        offer: {
          type: 'offer',
          sdp: `v=0\r\no=${user.ghostedId} 123456 2 IN IP4 127.0.0.1\r\ns=Ghosted Call\r\nt=0 0\r\nm=audio 54312 RTP/AVP 0\r\na=rtpmap:0 PCMU/8000`,
        },
        answer: null,
      };

      await setDoc(newCallRef, initialCallDoc);

      try {
        await fetch('/api/calls/sendCall', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            senderId,
            receiverId,
            senderToken: resolvedSenderToken,
            receiverToken,
            callId,
            callerName: user.name,
            callType,
          }),
        });
      } catch (fcmErr) {
        console.warn('Targeted FCM dispatch notice:', fcmErr);
      }

      if (callTimeoutTimerRef.current) clearInterval(callTimeoutTimerRef.current);
      let remaining = 30;
      callTimeoutTimerRef.current = setInterval(async () => {
        remaining -= 1;
        setCallTimeoutRemaining(remaining);
        if (remaining <= 0) {
          clearInterval(callTimeoutTimerRef.current!);
          ringTonePlayerRef.current.stop();
          playHangupTone();
          try {
            await updateDoc(doc(db, 'calls', callId), {
              status: 'timeout',
              endedAt: Date.now(),
            });
          } catch {
            // ignore
          }
          setCallSession((prev) => ({ ...prev, status: 'ended', isActive: false }));
          alert('Call timed out after 30 seconds: Recipient did not answer.');
        }
      }, 1000);

      const unsubCallDoc = onSnapshot(newCallRef, (snapshot) => {
        const data = snapshot.data() as FirestoreCallDoc | undefined;
        if (!data) return;
        if (data.status === 'answered') {
          ringTonePlayerRef.current.stop();
          playConnectedChime();
          if (callTimeoutTimerRef.current) clearInterval(callTimeoutTimerRef.current);
          setCallSession((prev) => ({
            ...prev,
            status: 'connected',
          }));
        } else if (data.status === 'declined') {
          ringTonePlayerRef.current.stop();
          playHangupTone();
          if (callTimeoutTimerRef.current) clearInterval(callTimeoutTimerRef.current);
          setCallSession((prev) => ({ ...prev, status: 'ended', isActive: false }));
          alert('Call declined by recipient.');
          unsubCallDoc();
        } else if (data.status === 'ended') {
          ringTonePlayerRef.current.stop();
          playHangupTone();
          if (callTimeoutTimerRef.current) clearInterval(callTimeoutTimerRef.current);
          setCallSession((prev) => ({ ...prev, status: 'ended', isActive: false }));
          unsubCallDoc();
        } else if (data.status === 'timeout') {
          ringTonePlayerRef.current.stop();
          playHangupTone();
          setCallSession((prev) => ({ ...prev, status: 'ended', isActive: false }));
          unsubCallDoc();
        }
      });
    } catch (err: unknown) {
      ringTonePlayerRef.current.stop();
      alert(`Call failed: ${(err as Error).message}`);
    }
  };

  const startFirestoreSignalingCall = sendCall;

  const stopRingtoneAudio = () => {
    if (ringtoneRef.current) {
      try {
        ringtoneRef.current.pause();
        ringtoneRef.current.currentTime = 0;
      } catch {}
    }
    if (ringIntervalRef.current) {
      clearInterval(ringIntervalRef.current);
      ringIntervalRef.current = null;
    }
    if (incomingTimeoutTimerRef.current) {
      clearInterval(incomingTimeoutTimerRef.current);
      incomingTimeoutTimerRef.current = null;
    }
    if (callTimeoutTimerRef.current) {
      clearInterval(callTimeoutTimerRef.current);
      callTimeoutTimerRef.current = null;
    }
    if (peerConnection.current) {
      try {
        peerConnection.current.close();
      } catch {}
      peerConnection.current = null;
    }
    ringTonePlayerRef.current?.stop();
    stopAllActiveRingtones();
  };

  const acceptCall = async () => {
    stopRingtoneAudio();
    if (!incomingCallDoc) return;
    try {
      playConnectedChime();
      let stream: MediaStream | null = null;
      try {
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          stream = await navigator.mediaDevices.getUserMedia({
            audio: true,
            video: incomingCallDoc.callType === 'video',
          });
          setLocalStream(stream);
          setupRealAudioAnalysis(stream);
        }
      } catch {
        // microphone permission handled
      }

      const callRef = doc(db, 'calls', incomingCallDoc.id);
      await updateDoc(callRef, {
        status: 'answered',
        answeredAt: Date.now(),
        answer: {
          type: 'answer',
          sdp: `v=0\r\no=${user.ghostedId} 654321 2 IN IP4 127.0.0.1\r\ns=Ghosted Answer\r\nt=0 0\r\nm=audio 54312 RTP/AVP 0\r\na=rtpmap:0 PCMU/8000`,
        },
      });

      setActiveFirestoreCallId(incomingCallDoc.id);
      setCallSession({
        isActive: true,
        type: incomingCallDoc.callType,
        remoteGhostedId: incomingCallDoc.callerId,
        remoteName: incomingCallDoc.callerName,
        isIncoming: true,
        status: 'connected',
        isMuted: false,
        isVideoEnabled: incomingCallDoc.callType === 'video',
        durationSeconds: 0,
        isConsentGranted: true,
      });

      setIncomingCallDoc(null);

      const unsubEndListener = onSnapshot(callRef, (snapshot) => {
        const data = snapshot.data() as FirestoreCallDoc | undefined;
        if (!data) return;
        if (data.status === 'ended' || data.status === 'declined') {
          stopRingtoneAudio();
          playHangupTone();
          setCallSession((prev) => ({ ...prev, status: 'ended', isActive: false }));
          unsubEndListener();
        }
      });
    } catch (err: unknown) {
      stopRingtoneAudio();
      alert(`Error answering call: ${(err as Error).message}`);
    }
  };

  const declineCall = async () => {
    stopRingtoneAudio();
    if (!incomingCallDoc) return;
    try {
      playHangupTone();
      const callRef = doc(db, 'calls', incomingCallDoc.id);
      await updateDoc(callRef, {
        status: 'declined',
        endedAt: Date.now(),
      });
      setIncomingCallDoc(null);
    } catch {
      setIncomingCallDoc(null);
    }
  };

  const endCall = async () => {
    stopRingtoneAudio();
    playHangupTone();

    if (activeFirestoreCallId) {
      try {
        const callRef = doc(db, 'calls', activeFirestoreCallId);
        await updateDoc(callRef, {
          status: 'ended',
          endedAt: Date.now(),
        });
      } catch {
        // ignore
      }
    }

    if (callSession.durationSeconds > 0) {
      fetch('/api/calls/log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          callerGhostedId: user.ghostedId,
          targetNumberOrId: callSession.remoteGhostedId || targetId,
          type: callSession.type,
          durationSeconds: callSession.durationSeconds,
          status: 'completed',
        }),
      })
        .then((res) => res.json())
        .then((data) => {
          if (data.log) {
            setCallLogs((prev) => [data.log, ...prev]);
          }
        })
        .catch(() => {});
    }

    if (localStream) {
      localStream.getTracks().forEach((track) => track.stop());
      setLocalStream(null);
    }
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close().catch(() => {});
    }
    setMicVolumeLevel(0);
    setActiveFirestoreCallId(null);

    const remoteName = callSession.remoteName || targetName || 'Anonymous Ghost';
    const remoteId = callSession.remoteGhostedId || targetId || '';
    const callType = callSession.type;

    setCallSession((prev) => ({
      ...prev,
      isActive: false,
      status: 'ended',
      durationSeconds: 0,
    }));

    const isNigeria = checkIsNigeria(user.userCountry || user.country || user.stateCountry);
    if (shouldShowAd(user, isNigeria)) {
      setPendingRatingData({
        callerName: remoteName,
        callerId: remoteId,
        callType,
      });
      setIsCallAdOpen(true);
    } else {
      setCallRatingModal({
        isOpen: true,
        callerName: remoteName,
        callerId: remoteId,
        callType,
      });
    }
  };

  const toggleMute = () => {
    setCallSession((prev) => {
      const nextMuted = !prev.isMuted;
      if (localStream) {
        localStream.getAudioTracks().forEach((t) => {
          t.enabled = !nextMuted;
        });
      }
      return { ...prev, isMuted: nextMuted };
    });
  };

  const toggleVideo = () => {
    setCallSession((prev) => {
      const nextVideo = !prev.isVideoEnabled;
      if (localStream) {
        localStream.getVideoTracks().forEach((t) => {
          t.enabled = nextVideo;
        });
      }
      return { ...prev, isVideoEnabled: nextVideo };
    });
  };

  const COMMUNICATOR_TABS: CommunicatorTab[] = ['all', 'unread', 'favourites', 'groups', 'calls'];
  const activeTabIndex = COMMUNICATOR_TABS.indexOf(activeTab);

  const selectTabByIndex = (index: number) => {
    const clamped = Math.max(0, Math.min(COMMUNICATOR_TABS.length - 1, index));
    setActiveTab(COMMUNICATOR_TABS[clamped]);
  };

  const [copiedLink, setCopiedLink] = useState(false);
  const handleCreateCallLink = () => {
    const callUrl = `${window.location.origin}/call/${user.ghostedId}`;
    if (navigator.share) {
      navigator.share({
        title: 'GHOSTED Encrypted Call',
        text: 'Join my private encrypted call on GHOSTED:',
        url: callUrl,
      }).catch(() => {
        navigator.clipboard.writeText(callUrl);
        setCopiedLink(true);
        setTimeout(() => setCopiedLink(false), 2000);
      });
    } else {
      navigator.clipboard.writeText(callUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const counts = {
    all: sharedConversations.length,
    unread: sharedConversations.filter((c) => c.unreadCount > 0).length,
    favourites: sharedConversations.filter((c) => c.isFavourite).length,
    groups: sharedConversations.filter((c) => c.isGroup).length,
    calls: callLogs.length,
  };

  const tabBarContainerRef = useRef<HTMLDivElement | null>(null);
  const tabButtonRefs = useRef<(HTMLButtonElement | null)[]>([]);

  useEffect(() => {
    const activeBtn = tabButtonRefs.current[activeTabIndex];
    if (activeBtn) {
      activeBtn.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
    }
  }, [activeTabIndex]);

  return (
    <div className="max-w-4xl mx-auto space-y-4 min-h-[100dvh] relative pb-12">
      {/* STICKY TABBAR (WHATSAPP STYLE: ALL, UNREAD, FAVOURITES, GROUPS, CALLS) */}
      <div
        className="sticky -top-4 sm:-top-6 z-30 backdrop-blur-2xl border-b -mx-4 sm:-mx-6 px-4 sm:px-6 py-2.5 shadow-xl transition-all duration-300"
        style={{
          backgroundColor: currentTheme.headerBg,
          borderColor: currentTheme.border,
        }}
      >
        <div className="flex items-center justify-between gap-2 overflow-x-auto scrollbar-none pb-0.5 relative">
          <div
            ref={tabBarContainerRef}
            className="flex items-center space-x-1.5 sm:space-x-2 relative"
          >
            <button
              ref={(el) => {
                tabButtonRefs.current[0] = el;
              }}
              type="button"
              onClick={() => selectTabByIndex(0)}
              className={`py-1.5 px-3.5 sm:px-4 rounded-full text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer active:scale-95 whitespace-nowrap border ${
                activeTab === 'all' ? 'shadow-md scale-102' : 'border-transparent opacity-80 hover:opacity-100'
              }`}
              style={{
                backgroundColor: activeTab === 'all'
                  ? (isGhost ? '#00F5FF' : isBlack ? '#FFFFFF' : '#000000')
                  : (isBlack ? '#F3F4F6' : '#141414'),
                color: activeTab === 'all'
                  ? (isGhost ? '#000000' : isBlack ? '#000000' : '#FFFFFF')
                  : currentTheme.cardSubtext,
                borderColor: currentTheme.border,
              }}
            >
              <span>All</span>
              {counts.all > 0 && (
                <span className="text-[10px] font-mono ml-0.5 opacity-80">({counts.all})</span>
              )}
            </button>

            <button
              ref={(el) => {
                tabButtonRefs.current[1] = el;
              }}
              type="button"
              onClick={() => selectTabByIndex(1)}
              className={`py-1.5 px-3.5 sm:px-4 rounded-full text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer active:scale-95 whitespace-nowrap border ${
                activeTab === 'unread' ? 'shadow-md scale-102' : 'border-transparent opacity-80 hover:opacity-100'
              }`}
              style={{
                backgroundColor: activeTab === 'unread'
                  ? (isGhost ? '#00F5FF' : isBlack ? '#FFFFFF' : '#000000')
                  : (isBlack ? '#F3F4F6' : '#141414'),
                color: activeTab === 'unread'
                  ? (isGhost ? '#000000' : isBlack ? '#000000' : '#FFFFFF')
                  : currentTheme.cardSubtext,
                borderColor: currentTheme.border,
              }}
            >
              <span>Unread</span>
              {counts.unread > 0 && (
                <span className="min-w-[18px] h-4 rounded-full bg-[#25D366] text-black font-extrabold text-[10px] flex items-center justify-center px-1">
                  {counts.unread}
                </span>
              )}
            </button>

            <button
              ref={(el) => {
                tabButtonRefs.current[2] = el;
              }}
              type="button"
              onClick={() => selectTabByIndex(2)}
              className={`py-1.5 px-3.5 sm:px-4 rounded-full text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer active:scale-95 whitespace-nowrap border ${
                activeTab === 'favourites' ? 'shadow-md scale-102' : 'border-transparent opacity-80 hover:opacity-100'
              }`}
              style={{
                backgroundColor: activeTab === 'favourites'
                  ? (isGhost ? '#00F5FF' : isBlack ? '#FFFFFF' : '#000000')
                  : (isBlack ? '#F3F4F6' : '#141414'),
                color: activeTab === 'favourites'
                  ? (isGhost ? '#000000' : isBlack ? '#000000' : '#FFFFFF')
                  : currentTheme.cardSubtext,
                borderColor: currentTheme.border,
              }}
            >
              <Star className={`w-3.5 h-3.5 ${activeTab === 'favourites' ? 'fill-current' : 'text-amber-400 fill-amber-400'}`} />
              <span>Favourites</span>
              {counts.favourites > 0 && (
                <span className="text-[10px] text-amber-400 font-mono ml-0.5">({counts.favourites})</span>
              )}
            </button>

            <button
              ref={(el) => {
                tabButtonRefs.current[3] = el;
              }}
              type="button"
              onClick={() => selectTabByIndex(3)}
              className={`py-1.5 px-3.5 sm:px-4 rounded-full text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer active:scale-95 whitespace-nowrap border ${
                activeTab === 'groups' ? 'shadow-md scale-102' : 'border-transparent opacity-80 hover:opacity-100'
              }`}
              style={{
                backgroundColor: activeTab === 'groups'
                  ? (isGhost ? '#00F5FF' : isBlack ? '#FFFFFF' : '#000000')
                  : (isBlack ? '#F3F4F6' : '#141414'),
                color: activeTab === 'groups'
                  ? (isGhost ? '#000000' : isBlack ? '#000000' : '#FFFFFF')
                  : currentTheme.cardSubtext,
                borderColor: currentTheme.border,
              }}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Groups</span>
              {counts.groups > 0 && (
                <span className="text-[10px] font-mono ml-0.5 opacity-80">({counts.groups})</span>
              )}
            </button>

            <button
              ref={(el) => {
                tabButtonRefs.current[4] = el;
              }}
              type="button"
              onClick={() => selectTabByIndex(4)}
              className={`py-1.5 px-3.5 sm:px-4 rounded-full text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer active:scale-95 whitespace-nowrap border ${
                activeTab === 'calls' ? 'shadow-md scale-102' : 'border-transparent opacity-80 hover:opacity-100'
              }`}
              style={{
                backgroundColor: activeTab === 'calls'
                  ? (isGhost ? '#00F5FF' : isBlack ? '#FFFFFF' : '#000000')
                  : (isBlack ? '#F3F4F6' : '#141414'),
                color: activeTab === 'calls'
                  ? (isGhost ? '#000000' : isBlack ? '#000000' : '#FFFFFF')
                  : currentTheme.cardSubtext,
                borderColor: currentTheme.border,
              }}
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Calls</span>
              {counts.calls > 0 && (
                <span className="text-[10px] font-mono ml-0.5 opacity-80">({counts.calls})</span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* ACTIVE IN-APP CALL OVERLAY */}
      {callSession.isActive && (
        <div className="p-6 rounded-3xl bg-black/80 border border-purple-500/50 text-center space-y-6 animate-in fade-in zoom-in-95 duration-200 shadow-2xl">
          <div className="space-y-1">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-purple-500/20 border border-purple-400/30 text-[10px] font-bold uppercase tracking-wider text-purple-300">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>{callSession.status === 'ringing' ? 'Firestore Signaling: Ringing...' : 'Connected WebRTC Channel'}</span>
            </div>
            <h4 className="text-xl font-bold text-white mt-2">{callSession.remoteName || callSession.remoteGhostedId}</h4>
            <p className="text-xs text-purple-300">
              {callSession.status === 'ringing' ? (
                <span className="animate-pulse text-amber-300 font-medium">
                  Ringing recipient phone... (Auto-timeout in {callTimeoutRemaining}s)
                </span>
              ) : (
                <span className="text-emerald-300 font-mono font-bold text-base">{formatDuration(callSession.durationSeconds)}</span>
              )}
            </p>
          </div>

          {callSession.status === 'ringing' && (
            <div className="max-w-xs mx-auto bg-slate-800 rounded-full h-1.5 overflow-hidden">
              <div
                className="bg-amber-400 h-full transition-all duration-1000"
                style={{ width: `${(callTimeoutRemaining / 30) * 100}%` }}
              />
            </div>
          )}

          {callSession.type === 'video' ? (
            <div className="relative aspect-video max-w-md mx-auto rounded-2xl overflow-hidden bg-purple-950/40 border border-white/20 shadow-inner">
              <div className="w-full h-full flex flex-col items-center justify-center space-y-2 bg-gradient-to-b from-[#1b173d] to-[#0f0c29]">
                <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-purple-500 to-indigo-600 flex items-center justify-center text-white text-2xl font-bold shadow-lg shadow-purple-900/60">
                  {(callSession.remoteName || callSession.remoteGhostedId).slice(0, 2).toUpperCase()}
                </div>
                <span className="text-xs text-purple-200 font-medium">{callSession.remoteName || 'Remote Peer'}</span>
                <span className="text-[10px] text-emerald-400 font-mono">1080p HD • WebRTC Opus</span>
              </div>
              <div className="absolute bottom-3 right-3 w-32 h-24 rounded-xl overflow-hidden bg-black/80 border border-white/30 shadow-2xl">
                {localStream && callSession.isVideoEnabled ? (
                  <video
                    ref={localVideoRef}
                    autoPlay
                    muted
                    playsInline
                    className="w-full h-full object-cover -scale-x-100"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center text-[10px] text-purple-300 p-2 text-center">
                    <VideoOff className="w-4 h-4 text-purple-400 mb-1" />
                    <span>Camera Off</span>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="py-6 space-y-3">
              <div className="flex items-center justify-center space-x-2 h-20">
                {[1, 2, 3, 4, 5, 6, 7].map((bar) => {
                  const activeHeight = Math.max(12, Math.min(64, (micVolumeLevel * (bar % 3 + 1)) * 0.7));
                  return (
                    <div
                      key={bar}
                      style={{ height: `${callSession.status === 'connected' ? activeHeight : 24}px` }}
                      className={`w-2 rounded-full transition-all duration-75 ${
                        bar % 2 === 0 ? 'bg-indigo-400' : 'bg-purple-400'
                      } ${callSession.status === 'ringing' ? 'animate-bounce' : ''}`}
                    />
                  );
                })}
              </div>
              <div className="flex items-center justify-center space-x-2 text-xs text-purple-300">
                <Volume2 className="w-4 h-4 text-emerald-400" />
                <span>Real Microphone Input:</span>
                <span className="font-mono font-bold text-white">
                  {callSession.isMuted ? 'Muted' : `${micVolumeLevel}% Live Audio`}
                </span>
              </div>
            </div>
          )}

          <div className="flex items-center justify-center space-x-4 pt-2">
            <button
              type="button"
              onClick={toggleMute}
              className={`p-3.5 rounded-full transition ${
                callSession.isMuted
                  ? 'bg-rose-500 text-white'
                  : 'bg-white/10 hover:bg-white/20 text-white'
              }`}
              title={callSession.isMuted ? 'Unmute Microphone' : 'Mute Microphone'}
            >
              {callSession.isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>
            {callSession.type === 'video' && (
              <button
                type="button"
                onClick={toggleVideo}
                className={`p-3.5 rounded-full transition ${
                  !callSession.isVideoEnabled
                    ? 'bg-rose-500 text-white'
                    : 'bg-white/10 hover:bg-white/20 text-white'
                }`}
                title={callSession.isVideoEnabled ? 'Disable Camera' : 'Enable Camera'}
              >
                {callSession.isVideoEnabled ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
              </button>
            )}
            <button
              type="button"
              onClick={endCall}
              className="p-4 rounded-full bg-rose-600 hover:bg-rose-700 text-white shadow-lg shadow-rose-600/40 transition hover:scale-105"
              title="End Call"
            >
              <PhoneOff className="w-6 h-6" />
            </button>
          </div>
        </div>
      )}

      {/* WHATSAPP VIEW CONTAINER */}
      <div className="w-full">
        {activeTab === 'calls' ? (
          <div
            className="w-full rounded-3xl border shadow-2xl p-4 sm:p-6 space-y-5 theme-card transition-colors duration-300"
            style={{
              backgroundColor: currentTheme.card,
              color: currentTheme.cardText,
              borderColor: currentTheme.border,
            }}
          >
            <div
              onClick={handleCreateCallLink}
              className="p-3.5 sm:p-4 rounded-2xl border transition flex items-center justify-between cursor-pointer group active:scale-[0.99] duration-200"
              style={{
                backgroundColor: isBlack ? '#F9FAFB' : '#141414',
                borderColor: currentTheme.border,
              }}
            >
              <div className="flex items-center space-x-3.5">
                <div
                  className="w-11 h-11 rounded-full border flex items-center justify-center group-hover:scale-105 transition flex-shrink-0"
                  style={{
                    backgroundColor: isGhost ? '#00F5FF' : isBlack ? '#000000' : '#FFFFFF',
                    color: isGhost ? '#000000' : isBlack ? '#FFFFFF' : '#000000',
                    borderColor: currentTheme.border,
                  }}
                >
                  <ExternalLink className="w-5 h-5 stroke-[2.2]" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold transition hover:underline" style={{ color: currentTheme.cardText }}>
                    Create call link
                  </h4>
                  <p className="text-xs" style={{ color: currentTheme.cardSubtext }}>
                    Share a link for your GHOSTED encrypted call
                  </p>
                </div>
              </div>
              <span
                className="text-xs font-semibold px-2.5 py-1 rounded-xl border"
                style={{
                  backgroundColor: isGhost ? 'rgba(0,245,255,0.1)' : isBlack ? '#E5E7EB' : '#1F2937',
                  color: isGhost ? '#00F5FF' : currentTheme.cardText,
                  borderColor: currentTheme.border,
                }}
              >
                {copiedLink ? 'Copied ✓' : 'Share'}
              </span>
            </div>

            {/* ENCRYPTED CALLS HEADER & FULL-WIDTH RESPONSIVE TABS */}
            <div className="space-y-2.5 border-b pb-3" style={{ borderColor: currentTheme.border }}>
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold flex items-center space-x-2" style={{ color: currentTheme.cardText }}>
                  <Phone className="w-4 h-4 text-emerald-400" />
                  <span>Encrypted Calls</span>
                </h4>
                <span
                  className="text-[10px] font-mono px-2 py-0.5 rounded-full border"
                  style={{
                    borderColor: currentTheme.border,
                    color: currentTheme.cardSubtext,
                  }}
                >
                  Ghosted Only 🔒
                </span>
              </div>

              {/* 3 FULL-WIDTH SUB-TABS FITTING MOBILE SCREEN NORMALLY */}
              <div
                className="grid grid-cols-3 gap-1 p-1 border rounded-2xl w-full"
                style={{
                  backgroundColor: isBlack ? '#F3F4F6' : '#141414',
                  borderColor: currentTheme.border,
                }}
              >
                <button
                  type="button"
                  onClick={() => setCallsSubView('users')}
                  className={`py-1.5 px-1 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-1 cursor-pointer border ${
                    callsSubView === 'users' ? 'shadow-sm' : 'border-transparent opacity-75 hover:opacity-100'
                  }`}
                  style={{
                    backgroundColor: callsSubView === 'users'
                      ? (isGhost ? '#00F5FF' : isBlack ? '#FFFFFF' : '#000000')
                      : 'transparent',
                    color: callsSubView === 'users'
                      ? (isGhost ? '#000000' : isBlack ? '#000000' : '#FFFFFF')
                      : currentTheme.cardSubtext,
                    borderColor: callsSubView === 'users' ? currentTheme.border : 'transparent',
                  }}
                >
                  <Users className="w-3.5 h-3.5 flex-shrink-0" />
                  <span className="truncate">Peers</span>
                  {realGhostUsers.length > 0 && (
                    <span
                      className="text-[10px] px-1.5 py-0.2 rounded-full font-mono border ml-0.5 flex-shrink-0"
                      style={{
                        backgroundColor: isBlack ? '#E5E7EB' : '#000000',
                        color: currentTheme.cardText,
                        borderColor: currentTheme.border,
                      }}
                    >
                      {realGhostUsers.filter((u) => u.id !== user.id).length}
                    </span>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => setCallsSubView('logs')}
                  className={`py-1.5 px-1 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-1 cursor-pointer border ${
                    callsSubView === 'logs' ? 'shadow-sm' : 'border-transparent opacity-75 hover:opacity-100'
                  }`}
                  style={{
                    backgroundColor: callsSubView === 'logs'
                      ? (isGhost ? '#00F5FF' : isBlack ? '#FFFFFF' : '#000000')
                      : 'transparent',
                    color: callsSubView === 'logs'
                      ? (isGhost ? '#000000' : isBlack ? '#000000' : '#FFFFFF')
                      : currentTheme.cardSubtext,
                    borderColor: callsSubView === 'logs' ? currentTheme.border : 'transparent',
                  }}
                >
                  <Clock className="w-3.5 h-3.5 flex-shrink-0" />
                  <span className="truncate">History</span>
                  {realCallHistory.length > 0 && (
                    <span
                      className="text-[10px] px-1.5 py-0.2 rounded-full font-mono border ml-0.5 flex-shrink-0"
                      style={{
                        backgroundColor: isBlack ? '#E5E7EB' : '#000000',
                        color: currentTheme.cardText,
                        borderColor: currentTheme.border,
                      }}
                    >
                      {realCallHistory.length}
                    </span>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => setCallsSubView('lab')}
                  className={`py-1.5 px-1 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-1 cursor-pointer border ${
                    callsSubView === 'lab' ? 'shadow-sm' : 'border-transparent opacity-75 hover:opacity-100'
                  }`}
                  style={{
                    backgroundColor: callsSubView === 'lab'
                      ? (isGhost ? '#00F5FF' : isBlack ? '#FFFFFF' : '#000000')
                      : 'transparent',
                    color: callsSubView === 'lab'
                      ? (isGhost ? '#000000' : isBlack ? '#000000' : '#FFFFFF')
                      : currentTheme.cardSubtext,
                    borderColor: callsSubView === 'lab' ? currentTheme.border : 'transparent',
                  }}
                >
                  <Zap className="w-3.5 h-3.5 flex-shrink-0" />
                  <span className="truncate">Call Lab</span>
                </button>
              </div>
            </div>

            {/* 1. REAL GHOST USERS TAB (Ghosted Only, Private In-App Calls) */}
            {callsSubView === 'users' && (
              <div className="space-y-3">
                {/* Search Registered Ghosts */}
                <div className="relative w-full">
                  <Search
                    className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none opacity-50"
                    style={{ color: currentTheme.cardText }}
                  />
                  <input
                    type="text"
                    value={ghostUserSearch}
                    onChange={(e) => setGhostUserSearch(e.target.value)}
                    placeholder="Search Ghosted peers by Ghost Name or Ghost ID..."
                    className="w-full pl-10 pr-4 py-2.5 rounded-2xl border text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-[#1877F2]"
                    style={{
                      backgroundColor: isBlack ? '#FFFFFF' : '#000000',
                      color: currentTheme.cardText,
                      borderColor: currentTheme.border,
                    }}
                  />
                </div>

                <div className="flex items-center justify-between pb-1 border-b text-xs" style={{ borderColor: currentTheme.border, color: currentTheme.cardSubtext }}>
                  <span>Registered Ghosted Users ({realGhostUsers.filter((u) => u.id !== user.id).length})</span>
                  <span className="text-[11px] font-mono">Real-time WebRTC Call Channels</span>
                </div>

                <div className="space-y-2">
                  {realGhostUsers
                    .filter(
                      (u) =>
                        u.id !== user.id &&
                        (u.ghost_name.toLowerCase().includes(ghostUserSearch.toLowerCase()) ||
                          u.ghost_id.toLowerCase().includes(ghostUserSearch.toLowerCase()))
                    )
                    .map((targetGhost) => (
                      <div
                        key={targetGhost.id}
                        className="p-3 sm:p-3.5 rounded-2xl border flex items-center justify-between gap-3 transition shadow-xs"
                        style={{
                          backgroundColor: isBlack ? '#F9FAFB' : '#141414',
                          borderColor: currentTheme.border,
                        }}
                      >
                        <div className="flex items-center space-x-3 min-w-0 flex-1">
                          <div className="relative flex-shrink-0">
                            <div
                              className="w-11 h-11 rounded-full overflow-hidden flex items-center justify-center font-bold text-sm shadow-md border"
                              style={{
                                backgroundColor: isBlack ? '#FFFFFF' : '#000000',
                                color: currentTheme.cardText,
                                borderColor: currentTheme.border,
                              }}
                            >
                              <img
                                src={targetGhost.avatar}
                                alt={targetGhost.ghost_name}
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <span
                              className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 ${
                                targetGhost.is_online !== false ? 'bg-emerald-500' : 'bg-gray-500'
                              }`}
                              style={{ borderColor: isBlack ? '#F9FAFB' : '#141414' }}
                            />
                          </div>

                          <div className="min-w-0 flex-1">
                            <div className="flex items-center space-x-2">
                              <h5 className="text-sm font-bold truncate" style={{ color: currentTheme.cardText }}>
                                {targetGhost.ghost_name}
                              </h5>
                              <span
                                className="text-[10px] font-mono px-2 py-0.5 rounded-full border flex-shrink-0"
                                style={{
                                  backgroundColor: isBlack ? '#E5E7EB' : '#000000',
                                  color: currentTheme.cardText,
                                  borderColor: currentTheme.border,
                                }}
                              >
                                {targetGhost.is_public_id ? targetGhost.ghost_id : 'ID: Private 🔒'}
                              </span>
                            </div>
                            <p className="text-[11px] truncate mt-0.5" style={{ color: currentTheme.cardSubtext }}>
                              {targetGhost.bio || 'Encrypted Ghosted Peer • Pure in-app call'}
                            </p>
                          </div>
                        </div>

                        {/* ONLY 2 BUTTONS: [Voice Call] [Video Call] - PURE GHOSTED IN-APP */}
                        <div className="flex items-center space-x-1.5 flex-shrink-0">
                          <button
                            type="button"
                            onClick={() =>
                              startFirestoreSignalingCall(targetGhost.id, targetGhost.ghost_name, 'voice')
                            }
                            className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center space-x-1.5 transition cursor-pointer shadow-md active:scale-95"
                            title="Voice Call"
                          >
                            <Phone className="w-3.5 h-3.5" />
                            <span className="hidden sm:inline">Voice Call</span>
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              startFirestoreSignalingCall(targetGhost.id, targetGhost.ghost_name, 'video')
                            }
                            className="px-3 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-500 hover:to-cyan-500 text-white font-bold text-xs flex items-center space-x-1.5 transition cursor-pointer shadow-md active:scale-95"
                            title="Video Call"
                          >
                            <Video className="w-3.5 h-3.5" />
                            <span className="hidden sm:inline">Video Call</span>
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            )}

            {/* 2. REAL CALL HISTORY (From Firestore calls table) */}
            {callsSubView === 'logs' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between pb-1 border-b text-xs" style={{ borderColor: currentTheme.border, color: currentTheme.cardSubtext }}>
                  <span>Encrypted Call History ({realCallHistory.length})</span>
                  <span className="text-[11px] font-mono">Real database records</span>
                </div>
                {realCallHistory.length === 0 ? (
                  <div
                    className="text-center py-12 text-xs space-y-2 rounded-2xl border"
                    style={{
                      backgroundColor: isBlack ? '#F9FAFB' : '#141414',
                      borderColor: currentTheme.border,
                      color: currentTheme.cardSubtext,
                    }}
                  >
                    <div
                      className="w-12 h-12 rounded-full border flex items-center justify-center mx-auto"
                      style={{
                        backgroundColor: isBlack ? '#FFFFFF' : '#000000',
                        borderColor: currentTheme.border,
                        color: currentTheme.cardText,
                      }}
                    >
                      <Phone className="w-6 h-6 text-emerald-400" />
                    </div>
                    <p className="font-semibold text-sm" style={{ color: currentTheme.cardText }}>
                      No call history yet
                    </p>
                    <p className="text-[11px] max-w-xs mx-auto" style={{ color: currentTheme.cardSubtext }}>
                      Tap "Ghosted Peers" above to start a secure voice or video call with any registered user.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-1.5 pr-1">
                    {realCallHistory.map((call) => {
                      const isOutgoing = call.caller_id === user.id;
                      const peerName = isOutgoing
                        ? call.receiver_name || call.receiver_id
                        : call.caller_name || call.caller_id;
                      const isMissed =
                        call.status === 'missed' || call.status === 'declined' || call.status === 'timeout';
                      const targetIdForCallback = isOutgoing ? call.receiver_id : call.caller_id;

                      return (
                        <div
                          key={call.id}
                          className="p-3 sm:p-3.5 rounded-2xl border flex items-center justify-between gap-3 transition"
                          style={{
                            backgroundColor: isBlack ? '#F9FAFB' : '#141414',
                            borderColor: currentTheme.border,
                          }}
                        >
                          <div className="flex items-center space-x-3 min-w-0 flex-1">
                            <div
                              className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm shadow-md flex-shrink-0 border"
                              style={{
                                backgroundColor: isBlack ? '#FFFFFF' : '#000000',
                                color: currentTheme.cardText,
                                borderColor: currentTheme.border,
                              }}
                            >
                              {call.type === 'video' ? (
                                <Video className="w-4 h-4 text-cyan-400" />
                              ) : (
                                <Phone className="w-4 h-4 text-emerald-400" />
                              )}
                            </div>
                            <div className="min-w-0 flex-1">
                              <h5
                                className="text-sm font-semibold truncate"
                                style={{ color: isMissed ? '#F43F5E' : currentTheme.cardText }}
                              >
                                {peerName}
                              </h5>
                              <div className="flex items-center space-x-1.5 text-xs font-medium mt-0.5" style={{ color: currentTheme.cardSubtext }}>
                                <span className={isMissed ? 'text-rose-500 font-bold' : 'text-emerald-400 font-bold'}>
                                  {isMissed ? '↙ Missed' : isOutgoing ? '↗ Outgoing' : '↙ Incoming'} ({call.type})
                                </span>
                                <span>•</span>
                                <span>
                                  {new Date(call.time).toLocaleDateString([], { month: 'short', day: 'numeric' })},{' '}
                                  {new Date(call.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </span>
                                {call.duration > 0 && <span>• {formatDuration(call.duration)}</span>}
                              </div>
                            </div>
                          </div>

                          {/* Only 2 buttons: [Voice Call] [Video Call] */}
                          <div className="flex items-center space-x-1 flex-shrink-0">
                            <button
                              type="button"
                              onClick={() => startFirestoreSignalingCall(targetIdForCallback, peerName, 'voice')}
                              className="p-2.5 rounded-full hover:bg-emerald-500/20 text-emerald-400 transition cursor-pointer"
                              title="Voice Call"
                            >
                              <Phone className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => startFirestoreSignalingCall(targetIdForCallback, peerName, 'video')}
                              className="p-2.5 rounded-full hover:bg-cyan-500/20 text-cyan-400 transition cursor-pointer"
                              title="Video Call"
                            >
                              <Video className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* 3. CALL LAB SUBVIEW */}
            {callsSubView === 'lab' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-white/10">
                  <h4 className="text-sm font-bold text-white flex items-center space-x-2">
                    <span>🧪</span>
                    <span>Simultaneous 2-Phone WebRTC Call Lab</span>
                  </h4>
                </div>
                <DualDeviceCallTester />
              </div>
            )}
          </div>
        ) : (
          <ChatHub
            user={user}
            letters={letters}
            forcedSection={activeTab === 'favourites' ? 'favourite' : activeTab}
            sharedConversations={sharedConversations}
            setSharedConversations={setSharedConversations}
            sharedMessages={sharedMessages}
            setSharedMessages={setSharedMessages}
            isPrimaryListener={true}
            onStartCall={(contactId, contactName, type) => {
              startFirestoreSignalingCall(contactId, contactName, type);
            }}
            onSelectContactForDialer={(id, name) => {
              setTargetId(id);
              setTargetName(name);
              setActiveTab('calls');
              setCallsSubView('users');
            }}
          />
        )}
      </div>

      {incomingCallDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-200">
          <div className="w-full max-w-sm rounded-3xl bg-slate-900 border-2 border-purple-500/60 p-6 text-center space-y-6 shadow-2xl relative overflow-hidden">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-purple-500/20 border border-purple-400/40 text-[10px] font-bold uppercase tracking-wider text-amber-300">
              <PhoneCall className="w-3 h-3 animate-pulse text-amber-300" />
              <span>Incoming Encrypted Call</span>
            </div>
            <div className="relative w-28 h-28 mx-auto flex items-center justify-center">
              <div className="absolute inset-0 rounded-full bg-purple-500/20 animate-ping" />
              <div className="absolute -inset-2 rounded-full border-2 border-purple-400/30 animate-pulse" />
              <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-purple-600 via-indigo-600 to-pink-600 flex items-center justify-center text-white shadow-2xl shadow-purple-500/50">
                <Volume2 className="w-10 h-10 animate-bounce text-amber-300" />
              </div>
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">{incomingCallDoc.callerName}</h3>
              <p className="text-xs text-purple-300 font-mono mt-0.5">{incomingCallDoc.callerId}</p>
              <p className="text-[11px] text-emerald-400 mt-2 font-medium flex items-center justify-center space-x-1">
                <span>Ringtone & Vibration Active</span>
              </p>
            </div>
            <div className="bg-slate-800/80 rounded-xl p-3 border border-purple-500/30 text-xs">
              <div className="flex items-center justify-between text-purple-200 mb-1">
                <span className="flex items-center space-x-1">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span>Auto-Timeout:</span>
                </span>
                <span className="font-mono font-bold text-amber-300">{incomingTimeoutRemaining}s</span>
              </div>
              <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
                <div
                  className="bg-amber-400 h-full transition-all duration-1000"
                  style={{ width: `${(incomingTimeoutRemaining / 30) * 100}%` }}
                />
              </div>
            </div>
            <div className="flex items-center justify-center space-x-4 pt-2">
              <button
                type="button"
                onClick={declineCall}
                className="flex-1 py-3.5 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm shadow-lg shadow-red-500/40 flex items-center justify-center space-x-2 transition cursor-pointer"
              >
                <PhoneOff className="w-5 h-5" />
                <span>Decline</span>
              </button>
              <button
                type="button"
                onClick={acceptCall}
                className="flex-1 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm shadow-xl shadow-emerald-500/40 flex items-center justify-center space-x-2 transition cursor-pointer animate-pulse"
              >
                <Phone className="w-5 h-5" />
                <span>Answer</span>
              </button>
            </div>
          </div>
        </div>
      )}

      <SmartAdInterstitial
        context="call"
        isOpen={isCallAdOpen}
        onClose={() => {
          setIsCallAdOpen(false);
          if (pendingRatingData) {
            setCallRatingModal({
              isOpen: true,
              callerName: pendingRatingData.callerName,
              callerId: pendingRatingData.callerId,
              callType: pendingRatingData.callType,
            });
            setPendingRatingData(null);
          }
        }}
      />

      {callRatingModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-sm rounded-3xl bg-[#120d2b] border border-purple-500/50 p-6 text-center space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-purple-500/20 text-purple-300 flex items-center justify-center text-2xl mx-auto shadow-inner">
              ⭐
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Call Ended • Feedback</h3>
              <p className="text-xs text-purple-300/80 mt-0.5">
                Rate your connection with <strong>{callRatingModal.callerName}</strong>
              </p>
            </div>
            <div className="p-3 rounded-2xl bg-black/40 border border-white/10 space-y-2">
              <span className="text-xs font-semibold text-purple-200 block">
                Was this caller supportive & respectful?
              </span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setIsCallSupportive(true)}
                  className={`py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-1.5 ${
                    isCallSupportive
                      ? 'bg-emerald-600 text-white shadow-md'
                      : 'bg-white/5 text-purple-300 hover:bg-white/10'
                  }`}
                >
                  <span>Yes, Supportive ✨</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsCallSupportive(false)}
                  className={`py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-1.5 ${
                    !isCallSupportive
                      ? 'bg-rose-600 text-white shadow-md'
                      : 'bg-white/5 text-purple-300 hover:bg-white/10'
                  }`}
                >
                  <span>Needs Work ⚠️</span>
                </button>
              </div>
            </div>

            <div className="space-y-1">
              <span className="text-[11px] text-purple-300 font-medium">Audio Quality Rating</span>
              <div className="flex items-center justify-center space-x-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setCallRatingStars(star)}
                    className="p-1 text-2xl transition hover:scale-125 cursor-pointer"
                  >
                    <span className={star <= callRatingStars ? 'text-amber-400' : 'text-white/20'}>
                      ★
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setCallRatingModal({ isOpen: false, callerName: '', callerId: '', callType: 'voice' });
              }}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg transition active:scale-95"
            >
              Submit Rating & Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
