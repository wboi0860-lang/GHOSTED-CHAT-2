import React, { useState, useEffect } from 'react';
import {
  Shield,
  Eye,
  EyeOff,
  Sparkles,
  RefreshCw,
  Lock,
  User,
  Mail,
  CheckCircle2,
  AlertCircle,
  X,
  Ghost,
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import {
  signUpGhostUser,
  loginGhostUser,
  generateUniqueGhostId,
} from '../services/ghostService';
import { GhostUserDoc, UserProfile } from '../types';

interface PrivateAuthModalProps {
  isOpen: boolean;
  onClose?: () => void;
  onSuccess: (userDoc: GhostUserDoc) => void;
  initialMode?: 'signup' | 'login';
  canClose?: boolean;
}

const PRESET_AVATARS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=250&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=250&q=80',
  'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=250&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=250&q=80',
];

export const PrivateAuthModal: React.FC<PrivateAuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  initialMode = 'signup',
  canClose = false,
}) => {
  const { currentTheme, isBlack, isGhost } = useTheme();
  const [mode, setMode] = useState<'signup' | 'login'>(initialMode);

  // Form states
  const [ghostName, setGhostName] = useState('');
  const [autoGhostId, setAutoGhostId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [optionalEmail, setOptionalEmail] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState(PRESET_AVATARS[0]);

  // Login states
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // UI status
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Initialize auto Ghost ID on load
  useEffect(() => {
    setAutoGhostId(generateUniqueGhostId());
  }, []);

  const handleRegenerateId = () => {
    setAutoGhostId(generateUniqueGhostId());
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!ghostName.trim()) {
      setErrorMessage('Please enter a Ghost Name.');
      return;
    }
    if (password.length < 4) {
      setErrorMessage('Password must be at least 4 characters.');
      return;
    }

    setIsSubmitting(true);
    const res = await signUpGhostUser({
      ghost_name: ghostName.trim(),
      password,
      email: optionalEmail.trim() || undefined,
      avatar: selectedAvatar,
    });

    setIsSubmitting(false);
    if (!res.success || !res.user) {
      setErrorMessage(res.error || 'Failed to create account.');
      return;
    }

    setSuccessMessage(`Welcome, ${res.user.ghost_name}! Your ID is ${res.user.ghost_id}`);
    setTimeout(() => {
      onSuccess(res.user!);
    }, 700);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);

    if (!loginIdentifier.trim()) {
      setErrorMessage('Please enter your Ghost Name or Ghost ID.');
      return;
    }
    if (!loginPassword) {
      setErrorMessage('Please enter your password.');
      return;
    }

    setIsSubmitting(true);
    const res = await loginGhostUser(loginIdentifier.trim(), loginPassword);
    setIsSubmitting(false);

    if (!res.success || !res.user) {
      setErrorMessage(res.error || 'Login failed.');
      return;
    }

    setSuccessMessage(`Welcome back, ${res.user.ghost_name}!`);
    setTimeout(() => {
      onSuccess(res.user!);
    }, 700);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-md rounded-3xl border p-5 sm:p-6 shadow-2xl relative overflow-hidden theme-card space-y-4 max-h-[92vh] overflow-y-auto"
        style={{
          backgroundColor: currentTheme.card,
          borderColor: currentTheme.border,
          color: currentTheme.cardText,
        }}
      >
        {/* Top Header */}
        <div className="flex items-center justify-between pb-3 border-b" style={{ borderColor: currentTheme.border }}>
          <div className="flex items-center space-x-2.5">
            <div
              className="w-9 h-9 rounded-2xl flex items-center justify-center shadow-md border"
              style={{
                backgroundColor: isGhost ? '#00F5FF' : isBlack ? '#000000' : '#FFFFFF',
                color: isGhost ? '#000000' : isBlack ? '#FFFFFF' : '#000000',
                borderColor: currentTheme.border,
              }}
            >
              <Ghost className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black tracking-tight" style={{ color: currentTheme.cardText }}>
                {mode === 'signup' ? 'Private Ghost Sign Up' : 'Ghosted Log In'}
              </h3>
              <p className="text-[11px] font-medium" style={{ color: currentTheme.cardSubtext }}>
                Zero phone numbers • Real anonymous database
              </p>
            </div>
          </div>

          {canClose && onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-full transition cursor-pointer hover:opacity-75"
              style={{ color: currentTheme.cardSubtext }}
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Tab Switcher: Sign Up vs Log In */}
        <div
          className="grid grid-cols-2 p-1 rounded-2xl border"
          style={{
            backgroundColor: isBlack ? '#F3F4F6' : '#141414',
            borderColor: currentTheme.border,
          }}
        >
          <button
            type="button"
            onClick={() => {
              setMode('signup');
              setErrorMessage(null);
            }}
            className={`py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              mode === 'signup' ? 'shadow-md scale-102 border' : 'opacity-70 hover:opacity-100'
            }`}
            style={{
              backgroundColor: mode === 'signup'
                ? (isGhost ? '#00F5FF' : isBlack ? '#FFFFFF' : '#000000')
                : 'transparent',
              color: mode === 'signup'
                ? (isGhost ? '#000000' : isBlack ? '#000000' : '#FFFFFF')
                : currentTheme.cardSubtext,
              borderColor: mode === 'signup' ? currentTheme.border : 'transparent',
            }}
          >
            Create Account
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setErrorMessage(null);
            }}
            className={`py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              mode === 'login' ? 'shadow-md scale-102 border' : 'opacity-70 hover:opacity-100'
            }`}
            style={{
              backgroundColor: mode === 'login'
                ? (isGhost ? '#00F5FF' : isBlack ? '#FFFFFF' : '#000000')
                : 'transparent',
              color: mode === 'login'
                ? (isGhost ? '#000000' : isBlack ? '#000000' : '#FFFFFF')
                : currentTheme.cardSubtext,
              borderColor: mode === 'login' ? currentTheme.border : 'transparent',
            }}
          >
            Log In
          </button>
        </div>

        {/* Error / Success Feedback */}
        {errorMessage && (
          <div className="p-3 rounded-2xl bg-rose-500/15 border border-rose-500/40 text-rose-400 text-xs flex items-center space-x-2 animate-in fade-in">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}
        {successMessage && (
          <div className="p-3 rounded-2xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-400 text-xs flex items-center space-x-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* 1. SIGN UP FORM */}
        {mode === 'signup' ? (
          <form onSubmit={handleSignUp} className="space-y-3.5">
            {/* Ghost Name */}
            <div>
              <label className="block text-xs font-semibold mb-1" style={{ color: currentTheme.cardText }}>
                Ghost Name <span className="text-rose-400">*</span> (Unique)
              </label>
              <div className="relative">
                <User className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none opacity-50" />
                <input
                  type="text"
                  value={ghostName}
                  onChange={(e) => setGhostName(e.target.value)}
                  placeholder="e.g. Phantom_Soul"
                  required
                  className="w-full pl-9 pr-3.5 py-2.5 border rounded-xl text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-[#1877F2]"
                  style={{
                    backgroundColor: isBlack ? '#FFFFFF' : '#000000',
                    color: currentTheme.cardText,
                    borderColor: currentTheme.border,
                  }}
                />
              </div>
              <p className="text-[10px] mt-0.5" style={{ color: currentTheme.cardSubtext }}>
                Your public display handle in the void. Must be unique.
              </p>
            </div>

            {/* Auto-generated Ghost ID (Auto Ghost#1234) */}
            <div>
              <label className="block text-xs font-semibold mb-1" style={{ color: currentTheme.cardText }}>
                Ghost ID (Auto-Generated)
              </label>
              <div
                className="flex items-center justify-between p-2.5 rounded-xl border"
                style={{
                  backgroundColor: isBlack ? '#F3F4F6' : '#141414',
                  borderColor: currentTheme.border,
                }}
              >
                <div className="flex items-center space-x-2">
                  <Shield className="w-4 h-4 text-emerald-400" />
                  <span className="font-mono text-xs sm:text-sm font-bold" style={{ color: currentTheme.cardText }}>
                    {autoGhostId}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleRegenerateId}
                  className="p-1 rounded-lg text-xs flex items-center space-x-1 hover:opacity-80 transition cursor-pointer"
                  style={{ color: currentTheme.cardSubtext }}
                  title="Generate new ID"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span className="text-[10px]">Change</span>
                </button>
              </div>
              <div
                className="mt-1 p-2 rounded-xl border flex items-center space-x-2 text-[10px]"
                style={{
                  backgroundColor: isBlack ? '#F9FAFB' : '#0B0B0B',
                  borderColor: currentTheme.border,
                  color: currentTheme.cardSubtext,
                }}
              >
                <Lock className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                <span>
                  <strong>Private by default:</strong> Stored as private in database. Other users cannot see your ID unless you share it.
                </span>
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-semibold mb-1" style={{ color: currentTheme.cardText }}>
                Password <span className="text-rose-400">*</span>
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none opacity-50" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 4 characters"
                  required
                  className="w-full pl-9 pr-10 py-2.5 border rounded-xl text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-[#1877F2]"
                  style={{
                    backgroundColor: isBlack ? '#FFFFFF' : '#000000',
                    color: currentTheme.cardText,
                    borderColor: currentTheme.border,
                  }}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 opacity-60 hover:opacity-100 transition cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Optional Email (Private, never shown) */}
            <div>
              <label className="block text-xs font-semibold mb-1" style={{ color: currentTheme.cardText }}>
                Optional Email <span className="text-[10px] font-normal opacity-70">(Private, Never Shown)</span>
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none opacity-50" />
                <input
                  type="email"
                  value={optionalEmail}
                  onChange={(e) => setOptionalEmail(e.target.value)}
                  placeholder="Optional email for recovery only"
                  className="w-full pl-9 pr-3.5 py-2.5 border rounded-xl text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-[#1877F2]"
                  style={{
                    backgroundColor: isBlack ? '#FFFFFF' : '#000000',
                    color: currentTheme.cardText,
                    borderColor: currentTheme.border,
                  }}
                />
              </div>
              <p className="text-[10px] mt-0.5" style={{ color: currentTheme.cardSubtext }}>
                🔒 Never exposed in profile, chats, or calls. Pure anonymity.
              </p>
            </div>

            {/* Avatar Selection */}
            <div>
              <label className="block text-xs font-semibold mb-1.5" style={{ color: currentTheme.cardText }}>
                Choose Avatar
              </label>
              <div className="flex items-center space-x-2 overflow-x-auto pb-1">
                {PRESET_AVATARS.map((av, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setSelectedAvatar(av)}
                    className={`w-11 h-11 rounded-2xl overflow-hidden border-2 transition cursor-pointer flex-shrink-0 ${
                      selectedAvatar === av ? 'ring-2 ring-[#1877F2] scale-105' : 'opacity-70 hover:opacity-100'
                    }`}
                    style={{ borderColor: selectedAvatar === av ? '#1877F2' : currentTheme.border }}
                  >
                    <img src={av} alt="avatar" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 rounded-2xl font-bold text-xs sm:text-sm shadow-xl transition flex items-center justify-center space-x-2 active:scale-95 cursor-pointer disabled:opacity-50 border mt-2"
              style={{
                backgroundColor: currentTheme.btnPrimaryBg,
                color: currentTheme.btnPrimaryText,
                borderColor: currentTheme.border,
              }}
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                  <span>Securing Identity...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Create Anonymous Ghost Account</span>
                </>
              )}
            </button>
          </form>
        ) : (
          /* 2. LOG IN FORM */
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold mb-1" style={{ color: currentTheme.cardText }}>
                Ghost Name or Ghost ID
              </label>
              <div className="relative">
                <User className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none opacity-50" />
                <input
                  type="text"
                  value={loginIdentifier}
                  onChange={(e) => setLoginIdentifier(e.target.value)}
                  placeholder="e.g. Phantom_Vision or Ghost#8902"
                  required
                  className="w-full pl-9 pr-3.5 py-2.5 border rounded-xl text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-[#1877F2]"
                  style={{
                    backgroundColor: isBlack ? '#FFFFFF' : '#000000',
                    color: currentTheme.cardText,
                    borderColor: currentTheme.border,
                  }}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1" style={{ color: currentTheme.cardText }}>
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none opacity-50" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="Enter your password"
                  required
                  className="w-full pl-9 pr-10 py-2.5 border rounded-xl text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-[#1877F2]"
                  style={{
                    backgroundColor: isBlack ? '#FFFFFF' : '#000000',
                    color: currentTheme.cardText,
                    borderColor: currentTheme.border,
                  }}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 opacity-60 hover:opacity-100 transition cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 rounded-2xl font-bold text-xs sm:text-sm shadow-xl transition flex items-center justify-center space-x-2 active:scale-95 cursor-pointer disabled:opacity-50 border mt-2"
              style={{
                backgroundColor: currentTheme.btnPrimaryBg,
                color: currentTheme.btnPrimaryText,
                borderColor: currentTheme.border,
              }}
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                  <span>Logging In...</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  <span>Log In to Ghosted</span>
                </>
              )}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
