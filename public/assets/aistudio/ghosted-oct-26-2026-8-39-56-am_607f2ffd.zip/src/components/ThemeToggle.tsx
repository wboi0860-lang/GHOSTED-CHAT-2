import React, { useState, useRef, useEffect } from 'react';
import { useTheme } from '../context/ThemeContext';
import { Sun, Moon, Sparkles, Check } from 'lucide-react';
import { ThemeId } from '../utils/theme';

export const ThemeToggle: React.FC = () => {
  const { theme, setTheme, cycleTheme, isGhost, isDark } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleOutsideClick);
    }
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, [isOpen]);

  const themes: Array<{ id: ThemeId; name: string; icon: string; desc: string }> = [
    { id: 'white', name: 'White Theme (Light)', icon: '☀️', desc: 'White page, black cards, white text inside' },
    { id: 'black', name: 'Black Theme (Dark)', icon: '🌙', desc: 'Black page, white cards, black text inside' },
    { id: 'ghost', name: 'Ghost Theme (Neon)', icon: '👻', desc: 'Purple page, black cards, cyan/purple glow' },
  ];

  return (
    <div ref={containerRef} className="relative inline-flex items-center">
      {/* HEADER THEME BUTTON */}
      <button
        type="button"
        onClick={() => cycleTheme()}
        onContextMenu={(e) => {
          e.preventDefault();
          setIsOpen(!isOpen);
        }}
        className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-full text-xs font-bold transition-all duration-300 cursor-pointer active:scale-95 shadow-xs border select-none ${
          isGhost
            ? 'bg-[#15151F] border-[#2A2A3F] text-[#00F5FF] shadow-[0_0_12px_rgba(124,58,237,0.3)] hover:shadow-[0_0_18px_rgba(0,245,255,0.4)]'
            : isDark
            ? 'bg-[#3A3B3C] border-[#3E4042] text-[#E4E6EB] hover:bg-[#4E4F50]'
            : 'bg-[#F0F2F5] border-[#E4E6EB] text-[#050505] hover:bg-[#E4E6EB]'
        }`}
        title={`Current Theme: ${theme}. Tap to switch theme!`}
      >
        <span className="text-sm transition-transform duration-300 hover:rotate-12 inline-block">
          {theme === 'white' ? '☀️' : theme === 'black' ? '🌙' : '👻'}
        </span>
        <span className="hidden sm:inline font-bold">
          {theme === 'white' ? 'White' : theme === 'black' ? 'Black' : 'Ghost'}
        </span>
      </button>

      {/* QUICK SELECTOR DROPDOWN (Click 3-dots or long-tap / right click) */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`ml-1 p-1 rounded-full text-xs transition cursor-pointer ${
          isDark ? 'text-zinc-400 hover:text-white' : 'text-gray-400 hover:text-black'
        }`}
        title="Open theme menu"
      >
        <span className="text-[10px]">▼</span>
      </button>

      {isOpen && (
        <div
          className={`absolute right-0 top-full mt-2 w-64 rounded-2xl p-2 shadow-2xl border z-50 text-left animate-in fade-in zoom-in-95 duration-200 ${
            isGhost
              ? 'bg-[#15151F] border-[#2A2A3F] text-[#E0E0FF] shadow-[0_10px_35px_rgba(0,0,0,0.8),0_0_20px_rgba(124,58,237,0.25)]'
              : isDark
              ? 'bg-[#242526] border-[#3E4042] text-[#E4E6EB]'
              : 'bg-white border-[#E4E6EB] text-[#050505]'
          }`}
        >
          <div className="px-2.5 py-1.5 border-b border-white/10 mb-1 flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider opacity-70">Switch Theme</span>
            <span className="text-[10px] opacity-60">3 Themes</span>
          </div>
          <div className="space-y-1">
            {themes.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => {
                  setTheme(t.id);
                  setIsOpen(false);
                }}
                className={`w-full p-2 rounded-xl text-left flex items-center justify-between transition cursor-pointer text-xs font-semibold ${
                  theme === t.id
                    ? isGhost
                      ? 'bg-[#7C3AED]/25 text-[#00F5FF] border border-[#00F5FF]/40 shadow-[0_0_10px_rgba(0,245,255,0.2)]'
                      : isDark
                      ? 'bg-[#3A3B3C] text-white font-bold'
                      : 'bg-[#E7F3FF] text-[#0866FF] font-bold'
                    : isDark
                    ? 'hover:bg-white/5 text-zinc-300'
                    : 'hover:bg-gray-100 text-gray-700'
                }`}
              >
                <div className="flex items-center space-x-2.5">
                  <span className="text-base">{t.icon}</span>
                  <div>
                    <span className="block font-bold">{t.name}</span>
                    <span className="text-[10px] opacity-70 block">{t.desc}</span>
                  </div>
                </div>
                {theme === t.id && (
                  <Check className={`w-4 h-4 stroke-[2.5] ${isGhost ? 'text-[#00F5FF]' : isDark ? 'text-white' : 'text-[#0866FF]'}`} />
                )}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
