import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { GhostPost, GhostPostComment, UserProfile, UserSticker } from '../types';
import {
  Heart,
  Send,
  Clock,
  Sparkles,
  ShieldAlert,
  ChevronDown,
  Trash2,
  Image as ImageIcon,
  AtSign,
  Smile,
  Plus,
  Play,
  X,
  ExternalLink,
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { StickerCreatorModal } from './StickerCreatorModal';

interface CommentBottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  post: GhostPost;
  user: UserProfile;
  comments: GhostPostComment[];
  onAddComment: (
    postId: string,
    text: string,
    isGhost: boolean,
    expiryHours?: number,
    attachments?: {
      imageUrl?: string;
      stickerUrl?: string;
      stickerType?: 'ghost' | 'custom_image' | 'live';
      stickerTitle?: string;
      mentionedProfileId?: string;
      mentionedVideoUrl?: string;
    }
  ) => void;
  onDeleteComment?: (postId: string, commentId: string) => void;
  onLikeToggle: (postId: string) => void;
  onSharePost: (post: GhostPost) => void;
}

const DEFAULT_GHOST_STICKERS: UserSticker[] = [
  { id: 'stk-ghost-1', title: 'Floating Ghost', imageUrl: '👻', type: 'ghost', isLive: true, createdAt: 1 },
  { id: 'stk-ghost-2', title: 'Candlelight Spirit', imageUrl: '🕯️', type: 'ghost', isLive: true, createdAt: 2 },
  { id: 'stk-ghost-3', title: 'Void Portal', imageUrl: '🌌', type: 'ghost', isLive: true, createdAt: 3 },
  { id: 'stk-ghost-4', title: 'Phantom Heart', imageUrl: '💔', type: 'ghost', isLive: true, createdAt: 4 },
  { id: 'stk-ghost-5', title: 'Crystal Sphere', imageUrl: '🔮', type: 'ghost', isLive: true, createdAt: 5 },
  { id: 'stk-ghost-6', title: 'Angelic Ghost', imageUrl: '🪽', type: 'ghost', isLive: true, createdAt: 6 },
  { id: 'stk-ghost-7', title: 'Electric Shock', imageUrl: '⚡', type: 'ghost', isLive: true, createdAt: 7 },
  { id: 'stk-ghost-8', title: 'Peaceful Rest', imageUrl: '🕊️', type: 'ghost', isLive: true, createdAt: 8 },
  { id: 'stk-ghost-9', title: 'Phantom Mask', imageUrl: '🎭', type: 'ghost', isLive: true, createdAt: 9 },
  { id: 'stk-ghost-10', title: 'Shielded Soul', imageUrl: '🛡️', type: 'ghost', isLive: true, createdAt: 10 },
];

export const CommentBottomSheet: React.FC<CommentBottomSheetProps> = ({
  isOpen,
  onClose,
  post,
  user,
  comments,
  onAddComment,
  onDeleteComment,
  onLikeToggle,
  onSharePost,
}) => {
  const { currentTheme, isWhite, isBlack, isGhost, isDark } = useTheme();
  const [sheetHeight, setSheetHeight] = useState<'50vh' | '95vh'>('50vh');
  const [isGhostToggled, setIsGhostToggled] = useState<boolean>(true);
  const [showGhostWarning, setShowGhostWarning] = useState<boolean>(false);
  const [ghostTTL, setGhostTTL] = useState<number>(24);
  const [commentInput, setCommentInput] = useState<string>('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [sliderStartX, setSliderStartX] = useState<number | null>(null);

  // Attachments State (Images, Stickers, @ Mentions, Video Links)
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const [attachedSticker, setAttachedSticker] = useState<UserSticker | null>(null);
  const [isStickerDrawerOpen, setIsStickerDrawerOpen] = useState<boolean>(false);
  const [isCreateStickerOpen, setIsCreateStickerOpen] = useState<boolean>(false);
  const [showMentionPrompt, setShowMentionPrompt] = useState<boolean>(false);
  const [mentionType, setMentionType] = useState<'profile' | 'video'>('profile');
  const [mentionInput, setMentionInput] = useState<string>('');

  const [userStickers, setUserStickers] = useState<UserSticker[]>(() => {
    try {
      const saved = localStorage.getItem(`ghosted_stickers_${user.id}`);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const dragStartYRef = useRef<number | null>(null);
  const touchStartTimeRef = useRef<number>(0);
  const startHeightPxRef = useRef<number>(0);
  const currentDeltaYRef = useRef<number>(0);
  const [customHeightPx, setCustomHeightPx] = useState<number | null>(null);
  const [isDraggingSheet, setIsDraggingSheet] = useState<boolean>(false);
  const commentsListRef = useRef<HTMLDivElement | null>(null);
  const imageInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (isOpen) {
      setSheetHeight('50vh');
      setCustomHeightPx(null);
      setIsDraggingSheet(false);
    }
  }, [isOpen, post.id]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    const target = e.target as HTMLElement;
    if (target.closest('input, textarea, button, [data-no-drag="true"]')) {
      return;
    }
    if (commentsListRef.current && commentsListRef.current.scrollTop > 5 && !target.closest('[data-drag-handle="true"]')) {
      return;
    }
    dragStartYRef.current = e.touches[0].clientY;
    touchStartTimeRef.current = Date.now();
    startHeightPxRef.current = sheetHeight === '95vh' ? window.innerHeight * 0.95 : window.innerHeight * 0.5;
    setIsDraggingSheet(true);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (dragStartYRef.current === null) return;
    const currentY = e.touches[0].clientY;
    const deltaY = currentY - dragStartYRef.current;
    currentDeltaYRef.current = deltaY;

    const targetHeight = startHeightPxRef.current - deltaY;
    const minH = window.innerHeight * 0.25;
    const maxH = window.innerHeight * 0.95;
    const clampedH = Math.min(maxH, Math.max(minH, targetHeight));
    setCustomHeightPx(clampedH);
  };

  const handleTouchEnd = () => {
    if (dragStartYRef.current === null) return;
    const deltaY = currentDeltaYRef.current;
    const duration = Math.max(1, Date.now() - touchStartTimeRef.current);
    const velocity = deltaY / duration;
    setIsDraggingSheet(false);
    const releaseHeight = customHeightPx;
    setCustomHeightPx(null);
    dragStartYRef.current = null;
    currentDeltaYRef.current = 0;

    if (deltaY < -30 || velocity < -0.3) {
      setSheetHeight('95vh');
    } else if (deltaY > 100 || velocity > 0.4) {
      if (sheetHeight === '95vh' && deltaY < 220 && velocity < 0.7) {
        setSheetHeight('50vh');
      } else {
        onClose();
      }
    } else {
      if (releaseHeight && releaseHeight > window.innerHeight * 0.7) {
        setSheetHeight('95vh');
      } else if (releaseHeight && releaseHeight < window.innerHeight * 0.35) {
        onClose();
      } else {
        setSheetHeight('50vh');
      }
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setAttachedImage(reader.result as string);
        showToast('Image attached to comment 📸');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleStickerCreated = (newSticker: UserSticker) => {
    const updated = [...userStickers, newSticker];
    setUserStickers(updated);
    try {
      localStorage.setItem(`ghosted_stickers_${user.id}`, JSON.stringify(updated));
    } catch {}
    setAttachedSticker(newSticker);
    setIsStickerDrawerOpen(false);
    showToast(`Created & selected sticker: "${newSticker.title}" ✨`);
  };

  const handleSendComment = () => {
    const text = commentInput.trim();
    if (!text && !attachedImage && !attachedSticker) return;

    onAddComment(
      post.id,
      text || (attachedSticker ? `[Sticker: ${attachedSticker.title}]` : '[Image]'),
      isGhostToggled,
      isGhostToggled ? ghostTTL : undefined,
      {
        imageUrl: attachedImage || undefined,
        stickerUrl: attachedSticker?.imageUrl,
        stickerType: attachedSticker?.type,
        stickerTitle: attachedSticker?.title,
        mentionedProfileId: mentionType === 'profile' && mentionInput.trim() ? mentionInput.trim() : undefined,
        mentionedVideoUrl: mentionType === 'video' && mentionInput.trim() ? mentionInput.trim() : undefined,
      }
    );

    setCommentInput('');
    setAttachedImage(null);
    setAttachedSticker(null);
    setMentionInput('');
    setShowMentionPrompt(false);
    setIsStickerDrawerOpen(false);

    if (isGhostToggled) {
      showToast(`Comment permanently recorded. Ghost identity active for ${ghostTTL}h 🔒`);
    } else {
      showToast('Comment permanently recorded as (Real me) 👤 (only deleted if you choose to delete).');
    }
  };

  if (!isOpen) return null;

  const isLiked = post.likedBy?.includes(user.id);
  const likesCount = post.likedBy?.length ?? (post.likesCount || 0);
  const sharesCount = post.sharesCount || 0;

  const formatCount = (count: number) => {
    if (count >= 1000) return `${(count / 1000).toFixed(1)}k`;
    return count.toString();
  };

  return (
    <>
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/50 z-[10010] backdrop-blur-[2px] transition-opacity duration-300 animate-in fade-in"
      />
      <div
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        style={{
          height: customHeightPx ? `${customHeightPx}px` : sheetHeight,
          transition: isDraggingSheet ? 'none' : 'height 250ms cubic-bezier(0.16, 1, 0.3, 1)',
          backgroundColor: currentTheme.card,
          color: currentTheme.cardText,
          borderColor: currentTheme.border,
          boxShadow: isGhost
            ? '0 -10px 40px rgba(0, 245, 255, 0.25), 0 -4px 30px rgba(124, 58, 237, 0.4)'
            : '0 -8px 30px rgba(0, 0, 0, 0.25)',
        }}
        className="fixed bottom-0 left-0 right-0 z-[10010] border-t rounded-t-[28px] shadow-2xl flex flex-col overflow-hidden max-w-2xl mx-auto transition-colors duration-300"
      >
        {/* DRAG HANDLE */}
        <div
          data-drag-handle="true"
          onClick={() => setSheetHeight(sheetHeight === '50vh' ? '95vh' : '50vh')}
          className="w-full pt-2.5 pb-1 flex flex-col items-center justify-center cursor-grab active:cursor-grabbing transition opacity-70 hover:opacity-100"
        >
          <div
            className="w-12 h-1.5 rounded-full transition"
            style={{ backgroundColor: isGhost ? '#00F5FF' : isBlack ? '#D1D5DB' : '#374151' }}
          />
        </div>

        {/* HEADER BAR: LIKES ON LEFT, ENLARGED ARROW IN THE MIDDLE (NO X), SHARE ON RIGHT */}
        <div
          className="px-4 py-2.5 flex items-center justify-between border-b select-none transition-colors duration-300"
          style={{ borderColor: currentTheme.border }}
        >
          {/* LIKES COUNTER */}
          <button
            type="button"
            data-no-drag="true"
            onClick={() => onLikeToggle(post.id)}
            className="flex items-center space-x-1.5 transition cursor-pointer group text-xs sm:text-sm font-semibold opacity-85 hover:opacity-100"
            style={{ color: currentTheme.cardText }}
          >
            <Heart
              className={`w-4 h-4 transition ${
                isLiked ? 'fill-rose-500 text-rose-500 scale-110' : ''
              }`}
            />
            <span className="font-bold">{formatCount(likesCount)}</span>
            <span className="text-xs opacity-75">likes</span>
          </button>

          {/* ENLARGED ARROW BUTTON THAT TAKES COMMENT UP AND DOWN (NO X IN THE MIDDLE) */}
          <button
            type="button"
            data-no-drag="true"
            onClick={() => setSheetHeight(sheetHeight === '50vh' ? '95vh' : '50vh')}
            className="w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 active:scale-90 cursor-pointer shadow-md border"
            style={{
              backgroundColor: isGhost ? '#15151F' : isBlack ? '#F3F4F6' : '#141414',
              borderColor: isGhost ? '#00F5FF' : currentTheme.border,
              color: isGhost ? '#00F5FF' : isBlack ? '#000000' : '#FFFFFF',
              boxShadow: isGhost ? '0 0 16px rgba(0,245,255,0.45)' : undefined,
            }}
            title={sheetHeight === '50vh' ? 'Expand comments (Take up)' : 'Collapse comments (Take down)'}
          >
            <ChevronDown
              className={`w-7 h-7 stroke-[3.5] transition-transform duration-300 ${
                sheetHeight === '95vh' ? 'rotate-0' : 'rotate-180'
              }`}
            />
          </button>

          {/* SHARE COUNTER */}
          <button
            type="button"
            data-no-drag="true"
            onClick={() => onSharePost(post)}
            className="flex items-center space-x-1.5 transition cursor-pointer text-xs sm:text-sm font-semibold opacity-85 hover:opacity-100"
            style={{ color: isGhost ? '#00F5FF' : currentTheme.cardText }}
          >
            <Send className="w-4 h-4 -rotate-12" />
            <span className="font-bold">{formatCount(sharesCount)}</span>
          </button>
        </div>

        {/* COMMENTS LIST */}
        <div
          ref={commentsListRef}
          className="flex-1 overflow-y-auto px-4 py-3 space-y-3 pb-36"
        >
          {comments.length === 0 ? (
            <div className="py-12 text-center space-y-2 opacity-60">
              <span className="text-3xl">👻</span>
              <p className="text-xs font-semibold">No whispers or comments yet. Be the first!</p>
            </div>
          ) : (
            comments.map((c) => {
              const now = Date.now();
              const isUrgent = c.revealAt && c.revealAt - now < 3600000;
              const timeLeftSeconds = c.revealAt ? Math.max(0, Math.floor((c.revealAt - now) / 1000)) : 0;
              const hours = Math.floor(timeLeftSeconds / 3600);
              const minutes = Math.floor((timeLeftSeconds % 3600) / 60);

              return (
                <div
                  key={c.id}
                  className={`p-3 rounded-2xl border space-y-2 transition-all duration-200 ${
                    c.isGhost
                      ? isGhost
                        ? 'bg-[#181028]/80 border-[#7C3AED]/40 shadow-[0_0_15px_rgba(124,58,237,0.15)]'
                        : isDark
                        ? 'bg-[#2D88FF]/15 border-[#2D88FF]/30'
                        : 'bg-[#E7F3FF] border-[#0866FF]/20'
                      : isGhost
                      ? 'bg-[#0A0A0F] border-[#2A2A3F]'
                      : isDark
                      ? 'bg-[#3A3B3C] border-transparent'
                      : 'bg-[#F0F2F5] border-transparent'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                        c.isGhost
                          ? 'bg-[#0866FF]/20 text-[#0866FF]'
                          : isDark
                          ? 'bg-[#4E4F50] text-[#E4E6EB]'
                          : 'bg-gray-200 text-[#050505]'
                      }`}>
                        {c.isGhost ? '👻' : c.displayName?.[0] || '👤'}
                      </div>
                      <span className={`text-xs font-bold ${isDark ? 'text-white' : 'text-[#050505]'}`}>
                        {c.isGhost && !c.revealed ? c.displayName : c.revealed ? `@${c.realUsername}` : c.displayName}
                      </span>
                      {c.isGhost && (
                        <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-mono border ${
                          isGhost
                            ? 'bg-[#7C3AED]/20 text-[#00F5FF] border-[#00F5FF]/30'
                            : 'bg-[#0866FF]/15 text-[#0866FF] border-[#0866FF]/30'
                        }`}>
                          Ghost
                        </span>
                      )}
                    </div>

                    <div className="flex items-center space-x-2">
                      {c.isGhost && !c.revealed && c.commentExpiresAt && (
                        <span className={`text-[9px] font-mono ${isDark ? 'text-zinc-400' : 'text-[#65676B]'}`}>
                          Ghost mode: {Math.max(1, Math.round((c.commentExpiresAt - now) / 3600000))}h
                        </span>
                      )}
                      {(c.realUserId === user.id || post.authorId === user.id) && onDeleteComment && (
                        <button
                          type="button"
                          onClick={() => onDeleteComment(post.id, c.id)}
                          className="flex items-center space-x-1 text-gray-400 hover:text-rose-500 transition px-1.5 py-0.5 rounded text-[10px] cursor-pointer"
                          title="Delete your permanent comment"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline">Delete</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* COMMENT TEXT */}
                  {c.originalText && (
                    <p className={`text-xs leading-relaxed pl-1 ${isDark ? 'text-[#E4E6EB]' : 'text-[#050505]'}`}>
                      {c.originalText}
                    </p>
                  )}

                  {/* COMMENT ATTACHMENT: PHOTO */}
                  {c.imageUrl && (
                    <div className="pt-1">
                      <img
                        src={c.imageUrl}
                        alt="Comment attachment"
                        className="max-h-52 rounded-xl object-cover border border-white/10 shadow-sm"
                      />
                    </div>
                  )}

                  {/* COMMENT ATTACHMENT: GHOST STICKER */}
                  {c.stickerUrl && (
                    <div className="pt-1 flex items-center space-x-2">
                      <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#7C3AED]/20 to-[#00F5FF]/20 border border-purple-500/30 flex items-center justify-center p-1.5 shadow-md">
                        {c.stickerUrl.startsWith('data:image/svg') || c.stickerUrl.startsWith('http') || c.stickerUrl.startsWith('data:image') ? (
                          <img src={c.stickerUrl} alt="Sticker" className="w-full h-full object-contain" />
                        ) : (
                          <span className="text-3xl">{c.stickerUrl}</span>
                        )}
                      </div>
                      {c.stickerTitle && (
                        <span className="text-[10px] font-bold opacity-75 font-mono">
                          {c.stickerTitle}
                        </span>
                      )}
                    </div>
                  )}

                  {/* COMMENT MENTION: PROFILE OR VIDEO LINK */}
                  {c.mentionedProfileId && (
                    <div className="pt-1 flex items-center space-x-1.5 text-xs text-[#0866FF] font-bold">
                      <AtSign className="w-3.5 h-3.5" />
                      <span className="underline cursor-pointer">Profile: {c.mentionedProfileId}</span>
                    </div>
                  )}
                  {c.mentionedVideoUrl && (
                    <div className="pt-1 flex items-center space-x-1.5 text-xs text-[#7C3AED] font-bold">
                      <Play className="w-3.5 h-3.5" />
                      <span className="underline cursor-pointer">Video Link Attached</span>
                    </div>
                  )}

                  {/* GHOST TIMER BADGE */}
                  {c.isGhost && !c.revealed && (
                    <div className="pt-1">
                      <div
                        className={`inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-[10px] font-mono border ${
                          isUrgent
                            ? 'bg-rose-950/60 border-rose-500/80 text-rose-300 animate-pulse'
                            : 'bg-rose-950/40 border-rose-500/50 text-rose-300/90'
                        }`}
                      >
                        <Clock className="w-3 h-3 text-rose-400 flex-shrink-0" />
                        <span>
                          {isUrgent
                            ? `Revealing in ${minutes}m...`
                            : `⏳ Ghost revealed in ${hours}h ${minutes}m`}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* STICKER PICKER DRAWER */}
        {isStickerDrawerOpen && (
          <div
            data-no-drag="true"
            className={`absolute bottom-24 left-3 right-3 rounded-2xl p-3 border shadow-2xl z-20 animate-in slide-in-from-bottom-2 duration-150 ${
              isGhost
                ? 'bg-[#15151F] border-[#2A2A3F] text-[#E0E0FF]'
                : isDark
                ? 'bg-[#242526] border-[#3E4042] text-[#E4E6EB]'
                : 'bg-white border-gray-200 text-[#050505]'
            }`}
          >
            <div className="flex items-center justify-between pb-2 border-b border-white/10 mb-2">
              <span className="text-xs font-bold flex items-center space-x-1.5">
                <span>👻</span>
                <span>Ghost Stickers & Created</span>
              </span>
              <button
                type="button"
                onClick={() => setIsStickerDrawerOpen(false)}
                className="p-1 rounded-full opacity-70 hover:opacity-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* STICKERS HORIZONTAL SCROLL & GRID */}
            <div className="max-h-48 overflow-y-auto grid grid-cols-4 sm:grid-cols-5 gap-2 p-1">
              {/* User created stickers first */}
              {userStickers.map((stk) => (
                <button
                  key={stk.id}
                  type="button"
                  onClick={() => {
                    setAttachedSticker(stk);
                    setIsStickerDrawerOpen(false);
                  }}
                  className="p-2 rounded-xl border border-white/10 hover:border-[#0866FF] flex flex-col items-center justify-center space-y-1 transition active:scale-95 cursor-pointer bg-white/5"
                >
                  {stk.imageUrl.startsWith('data:') || stk.imageUrl.startsWith('http') ? (
                    <img src={stk.imageUrl} alt={stk.title} className="w-9 h-9 object-contain" />
                  ) : (
                    <span className="text-2xl">{stk.imageUrl}</span>
                  )}
                  <span className="text-[9px] font-bold truncate max-w-[50px]">{stk.title}</span>
                </button>
              ))}

              {/* Default Ghost stickers */}
              {DEFAULT_GHOST_STICKERS.map((stk) => (
                <button
                  key={stk.id}
                  type="button"
                  onClick={() => {
                    setAttachedSticker(stk);
                    setIsStickerDrawerOpen(false);
                  }}
                  className="p-2 rounded-xl border border-white/10 hover:border-[#7C3AED] flex flex-col items-center justify-center space-y-1 transition active:scale-95 cursor-pointer bg-white/5"
                >
                  <span className="text-2xl">{stk.imageUrl}</span>
                  <span className="text-[9px] font-bold truncate max-w-[50px]">{stk.title}</span>
                </button>
              ))}

              {/* AT THE END OF THE LIST: CREATE STICKERS BUTTON */}
              <button
                type="button"
                onClick={() => {
                  setIsStickerDrawerOpen(false);
                  setIsCreateStickerOpen(true);
                }}
                className={`p-2 rounded-xl border-2 border-dashed flex flex-col items-center justify-center space-y-1 transition active:scale-95 cursor-pointer ${
                  isGhost
                    ? 'border-[#00F5FF]/60 text-[#00F5FF] bg-[#7C3AED]/15'
                    : 'border-[#0866FF]/60 text-[#0866FF] bg-[#0866FF]/10'
                }`}
              >
                <Plus className="w-5 h-5" />
                <span className="text-[9px] font-bold text-center leading-tight">Create Sticker</span>
              </button>
            </div>
          </div>
        )}

        {/* MENTION PROMPT MODAL / POPUP */}
        {showMentionPrompt && (
          <div
            data-no-drag="true"
            className={`absolute bottom-24 left-3 right-3 rounded-2xl p-3 border shadow-2xl z-20 animate-in slide-in-from-bottom-2 duration-150 ${
              isGhost
                ? 'bg-[#15151F] border-[#2A2A3F] text-[#E0E0FF]'
                : isDark
                ? 'bg-[#242526] border-[#3E4042] text-[#E4E6EB]'
                : 'bg-white border-gray-200 text-[#050505]'
            }`}
          >
            <div className="flex items-center justify-between pb-2 border-b border-white/10 mb-2">
              <span className="text-xs font-bold flex items-center space-x-1.5">
                <AtSign className="w-3.5 h-3.5 text-[#0866FF]" />
                <span>Link a Profile or Video</span>
              </span>
              <button
                type="button"
                onClick={() => setShowMentionPrompt(false)}
                className="p-1 rounded-full opacity-70 hover:opacity-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-2">
              <div className="flex space-x-2">
                <button
                  type="button"
                  onClick={() => setMentionType('profile')}
                  className={`flex-1 py-1 px-2 rounded-lg text-xs font-bold border transition ${
                    mentionType === 'profile' ? 'bg-[#0866FF] text-white border-[#0866FF]' : 'border-white/10'
                  }`}
                >
                  @ Profile ID
                </button>
                <button
                  type="button"
                  onClick={() => setMentionType('video')}
                  className={`flex-1 py-1 px-2 rounded-lg text-xs font-bold border transition ${
                    mentionType === 'video' ? 'bg-[#7C3AED] text-white border-[#7C3AED]' : 'border-white/10'
                  }`}
                >
                  🎥 Video Link
                </button>
              </div>
              <input
                type="text"
                value={mentionInput}
                onChange={(e) => setMentionInput(e.target.value)}
                placeholder={mentionType === 'profile' ? 'e.g. GH-8421 or @handle' : 'e.g. https://.../video.mp4'}
                className={`w-full px-3 py-1.5 rounded-xl text-xs font-medium border focus:outline-none ${
                  isDark ? 'bg-black/40 border-zinc-700 text-white' : 'bg-gray-100 border-gray-300 text-black'
                }`}
              />
              <button
                type="button"
                onClick={() => {
                  if (mentionInput.trim()) {
                    setCommentInput((prev) => `${prev} ${mentionType === 'profile' ? '@' + mentionInput.trim().replace(/^@/, '') : mentionInput.trim()}`);
                  }
                  setShowMentionPrompt(false);
                }}
                className="w-full py-1.5 rounded-xl bg-[#0866FF] text-white text-xs font-bold"
              >
                Add Link
              </button>
            </div>
          </div>
        )}

        {/* BOTTOM COMPOSER & ACTIONS */}
        <div
          data-no-drag="true"
          className={`absolute bottom-0 left-0 right-0 pt-2 pb-3 px-3 sm:px-4 flex flex-col justify-end space-y-2 border-t backdrop-blur-xl transition-colors ${
            isGhost
              ? 'bg-[#15151F]/95 border-[#2A2A3F]'
              : isDark
              ? 'bg-[#242526]/95 border-[#3E4042]'
              : 'bg-white/95 border-gray-200 shadow-lg'
          }`}
        >
          {/* ATTACHED PREVIEW CHIP (IF IMAGE OR STICKER SELECTED) */}
          {(attachedImage || attachedSticker) && (
            <div className="flex items-center space-x-2 py-1 px-2.5 rounded-xl bg-white/10 border border-white/15 w-fit">
              {attachedImage && (
                <div className="flex items-center space-x-1.5">
                  <img src={attachedImage} alt="" className="w-7 h-7 rounded-lg object-cover" />
                  <span className="text-[11px] font-bold">Photo attached</span>
                  <button
                    type="button"
                    onClick={() => setAttachedImage(null)}
                    className="p-1 text-rose-400 hover:text-rose-300"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
              {attachedSticker && (
                <div className="flex items-center space-x-1.5">
                  <span className="text-xl">{attachedSticker.imageUrl}</span>
                  <span className="text-[11px] font-bold">{attachedSticker.title}</span>
                  <button
                    type="button"
                    onClick={() => setAttachedSticker(null)}
                    className="p-1 text-rose-400 hover:text-rose-300"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          )}

          {/* GHOST ME vs REAL ME SLIDER & TIME SELECTION BAR */}
          <div className="flex items-center justify-between gap-2 px-1 flex-wrap">
            {/* SLIDING TOGGLE: (Ghost me) ----------------> Real me  vs  Ghost me <------------------ (Real me) */}
            <div
              onPointerDown={(e) => setSliderStartX(e.clientX)}
              onPointerUp={(e) => {
                if (sliderStartX !== null) {
                  const diff = e.clientX - sliderStartX;
                  if (diff > 20) {
                    setIsGhostToggled(false);
                  } else if (diff < -20) {
                    setIsGhostToggled(true);
                  }
                }
                setSliderStartX(null);
              }}
              className="relative flex items-center p-0.5 rounded-full border cursor-pointer select-none transition-all duration-300 touch-none shadow-inner"
              style={{
                backgroundColor: isBlack ? '#E5E7EB' : isGhost ? '#0A0A12' : '#18191A',
                borderColor: isGhost ? '#2A2A3F' : currentTheme.border,
                minWidth: '225px',
              }}
              title="Slide or click to switch between Ghost me and Real me"
            >
              {/* Sliding active pill indicator */}
              <div
                className="absolute top-0.5 bottom-0.5 w-[calc(50%-2px)] rounded-full transition-all duration-300 ease-out shadow-md pointer-events-none"
                style={{
                  left: isGhostToggled ? '2px' : 'calc(50%)',
                  backgroundColor: isGhostToggled
                    ? isGhost
                      ? '#7C3AED'
                      : '#0866FF'
                    : isGhost
                    ? '#059669'
                    : '#10B981',
                }}
              />

              {/* (Ghost me) option on left */}
              <button
                type="button"
                onClick={() => setIsGhostToggled(true)}
                className={`relative z-10 flex-1 flex items-center justify-center space-x-1 py-1.5 px-2 rounded-full text-xs font-bold transition-all cursor-pointer ${
                  isGhostToggled
                    ? 'text-white font-extrabold shadow-xs'
                    : isBlack
                    ? 'text-gray-600 hover:text-black font-semibold'
                    : 'text-gray-400 hover:text-gray-200 font-semibold'
                }`}
              >
                <span>👻</span>
                <span>{isGhostToggled ? '(Ghost me)' : 'Ghost me'}</span>
                {isGhostToggled && (
                  <span className="text-[10px] font-mono tracking-tighter opacity-80 ml-0.5 animate-pulse">
                    ────&gt;
                  </span>
                )}
              </button>

              {/* Real me option on right */}
              <button
                type="button"
                onClick={() => setIsGhostToggled(false)}
                className={`relative z-10 flex-1 flex items-center justify-center space-x-1 py-1.5 px-2 rounded-full text-xs font-bold transition-all cursor-pointer ${
                  !isGhostToggled
                    ? 'text-white font-extrabold shadow-xs'
                    : isBlack
                    ? 'text-gray-600 hover:text-black font-semibold'
                    : 'text-gray-400 hover:text-gray-200 font-semibold'
                }`}
              >
                {!isGhostToggled && (
                  <span className="text-[10px] font-mono tracking-tighter opacity-80 mr-0.5 animate-pulse">
                    &lt;────
                  </span>
                )}
                <span>👤</span>
                <span>{!isGhostToggled ? '(Real me)' : 'Real me'}</span>
              </button>
            </div>

            {/* TIME SELECTION (2h, 10h, 24h) - INCLUDED ONLY IF GHOST ME */}
            {isGhostToggled ? (
              <div className="flex items-center space-x-1.5 animate-in fade-in slide-in-from-left-2 duration-200">
                <span
                  className="text-[10px] font-mono flex items-center gap-1 font-semibold opacity-80"
                  style={{ color: currentTheme.cardText }}
                >
                  <Clock className="w-3 h-3 text-cyan-400 animate-pulse" />
                  <span>Time:</span>
                </span>
                {[2, 10, 24].map((hours) => (
                  <button
                    key={hours}
                    type="button"
                    onClick={() => setGhostTTL(hours)}
                    className={`px-2.5 py-1 rounded-full text-[11px] font-mono font-bold transition-all cursor-pointer active:scale-95 border ${
                      ghostTTL === hours
                        ? isGhost
                          ? 'bg-[#00F5FF] text-black border-[#00F5FF] shadow-[0_0_12px_rgba(0,245,255,0.7)] font-black'
                          : 'bg-[#0866FF] text-white border-[#0866FF] shadow-xs font-black'
                        : isDark
                        ? 'bg-[#2A2B2D] text-zinc-300 border-white/10 hover:border-white/30'
                        : 'bg-gray-100 text-gray-700 border-gray-300 hover:border-gray-400'
                    }`}
                    title={`Disappear after ${hours} hours`}
                  >
                    {hours}h
                  </button>
                ))}
              </div>
            ) : (
              /* IF USER SLID TO REAL ME: NO TIME SELECTION INCLUDED */
              <div className="flex items-center space-x-1.5 text-[11px] opacity-70 animate-in fade-in duration-200">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                <span style={{ color: currentTheme.cardSubtext }}>No timer • Permanent comment</span>
              </div>
            )}
          </div>

          {/* INPUT BAR WITH ATTACHMENT ICONS */}
          <div
            className="flex items-center rounded-full border px-2 py-1 transition-all duration-300 relative"
            style={{
              backgroundColor: isBlack ? '#F3F4F6' : '#141414',
              borderColor: isGhost ? '#2A2A3F' : currentTheme.border,
              color: currentTheme.cardText,
            }}
          >
            {/* ATTACH IMAGE BUTTON */}
            <button
              type="button"
              onClick={() => imageInputRef.current?.click()}
              className="p-1.5 rounded-full text-gray-400 hover:text-[#0866FF] transition cursor-pointer"
              title="Attach photo"
            >
              <ImageIcon className="w-4 h-4" />
            </button>
            <input
              ref={imageInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleImageUpload}
            />

            {/* ATTACH STICKER BUTTON */}
            <button
              type="button"
              onClick={() => setIsStickerDrawerOpen(!isStickerDrawerOpen)}
              className="p-1.5 rounded-full text-gray-400 hover:text-[#7C3AED] transition cursor-pointer"
              title="Add Ghost or custom sticker"
            >
              <Smile className="w-4 h-4" />
            </button>

            {/* ATTACH @ PROFILE / VIDEO LINK BUTTON */}
            <button
              type="button"
              onClick={() => setShowMentionPrompt(!showMentionPrompt)}
              className="p-1.5 rounded-full text-gray-400 hover:text-[#0866FF] transition cursor-pointer"
              title="@ Link Profile or Video"
            >
              <AtSign className="w-4 h-4" />
            </button>

            {/* INPUT FIELD */}
            <input
              type="text"
              value={commentInput}
              onChange={(e) => setCommentInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleSendComment();
                }
              }}
              placeholder={
                isGhostToggled
                  ? `Whisper anonymously as (Ghost me) — vanishes in ${ghostTTL}h...`
                  : `Comment as ${user.name || 'yourself'} (Real me)...`
              }
              className="flex-1 px-2.5 py-1.5 bg-transparent text-xs sm:text-sm focus:outline-none font-medium"
              style={{
                color: currentTheme.cardText,
              }}
            />

            {/* SEND BUTTON */}
            <button
              type="button"
              onClick={handleSendComment}
              disabled={!commentInput.trim() && !attachedImage && !attachedSticker}
              className={`py-1.5 px-3.5 rounded-full font-bold text-xs transition cursor-pointer disabled:opacity-40 flex items-center space-x-1 shadow-xs active:scale-95 text-white ${
                isGhost
                  ? 'bg-gradient-to-r from-[#7C3AED] to-[#00F5FF]'
                  : 'bg-[#0866FF] hover:bg-[#0055E0]'
              }`}
            >
              <span>Send</span>
              <Send className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* CREATE STICKER MODAL */}
      <StickerCreatorModal
        isOpen={isCreateStickerOpen}
        onClose={() => setIsCreateStickerOpen(false)}
        onStickerCreated={handleStickerCreated}
      />
    </>
  );
};
