import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, Gender, RelationshipType, GhostPost, GhostPostComment } from '../types';
import { calculateAge, generateGhostedId, generateGhostedNumber } from '../utils/idGenerator';
import { checkIsNigeria } from '../utils/countryDetection';
import { db, auth, ensureAuthenticated } from '../firebase';
import { collection, onSnapshot, doc, updateDoc, setDoc, serverTimestamp, deleteDoc, increment } from 'firebase/firestore';
import { checkBadWords } from '../utils/textFilter';
import { uploadMedia, cancelActiveUpload } from '../utils/mediaUpload';
import { enhanceImageFree } from '../utils/imageEnhancer';
import { permanentlyDeletePost } from '../utils/postManager';
import {
  saveLocalMediaBlob,
  getLocalMediaBlob,
  saveLocalUserPost,
  getLocalUserPosts,
  generateVideoThumbnail,
} from '../utils/localMediaStore';
import {
  ShieldCheck,
  Lock,
  Copy,
  Check,
  Sparkles,
  HeartHandshake,
  Eye,
  Flame,
  MapPin,
  AlertTriangle,
  User,
  Edit3,
  Camera,
  Save,
  RefreshCw,
  CheckCircle2,
  Calendar,
  Globe,
  Phone,
  Share2,
  Moon,
  Clock,
  UserCheck,
  Radio,
  Sliders,
  Users,
  MoreVertical,
  ArrowLeft,
  UserPlus,
  Menu,
  Plus,
  ChevronDown,
  LayoutGrid,
  Repeat,
  Bookmark,
  Heart,
  Pencil,
  Play,
  X,
  ExternalLink,
  MessageCircle,
  QrCode,
  Search,
  Trash2,
  Download,
  Type,
  Image,
  Video,
  Send,
} from 'lucide-react';
import { isUserTeen, getTeenSettings, saveTeenSettings, TeenSettings } from '../utils/teenProtection';
import { FullscreenMediaViewer } from './FullscreenMediaViewer';
import { CommentBottomSheet } from './CommentBottomSheet';
import { downloadLikeTikTok, TikTokDownloadProgress } from '../utils/tiktokDownloader';
import { TikTokDownloadModal } from './TikTokDownloadModal';
import { useTheme } from '../context/ThemeContext';

interface ProfileSafetyTabProps {
  user: UserProfile;
  dailySendsRemaining: number;
  onResetOnboarding: () => void;
  onProfileUpdated?: (updated: UserProfile) => void;
  onOpenThemeModal?: () => void;
}

const AVATAR_PRESETS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=250&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=250&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=250&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=250&q=80',
  'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=250&q=80',
];

const LOCATION_SUGGESTIONS = [
  { city: 'Lagos', country: 'Nigeria', flag: '🇳🇬' },
  { city: 'Abuja', country: 'Nigeria', flag: '🇳🇬' },
  { city: 'London', country: 'United Kingdom', flag: '🇬🇧' },
  { city: 'New York', country: 'United States', flag: '🇺🇸' },
  { city: 'Toronto', country: 'Canada', flag: '🇨🇦' },
  { city: 'Accra', country: 'Ghana', flag: '🇬🇭' },
  { city: 'Nairobi', country: 'Kenya', flag: '🇰🇪' },
  { city: 'Johannesburg', country: 'South Africa', flag: '🇿🇦' },
];

export const ProfileSafetyTab: React.FC<ProfileSafetyTabProps> = ({
  user,
  dailySendsRemaining,
  onResetOnboarding,
  onProfileUpdated,
  onOpenThemeModal,
}) => {
  const isNigeria = checkIsNigeria(user.userCountry || user.country || user.stateCountry);
  const { theme, currentTheme, isWhite, isBlack, isGhost, isLight, isDark, setTheme } = useTheme();
  const [tiktokProgress, setTiktokProgress] = useState<TikTokDownloadProgress | null>(null);
  const [isTikTokModalOpen, setIsTikTokModalOpen] = useState<boolean>(false);
  const [downloadingAuthorName, setDownloadingAuthorName] = useState<string>('');
  const [isEditing, setIsEditing] = useState(false);
  const [showAccountInfo, setShowAccountInfo] = useState(false);
  const [showOptionsMenu, setShowOptionsMenu] = useState(false);
  const [copiedId, setCopiedId] = useState(false);
  const [copiedNum, setCopiedNum] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const [activeProfileTab, setActiveProfileTab] = useState<'you_post' | 'favorites' | 'watched'>('you_post');
  const [youPostFilter, setYouPostFilter] = useState<'all' | 'videos' | 'photos' | 'text'>('all');
  const [isSelectMode, setIsSelectMode] = useState<boolean>(false);
  const [selectedVideoIds, setSelectedVideoIds] = useState<string[]>([]);
  const [showDeleteConfirmModal, setShowDeleteConfirmModal] = useState<boolean>(false);
  const [videoToDeleteSingle, setVideoToDeleteSingle] = useState<GhostPost | null>(null);
  const [isDeletingVideos, setIsDeletingVideos] = useState<boolean>(false);
  const [showProfileViewsModal, setShowProfileViewsModal] = useState<boolean>(false);
  const [profileViewHistoryEnabled, setProfileViewHistoryEnabled] = useState<boolean>(() => {
    return localStorage.getItem(`ghosted_view_history_opt_${user.id}`) !== 'false';
  });
  const [profileViewers, setProfileViewers] = useState<Array<{ id: string; name: string; handle: string; avatar: string; viewedAt: string }>>(() => {
    try {
      const s = localStorage.getItem(`ghosted_profile_views_${user.id}`);
      if (s) return JSON.parse(s);
    } catch {}
    return [];
  });

  const [showUploadPostModal, setShowUploadPostModal] = useState<boolean>(false);
  const [uploadFormat, setUploadFormat] = useState<'text' | 'photos' | 'videos'>('text');
  const [newPostText, setNewPostText] = useState<string>('');
  const [newPostMedia, setNewPostMedia] = useState<string>('');
  const [originalPostMedia, setOriginalPostMedia] = useState<string>('');
  const [isEnhancedPost, setIsEnhancedPost] = useState<boolean>(false);
  const [isEnhancingPost, setIsEnhancingPost] = useState<boolean>(false);
  const [enhancedPostMedia, setEnhancedPostMedia] = useState<string | null>(null);
  const [sliderSplitPos, setSliderSplitPos] = useState<number>(50);
  const [newPostMediaType, setNewPostMediaType] = useState<'image' | 'video' | 'none'>('none');
  const [newPostAudience, setNewPostAudience] = useState<'public' | 'private'>('public');
  const [newPostBgColor, setNewPostBgColor] = useState<string>('from-[#160d2e] via-[#0f091f] to-[#07040d]');
  const [isSubmittingPost, setIsSubmittingPost] = useState<boolean>(false);

  const [savedPosts, setSavedPosts] = useState<GhostPost[]>(() => {
    try {
      const s = localStorage.getItem(`ghosted_saved_posts_${user.id}`);
      return s ? JSON.parse(s) : [];
    } catch {
      return [];
    }
  });

  const [watchedPosts, setWatchedPosts] = useState<GhostPost[]>(() => {
    try {
      const s = localStorage.getItem(`ghosted_recently_watched_${user.id}`);
      return s ? JSON.parse(s) : [];
    } catch {
      return [];
    }
  });

  const [fullscreenMediaPost, setFullscreenMediaPost] = useState<GhostPost | null>(null);
  const [followingList, setFollowingList] = useState<string[]>(() => {
    try {
      const s = localStorage.getItem(`ghosted_following_${user.id}`);
      return s ? JSON.parse(s) : [];
    } catch {
      return [];
    }
  });
  const [followersList, setFollowersList] = useState<string[]>(() => {
    try {
      const s = localStorage.getItem(`ghosted_followers_${user.id}`);
      return s ? JSON.parse(s) : [];
    } catch {
      return [];
    }
  });

  const [showFollowListModal, setShowFollowListModal] = useState<'following' | 'followers' | null>(null);
  const [searchFriendQuery, setSearchFriendQuery] = useState('');
  const [showAddFriendModal, setShowAddFriendModal] = useState(false);
  const [showHamburgerMenu, setShowHamburgerMenu] = useState(false);
  const [previewingPost, setPreviewingPost] = useState<GhostPost | null>(null);
  const [activeCommentSheetPost, setActiveCommentSheetPost] = useState<GhostPost | null>(null);
  const [commentsMap, setCommentsMap] = useState<Record<string, GhostPostComment[]>>({});
  const [userPosts, setUserPosts] = useState<GhostPost[]>([]);
  const [allPosts, setAllPosts] = useState<GhostPost[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const avatarFileInputRef = useRef<HTMLInputElement>(null);
  const postImageInputRef = useRef<HTMLInputElement>(null);
  const postVideoInputRef = useRef<HTMLInputElement>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const compressImageQuick = async (dataUrl: string, maxDim = 1200, quality = 0.75): Promise<string> => {
    if (!dataUrl || !dataUrl.startsWith('data:image')) return dataUrl;
    return new Promise((resolve) => {
      const img = typeof window !== 'undefined' ? new window.Image() : (document.createElement('img') as HTMLImageElement);
      img.onload = () => {
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', quality));
        } else {
          resolve(dataUrl);
        }
      };
      img.onerror = () => resolve(dataUrl);
      img.src = dataUrl;
    });
  };

  const handlePostImageSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = reader.result as string;
      const compressed = await compressImageQuick(dataUrl, 1200, 0.75);
      setNewPostMedia(compressed);
      setOriginalPostMedia(compressed);
      setEnhancedPostMedia(null);
      setIsEnhancedPost(false);
      setSliderSplitPos(50);
      setNewPostMediaType('image');
      setUploadFormat('photos');
    };
    reader.readAsDataURL(file);
  };

  const handleToggleEnhancePost = async () => {
    const baseSource = originalPostMedia || newPostMedia;
    if (!baseSource) return;

    if (isEnhancedPost) {
      // Toggle OFF: revert to original image
      setIsEnhancedPost(false);
      setNewPostMedia(baseSource);
    } else {
      // Toggle ON: run free AI enhancement
      setIsEnhancingPost(true);
      try {
        let enhanced = enhancedPostMedia;
        if (!enhanced) {
          enhanced = await enhanceImageFree(baseSource);
          setEnhancedPostMedia(enhanced);
        }
        setNewPostMedia(enhanced);
        setIsEnhancedPost(true);
      } catch (err) {
        console.warn('Enhancement error:', err);
      } finally {
        setIsEnhancingPost(false);
      }
    }
  };

  const handlePostVideoSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setNewPostMedia(reader.result as string);
      setOriginalPostMedia('');
      setEnhancedPostMedia(null);
      setIsEnhancedPost(false);
      setNewPostMediaType('video');
      setUploadFormat('videos');
    };
    reader.readAsDataURL(file);
  };

  const handleCreatePost = async () => {
    if (!newPostText.trim() && !newPostMedia) {
      showToast('Please enter text or select media to post.');
      return;
    }
    const check = newPostText ? checkBadWords(newPostText) : { isBlocked: false, flaggedWords: [], cleanText: '' };
    if (check.isBlocked) {
      showToast(`Post contains prohibited words: ${check.flaggedWords.join(', ')}`);
      return;
    }

    setIsSubmittingPost(true);
    try {
      const postId = `post-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      const rawText = check.cleanText || (uploadFormat === 'videos' ? '🎬 Video post' : uploadFormat === 'photos' ? '🖼️ Photo post' : '');
      const caption = ((rawText ?? '').slice(0, 490)) as string;
      const uid = (auth.currentUser?.uid || user.id || 'ghost_user') as string;

      const isVideo = uploadFormat === 'videos' || newPostMediaType === 'video';
      const isPhoto = uploadFormat === 'photos' || newPostMediaType === 'image';
      const mediaSource = newPostMedia || '';

      let videoThumb = '';
      if (isVideo && mediaSource) {
        // 1. Immediately store heavy video blob in IndexedDB so it's immune to quota limits
        await saveLocalMediaBlob(postId, mediaSource);
        // 2. Generate a compact (<30KB) JPEG video thumbnail for Firestore instant persistence
        try {
          videoThumb = await generateVideoThumbnail(mediaSource);
        } catch {}
      }

      // Safe Firestore payload: NEVER exceed 1MB document limit
      const postPayload: GhostPost & { userId: string; imageUrl: string; likes: number } = {
        id: postId,
        userId: uid,
        imageUrl: isPhoto ? mediaSource : (videoThumb || ''),
        text: caption ?? '',
        createdAt: serverTimestamp() as any,
        likes: 0,
        likesCount: 0,
        likedBy: [],
        commentsCount: 0,
        sharesCount: 0,
        shares_count: 0,
        authorId: user.id as string,
        authorName: (name || user.name || 'Ghost User') as string,
        authorAvatar: (avatarUrl || user.avatarUrl || '👻') as string,
        authorGhostedId: user.ghostedId as string,
        // Only embed raw dataUrl in Firestore if it's smaller than 400KB; otherwise keep empty until storage upload finishes
        mediaUrl: isVideo ? (mediaSource.length > 400000 ? '' : mediaSource) : (mediaSource || undefined),
        mediaType: isVideo ? 'video' : isPhoto ? 'image' : undefined,
        audience: newPostAudience,
        isEnhanced: isEnhancedPost,
      };

      // 1. FAST OPTIMISTIC UI: Immediately display post and dismiss modal (<100ms response time - 2x faster)
      const localPost: GhostPost = {
        ...postPayload,
        id: postId,
        createdAt: Date.now(),
        mediaUrl: mediaSource || undefined, // always keep full media locally
        imageUrl: isPhoto ? mediaSource : (videoThumb || ''),
      };

      // Save full post in IndexedDB (virtually unlimited quota)
      await saveLocalUserPost(localPost);

      setUserPosts((prev) => [localPost, ...prev.filter((p) => p.id !== postId)]);
      setAllPosts((prev) => [localPost, ...prev.filter((p) => p.id !== postId)]);

      try {
        // In localStorage, store compact version to prevent QuotaExceededError
        const compactPost: GhostPost = {
          ...localPost,
          mediaUrl: isVideo && mediaSource.length > 200000 ? (videoThumb || '') : localPost.mediaUrl,
        };
        const cachedUser: GhostPost[] = JSON.parse(localStorage.getItem(`ghosted_user_posts_${user.id}`) || '[]');
        localStorage.setItem(`ghosted_user_posts_${user.id}`, JSON.stringify([compactPost, ...cachedUser.filter((p) => p.id !== postId)].slice(0, 40)));
        const cachedFeed: GhostPost[] = JSON.parse(localStorage.getItem('ghosted_cached_feed_posts') || '[]');
        localStorage.setItem('ghosted_cached_feed_posts', JSON.stringify([compactPost, ...cachedFeed.filter((p) => p.id !== postId)].slice(0, 40)));
      } catch (err) {
        console.warn('localStorage cache note:', err);
      }

      showToast(isVideo ? 'Video post published!' : isPhoto ? 'Photo post published!' : 'Post published!');
      setNewPostText('');
      setNewPostMedia('');
      setOriginalPostMedia('');
      setEnhancedPostMedia(null);
      setIsEnhancedPost(false);
      setNewPostMediaType('none');
      setShowUploadPostModal(false);

      // 2. FIRESTORE PERMANENT BACKGROUND SAVE: persists in Firestore "posts" collection so all users see it
      (async () => {
        try {
          await ensureAuthenticated();
          await setDoc(doc(db, 'posts', postId), postPayload);

          // If heavy media, upload to Firebase Storage in background and update Firestore with compact cloud URL
          if (mediaSource && mediaSource.startsWith('data:') && uid) {
            try {
              const cloudUrl = await uploadMedia(mediaSource, 'posts', uid);
              if (cloudUrl && cloudUrl !== mediaSource) {
                await updateDoc(doc(db, 'posts', postId), {
                  mediaUrl: cloudUrl,
                  ...(isPhoto ? { imageUrl: cloudUrl } : {}),
                });
                const updatedLocal = { ...localPost, mediaUrl: cloudUrl };
                await saveLocalUserPost(updatedLocal);
                setUserPosts((prev) => prev.map((p) => (p.id === postId ? { ...p, mediaUrl: cloudUrl } : p)));
              }
            } catch (mediaErr) {
              console.warn('Storage upload note:', mediaErr);
            }
          }
        } catch (dbErr) {
          console.warn('Firestore post persist note:', dbErr);
        }
      })();
    } catch (e: any) {
      console.error('PUBLISH ERROR FULL:', e);
      showToast(`Failed: ${e?.message || String(e)}`);
    } finally {
      setIsSubmittingPost(false);
    }
  };

  const handleToggleFollow = async (targetId: string, targetName?: string) => {
    if (targetId === user.id) return;
    const isFollowing = followingList.includes(targetId);
    const updated = isFollowing
      ? followingList.filter((id) => id !== targetId)
      : [...followingList, targetId];
    setFollowingList(updated);
    try {
      localStorage.setItem(`ghosted_following_${user.id}`, JSON.stringify(updated));
    } catch {}
    showToast(isFollowing ? `Unfollowed ${targetName || 'user'}` : `Following ${targetName || 'user'}`);
    try {
      await updateDoc(doc(db, 'users', user.id), { following: updated });
    } catch {}
  };

  const handleDownloadPost = async (post: GhostPost) => {
    setDownloadingAuthorName(post.authorName || user.name || 'ghost_user');
    setIsTikTokModalOpen(true);
    setTiktokProgress({
      status: 'preparing',
      progress: 5,
      message: 'Preparing download...',
    });

    await downloadLikeTikTok(
      {
        id: post.id,
        text: post.text,
        mediaUrl: post.mediaUrl,
        mediaType: post.mediaType,
        authorName: post.authorName || user.name,
        authorId: post.authorId || user.id,
        createdAt: post.createdAt,
      },
      (progress) => {
        setTiktokProgress(progress);
        if (progress.status === 'completed') {
          showToast('Saved with TikTok watermark! 🎬');
          setTimeout(() => {
            setIsTikTokModalOpen(false);
          }, 2000);
        }
      }
    );
  };

  const handleShareProfile = () => {
    const text = `Check out my profile on GHOSTED! Handle: @${user.ghostedId} (${user.name})`;
    const url = window.location.href;
    if (navigator.share) {
      navigator.share({ title: `${user.name} on Ghosted`, text, url }).catch(() => {});
    } else {
      navigator.clipboard.writeText(`${text}\n${url}`);
      showToast('Profile link copied to clipboard!');
    }
  };

  useEffect(() => {
    // 1. Initial load from localStorage
    try {
      const stored = localStorage.getItem(`ghosted_user_posts_${user.id}`);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setUserPosts(parsed);
        }
      }
    } catch (e) {
      console.warn('Error reading local user posts:', e);
    }

    // 2. Initial load from IndexedDB (preserves raw video blobs & complete posts)
    getLocalUserPosts().then((idbPosts) => {
      if (idbPosts && idbPosts.length > 0) {
        const deletedIds: string[] = JSON.parse(
          localStorage.getItem(`ghosted_deleted_posts_${user.id}`) || '[]'
        );
        const valid = idbPosts.filter((p) => !p.isDeleted && !deletedIds.includes(p.id));
        if (valid.length > 0) {
          setUserPosts((prev) => {
            const map = new Map<string, GhostPost>();
            prev.forEach((p) => map.set(p.id, p));
            valid.forEach((p) => {
              const existing = map.get(p.id);
              if (existing) {
                map.set(p.id, {
                  ...existing,
                  mediaUrl: existing.mediaUrl || p.mediaUrl,
                  imageUrl: existing.imageUrl || p.imageUrl,
                });
              } else {
                map.set(p.id, p);
              }
            });
            const merged = Array.from(map.values());
            merged.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
            return merged;
          });
        }
      }
    });

    // Listener for cross-component deletion event
    const handlePostDeleted = (e: any) => {
      const deletedId = e.detail?.postId;
      if (deletedId) {
        setUserPosts((prev) => prev.filter((p) => p.id !== deletedId));
        setAllPosts((prev) => prev.filter((p) => p.id !== deletedId));
        setSelectedVideoIds((prev) => prev.filter((id) => id !== deletedId));
      }
    };
    window.addEventListener('ghosted_post_deleted', handlePostDeleted);

    // 3. Realtime listener to Firestore posts collection with safe non-destructive merging
    try {
      const unsub = onSnapshot(collection(db, 'posts'), (snapshot) => {
        const deletedIds: string[] = JSON.parse(localStorage.getItem(`ghosted_deleted_posts_${user.id}`) || '[]');
        const loaded: GhostPost[] = [];
        snapshot.forEach((d) => {
          const data = d.data();
          if (data.isDeleted) return;
          if (deletedIds.includes(d.id)) return;
          const createdAtVal = data.createdAt?.toMillis
            ? data.createdAt.toMillis()
            : typeof data.createdAt === 'number'
            ? data.createdAt
            : Date.now();
          loaded.push({ id: d.id, ...data, createdAt: createdAtVal } as GhostPost);
        });
        loaded.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        setAllPosts(loaded);

        const currentUid = auth.currentUser?.uid;
        const myCloudPosts = loaded.filter(
          (p) =>
            !p.isDeleted &&
            !deletedIds.includes(p.id) &&
            (p.authorId === user.id ||
              p.userId === user.id ||
              (p.authorGhostedId && p.authorGhostedId === user.ghostedId) ||
              (currentUid && (p.authorId === currentUid || p.userId === currentUid)) ||
              (user.uid && (p.authorId === user.uid || p.userId === user.uid)))
        );

        // MERGE without wiping local posts
        setUserPosts((prev) => {
          const map = new Map<string, GhostPost>();
          // 1. Keep existing local posts
          prev.forEach((p) => {
            if (!deletedIds.includes(p.id) && !p.isDeleted) {
              map.set(p.id, p);
            }
          });
          // 2. Merge cloud posts
          myCloudPosts.forEach((cp) => {
            if (!deletedIds.includes(cp.id) && !cp.isDeleted) {
              const existing = map.get(cp.id);
              if (existing) {
                map.set(cp.id, {
                  ...cp,
                  mediaUrl: cp.mediaUrl || existing.mediaUrl || cp.imageUrl,
                  imageUrl: cp.imageUrl || existing.imageUrl || '',
                });
              } else {
                map.set(cp.id, cp);
              }
            }
          });
          const merged = Array.from(map.values());
          merged.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
          return merged;
        });

        try {
          // Store compact version in localStorage
          const compactPosts = myCloudPosts.map((p) => ({
            ...p,
            mediaUrl: p.mediaUrl && p.mediaUrl.length > 200000 ? (p.imageUrl || '') : p.mediaUrl,
          }));
          localStorage.setItem(`ghosted_user_posts_${user.id}`, JSON.stringify(compactPosts.slice(0, 40)));
        } catch {}
      }, (err) => {
        console.warn('Profile posts error:', err);
      });
      return () => {
        unsub();
        window.removeEventListener('ghosted_post_deleted', handlePostDeleted);
      };
    } catch (err) {
      console.warn('Firestore posts subscribe error:', err);
      return () => {
        window.removeEventListener('ghosted_post_deleted', handlePostDeleted);
      };
    }
  }, [user.id, user.uid]);

  // Ensure any local video posts have their full media blobs restored from IndexedDB
  useEffect(() => {
    userPosts.forEach((p) => {
      if (isPostVideo(p) && (!p.mediaUrl || p.mediaUrl.length < 100)) {
        getLocalMediaBlob(p.id).then((blob) => {
          if (blob) {
            setUserPosts((prev) =>
              prev.map((item) => (item.id === p.id && !item.mediaUrl ? { ...item, mediaUrl: blob } : item))
            );
          }
        });
      }
    });
  }, [userPosts.length]);

  const handleDeletePost = async (postId: string) => {
    try {
      await permanentlyDeletePost(postId, user.id);
    } catch (err) {
      console.warn('Delete post firestore warning:', err);
    }

    setUserPosts((prev) => prev.filter((p) => p.id !== postId));
    setAllPosts((prev) => prev.filter((p) => p.id !== postId));
    setSelectedVideoIds((prev) => prev.filter((id) => id !== postId));
    if (fullscreenMediaPost?.id === postId) {
      setFullscreenMediaPost(null);
    }
    showToast('Post deleted permanently everywhere 🗑️');
  };

  const handleDeleteSelectedVideos = async () => {
    if (selectedVideoIds.length === 0) return;
    setIsDeletingVideos(true);
    const idsToDelete = [...selectedVideoIds];
    try {
      for (const id of idsToDelete) {
        await permanentlyDeletePost(id, user.id);
      }
      setUserPosts((prev) => prev.filter((p) => !idsToDelete.includes(p.id)));
      setAllPosts((prev) => prev.filter((p) => !idsToDelete.includes(p.id)));
      setSelectedVideoIds([]);
      setIsSelectMode(false);
      setShowDeleteConfirmModal(false);
      showToast(`${idsToDelete.length} video${idsToDelete.length > 1 ? 's' : ''} deleted permanently everywhere 🗑️`);
    } catch (err) {
      console.warn('Error deleting selected videos:', err);
      showToast('Error deleting selected videos');
    } finally {
      setIsDeletingVideos(false);
      setShowDeleteConfirmModal(false);
    }
  };

  const handleSharePost = async (post: GhostPost) => {
    const shareUrl = post.mediaUrl || window.location.href;
    const shareText = post.text ? `${post.text}\nShared from GHOSTED` : 'Shared from GHOSTED';

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Ghosted Whisper',
          text: shareText,
          url: shareUrl,
        });
        // User completed share > app: increment shares count
        const updatedShares = (post.shares_count ?? post.sharesCount ?? 0) + 1;
        setUserPosts((prev) =>
          prev.map((p) =>
            p.id === post.id
              ? { ...p, sharesCount: updatedShares, shares_count: updatedShares }
              : p
          )
        );
        setAllPosts((prev) =>
          prev.map((p) =>
            p.id === post.id
              ? { ...p, sharesCount: updatedShares, shares_count: updatedShares }
              : p
          )
        );
        try {
          await updateDoc(doc(db, 'posts', post.id), {
            shares_count: increment(1),
            sharesCount: increment(1),
          });
        } catch {}
        showToast('Shared via app! 🚀');
      } catch (err: any) {
        if (err?.name !== 'AbortError') {
          console.warn('Share error:', err);
        }
      }
    } else {
      navigator.clipboard.writeText(shareUrl);
      showToast('Media post link copied to clipboard 📋');
    }
  };

  // Listen for comments on the active comment sheet post
  useEffect(() => {
    if (!activeCommentSheetPost) return;
    const unsub = onSnapshot(collection(db, 'post_comments'), (snap) => {
      const allC = snap.docs.map((d) => ({ id: d.id, ...d.data() } as GhostPostComment));
      const filtered = allC
        .filter((c) => c.postId === activeCommentSheetPost.id && !c.isDeleted)
        .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      setCommentsMap((prev) => ({ ...prev, [activeCommentSheetPost.id]: filtered }));
    });
    return () => unsub();
  }, [activeCommentSheetPost?.id]);

  const handleSendComment = async (
    postId: string,
    explicitText?: string,
    explicitIsGhost?: boolean,
    explicitHours?: number,
    attachments?: {
      imageUrl?: string;
      stickerUrl?: string;
      stickerType?: 'ghost' | 'custom_image' | 'live';
      stickerTitle?: string;
      mentionedProfileId?: string;
      mentionedVideoUrl?: string;
    }
  ) => {
    const rawText = explicitText?.trim() || '';
    if (!rawText && !attachments?.imageUrl && !attachments?.stickerUrl && !attachments?.mentionedVideoUrl) return;

    const check = rawText ? checkBadWords(rawText) : { isBlocked: false, flaggedWords: [], cleanText: '' };
    if (check.isBlocked) {
      showToast(`Comment blocked: prohibited words (${check.flaggedWords.join(', ')}).`);
      return;
    }

    const isGhost = explicitIsGhost ?? true;
    const selectedHours = isGhost ? (explicitHours ?? 24) : undefined;
    const now = Date.now();
    const commentId = `comm-${now}-${Math.random().toString(36).slice(2, 6)}`;
    const commentExpiresAt = isGhost && selectedHours ? now + selectedHours * 60 * 60 * 1000 : undefined;
    const randomDigits = Math.floor(1000 + Math.random() * 9000);

    const newComment: GhostPostComment = {
      id: commentId,
      postId,
      isGhost,
      ghostMode: isGhost,
      realUserId: user.id,
      realUsername: user.name || user.ghostedId || 'Ghoster',
      realUserAvatar: user.avatarUrl || '👻',
      originalText: check.cleanText,
      displayName: isGhost ? 'Ghost User' : user.name || 'Anonymous',
      ghostName: isGhost ? `Ghost #${randomDigits}` : undefined,
      revealAt: isGhost ? now + 86400000 : undefined,
      revealed: !isGhost,
      isDeleted: false,
      createdAt: now,
      commentExpiresAt,
      timerDurationHours: selectedHours,
      imageUrl: attachments?.imageUrl,
      stickerUrl: attachments?.stickerUrl,
      stickerType: attachments?.stickerType,
      stickerTitle: attachments?.stickerTitle,
      mentionedProfileId: attachments?.mentionedProfileId,
      mentionedVideoUrl: attachments?.mentionedVideoUrl,
    };

    try {
      await setDoc(doc(db, 'post_comments', commentId), newComment);
      const targetPost = userPosts.find((p) => p.id === postId) || allPosts.find((p) => p.id === postId);
      const newCount = (targetPost?.commentsCount || 0) + 1;
      await updateDoc(doc(db, 'posts', postId), { commentsCount: newCount });
      setUserPosts((prev) => prev.map((p) => (p.id === postId ? { ...p, commentsCount: newCount } : p)));
    } catch (err) {
      console.warn('Comment write error:', err);
    }

    showToast(isGhost ? `Posted as 👻 (Ghost me). Vanishes in ${selectedHours}h.` : 'Comment posted!');
  };

  const handleDeleteComment = async (postId: string, commentId: string) => {
    try {
      await deleteDoc(doc(db, 'post_comments', commentId));
      setCommentsMap((prev) => ({
        ...prev,
        [postId]: (prev[postId] || []).filter((c) => c.id !== commentId),
      }));
      const targetPost = userPosts.find((p) => p.id === postId);
      if (targetPost && (targetPost.commentsCount || 0) > 0) {
        const nextCount = Math.max(0, (targetPost.commentsCount || 1) - 1);
        await updateDoc(doc(db, 'posts', postId), { commentsCount: nextCount });
        setUserPosts((prev) => prev.map((p) => (p.id === postId ? { ...p, commentsCount: nextCount } : p)));
      }
      showToast('Comment deleted');
    } catch (err) {
      console.warn('Delete comment error:', err);
    }
  };

  const isPostVideo = (p: GhostPost) =>
    p.mediaType === 'video' ||
    Boolean(
      p.mediaUrl &&
        (p.mediaUrl.includes('.mp4') ||
          p.mediaUrl.includes('.webm') ||
          p.mediaUrl.includes('.mov') ||
          p.mediaUrl.includes('.m4v') ||
          p.mediaUrl.startsWith('data:video/'))
    );

  const [name, setName] = useState(user.name);
  const [avatarUrl, setAvatarUrl] = useState(user.avatarUrl);
  const [bio, setBio] = useState(user.bio || 'Seeking closure, warm memories, and safe re-connections without harassment.');
  const [dob, setDob] = useState(user.dob || '2000-01-15');
  const [gender, setGender] = useState<Gender>(user.gender || 'Prefer not to say');
  const [city, setCity] = useState(user.city || 'Lagos');
  const [stateCountry, setStateCountry] = useState(user.stateCountry || 'Nigeria');
  const [relationship, setRelationship] = useState<RelationshipType>(user.primaryRelationship || 'Friend');
  const [phone, setPhone] = useState(user.phone || '');
  const [ghostedId, setGhostedId] = useState(user.ghostedId);
  const [ghostedNumber, setGhostedNumber] = useState(user.ghostedNumber);

  const copyText = (txt: string, isId: boolean) => {
    navigator.clipboard.writeText(txt);
    if (isId) {
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    } else {
      setCopiedNum(true);
      setTimeout(() => setCopiedNum(false), 2000);
    }
  };

  const [copiedShare, setCopiedShare] = useState(false);
  const copyShare = () => {
    navigator.clipboard.writeText(`Call or whisper to me on Ghosted! My Ghosted Number: ${ghostedNumber} (ID: ${ghostedId})`);
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 2000);
  };

  const isTeen = isUserTeen(user);
  const [teenSettings, setTeenSettings] = useState<TeenSettings>(() => getTeenSettings(user.id));
  const [parentDashboardOpen, setParentDashboardOpen] = useState(false);
  const [parentEmailInput, setParentEmailInput] = useState(teenSettings.parentSupervision.parentEmail || '');

  const updateTeenSetting = <K extends keyof TeenSettings>(key: K, val: TeenSettings[K]) => {
    const updated = { ...teenSettings, [key]: val };
    setTeenSettings(updated);
    saveTeenSettings(user.id, updated);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setAvatarUrl(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleRegenerateGhostedId = () => {
    const newId = generateGhostedId();
    const newNum = generateGhostedNumber();
    setGhostedId(newId);
    setGhostedNumber(newNum);
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    const calculatedAge = calculateAge(dob);
    const isNigeria = stateCountry.toLowerCase().includes('nigeria') || (user.country && user.country.toLowerCase().includes('nigeria'));
    const updatedProfile: UserProfile = {
      ...user,
      name: name.trim() || user.name,
      avatarUrl,
      bio: bio.trim(),
      dob,
      age: calculatedAge,
      gender,
      city: city.trim(),
      stateCountry: stateCountry.trim(),
      country: isNigeria ? 'Nigeria' : (user.country || stateCountry.trim()),
      primaryRelationship: relationship,
      phone: phone.trim() || undefined,
      ghostedId,
      ghostedNumber,
      isPremium: isNigeria ? true : user.isPremium,
      dailySendsRemaining: isNigeria ? 999 : user.dailySendsRemaining,
      subscriptionPlan: isNigeria ? 'premium' : user.subscriptionPlan,
    };
    try {
      await fetch(`/api/users/${user.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedProfile),
      }).catch(() => {});
      if (onProfileUpdated) {
        onProfileUpdated(updatedProfile);
      }
      setSaveSuccess(true);
      setIsEditing(false);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch {
      if (onProfileUpdated) {
        onProfileUpdated(updatedProfile);
      }
      setIsEditing(false);
    } finally {
      setIsSaving(false);
    }
  };

  // The user sees all their own posts (public & private) in "(you post)" on their own profile
  const displayedPublicPosts = userPosts;
  const privatePosts = userPosts.filter((p) => p.audience === 'private');
  const likedPosts = allPosts.filter((p) => p.likedBy?.includes(user.id));

  const totalLikesCount = userPosts.reduce(
    (acc, p) => acc + (p.likedBy?.length ?? p.likesCount ?? 0),
    0
  );

  if (!showAccountInfo) {
    return (
      <div
        className="w-full min-h-screen font-sans flex flex-col transition-colors duration-300"
        style={{
          backgroundColor: currentTheme.background,
          color: currentTheme.textOutside,
        }}
      >
        {toastMessage && (
          <div
            className="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-full text-xs font-semibold shadow-2xl flex items-center space-x-2 animate-in fade-in slide-in-from-top duration-200 border"
            style={{
              backgroundColor: currentTheme.card,
              color: currentTheme.cardText,
              borderColor: currentTheme.border,
            }}
          >
            <Sparkles className="w-4 h-4 text-amber-400 flex-shrink-0" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* TOP HEADER */}
        <div
          className="sticky top-0 z-30 backdrop-blur-md border-b px-4 h-12 flex items-center justify-between transition-colors duration-300"
          style={{
            backgroundColor: currentTheme.headerBg,
            borderColor: currentTheme.headerBorder,
            color: currentTheme.headerText,
          }}
        >
          <button
            type="button"
            onClick={() => {
              window.history.pushState({ modal: 'profile_views' }, '');
              setShowProfileViewsModal(true);
            }}
            className={`p-1.5 active:scale-95 transition cursor-pointer relative flex items-center justify-center group ${
              isDark ? 'text-white hover:text-cyan-300' : 'text-slate-700 hover:text-slate-900'
            }`}
            title="Profile views - see who viewed your profile"
          >
            <Eye className="w-5 h-5 transition" />
            <span className="w-2 h-2 rounded-full bg-cyan-400 absolute top-1 right-1 animate-pulse ring-2 ring-white" />
          </button>

          <div className="flex items-center">
            <span className="font-extrabold text-sm tracking-tight">Profile</span>
          </div>

          <div className="flex items-center space-x-2">
            {/* 3DOTS MENU WITH CHANGE THEME AND ACCOUNT INFO */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowOptionsMenu((prev) => !prev)}
                className={`p-1.5 rounded-full active:scale-95 transition cursor-pointer ${
                  isDark ? 'text-white hover:bg-zinc-800' : 'text-slate-700 hover:bg-slate-100'
                }`}
                title="Profile Options"
              >
                <MoreVertical className="w-5 h-5 stroke-[2.2]" />
              </button>

              {showOptionsMenu && (
                <>
                  <div
                    className="fixed inset-0 z-40"
                    onClick={() => setShowOptionsMenu(false)}
                  />
                  <div
                    className={`absolute right-0 top-full mt-1.5 z-50 w-52 rounded-2xl p-1.5 shadow-2xl text-left animate-in fade-in zoom-in-95 duration-150 border transition-colors ${
                      isGhost
                        ? 'bg-[#15151F] border-[#2A2A3F] text-[#E0E0FF] shadow-[0_10px_35px_rgba(0,0,0,0.8),0_0_20px_rgba(124,58,237,0.25)]'
                        : isDark
                        ? 'bg-[#242526] border-[#3E4042] text-[#E4E6EB] shadow-2xl'
                        : 'bg-white border-[#E4E6EB] text-[#050505] shadow-xl'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => {
                        setShowOptionsMenu(false);
                        window.history.pushState({ modal: 'account_info' }, '');
                        setShowAccountInfo(true);
                      }}
                      className={`w-full flex items-center space-x-2.5 px-3 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                        isGhost
                          ? 'hover:bg-[#7C3AED]/20 text-[#E0E0FF]'
                          : isDark
                          ? 'hover:bg-[#3A3B3C] text-[#E4E6EB]'
                          : 'hover:bg-[#F2F2F2] text-[#050505]'
                      }`}
                    >
                      <ShieldCheck className="w-4 h-4 text-emerald-500 stroke-[2.4]" />
                      <span className="font-bold">Account info</span>
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* CENTER PROFILE SECTION */}
        <div className="flex flex-col items-center pt-5 pb-2 px-4 max-w-lg mx-auto w-full">
          <div className="relative w-[114px] h-[126px] my-1 flex items-center justify-center">
            <svg width="0" height="0" className="absolute">
              <defs>
                <clipPath id="cartoonGhostSheetClip" clipPathUnits="objectBoundingBox">
                  <path d="M 0.5 0.02 C 0.26 0.02, 0.08 0.22, 0.08 0.46 C 0.08 0.68, 0.02 0.82, 0.05 0.91 C 0.08 0.98, 0.18 0.98, 0.23 0.91 C 0.28 0.84, 0.35 0.84, 0.40 0.91 C 0.46 0.98, 0.54 0.98, 0.60 0.91 C 0.65 0.84, 0.72 0.84, 0.77 0.91 C 0.82 0.98, 0.92 0.98, 0.95 0.91 C 0.98 0.82, 0.92 0.68, 0.92 0.46 C 0.92 0.22, 0.74 0.02, 0.5 0.02 Z" />
                </clipPath>
              </defs>
            </svg>
            <div className="absolute inset-0 filter drop-shadow-[0_0_12px_rgba(255,255,255,0.7)] pointer-events-none animate-pulse duration-3000">
              <svg viewBox="0 0 100 115" className="w-full h-full fill-white/10 stroke-white/80 stroke-[2.5]">
                <path d="M 50 3 C 26 3, 8 25, 8 52 C 8 78, 2 94, 5 104 C 8 112, 18 112, 23 104 C 28 96, 35 96, 40 104 C 46 112, 54 112, 60 104 C 65 96, 72 96, 77 104 C 82 112, 92 112, 95 104 C 98 94, 92 78, 92 52 C 92 25, 74 3, 50 3 Z" />
              </svg>
            </div>
            <div
              style={{ clipPath: 'url(#cartoonGhostSheetClip)' }}
              className="w-[104px] h-[116px] bg-zinc-900 flex items-center justify-center overflow-hidden relative shadow-2xl"
            >
              {avatarUrl && (avatarUrl.startsWith('http') || avatarUrl.startsWith('data:')) ? (
                <img
                  src={avatarUrl}
                  alt={name || user.name}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                  }}
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center font-bold text-3xl text-white bg-gradient-to-b from-purple-800 to-indigo-950">
                  <span className="text-4xl mt-2">👻</span>
                </div>
              )}
              <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-transparent via-transparent to-black/40" />
              <div className="absolute top-8 flex space-x-4 pointer-events-none opacity-40">
                <div className="w-2.5 h-3.5 rounded-full bg-black/70" />
                <div className="w-2.5 h-3.5 rounded-full bg-black/70" />
              </div>
            </div>
            <button
              type="button"
              onClick={() => avatarFileInputRef.current?.click()}
              className="absolute bottom-0 right-1 w-7 h-7 rounded-full bg-[#20D5EC] hover:bg-[#1bc1d5] text-black font-black flex items-center justify-center shadow-lg border-2 border-black active:scale-90 transition cursor-pointer z-10"
              title="Add photo or change avatar"
            >
              <Plus className="w-4 h-4 text-black stroke-[3.2]" />
            </button>
            <input
              ref={avatarFileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileUpload}
            />
          </div>

          <div className="flex items-center justify-center space-x-1.5 mt-2.5">
            <h2 className={`text-base sm:text-lg font-bold tracking-tight ${isDark ? 'text-white' : 'text-[#050505]'}`}>
              {name || user.name || 'Ghost User'}
            </h2>
            <ChevronDown
              onClick={() => setShowAccountInfo(true)}
              className={`w-4 h-4 cursor-pointer transition ${isDark ? 'text-zinc-400 hover:text-white' : 'text-gray-500 hover:text-black'}`}
            />
          </div>

          <p className={`text-xs font-mono mt-0.5 select-text ${isDark ? 'text-zinc-400' : 'text-[#65676B]'}`}>
            @{user.ghostedId ? user.ghostedId.toLowerCase().replace(/[^a-z0-9_]/g, '_') : 'ghost_user'}
          </p>

          <div className="flex items-center space-x-2 mt-3.5">
            <button
              type="button"
              onClick={() => setShowUploadPostModal(true)}
              className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center space-x-1.5 transition active:scale-95 shadow-xs cursor-pointer ${
                isGhost
                  ? 'bg-gradient-to-r from-[#00F5FF] to-[#7C3AED] text-black font-extrabold shadow-[0_0_15px_rgba(0,245,255,0.4)]'
                  : 'bg-[#1877F2] hover:bg-[#166fe5] text-white font-extrabold'
              }`}
              title="Create Post"
            >
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
              <span>Post</span>
            </button>
            <button
              type="button"
              onClick={() => setShowAccountInfo(true)}
              className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center space-x-1.5 transition active:scale-95 shadow-xs cursor-pointer ${
                isGhost
                  ? 'bg-[#15151F] border border-[#2A2A3F] text-[#E0E0FF] hover:border-[#7C3AED]'
                  : isDark
                  ? 'bg-[#3A3B3C] hover:bg-[#4E4F50] text-[#E4E6EB] border border-[#4E4F50]'
                  : 'bg-[#E4E6EB] hover:bg-[#D8DADF] text-[#050505] border border-gray-300'
              }`}
            >
              <Pencil className="w-3.5 h-3.5" />
              <span>Edit profile</span>
            </button>
            <button
              type="button"
              onClick={handleShareProfile}
              className={`p-2 rounded-lg text-xs font-bold flex items-center justify-center transition active:scale-95 shadow-xs cursor-pointer ${
                isGhost
                  ? 'bg-[#15151F] border border-[#2A2A3F] text-[#00F5FF] hover:border-[#00F5FF]'
                  : isDark
                  ? 'bg-[#3A3B3C] hover:bg-[#4E4F50] text-[#E4E6EB] border border-[#4E4F50]'
                  : 'bg-[#E4E6EB] hover:bg-[#D8DADF] text-[#050505] border border-gray-300'
              }`}
              title="Share profile"
            >
              <Share2 className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className={`flex items-center justify-center space-x-8 py-3.5 mt-3 w-full border-y transition-colors ${
            isGhost ? 'border-[#2A2A3F]' : isDark ? 'border-[#3E4042]' : 'border-[#E4E6EB]'
          }`}>
            <div
              onClick={() => setShowFollowListModal('following')}
              className="text-center cursor-pointer hover:opacity-80 active:scale-95 transition"
              title="Tap to see who you are following"
            >
              <span className={`text-sm sm:text-base font-bold block ${
                isGhost ? 'text-[#E0E0FF]' : isDark ? 'text-white' : 'text-[#050505]'
              }`}>
                {followingList.length}
              </span>
              <span className={`text-[11px] font-medium ${
                isGhost ? 'text-[#8A8AA3]' : isDark ? 'text-[#B0B3B8]' : 'text-[#65676B]'
              }`}>Following</span>
            </div>
            <div className={`w-[1px] h-3.5 ${
              isGhost ? 'bg-[#2A2A3F]' : isDark ? 'bg-[#3E4042]' : 'bg-gray-300'
            }`} />
            <div
              onClick={() => setShowFollowListModal('followers')}
              className="text-center cursor-pointer hover:opacity-80 active:scale-95 transition"
              title="Tap to see your followers"
            >
              <span className={`text-sm sm:text-base font-bold block ${
                isGhost ? 'text-[#E0E0FF]' : isDark ? 'text-white' : 'text-[#050505]'
              }`}>
                {followersList.length}
              </span>
              <span className={`text-[11px] font-medium ${
                isGhost ? 'text-[#8A8AA3]' : isDark ? 'text-[#B0B3B8]' : 'text-[#65676B]'
              }`}>Followers</span>
            </div>
            <div className={`w-[1px] h-3.5 ${
              isGhost ? 'bg-[#2A2A3F]' : isDark ? 'bg-[#3E4042]' : 'bg-gray-300'
            }`} />
            <div
              onClick={() => setActiveProfileTab('favorites')}
              className="text-center cursor-pointer hover:opacity-80 active:scale-95 transition"
              title="Likes received"
            >
              <span className={`text-sm sm:text-base font-bold block ${
                isGhost ? 'text-[#E0E0FF]' : isDark ? 'text-white' : 'text-[#050505]'
              }`}>
                {totalLikesCount}
              </span>
              <span className={`text-[11px] font-medium ${
                isGhost ? 'text-[#8A8AA3]' : isDark ? 'text-[#B0B3B8]' : 'text-[#65676B]'
              }`}>Likes</span>
            </div>
          </div>

          <div className="py-2.5 px-4 text-center max-w-sm">
            <p className={`text-xs leading-relaxed whitespace-pre-wrap select-text font-medium ${
              isGhost ? 'text-[#E0E0FF]/90' : isDark ? 'text-[#E4E6EB]' : 'text-[#050505]'
            }`}>
              {bio || 'Whispering in THE VOID 🌌\nGhosted ID: ' + user.ghostedId + ' 🕊️\nAlways listen to the quiet truth ✨'}
            </p>
          </div>
        </div>

        {/* TABS ROW BELOW BIO */}
        <div className={`border-b sticky top-12 z-20 flex items-center justify-around w-full max-w-lg mx-auto transition-colors duration-300 ${
          isGhost
            ? 'border-[#2A2A3F] bg-[#0F0F19]'
            : isDark
            ? 'border-[#3E4042] bg-[#18191A]'
            : 'border-[#E4E6EB] bg-white shadow-xs'
        }`}>
          {[
            { id: 'you_post', icon: LayoutGrid, title: '(you post)' },
            { id: 'favorites', icon: Bookmark, title: 'Favourites' },
            { id: 'watched', icon: Clock, title: 'Recently Watched' },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeProfileTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveProfileTab(tab.id as any)}
                className={`flex-1 py-3 flex flex-col items-center justify-center relative transition cursor-pointer ${
                  isActive
                    ? isGhost
                      ? 'text-[#00F5FF] font-bold'
                      : isDark
                      ? 'text-white font-bold'
                      : 'text-[#0866FF] font-bold'
                    : isGhost
                    ? 'text-[#8A8AA3] hover:text-[#E0E0FF]'
                    : isDark
                    ? 'text-[#B0B3B8] hover:text-[#E4E6EB]'
                    : 'text-[#65676B] hover:text-[#050505]'
                }`}
                title={tab.title}
              >
                <div className="flex items-center space-x-1.5">
                  <Icon className="w-4 h-4 stroke-[2.2]" />
                  <span className="text-xs font-semibold">{tab.title}</span>
                </div>
                {isActive && (
                  <div className={`absolute bottom-0 left-1/4 right-1/4 h-[2.5px] rounded-full transition-all duration-200 ${
                    isGhost ? 'bg-[#00F5FF] shadow-[0_0_8px_rgba(0,245,255,0.8)]' : isDark ? 'bg-[#2374E1]' : 'bg-[#0866FF]'
                  }`} />
                )}
              </button>
            );
          })}
        </div>

        {/* CONTENT AREA */}
        <div className={`flex-1 w-full min-h-[360px] pb-12 transition-colors duration-300 ${
          isGhost ? 'bg-[#0A0A0F]' : isDark ? 'bg-[#18191A]' : 'bg-[#F0F2F5]'
        }`}>
          {(activeProfileTab === 'you_post' || (activeProfileTab as string) === 'posts' || (activeProfileTab as string) === 'videos') && (
            <div className="space-y-3 p-2 max-w-lg mx-auto animate-in fade-in duration-200">
              {/* Header Action Bar */}
              <div
                className="flex flex-col sm:flex-row sm:items-center justify-between p-3 rounded-2xl border shadow-xs gap-2.5"
                style={{
                  backgroundColor: isGhost ? '#12121E' : isDark ? '#242526' : '#FFFFFF',
                  borderColor: currentTheme.border,
                }}
              >
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
                    <LayoutGrid className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs font-bold" style={{ color: currentTheme.cardText }}>
                      (you post)
                    </h3>
                    <span className="text-[10px] font-mono" style={{ color: currentTheme.cardSubtext }}>
                      {displayedPublicPosts.length} posts • {displayedPublicPosts.filter(isPostVideo).length} videos, {displayedPublicPosts.filter((p) => !isPostVideo(p) && (p.mediaUrl || p.imageUrl)).length} photos
                    </span>
                  </div>
                </div>

                {/* Sub-filter chips & Selection buttons */}
                <div className="flex items-center space-x-1.5 flex-wrap">
                  <div className="flex items-center bg-black/20 rounded-xl p-0.5 border border-white/10 text-[11px] font-semibold">
                    {(['all', 'videos', 'photos', 'text'] as const).map((filterKey) => (
                      <button
                        key={filterKey}
                        type="button"
                        onClick={() => setYouPostFilter(filterKey)}
                        className={`px-2 py-1 rounded-lg capitalize transition cursor-pointer ${
                          youPostFilter === filterKey
                            ? 'bg-purple-600 text-white font-bold shadow-xs'
                            : 'text-zinc-400 hover:text-white'
                        }`}
                      >
                        {filterKey === 'all' ? 'All' : filterKey === 'text' ? 'Whispers' : filterKey}
                      </button>
                    ))}
                  </div>

                  {displayedPublicPosts.length > 0 && (
                    <div className="flex items-center space-x-1">
                      {isSelectMode ? (
                        <>
                          <button
                            type="button"
                            onClick={() => {
                              const currentFiltered = displayedPublicPosts.filter((p) => {
                                if (youPostFilter === 'videos') return isPostVideo(p);
                                if (youPostFilter === 'photos') return !isPostVideo(p) && (p.mediaUrl || p.imageUrl);
                                if (youPostFilter === 'text') return !p.mediaUrl && !p.imageUrl;
                                return true;
                              });
                              const allIds = currentFiltered.map((v) => v.id);
                              if (selectedVideoIds.length === allIds.length) {
                                setSelectedVideoIds([]);
                              } else {
                                setSelectedVideoIds(allIds);
                              }
                            }}
                            className="px-2 py-1 rounded-xl text-[10px] font-semibold border transition cursor-pointer"
                            style={{
                              backgroundColor: isBlack ? '#3A3B3C' : '#F0F2F5',
                              color: currentTheme.cardText,
                              borderColor: currentTheme.border,
                            }}
                          >
                            {selectedVideoIds.length > 0 ? 'Deselect All' : 'Select All'}
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setIsSelectMode(false);
                              setSelectedVideoIds([]);
                            }}
                            className="px-2 py-1 rounded-xl text-[10px] font-semibold text-zinc-400 hover:text-white transition cursor-pointer"
                          >
                            Cancel
                          </button>
                        </>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setIsSelectMode(true)}
                          className="px-2.5 py-1 rounded-xl text-[10px] font-bold bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/40 transition active:scale-95 cursor-pointer flex items-center space-x-1"
                        >
                          <Check className="w-3 h-3" />
                          <span>Select</span>
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Selection banner when 1+ selected */}
              {isSelectMode && selectedVideoIds.length > 0 && (
                <div className="p-3 rounded-2xl bg-gradient-to-r from-purple-950/80 via-rose-950/80 to-black border border-rose-500/40 flex items-center justify-between shadow-xl animate-in slide-in-from-top-2 duration-150">
                  <span className="text-xs font-bold text-white flex items-center space-x-1.5">
                    <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                    <span>
                      {selectedVideoIds.length} {selectedVideoIds.length === 1 ? 'post' : 'posts'} selected
                    </span>
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setVideoToDeleteSingle(null);
                      setShowDeleteConfirmModal(true);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg shadow-rose-950/50 flex items-center space-x-1.5 transition active:scale-95 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete Selected</span>
                  </button>
                </div>
              )}

              {/* Filtered Posts Grid */}
              {(() => {
                const filtered = displayedPublicPosts.filter((p) => {
                  if (youPostFilter === 'videos') return isPostVideo(p);
                  if (youPostFilter === 'photos') return !isPostVideo(p) && (p.mediaUrl || p.imageUrl);
                  if (youPostFilter === 'text') return !p.mediaUrl && !p.imageUrl;
                  return true;
                });

                if (filtered.length === 0) {
                  return (
                    <div className="py-16 text-center space-y-3 px-6 max-w-xs mx-auto">
                      <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto border ${
                        isGhost
                          ? 'bg-[#15151F] border-[#2A2A3F] text-[#8A8AA3]'
                          : isDark
                          ? 'bg-zinc-900 border-zinc-800 text-zinc-500'
                          : 'bg-white border-gray-200 text-[#65676B] shadow-xs'
                      }`}>
                        <LayoutGrid className="w-8 h-8" />
                      </div>
                      <h4 className={`text-sm font-bold ${
                        isGhost ? 'text-[#E0E0FF]' : isDark ? 'text-white' : 'text-[#050505]'
                      }`}>Upload your first post to (you post)</h4>
                      <p className={`text-xs ${
                        isGhost ? 'text-[#8A8AA3]' : isDark ? 'text-zinc-500' : 'text-[#65676B]'
                      }`}>Your whispers, pictures, and videos will appear here together on your profile.</p>
                    </div>
                  );
                }

                return (
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 sm:gap-2">
                    {filtered.map((post) => {
                      const isSelected = selectedVideoIds.includes(post.id);
                      const isVid = isPostVideo(post);
                      return (
                        <div
                          key={post.id}
                          onClick={() => {
                            if (isSelectMode) {
                              setSelectedVideoIds((prev) =>
                                prev.includes(post.id)
                                  ? prev.filter((id) => id !== post.id)
                                  : [...prev, post.id]
                              );
                            } else {
                              window.history.pushState({ modal: 'fullscreen_media', postId: post.id }, '');
                              setFullscreenMediaPost(post);
                            }
                          }}
                          className={`relative aspect-[3/4] rounded-2xl overflow-hidden cursor-pointer group border transition-all duration-200 ${
                            isSelected
                              ? 'border-2 border-purple-500 ring-4 ring-purple-500/50 shadow-[0_0_20px_rgba(168,85,247,0.8)] scale-[0.98]'
                              : 'border-white/10 hover:border-purple-400/40 bg-zinc-900'
                          }`}
                        >
                          {isVid ? (
                            <div className="w-full h-full relative">
                              <video
                                src={post.mediaUrl}
                                className="w-full h-full object-cover"
                                muted
                                playsInline
                                loop
                              />
                              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
                              <div className="absolute bottom-2 left-2 flex items-center space-x-1 text-white text-[11px] font-bold font-mono">
                                <Play className="w-3 h-3 fill-white" />
                                <span>{(post.likedBy?.length ?? post.likesCount ?? 0).toLocaleString()}</span>
                              </div>
                            </div>
                          ) : post.mediaUrl || post.imageUrl ? (
                            <div className="w-full h-full relative">
                              <img
                                src={post.mediaUrl || post.imageUrl}
                                alt=""
                                className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                              />
                              {post.isEnhanced && (
                                <div className="absolute top-2 left-2 px-1.5 py-0.5 rounded-md bg-purple-600/90 text-white font-extrabold text-[9px] shadow-md border border-purple-300/30 flex items-center space-x-0.5 backdrop-blur-md z-10 pointer-events-none">
                                  <span>✨ HD</span>
                                </div>
                              )}
                              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent pointer-events-none" />
                              <div className="absolute bottom-2 left-2 flex items-center space-x-1 text-white text-[11px] font-bold font-mono">
                                <Heart className="w-3 h-3 fill-white text-white" />
                                <span>{(post.likedBy?.length ?? post.likesCount ?? 0).toLocaleString()}</span>
                              </div>
                            </div>
                          ) : (
                            <div className="w-full h-full bg-gradient-to-br from-[#1b0d38] via-[#100726] to-black p-3 flex flex-col justify-between text-left">
                              <span className="text-base opacity-75">🌌</span>
                              <p className="text-[11px] text-zinc-200 line-clamp-4 leading-tight font-medium">
                                "{post.text}"
                              </p>
                              <div className="flex items-center space-x-1 text-purple-300 text-[10px] font-mono">
                                <Heart className="w-2.5 h-2.5 fill-purple-400 text-purple-400" />
                                <span>{post.likedBy?.length ?? post.likesCount ?? 0}</span>
                              </div>
                            </div>
                          )}

                          {/* Top Selection Indicator */}
                          <div className="absolute top-2 left-2 z-20">
                            {isSelectMode ? (
                              <div
                                className={`w-6 h-6 rounded-lg flex items-center justify-center transition-all ${
                                  isSelected
                                    ? 'bg-purple-600 text-white ring-2 ring-purple-300 shadow-lg scale-105'
                                    : 'bg-black/60 border-2 border-white/60 text-transparent'
                                }`}
                              >
                                <Check className="w-3.5 h-3.5 stroke-[3]" />
                              </div>
                            ) : null}
                          </div>

                          {/* Direct Delete button when not in bulk mode */}
                          {!isSelectMode && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setVideoToDeleteSingle(post);
                                setShowDeleteConfirmModal(true);
                              }}
                              className="absolute top-2 right-2 p-1.5 rounded-full bg-black/70 hover:bg-rose-600 text-rose-300 hover:text-white transition z-20 cursor-pointer shadow-lg opacity-80 group-hover:opacity-100"
                              title="Delete post"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* Bottom right shares indicator */}
                          <div className="absolute bottom-2 right-2 text-white/80 text-[10px] font-mono flex items-center space-x-0.5 pointer-events-none">
                            <Send className="w-2.5 h-2.5 -rotate-12" />
                            <span>{(post.shares_count ?? post.sharesCount ?? 0)}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                );
              })()}
            </div>
          )}

          {activeProfileTab === 'favorites' && (
            (savedPosts.length > 0 ? savedPosts : allPosts.filter((p) => p.likedBy?.includes(user.id))).length === 0 ? (
              <div className="py-16 text-center space-y-3 px-6 max-w-xs mx-auto">
                <div className="w-16 h-16 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-amber-400 mx-auto">
                  <Bookmark className="w-8 h-8" />
                </div>
                <h4 className="text-sm font-bold text-white">No favourites yet</h4>
                <p className="text-xs text-zinc-500">Tap the bookmark or like button on any post in THE VOID to collect your favourite posts here.</p>
              </div>
            ) : (
              <div className="grid grid-cols-3 gap-0.5 sm:gap-1 max-w-lg mx-auto bg-black">
                {(savedPosts.length > 0 ? savedPosts : allPosts.filter((p) => p.likedBy?.includes(user.id))).map((post) => (
                  <div
                    key={post.id}
                    onClick={() => {
                      window.history.pushState({ modal: 'fullscreen_media', postId: post.id }, '');
                      setFullscreenMediaPost(post);
                    }}
                    className="relative aspect-[3/4] bg-zinc-900 overflow-hidden cursor-pointer group border border-white/5"
                  >
                    {post.mediaType === 'video' || (post.mediaUrl && (post.mediaUrl.includes('.mp4') || post.mediaUrl.includes('.webm'))) ? (
                      <div className="w-full h-full relative">
                        <video src={post.mediaUrl} className="w-full h-full object-cover" muted playsInline loop />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent pointer-events-none" />
                        <div className="absolute bottom-1.5 left-1.5 flex items-center space-x-1 text-white text-[11px] font-bold font-mono">
                          <Play className="w-3 h-3 fill-white" />
                          <span>{(post.likedBy?.length ?? post.likesCount ?? 0).toLocaleString()}</span>
                        </div>
                      </div>
                    ) : post.mediaUrl ? (
                      <div className="w-full h-full relative">
                        <img src={post.mediaUrl} alt="" className="w-full h-full object-cover" />
                        <div className="absolute top-1.5 right-1.5 p-1 rounded-full bg-black/60 backdrop-blur-md">
                          <Bookmark className="w-3 h-3 text-amber-400 fill-amber-400" />
                        </div>
                      </div>
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-amber-950/30 to-black p-3 flex flex-col justify-between">
                        <Bookmark className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                        <p className="text-[11px] text-zinc-300 line-clamp-4 font-medium">"{post.text}"</p>
                        <span className="text-[10px] text-amber-300 font-mono">Saved</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )
          )}

          {activeProfileTab === 'watched' && (
            (watchedPosts.length > 0 ? watchedPosts : allPosts.slice(0, 6)).length === 0 ? (
              <div className="py-16 text-center space-y-3 px-6 max-w-xs mx-auto">
                <div className="w-16 h-16 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-cyan-400 mx-auto">
                  <Clock className="w-8 h-8" />
                </div>
                <h4 className="text-sm font-bold text-white">No watch history yet</h4>
                <p className="text-xs text-zinc-500">Posts and videos you watch in THE VOID will appear here in your watch history.</p>
              </div>
            ) : (
              <div className="grid grid-cols-3 gap-0.5 sm:gap-1 max-w-lg mx-auto bg-black">
                {(watchedPosts.length > 0 ? watchedPosts : allPosts.slice(0, 6)).map((post, idx) => (
                  <div
                    key={`${post.id}-${idx}`}
                    onClick={() => {
                      window.history.pushState({ modal: 'fullscreen_media', postId: post.id }, '');
                      setFullscreenMediaPost(post);
                    }}
                    className="relative aspect-[3/4] bg-zinc-900 overflow-hidden cursor-pointer group border border-white/5"
                  >
                    {post.mediaType === 'video' || (post.mediaUrl && (post.mediaUrl.includes('.mp4') || post.mediaUrl.includes('.webm'))) ? (
                      <div className="w-full h-full relative">
                        <video src={post.mediaUrl} className="w-full h-full object-cover" muted playsInline loop />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
                        <div className="absolute bottom-1.5 left-1.5 flex items-center space-x-1 text-cyan-300 text-[10px] font-bold font-mono">
                          <Eye className="w-3 h-3 text-cyan-400" />
                          <span>Watched</span>
                        </div>
                      </div>
                    ) : post.mediaUrl ? (
                      <div className="w-full h-full relative">
                        <img src={post.mediaUrl} alt="" className="w-full h-full object-cover" />
                        <div className="absolute bottom-1.5 left-1.5 px-1.5 py-0.5 rounded-full bg-black/70 backdrop-blur-md text-[9px] text-cyan-300 font-mono flex items-center space-x-0.5">
                          <Clock className="w-2.5 h-2.5" />
                          <span>Watched</span>
                        </div>
                      </div>
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-cyan-950/30 to-black p-3 flex flex-col justify-between">
                        <Clock className="w-3.5 h-3.5 text-cyan-400" />
                        <p className="text-[11px] text-zinc-300 line-clamp-4 font-medium">"{post.text}"</p>
                        <span className="text-[10px] text-cyan-400 font-mono">Watched</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )
          )}
        </div>

        {/* FOLLOWING / FOLLOWERS LIST MODAL */}
        {showFollowListModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
            <div className="relative w-full max-w-sm bg-[#121212] border border-zinc-800 rounded-3xl p-5 text-left space-y-4 shadow-2xl">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                <div className="flex items-center space-x-2">
                  <Users className="w-4 h-4 text-[#20D5EC]" />
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                    {showFollowListModal === 'following'
                      ? `Following (${followingList.length})`
                      : `Followers (${followersList.length})`}
                  </h3>
                </div>
                <button
                  type="button"
                  data-back-dismissible="true"
                  onClick={() => setShowFollowListModal(null)}
                  className="p-1 rounded-full text-zinc-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="max-h-64 overflow-y-auto space-y-2">
                {showFollowListModal === 'following' ? (
                  followingList.length === 0 ? (
                    <div className="py-8 text-center space-y-2.5">
                      <p className="text-xs text-zinc-400 font-medium">You are not following anyone yet.</p>
                      <button
                        type="button"
                        onClick={() => {
                          setShowFollowListModal(null);
                          setShowAddFriendModal(true);
                        }}
                        className="px-4 py-2 rounded-full bg-[#20D5EC] hover:bg-[#1bc1d5] text-black font-bold text-xs transition active:scale-95"
                      >
                        Discover People to Follow
                      </button>
                    </div>
                  ) : (
                    followingList.map((id) => (
                      <div
                        key={id}
                        className="flex items-center justify-between p-2.5 rounded-2xl bg-zinc-900 border border-zinc-800 text-xs"
                      >
                        <div className="flex items-center space-x-2.5">
                          <div className="w-8 h-8 rounded-full bg-purple-600/30 flex items-center justify-center font-bold text-white text-xs">
                            👻
                          </div>
                          <div>
                            <span className="font-bold text-white block">{id}</span>
                            <span className="text-[10px] text-zinc-400 font-mono">Ghost Creator</span>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleToggleFollow(id)}
                          className="px-3 py-1 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-semibold text-[11px] transition active:scale-95"
                        >
                          Unfollow
                        </button>
                      </div>
                    ))
                  )
                ) : (
                  followersList.length === 0 ? (
                    <div className="py-8 text-center space-y-2">
                      <p className="text-xs text-zinc-400 font-medium">You have 0 followers right now.</p>
                      <p className="text-[11px] text-zinc-500 leading-relaxed px-4">
                        Share your Ghosted ID or whisper in THE VOID so others can follow your account!
                      </p>
                    </div>
                  ) : (
                    followersList.map((id) => (
                      <div
                        key={id}
                        className="flex items-center justify-between p-2.5 rounded-2xl bg-zinc-900 border border-zinc-800 text-xs"
                      >
                        <div className="flex items-center space-x-2.5">
                          <div className="w-8 h-8 rounded-full bg-cyan-600/30 flex items-center justify-center font-bold text-white text-xs">
                            👻
                          </div>
                          <div>
                            <span className="font-bold text-white block">{id}</span>
                            <span className="text-[10px] text-zinc-400 font-mono">Follower</span>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleToggleFollow(id)}
                          className={`px-3 py-1 rounded-full text-[11px] font-semibold transition active:scale-95 ${
                            followingList.includes(id)
                              ? 'bg-zinc-800 text-zinc-300'
                              : 'bg-[#20D5EC] text-black font-bold'
                          }`}
                        >
                          {followingList.includes(id) ? 'Following' : 'Follow Back'}
                        </button>
                      </div>
                    ))
                  )
                )}
              </div>
            </div>
          </div>
        )}

        {/* PROFILE VIEWS MODAL */}
        {showProfileViewsModal && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
            <div className="relative w-full max-w-md bg-[#120a2e] border-t sm:border border-purple-500/30 rounded-t-3xl sm:rounded-3xl p-5 text-left space-y-4 shadow-2xl">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div className="flex items-center space-x-2">
                  <div className="p-2 rounded-xl bg-purple-500/20 text-cyan-400">
                    <Eye className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider">Profile Views</h3>
                    <p className="text-[11px] text-purple-200/70">People who viewed your profile in past 30 days</p>
                  </div>
                </div>
                <button
                  type="button"
                  data-back-dismissible="true"
                  onClick={() => setShowProfileViewsModal(false)}
                  className="p-1 rounded-full text-zinc-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-center justify-between p-3 rounded-2xl bg-white/5 border border-white/10">
                <div>
                  <span className="text-xs font-bold text-white block">Profile View History</span>
                  <span className="text-[10px] text-purple-200/70">Allow others to see when you view their profile</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const next = !profileViewHistoryEnabled;
                    setProfileViewHistoryEnabled(next);
                    localStorage.setItem(`ghosted_view_history_opt_${user.id}`, String(next));
                    showToast(next ? 'Profile view history ON' : 'Profile view history OFF');
                  }}
                  className={`w-11 h-6 rounded-full transition cursor-pointer p-0.5 ${
                    profileViewHistoryEnabled ? 'bg-cyan-500' : 'bg-zinc-700'
                  }`}
                >
                  <div
                    className={`w-5 h-5 rounded-full bg-white transition-transform ${
                      profileViewHistoryEnabled ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              <div className="max-h-72 overflow-y-auto space-y-2 pr-1">
                {profileViewers.length === 0 ? (
                  <div className="py-12 text-center space-y-2 px-4">
                    <div className="w-12 h-12 rounded-full bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-cyan-400 mx-auto">
                      <Eye className="w-6 h-6" />
                    </div>
                    <h4 className="text-xs font-bold text-white">No profile views yet</h4>
                    <p className="text-[11px] text-purple-200/60 leading-relaxed max-w-xs mx-auto">
                      Only real profile views appear here. When other users visit your profile, their real visits will show up in this list.
                    </p>
                  </div>
                ) : (
                  profileViewers.map((viewer) => (
                    <div
                      key={viewer.id}
                      className="flex items-center justify-between p-2.5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 transition"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-lg overflow-hidden border border-purple-400/40">
                          {viewer.avatar.startsWith('http') ? (
                            <img src={viewer.avatar} alt="" className="w-full h-full object-cover" />
                          ) : (
                            viewer.avatar
                          )}
                        </div>
                        <div>
                          <span className="text-xs font-bold text-white block">{viewer.name}</span>
                          <span className="text-[10px] text-purple-300 font-mono block">@{viewer.handle}</span>
                          <span className="text-[9px] text-zinc-400">{viewer.viewedAt}</span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleToggleFollow(viewer.id, viewer.name)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition active:scale-95 ${
                          followingList.includes(viewer.id)
                            ? 'bg-zinc-800 text-zinc-300 border border-zinc-700'
                            : 'bg-[#20D5EC] text-black shadow-sm font-black'
                        }`}
                      >
                        {followingList.includes(viewer.id) ? 'Following' : 'Follow'}
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {fullscreenMediaPost && (
          <FullscreenMediaViewer
            post={fullscreenMediaPost}
            user={user}
            isOpen={true}
            onClose={() => setFullscreenMediaPost(null)}
            onLikeToggle={(p) => {
              const isLiked = p.likedBy?.includes(user.id);
              const updatedLikedBy = isLiked
                ? (p.likedBy || []).filter((id) => id !== user.id)
                : [...(p.likedBy || []), user.id];
              const updatedPost = { ...p, likedBy: updatedLikedBy, likesCount: updatedLikedBy.length };
              setFullscreenMediaPost(updatedPost);
              setUserPosts((prev) => prev.map((item) => (item.id === p.id ? updatedPost : item)));
              updateDoc(doc(db, 'posts', p.id), {
                likedBy: updatedLikedBy,
                likesCount: updatedLikedBy.length,
              }).catch(() => {});
            }}
            onDownload={(p) => handleDownloadPost(p)}
            onOpenComments={(p) => setActiveCommentSheetPost(p)}
            onShare={(p) => handleSharePost(p)}
            onDelete={(p) => handleDeletePost(p.id)}
          />
        )}

        {/* COMMENT BOTTOM SHEET */}
        {activeCommentSheetPost && (
          <CommentBottomSheet
            isOpen={!!activeCommentSheetPost}
            onClose={() => setActiveCommentSheetPost(null)}
            post={activeCommentSheetPost}
            user={user}
            comments={commentsMap[activeCommentSheetPost.id] || []}
            onAddComment={handleSendComment}
            onDeleteComment={handleDeleteComment}
            onLikeToggle={(postId) => {
              const target = userPosts.find((p) => p.id === postId) || allPosts.find((p) => p.id === postId);
              if (target) {
                const isLiked = target.likedBy?.includes(user.id);
                const updatedLikedBy = isLiked
                  ? (target.likedBy || []).filter((id) => id !== user.id)
                  : [...(target.likedBy || []), user.id];
                const updatedPost = { ...target, likedBy: updatedLikedBy, likesCount: updatedLikedBy.length };
                setUserPosts((prev) => prev.map((item) => (item.id === postId ? updatedPost : item)));
                updateDoc(doc(db, 'posts', postId), {
                  likedBy: updatedLikedBy,
                  likesCount: updatedLikedBy.length,
                }).catch(() => {});
              }
            }}
            onSharePost={handleSharePost}
          />
        )}

        {/* DELETE VIDEOS CONFIRMATION MODAL */}
        {showDeleteConfirmModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
            <div className="w-full max-w-sm rounded-3xl bg-[#120a2e] border border-rose-500/40 p-5 shadow-2xl space-y-4 text-white text-center">
              <div className="w-14 h-14 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 mx-auto">
                <Trash2 className="w-7 h-7" />
              </div>
              <div className="space-y-1">
                <h3 className="text-base font-extrabold text-white">
                  {videoToDeleteSingle
                    ? isPostVideo(videoToDeleteSingle) ? 'Delete this video?' : 'Delete this post?'
                    : `Delete ${selectedVideoIds.length} selected item${selectedVideoIds.length > 1 ? 's' : ''}?`}
                </h3>
                <p className="text-xs text-zinc-400 leading-relaxed px-2">
                  Permanently deletes from THE VOID, your profile, and other users' feeds. This action cannot be undone.
                </p>
              </div>

              {videoToDeleteSingle && (
                <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 flex items-center space-x-3 text-left">
                  <div className="w-12 h-12 rounded-lg bg-black overflow-hidden flex-shrink-0">
                    {isPostVideo(videoToDeleteSingle) ? (
                      <video src={videoToDeleteSingle.mediaUrl} className="w-full h-full object-cover" muted />
                    ) : videoToDeleteSingle.mediaUrl || videoToDeleteSingle.imageUrl ? (
                      <img src={videoToDeleteSingle.mediaUrl || videoToDeleteSingle.imageUrl} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-sm">🌌</div>
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs text-white font-semibold truncate">
                      {videoToDeleteSingle.text && videoToDeleteSingle.text !== '🎬 Video post'
                        ? videoToDeleteSingle.text
                        : isPostVideo(videoToDeleteSingle) ? 'Video whisper' : 'Whisper post'}
                    </p>
                    <span className="text-[10px] text-zinc-400 font-mono">
                      {(videoToDeleteSingle.likedBy?.length ?? videoToDeleteSingle.likesCount ?? 0)} likes
                    </span>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowDeleteConfirmModal(false);
                    setVideoToDeleteSingle(null);
                  }}
                  disabled={isDeletingVideos}
                  className="py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-zinc-300 text-xs font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    if (videoToDeleteSingle) {
                      await handleDeletePost(videoToDeleteSingle.id);
                      setVideoToDeleteSingle(null);
                      setShowDeleteConfirmModal(false);
                    } else {
                      await handleDeleteSelectedVideos();
                    }
                  }}
                  disabled={isDeletingVideos}
                  className="py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-extrabold shadow-lg shadow-rose-950/60 transition active:scale-95 flex items-center justify-center space-x-1.5 cursor-pointer disabled:opacity-50"
                >
                  {isDeletingVideos ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Deleting...</span>
                    </>
                  ) : (
                    <>
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* TIKTOK STYLE DOWNLOAD MODAL */}
        <TikTokDownloadModal
          isOpen={isTikTokModalOpen}
          progressState={tiktokProgress}
          onClose={() => setIsTikTokModalOpen(false)}
          postAuthorName={downloadingAuthorName}
        />

        {/* CREATE POST MODAL - Triggered by (+) icon */}
        {showUploadPostModal && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
            <div
              className={`w-full max-w-lg rounded-3xl border shadow-2xl overflow-hidden flex flex-col max-h-[90vh] transition-colors ${
                isGhost
                  ? 'bg-[#15151F] border-[#2A2A3F] text-[#E0E0FF] shadow-[0_10px_40px_rgba(0,0,0,0.9),0_0_30px_rgba(0,245,255,0.2)]'
                  : isDark
                  ? 'bg-[#242526] border-[#3E4042] text-[#E4E6EB]'
                  : 'bg-white border-[#E4E6EB] text-[#050505]'
              }`}
            >
              {/* Modal Header */}
              <div
                className={`flex items-center justify-between px-4 py-3.5 border-b ${
                  isGhost ? 'border-[#2A2A3F]' : isDark ? 'border-[#3E4042]' : 'border-gray-200'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    isGhost ? 'bg-[#00F5FF]/20 text-[#00F5FF]' : 'bg-[#1877F2]/10 text-[#1877F2]'
                  }`}>
                    <Plus className="w-4 h-4 stroke-[3]" />
                  </div>
                  <div>
                    <h3 className="text-sm sm:text-base font-extrabold tracking-tight">Create Post</h3>
                    <p className={`text-[10px] ${isDark ? 'text-zinc-400' : 'text-gray-500'}`}>
                      Choose text, video, or image to share
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setShowUploadPostModal(false);
                    setNewPostMedia('');
                    setNewPostText('');
                    setNewPostMediaType('none');
                  }}
                  className={`p-1.5 rounded-full transition cursor-pointer ${
                    isDark ? 'hover:bg-zinc-800 text-zinc-400 hover:text-white' : 'hover:bg-gray-100 text-gray-500 hover:text-black'
                  }`}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-4 overflow-y-auto space-y-4">
                {/* 3 Prominent Choices: Text, Video, Image */}
                <div className="space-y-1.5">
                  <span className={`text-[11px] font-bold uppercase tracking-wider block ${
                    isDark ? 'text-zinc-400' : 'text-gray-500'
                  }`}>
                    Post Format
                  </span>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setUploadFormat('text');
                        setNewPostMedia('');
                        setNewPostMediaType('none');
                      }}
                      className={`p-3 rounded-2xl border flex flex-col items-center justify-center space-y-1.5 transition cursor-pointer active:scale-95 ${
                        uploadFormat === 'text'
                          ? isGhost
                            ? 'bg-[#00F5FF]/15 border-[#00F5FF] text-[#00F5FF] shadow-[0_0_15px_rgba(0,245,255,0.25)] font-bold'
                            : 'bg-[#1877F2]/15 border-[#1877F2] text-[#1877F2] font-bold'
                          : isDark
                          ? 'bg-[#18191A] border-[#3E4042] text-zinc-300 hover:bg-[#3A3B3C]'
                          : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      <Type className="w-5 h-5" />
                      <span className="text-xs font-semibold">Text</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setUploadFormat('photos');
                        if (!newPostMedia || newPostMediaType !== 'image') {
                          postImageInputRef.current?.click();
                        }
                      }}
                      className={`p-3 rounded-2xl border flex flex-col items-center justify-center space-y-1.5 transition cursor-pointer active:scale-95 ${
                        uploadFormat === 'photos'
                          ? isGhost
                            ? 'bg-[#00F5FF]/15 border-[#00F5FF] text-[#00F5FF] shadow-[0_0_15px_rgba(0,245,255,0.25)] font-bold'
                            : 'bg-[#1877F2]/15 border-[#1877F2] text-[#1877F2] font-bold'
                          : isDark
                          ? 'bg-[#18191A] border-[#3E4042] text-zinc-300 hover:bg-[#3A3B3C]'
                          : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      <Image className="w-5 h-5" />
                      <span className="text-xs font-semibold">Image</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setUploadFormat('videos');
                        if (!newPostMedia || newPostMediaType !== 'video') {
                          postVideoInputRef.current?.click();
                        }
                      }}
                      className={`p-3 rounded-2xl border flex flex-col items-center justify-center space-y-1.5 transition cursor-pointer active:scale-95 ${
                        uploadFormat === 'videos'
                          ? isGhost
                            ? 'bg-[#00F5FF]/15 border-[#00F5FF] text-[#00F5FF] shadow-[0_0_15px_rgba(0,245,255,0.25)] font-bold'
                            : 'bg-[#1877F2]/15 border-[#1877F2] text-[#1877F2] font-bold'
                          : isDark
                          ? 'bg-[#18191A] border-[#3E4042] text-zinc-300 hover:bg-[#3A3B3C]'
                          : 'bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      <Video className="w-5 h-5" />
                      <span className="text-xs font-semibold">Video</span>
                    </button>
                  </div>
                </div>

                {/* Author Info & Audience Selector */}
                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-center space-x-2.5">
                    <img
                      src={avatarUrl && (avatarUrl.startsWith('http') || avatarUrl.startsWith('data:')) ? avatarUrl : AVATAR_PRESETS[0]}
                      alt={name || user.name}
                      className="w-9 h-9 rounded-full object-cover border border-purple-400"
                    />
                    <div>
                      <p className="text-xs font-bold leading-tight">{name || user.name}</p>
                      <span className={`text-[10px] ${isDark ? 'text-zinc-400' : 'text-gray-500'}`}>
                        @{user.ghostedId}
                      </span>
                    </div>
                  </div>

                  {/* Audience Toggle */}
                  <div className="flex items-center space-x-1 p-1 rounded-xl border" style={{ borderColor: currentTheme.border }}>
                    <button
                      type="button"
                      onClick={() => setNewPostAudience('public')}
                      className={`px-2 py-1 rounded-lg text-[10px] font-bold transition flex items-center space-x-1 cursor-pointer ${
                        newPostAudience === 'public'
                          ? isGhost
                            ? 'bg-[#00F5FF] text-black'
                            : 'bg-[#1877F2] text-white'
                          : isDark
                          ? 'text-zinc-400 hover:text-white'
                          : 'text-gray-600 hover:text-black'
                      }`}
                    >
                      <Globe className="w-3 h-3" />
                      <span>Public</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setNewPostAudience('private')}
                      className={`px-2 py-1 rounded-lg text-[10px] font-bold transition flex items-center space-x-1 cursor-pointer ${
                        newPostAudience === 'private'
                          ? isGhost
                            ? 'bg-[#00F5FF] text-black'
                            : 'bg-[#1877F2] text-white'
                          : isDark
                          ? 'text-zinc-400 hover:text-white'
                          : 'text-gray-600 hover:text-black'
                      }`}
                    >
                      <Lock className="w-3 h-3" />
                      <span>Only Me</span>
                    </button>
                  </div>
                </div>

                {/* Hidden file inputs */}
                <input
                  ref={postImageInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handlePostImageSelected}
                />
                <input
                  ref={postVideoInputRef}
                  type="file"
                  accept="video/*"
                  className="hidden"
                  onChange={handlePostVideoSelected}
                />

                {/* Content Area Based on Chosen Format */}
                {uploadFormat === 'text' && (
                  <div className="space-y-2">
                    <textarea
                      rows={5}
                      value={newPostText}
                      onChange={(e) => setNewPostText(e.target.value)}
                      placeholder="What's on your mind? Share your story, anonymous reflection, or thoughts with peers..."
                      className={`w-full p-3.5 rounded-2xl border text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#1877F2] leading-relaxed resize-none ${
                        isGhost
                          ? 'bg-[#0A0A0F] border-[#2A2A3F] text-white placeholder-zinc-500'
                          : isDark
                          ? 'bg-[#18191A] border-[#3E4042] text-white placeholder-zinc-500'
                          : 'bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-400'
                      }`}
                    />
                    <div className="flex items-center justify-between text-[10px]" style={{ color: currentTheme.cardSubtext }}>
                      <span>Encrypted & safe under your Ghosted identity</span>
                      <span>{newPostText.length} characters</span>
                    </div>
                  </div>
                )}

                {uploadFormat === 'photos' && (
                  <div className="space-y-3">
                    {newPostMedia && newPostMediaType === 'image' ? (
                      <div className="space-y-2.5">
                        {/* Top Bar Button: ✨ Ghosted Enhance (Free) Toggle Switch */}
                        <div className="flex items-center justify-between p-2.5 rounded-2xl bg-gradient-to-r from-purple-950/70 via-indigo-950/50 to-black border border-purple-500/40 shadow-md">
                          <div className="flex items-center space-x-2">
                            <Sparkles className="w-4 h-4 text-purple-300 animate-pulse flex-shrink-0" />
                            <div className="flex items-center space-x-1.5">
                              <span className="text-xs font-extrabold text-white">✨ Ghosted Enhance (Free)</span>
                              <span className="text-[9px] px-1.5 py-0.2 rounded-md bg-purple-500/30 text-purple-200 font-mono font-bold border border-purple-400/30">HD</span>
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={handleToggleEnhancePost}
                            disabled={isEnhancingPost}
                            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                              isEnhancedPost ? 'bg-gradient-to-r from-purple-500 to-cyan-400' : 'bg-zinc-700'
                            }`}
                            title="Toggle Free AI HD Enhancement"
                          >
                            <span
                              className={`inline-block h-4 w-4 transform rounded-full bg-white shadow-md transition-transform ${
                                isEnhancedPost ? 'translate-x-6' : 'translate-x-1'
                              }`}
                            />
                          </button>
                        </div>

                        {/* Image Preview / Before-After Slider Container */}
                        <div className="relative rounded-2xl overflow-hidden border border-purple-500/30 group max-h-72 min-h-[220px] flex items-center justify-center bg-black/60 select-none">
                          {/* Enhancing Loading Shimmer Overlay */}
                          {isEnhancingPost && (
                            <div className="absolute inset-0 bg-black/80 backdrop-blur-xs flex flex-col items-center justify-center space-y-2 z-30 animate-in fade-in">
                              <div className="w-8 h-8 border-3 border-purple-400 border-t-transparent rounded-full animate-spin" />
                              <p className="text-xs font-bold text-purple-200 animate-pulse tracking-wide">
                                ✨ Enhancing... Making it HD
                              </p>
                              <span className="text-[10px] text-zinc-400">Auto brightness, contrast & sharpening</span>
                            </div>
                          )}

                          {isEnhancedPost && !isEnhancingPost ? (
                            /* Before / After Comparison Slider */
                            <div className="relative w-full h-full min-h-[220px] max-h-72 flex items-center justify-center overflow-hidden">
                              {/* Enhanced image underneath (right side) */}
                              <img
                                src={enhancedPostMedia || newPostMedia}
                                alt="Enhanced preview"
                                className="w-full max-h-72 object-contain"
                              />

                              {/* Original image on top clipped to sliderSplitPos (left side) */}
                              <div
                                className="absolute inset-0 overflow-hidden pointer-events-none flex items-center justify-center"
                                style={{ clipPath: `inset(0 ${100 - sliderSplitPos}% 0 0)` }}
                              >
                                <img
                                  src={originalPostMedia || newPostMedia}
                                  alt="Original preview"
                                  className="w-full max-h-72 object-contain"
                                />
                              </div>

                              {/* Draggable Divider Line */}
                              <div
                                className="absolute top-0 bottom-0 w-0.5 bg-white shadow-[0_0_8px_rgba(255,255,255,0.9)] z-20 pointer-events-none"
                                style={{ left: `${sliderSplitPos}%` }}
                              >
                                <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-black/85 border border-white text-[10px] text-white flex items-center justify-center font-bold shadow-lg">
                                  ↔
                                </div>
                              </div>

                              {/* Badges: Left (Original) vs Right (Enhanced) */}
                              <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-md text-[10px] text-zinc-300 font-bold z-20 pointer-events-none">
                                Original
                              </div>
                              <div className="absolute top-2 right-12 px-2 py-0.5 rounded-md bg-purple-600/90 backdrop-blur-md text-[10px] text-purple-100 font-extrabold z-20 pointer-events-none shadow-md">
                                ✨ Enhanced HD
                              </div>

                              {/* Range control slider */}
                              <div className="absolute bottom-2 left-3 right-20 z-20 bg-black/60 backdrop-blur-md px-2.5 py-1.5 rounded-xl border border-white/10 flex items-center space-x-2">
                                <span className="text-[9px] text-zinc-400 font-bold whitespace-nowrap">Compare</span>
                                <input
                                  type="range"
                                  min="0"
                                  max="100"
                                  value={sliderSplitPos}
                                  onChange={(e) => setSliderSplitPos(Number(e.target.value))}
                                  className="w-full h-1.5 accent-purple-400 bg-white/20 rounded-lg cursor-ew-resize"
                                />
                              </div>
                            </div>
                          ) : (
                            <img
                              src={newPostMedia}
                              alt="Post upload preview"
                              className="w-full max-h-72 object-contain"
                            />
                          )}

                          <button
                            type="button"
                            onClick={() => {
                              setNewPostMedia('');
                              setOriginalPostMedia('');
                              setEnhancedPostMedia(null);
                              setIsEnhancedPost(false);
                              setNewPostMediaType('none');
                            }}
                            className="absolute top-2 right-2 p-1.5 rounded-full bg-black/70 hover:bg-rose-600 text-white transition cursor-pointer shadow-lg z-20"
                            title="Remove image"
                          >
                            <X className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => postImageInputRef.current?.click()}
                            className="absolute bottom-2 right-2 px-2.5 py-1 rounded-lg bg-black/70 hover:bg-black/90 text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer transition z-20"
                          >
                            <Camera className="w-3.5 h-3.5" />
                            <span>Change</span>
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div
                        onClick={() => postImageInputRef.current?.click()}
                        className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition active:scale-[0.99] flex flex-col items-center justify-center space-y-2 ${
                          isGhost
                            ? 'border-[#00F5FF]/40 bg-[#00F5FF]/5 hover:bg-[#00F5FF]/10 text-[#00F5FF]'
                            : isDark
                            ? 'border-[#3E4042] bg-[#18191A] hover:bg-[#3A3B3C] text-zinc-300'
                            : 'border-gray-300 bg-gray-50 hover:bg-gray-100 text-gray-600'
                        }`}
                      >
                        <div className="w-12 h-12 rounded-2xl bg-purple-500/10 flex items-center justify-center">
                          <Image className="w-6 h-6 text-purple-400" />
                        </div>
                        <div>
                          <p className="text-xs font-bold">Tap here to choose an Image</p>
                          <p className="text-[10px] opacity-70">JPG, PNG, WEBP, GIF supported</p>
                        </div>
                      </div>
                    )}

                    <textarea
                      rows={2}
                      value={newPostText}
                      onChange={(e) => setNewPostText(e.target.value)}
                      placeholder="Write a caption for your image (optional)..."
                      className={`w-full p-2.5 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-[#1877F2] ${
                        isGhost
                          ? 'bg-[#0A0A0F] border-[#2A2A3F] text-white'
                          : isDark
                          ? 'bg-[#18191A] border-[#3E4042] text-white'
                          : 'bg-gray-50 border-gray-200 text-gray-900'
                      }`}
                    />
                  </div>
                )}

                {uploadFormat === 'videos' && (
                  <div className="space-y-3">
                    {newPostMedia && newPostMediaType === 'video' ? (
                      <div className="relative rounded-2xl overflow-hidden border border-purple-500/30 group max-h-64 flex items-center justify-center bg-black">
                        <video
                          src={newPostMedia}
                          controls
                          className="w-full max-h-64 object-contain"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            setNewPostMedia('');
                            setNewPostMediaType('none');
                          }}
                          className="absolute top-2 right-2 p-1.5 rounded-full bg-black/70 hover:bg-rose-600 text-white transition cursor-pointer shadow-lg"
                          title="Remove video"
                        >
                          <X className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => postVideoInputRef.current?.click()}
                          className="absolute bottom-2 right-2 px-2.5 py-1 rounded-lg bg-black/70 hover:bg-black/90 text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer transition"
                        >
                          <Video className="w-3.5 h-3.5" />
                          <span>Change</span>
                        </button>
                      </div>
                    ) : (
                      <div
                        onClick={() => postVideoInputRef.current?.click()}
                        className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition active:scale-[0.99] flex flex-col items-center justify-center space-y-2 ${
                          isGhost
                            ? 'border-[#00F5FF]/40 bg-[#00F5FF]/5 hover:bg-[#00F5FF]/10 text-[#00F5FF]'
                            : isDark
                            ? 'border-[#3E4042] bg-[#18191A] hover:bg-[#3A3B3C] text-zinc-300'
                            : 'border-gray-300 bg-gray-50 hover:bg-gray-100 text-gray-600'
                        }`}
                      >
                        <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 flex items-center justify-center">
                          <Video className="w-6 h-6 text-indigo-400" />
                        </div>
                        <div>
                          <p className="text-xs font-bold">Tap here to choose a Video</p>
                          <p className="text-[10px] opacity-70">MP4, WEBM, MOV supported</p>
                        </div>
                      </div>
                    )}

                    <textarea
                      rows={2}
                      value={newPostText}
                      onChange={(e) => setNewPostText(e.target.value)}
                      placeholder="Write a caption for your video (optional)..."
                      className={`w-full p-2.5 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-[#1877F2] ${
                        isGhost
                          ? 'bg-[#0A0A0F] border-[#2A2A3F] text-white'
                          : isDark
                          ? 'bg-[#18191A] border-[#3E4042] text-white'
                          : 'bg-gray-50 border-gray-200 text-gray-900'
                      }`}
                    />
                  </div>
                )}
              </div>

              {/* Modal Footer */}
              <div
                className={`p-3.5 border-t flex items-center justify-end space-x-2 ${
                  isGhost ? 'border-[#2A2A3F]' : isDark ? 'border-[#3E4042]' : 'border-gray-200'
                }`}
              >
                <button
                  type="button"
                  onClick={() => {
                    cancelActiveUpload();
                    setIsSubmittingPost(false);
                    setShowUploadPostModal(false);
                  }}
                  className={`px-4 py-2 rounded-xl text-xs font-semibold transition cursor-pointer ${
                    isDark ? 'hover:bg-[#3A3B3C] text-zinc-300' : 'hover:bg-gray-100 text-gray-600'
                  }`}
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleCreatePost}
                  disabled={isSubmittingPost || (!newPostText.trim() && !newPostMedia)}
                  className={`px-5 py-2.5 rounded-xl text-xs font-extrabold flex items-center space-x-1.5 transition cursor-pointer active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed shadow-md ${
                    isGhost
                      ? 'bg-gradient-to-r from-[#00F5FF] to-[#7C3AED] text-black font-black'
                      : 'bg-[#1877F2] hover:bg-[#166fe5] text-white'
                  }`}
                >
                  {isSubmittingPost ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                      <span>Publishing...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Publish Post</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // ACCOUNT INFO PAGE
  return (
    <div
      className="max-w-4xl mx-auto space-y-5 animate-in fade-in duration-200 transition-colors p-4 min-h-screen"
      style={{
        backgroundColor: currentTheme.background,
        color: currentTheme.textOutside,
      }}
    >
      <div
        className="flex items-center justify-between pb-3 border-b"
        style={{ borderColor: currentTheme.border }}
      >
        <button
          type="button"
          data-back-dismissible="true"
          onClick={() => setShowAccountInfo(false)}
          className={`flex items-center space-x-2 px-3 py-1.5 rounded-xl border transition cursor-pointer text-xs font-bold active:scale-95 ${
            isGhost
              ? 'bg-[#15151F] border-[#2A2A3F] text-[#00F5FF] hover:border-[#00F5FF]'
              : isDark
              ? 'bg-[#3A3B3C] border-[#4E4F50] text-[#E4E6EB] hover:bg-[#4E4F50]'
              : 'bg-[#E4E6EB] border-gray-300 text-[#050505] hover:bg-[#D8DADF]'
          }`}
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Profile</span>
        </button>
        <div className="flex items-center space-x-2">
          <User className={`w-4 h-4 ${isGhost ? 'text-[#00F5FF]' : isDark ? 'text-[#2374E1]' : 'text-[#0866FF]'}`} />
          <h2 className="text-sm font-black uppercase tracking-wider">Account Info</h2>
        </div>
        <div className="w-16" />
      </div>

      {saveSuccess && (
        <div className="p-3 rounded-2xl bg-emerald-950/70 border border-emerald-400/50 text-emerald-200 text-xs flex items-center space-x-2 animate-in fade-in duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>Profile successfully updated and saved!</span>
        </div>
      )}

      {/* HERO: YOUR GHOSTED NUMBER & IDENTITY */}
      <div className={`p-4 sm:p-5 rounded-3xl border shadow-lg space-y-3.5 transition-colors ${
        isGhost
          ? 'bg-[#15151F] border-[#2A2A3F] shadow-[0_0_25px_rgba(124,58,237,0.18)]'
          : isDark
          ? 'bg-[#242526] border-[#3E4042]'
          : 'bg-white border-[#E4E6EB]'
      }`}>
        <div className={`flex flex-wrap items-center justify-between gap-2 border-b pb-3 ${
          isGhost ? 'border-[#2A2A3F]' : isDark ? 'border-[#3E4042]' : 'border-gray-200'
        }`}>
          <div className="flex items-center space-x-2.5">
            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
              isGhost
                ? 'bg-[#7C3AED]/20 border border-[#00F5FF]/30 text-[#00F5FF]'
                : isDark
                ? 'bg-[#2374E1]/20 border border-[#2374E1]/30 text-[#2374E1]'
                : 'bg-[#0866FF]/10 border border-[#0866FF]/20 text-[#0866FF]'
            }`}>
              <Phone className="w-5 h-5" />
            </div>
            <div>
              <span className={`text-[10px] font-bold uppercase tracking-wider block ${
                isGhost ? 'text-[#00F5FF]' : isDark ? 'text-[#2374E1]' : 'text-[#0866FF]'
              }`}>
                Official In-App Credentials
              </span>
              <h3 className="text-base sm:text-lg font-black">My Ghosted Number</h3>
            </div>
          </div>
          <button
            type="button"
            onClick={copyShare}
            className={`px-3 py-1.5 rounded-xl font-bold text-xs shadow-md flex items-center space-x-1.5 transition cursor-pointer active:scale-95 text-white ${
              isGhost
                ? 'bg-gradient-to-r from-[#7C3AED] to-[#00F5FF] shadow-[0_0_15px_rgba(124,58,237,0.4)]'
                : isDark
                ? 'bg-[#2374E1] hover:bg-[#1B64C7]'
                : 'bg-[#0866FF] hover:bg-[#0055E0]'
            }`}
          >
            {copiedShare ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Share2 className="w-3.5 h-3.5" />}
            <span>{copiedShare ? 'Copied Details!' : 'Share My Number'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className={`p-3.5 rounded-2xl border space-y-1 flex items-center justify-between ${
            isGhost
              ? 'bg-[#0A0A0F] border-[#2A2A3F]'
              : isDark
              ? 'bg-[#18191A] border-[#3E4042]'
              : 'bg-[#F0F2F5] border-[#E4E6EB]'
          }`}>
            <div>
              <span className={`text-[10px] font-bold uppercase tracking-wider block ${
                isGhost ? 'text-[#00F5FF]' : isDark ? 'text-[#2374E1]' : 'text-[#0866FF]'
              }`}>
                In-App Ghosted Phone Number
              </span>
              <p className="font-mono text-base sm:text-lg font-black tracking-wider">
                {ghostedNumber || '+1 (555) GH-8421'}
              </p>
              <span className={`text-[10px] block ${
                isGhost ? 'text-[#8A8AA3]' : isDark ? 'text-[#B0B3B8]' : 'text-[#65676B]'
              }`}>
                For incoming DTMF dialer & direct calls
              </span>
            </div>
            <button
              type="button"
              onClick={() => copyText(ghostedNumber, false)}
              className={`p-2 sm:px-3 sm:py-2 rounded-xl border text-xs font-bold transition flex items-center space-x-1 cursor-pointer active:scale-95 flex-shrink-0 ${
                isGhost
                  ? 'bg-[#7C3AED]/25 text-[#00F5FF] border-[#00F5FF]/40'
                  : isDark
                  ? 'bg-[#3A3B3C] text-white border-[#4E4F50]'
                  : 'bg-white text-[#050505] border-gray-300'
              }`}
              title="Copy Ghosted Number"
            >
              {copiedNum ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span className="hidden sm:inline">{copiedNum ? 'Copied' : 'Copy'}</span>
            </button>
          </div>

          <div className={`p-3.5 rounded-2xl border space-y-1 flex items-center justify-between ${
            isGhost
              ? 'bg-[#0A0A0F] border-[#2A2A3F]'
              : isDark
              ? 'bg-[#18191A] border-[#3E4042]'
              : 'bg-[#F0F2F5] border-[#E4E6EB]'
          }`}>
            <div>
              <span className={`text-[10px] font-bold uppercase tracking-wider block ${
                isGhost ? 'text-[#00F5FF]' : isDark ? 'text-[#2374E1]' : 'text-[#0866FF]'
              }`}>
                Encrypted Ghosted ID
              </span>
              <p className="font-mono text-base sm:text-lg font-black tracking-wider">
                {ghostedId || 'GH-8429-1923'}
              </p>
              <span className={`text-[10px] block ${
                isGhost ? 'text-[#8A8AA3]' : isDark ? 'text-[#B0B3B8]' : 'text-[#65676B]'
              }`}>
                For anonymous letters & private chats
              </span>
            </div>
            <button
              type="button"
              onClick={() => copyText(ghostedId, true)}
              className={`p-2 sm:px-3 sm:py-2 rounded-xl border text-xs font-bold transition flex items-center space-x-1 cursor-pointer active:scale-95 flex-shrink-0 ${
                isGhost
                  ? 'bg-[#7C3AED]/25 text-[#00F5FF] border-[#00F5FF]/40'
                  : isDark
                  ? 'bg-[#3A3B3C] text-white border-[#4E4F50]'
                  : 'bg-white text-[#050505] border-gray-300'
              }`}
              title="Copy Ghosted ID"
            >
              {copiedId ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span className="hidden sm:inline">{copiedId ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
        </div>

        <p className={`text-[11px] leading-relaxed p-2.5 rounded-xl border ${
          isGhost
            ? 'bg-[#0A0A0F]/80 text-[#8A8AA3] border-[#2A2A3F]'
            : isDark
            ? 'bg-[#18191A] text-[#B0B3B8] border-[#3E4042]'
            : 'bg-[#F0F2F5] text-[#65676B] border-[#E4E6EB]'
        }`}>
          <strong>Privacy Protection:</strong> Friends and recipients cannot see your real phone number or email. Give them your <strong>Ghosted Number</strong> to receive anonymous voice & video calls.
        </p>
      </div>

      {/* Main Profile Box */}
      <div className={`p-4 sm:p-6 rounded-3xl border space-y-4 shadow-xl transition-colors ${
        isGhost
          ? 'bg-[#15151F] border-[#2A2A3F] text-[#E0E0FF]'
          : isDark
          ? 'bg-[#242526] border-[#3E4042] text-[#E4E6EB]'
          : 'bg-white border-[#E4E6EB] text-[#050505]'
      }`}>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-3">
            <div className="relative group">
              <img
                src={avatarUrl && !avatarUrl.includes('dicebear') ? avatarUrl : AVATAR_PRESETS[0]}
                alt={name}
                onError={(e) => {
                  e.currentTarget.src = AVATAR_PRESETS[0];
                }}
                className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl object-cover border-2 border-purple-400 shadow-md"
              />
              {isEditing && (
                <label className="absolute inset-0 bg-black/60 rounded-2xl flex items-center justify-center cursor-pointer opacity-90 transition">
                  <Camera className="w-4 h-4 text-white" />
                  <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                </label>
              )}
            </div>
            <div>
              <div className="flex items-center space-x-1.5">
                <h2 className="text-base sm:text-lg font-bold text-white">{name}</h2>
                <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-400/30">
                  Verified
                </span>
                {!isNigeria && (user.isPremium || user.hasVIP) && (
                  <span className="text-[9px] bg-amber-400/20 text-amber-300 px-2 py-0.5 rounded-full border border-amber-400/40 font-bold">
                    VIP
                  </span>
                )}
              </div>
              <p className="text-[11px] text-purple-300/80">{user.email}</p>
              <p className="text-[11px] text-purple-200/70 flex items-center space-x-1 mt-0.5">
                <MapPin className="w-3 h-3 text-purple-400" />
                <span>{city}, {stateCountry}</span>
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            {!isEditing ? (
              <button
                type="button"
                onClick={() => setIsEditing(true)}
                className="py-1.5 px-3 rounded-xl bg-purple-600/40 hover:bg-purple-600 text-white font-medium text-xs border border-purple-400/30 transition flex items-center space-x-1.5 shadow"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Set Up Profile</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="py-1.5 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-purple-200 text-xs border border-white/20 transition"
              >
                Cancel
              </button>
            )}
          </div>
        </div>

        {!isEditing && bio && (
          <p className="text-xs text-purple-100/90 italic bg-black/25 p-3 rounded-xl border border-white/10">
            "{bio}"
          </p>
        )}

        {isEditing ? (
          <form onSubmit={handleSaveProfile} className="space-y-4 pt-3 border-t border-white/10 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-purple-300 uppercase tracking-wider flex items-center space-x-1.5">
                <User className="w-3.5 h-3.5 text-purple-400" />
                <span>Personalize Your Profile</span>
              </h3>
              <span className="text-[10px] text-purple-300/60">Saved to encrypted session</span>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-purple-200">
                Choose or Upload Avatar Photo
              </label>
              <div className="flex flex-wrap gap-2 items-center">
                {AVATAR_PRESETS.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setAvatarUrl(preset)}
                    className={`w-9 h-9 rounded-xl overflow-hidden border-2 transition ${
                      avatarUrl === preset
                        ? 'border-purple-400 ring-2 ring-purple-400/50 scale-105'
                        : 'border-transparent hover:border-purple-300/60 opacity-80'
                    }`}
                  >
                    <img src={preset} alt={`Preset ${idx}`} className="w-full h-full object-cover" />
                  </button>
                ))}
                <label className="cursor-pointer py-1.5 px-2.5 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-[10px] text-purple-200 border border-purple-400/30 flex items-center space-x-1 transition">
                  <Camera className="w-3 h-3 text-purple-300" />
                  <span>Custom Photo</span>
                  <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                </label>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-purple-200 mb-1">
                  Your Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. David N."
                  className="w-full px-3 py-2 bg-black/35 border border-white/15 rounded-xl text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-purple-400"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-purple-200 mb-1">
                  Private Contact Phone
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="e.g. +234 801 234 5678"
                  className="w-full px-3 py-2 bg-black/35 border border-white/15 rounded-xl text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-purple-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-purple-200 mb-1">
                Bio / Personal Reconnection Statement
              </label>
              <textarea
                rows={2}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Share your intentions for reconnecting with peace, accountability, and boundaries..."
                className="w-full p-2.5 bg-black/35 border border-white/15 rounded-xl text-white text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-purple-400 resize-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-purple-200 mb-1">
                  Date of Birth (18+ Requirement)
                </label>
                <input
                  type="date"
                  value={dob}
                  onChange={(e) => setDob(e.target.value)}
                  max="2007-01-01"
                  className="w-full px-3 py-2 bg-black/35 border border-white/15 rounded-xl text-white text-xs focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-purple-200 mb-1">
                  Gender Identity
                </label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value as Gender)}
                  className="w-full px-3 py-2 bg-black/35 border border-white/15 rounded-xl text-white text-xs focus:outline-none"
                >
                  <option value="Male" className="bg-[#1e1b38]">Male</option>
                  <option value="Female" className="bg-[#1e1b38]">Female</option>
                  <option value="Non-binary" className="bg-[#1e1b38]">Non-binary</option>
                  <option value="Prefer not to say" className="bg-[#1e1b38]">Prefer not to say</option>
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-purple-200 mb-1">
                    Current City
                  </label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="e.g. Lagos"
                    className="w-full px-3 py-2 bg-black/35 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:ring-2 focus:ring-purple-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-purple-200 mb-1">
                    State / Country
                  </label>
                  <input
                    type="text"
                    value={stateCountry}
                    onChange={(e) => setStateCountry(e.target.value)}
                    placeholder="e.g. Nigeria"
                    className="w-full px-3 py-2 bg-black/35 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:ring-2 focus:ring-purple-400"
                  />
                </div>
              </div>

              <div className="flex flex-wrap gap-1.5 pt-1">
                <span className="text-[10px] text-purple-300/70 py-0.5">Quick Suggestions:</span>
                {LOCATION_SUGGESTIONS.map((loc) => (
                  <button
                    key={loc.city}
                    type="button"
                    onClick={() => {
                      setCity(loc.city);
                      setStateCountry(loc.country);
                    }}
                    className="px-2 py-0.5 rounded-lg bg-white/5 hover:bg-white/15 text-[10px] text-purple-200 border border-white/10 flex items-center space-x-1 transition"
                  >
                    <span>{loc.flag}</span>
                    <span>{loc.city}, {loc.country}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-purple-200 mb-1">
                Primary Reconnection Category
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(['Friend', 'Family', 'Ex-Partner', 'Other'] as RelationshipType[]).map((rel) => (
                  <button
                    key={rel}
                    type="button"
                    onClick={() => setRelationship(rel)}
                    className={`py-1.5 px-2 rounded-xl text-xs font-medium transition border text-center ${
                      relationship === rel
                        ? 'bg-purple-600/40 border-purple-400 text-white shadow-sm'
                        : 'bg-white/5 border-white/10 text-purple-200 hover:bg-white/10'
                    }`}
                  >
                    {rel}
                  </button>
                ))}
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-black/30 border border-white/10 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-purple-300 font-semibold uppercase">Encrypted Ghosted Number</span>
                <p className="font-mono text-xs font-bold text-white">{ghostedId} • {ghostedNumber}</p>
              </div>
              <button
                type="button"
                onClick={handleRegenerateGhostedId}
                className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-[10px] text-purple-200 flex items-center space-x-1 border border-white/10 transition"
              >
                <RefreshCw className="w-3 h-3 text-purple-400" />
                <span>Regenerate ID</span>
              </button>
            </div>

            <div className="pt-2 flex items-center space-x-2">
              <button
                type="submit"
                disabled={isSaving}
                className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-600 hover:to-indigo-700 text-white font-bold text-xs sm:text-sm shadow-lg shadow-purple-900/40 flex items-center justify-center space-x-2 transition active:scale-[0.99] disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'Saving Profile...' : 'Save Profile Changes'}</span>
              </button>
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/20 text-purple-200 text-xs font-medium transition"
              >
                Cancel
              </button>
            </div>
          </form>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2 border-t border-white/10">
            <div className="p-3 rounded-2xl bg-black/30 border border-white/10 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-purple-400 font-semibold uppercase tracking-wider">
                  My Ghosted ID
                </span>
                <p className="font-mono text-xs sm:text-sm font-bold text-white">{ghostedId}</p>
              </div>
              <button
                type="button"
                onClick={() => copyText(ghostedId, true)}
                className="px-2 py-1 rounded-lg bg-purple-600/30 hover:bg-purple-600/50 text-[11px] text-purple-200 font-medium transition"
              >
                {copiedId ? 'Copied' : 'Copy'}
              </button>
            </div>
            <div className="p-3 rounded-2xl bg-black/30 border border-white/10 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-purple-400 font-semibold uppercase tracking-wider">
                  In-App Ghosted Number
                </span>
                <p className="font-mono text-xs sm:text-sm font-bold text-white">{ghostedNumber}</p>
              </div>
              <button
                type="button"
                onClick={() => copyText(ghostedNumber, false)}
                className="px-2 py-1 rounded-lg bg-purple-600/30 hover:bg-purple-600/50 text-[11px] text-purple-200 font-medium transition"
              >
                {copiedNum ? 'Copied' : 'Copy'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* TEEN ACCOUNTS & REGIONAL SAFETY CONTROLS */}
      <div className="p-5 rounded-3xl bg-gradient-to-br from-indigo-950/40 via-[#130b29] to-purple-950/40 border border-indigo-400/30 space-y-4 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-3">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-2xl bg-indigo-600/30 border border-indigo-400/40 flex items-center justify-center text-indigo-300">
              <ShieldCheck className="w-5 h-5 text-indigo-300" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-sm font-bold text-white">Teen Controls & Protection</h3>
                <span className="text-[9px] px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 font-semibold">
                  Regional Shield
                </span>
              </div>
              <p className="text-[10px] text-purple-300/70">
                Automatic protections tailored to your region. No public age label is displayed.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setParentDashboardOpen(!parentDashboardOpen)}
            className="px-3 py-1.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-400/40 text-indigo-200 text-xs font-semibold flex items-center space-x-1.5 transition cursor-pointer"
          >
            <Users className="w-3.5 h-3.5 text-indigo-300" />
            <span>Parent Dashboard</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3 rounded-2xl bg-black/40 border border-white/10 flex items-start justify-between space-x-2">
            <div className="space-y-1">
              <div className="flex items-center space-x-1.5 text-purple-200 font-bold">
                <UserCheck className="w-3.5 h-3.5 text-indigo-400" />
                <span>Messaging Controls</span>
              </div>
              <p className="text-[11px] text-purple-300/70 leading-relaxed">
                Strangers cannot message you. Only mutual connections and close contacts can send whispers.
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                updateTeenSetting('messagingControlsEnabled', !teenSettings.messagingControlsEnabled)
              }
              className={`w-9 h-5 rounded-full transition-colors relative flex-shrink-0 cursor-pointer ${
                teenSettings.messagingControlsEnabled ? 'bg-indigo-600' : 'bg-white/20'
              }`}
            >
              <span
                className={`w-4 h-4 rounded-full bg-white transition-transform transform absolute top-0.5 left-0.5 ${
                  teenSettings.messagingControlsEnabled ? 'translate-x-4' : ''
                }`}
              />
            </button>
          </div>

          <div className="p-3 rounded-2xl bg-black/40 border border-white/10 flex items-start justify-between space-x-2">
            <div className="space-y-1">
              <div className="flex items-center space-x-1.5 text-purple-200 font-bold">
                <Sliders className="w-3.5 h-3.5 text-purple-400" />
                <span>Content Limits</span>
              </div>
              <p className="text-[11px] text-purple-300/70 leading-relaxed">
                Strictest filtering applied to language, explicit media, and non-consensual letters.
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                updateTeenSetting('contentLimitsEnabled', !teenSettings.contentLimitsEnabled)
              }
              className={`w-9 h-5 rounded-full transition-colors relative flex-shrink-0 cursor-pointer ${
                teenSettings.contentLimitsEnabled ? 'bg-indigo-600' : 'bg-white/20'
              }`}
            >
              <span
                className={`w-4 h-4 rounded-full bg-white transition-transform transform absolute top-0.5 left-0.5 ${
                  teenSettings.contentLimitsEnabled ? 'translate-x-4' : ''
                }`}
              />
            </button>
          </div>

          <div className="p-3 rounded-2xl bg-black/40 border border-white/10 flex items-start justify-between space-x-2">
            <div className="space-y-1">
              <div className="flex items-center space-x-1.5 text-cyan-200 font-bold">
                <Moon className="w-3.5 h-3.5 text-cyan-400" />
                <span>Sleep Mode (10 PM - 7 AM)</span>
              </div>
              <p className="text-[11px] text-purple-300/70 leading-relaxed">
                Silences night alerts, pauses direct call ringers, and encourages resting.
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                updateTeenSetting('sleepModeEnabled', !teenSettings.sleepModeEnabled)
              }
              className={`w-9 h-5 rounded-full transition-colors relative flex-shrink-0 cursor-pointer ${
                teenSettings.sleepModeEnabled ? 'bg-cyan-600' : 'bg-white/20'
              }`}
            >
              <span
                className={`w-4 h-4 rounded-full bg-white transition-transform transform absolute top-0.5 left-0.5 ${
                  teenSettings.sleepModeEnabled ? 'translate-x-4' : ''
                }`}
              />
            </button>
          </div>

          <div className="p-3 rounded-2xl bg-black/40 border border-white/10 flex items-start justify-between space-x-2">
            <div className="space-y-1">
              <div className="flex items-center space-x-1.5 text-amber-200 font-bold">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>Time Limits (60 Min Daily)</span>
              </div>
              <p className="text-[11px] text-purple-300/70 leading-relaxed">
                Sends a friendly reminder after 60 minutes of daily activity to take a break.
              </p>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-400/30 font-bold flex-shrink-0">
              60m active
            </span>
          </div>

          <div className="sm:col-span-2 p-3 rounded-2xl bg-black/40 border border-white/10 flex items-center justify-between space-x-3">
            <div className="space-y-0.5">
              <div className="flex items-center space-x-2 text-rose-200 font-bold">
                <Radio className="w-3.5 h-3.5 text-rose-400" />
                <span>Audience Restrictions: Close Friends Default & No Go Live under 16</span>
              </div>
              <p className="text-[11px] text-purple-300/70">
                New whispers default strictly to Close Friends. Broadcasting to Live Rooms is restricted for under-16 accounts.
              </p>
            </div>
            <span className="text-[10px] font-bold px-2.5 py-1 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-400/30 flex-shrink-0">
              Protected
            </span>
          </div>
        </div>

        {parentDashboardOpen && (
          <div className="p-4 rounded-2xl bg-black/60 border border-indigo-500/40 space-y-3 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-white flex items-center space-x-1.5">
                <Users className="w-3.5 h-3.5 text-indigo-400" />
                <span>Parent Supervision Dashboard</span>
              </h4>
              <span className="text-[10px] text-indigo-300 font-mono">
                Pairing Code: {teenSettings.parentSupervision.pairingCode}
              </span>
            </div>
            <p className="text-[11px] text-purple-200/80 leading-relaxed">
              Parents can link their email address or enter this one-time pairing code into their device to monitor safety limits, time spent, and approved contact requests without reading private whispers.
            </p>
            <div className="flex items-center space-x-2 pt-1">
              <input
                type="email"
                value={parentEmailInput}
                onChange={(e) => setParentEmailInput(e.target.value)}
                placeholder="parent@family.com"
                className="flex-1 px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 text-xs text-white placeholder-purple-300/40 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => {
                  updateTeenSetting('parentSupervision', {
                    ...teenSettings.parentSupervision,
                    parentEmail: parentEmailInput,
                    isLinked: true,
                    lastChecked: new Date().toISOString(),
                  });
                  alert(`Parent supervision invitation dispatched to ${parentEmailInput}!`);
                }}
                disabled={!parentEmailInput.trim()}
                className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition cursor-pointer disabled:opacity-40"
              >
                Link Parent
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Safety Constitution Card */}
      <div className="p-5 rounded-3xl bg-gradient-to-b from-purple-900/30 to-indigo-950/40 border border-purple-400/30 space-y-3">
        <h3 className="text-sm font-bold text-white flex items-center space-x-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>The Ghosted Safety Constitution</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
          <div className="p-3 rounded-2xl bg-black/30 border border-white/10 space-y-1">
            <p className="font-semibold text-purple-200 flex items-center space-x-1.5">
              <Eye className="w-3.5 h-3.5 text-purple-400" />
              <span>Receiver Exclusive Rights</span>
            </p>
            <p className="text-[11px] text-purple-300/80 leading-relaxed">
              Recipients choose whether to open. Senders cannot reveal their identity unless the recipient specifically requests it.
            </p>
          </div>
          <div className="p-3 rounded-2xl bg-black/30 border border-white/10 space-y-1">
            <p className="font-semibold text-rose-300 flex items-center space-x-1.5">
              <Flame className="w-3.5 h-3.5 text-rose-400" />
              <span>Permanent Decline Burn</span>
            </p>
            <p className="text-[11px] text-purple-300/80 leading-relaxed">
              If the recipient taps Decline, the letter and attached memories are permanently deleted from all databases.
            </p>
          </div>
          <div className="p-3 rounded-2xl bg-black/30 border border-white/10 space-y-1">
            <p className="font-semibold text-purple-200 flex items-center space-x-1.5">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>AI Content Moderation</span>
            </p>
            <p className="text-[11px] text-purple-300/80 leading-relaxed">
              AI evaluates threats, gaslighting, manipulation, and explicit content prior to transmission.
            </p>
          </div>
          <div className="p-3 rounded-2xl bg-black/30 border border-white/10 space-y-1">
            <p className="font-semibold text-purple-200 flex items-center space-x-1.5">
              <Lock className="w-3.5 h-3.5 text-purple-400" />
              <span>Daily Send Boundaries</span>
            </p>
            <p className="text-[11px] text-purple-300/80 leading-relaxed">
              Strict 3 sends / 24 hour limit prevents repetitive messaging or emotional overload.
            </p>
          </div>
        </div>

        <div className="pt-2 border-t border-white/10 flex items-center justify-between text-xs">
          <span className="text-[11px] text-purple-300/70">Need to re-test onboarding flow?</span>
          <button
            type="button"
            onClick={onResetOnboarding}
            className="text-xs text-rose-300 hover:text-rose-200 underline"
          >
            Reset Session & Test Onboarding
          </button>
        </div>
      </div>
    </div>
  );
};
