import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  ArrowLeft,
  Search,
  X,
  Clock,
  Trash2,
  Sparkles,
  MessageCircle,
  Heart,
  User,
  ChevronRight,
  Send,
  Flame,
} from 'lucide-react';
import { GhostPost, UserProfile } from '../types';
import { useTheme } from '../context/ThemeContext';

interface SearchHauntingModalProps {
  isOpen: boolean;
  onClose: () => void;
  posts: GhostPost[];
  currentUser: UserProfile;
  onSelectPost?: (post: GhostPost) => void;
  onNavigateToTab?: (tabId: string) => void;
  initialQuery?: string;
}

const STORAGE_KEY = 'ghosted_recent_haunting_searches';

const VOID_TOPICS = [
  { label: '💔 Unspoken Closure', query: 'closure' },
  { label: '🕊️ Anonymous Apologies', query: 'apology' },
  { label: '🤫 Secret Confessions', query: 'confession' },
  { label: '🌌 Late Night Whispers', query: 'whisper' },
  { label: '👻 Ghosted Connections', query: 'ghost' },
  { label: '🥀 Unsent Words', query: 'miss you' },
  { label: '✨ Spectral Truths', query: 'truth' },
  { label: '🌙 Midnight Thoughts', query: 'night' },
];

export const SearchHauntingModal: React.FC<SearchHauntingModalProps> = ({
  isOpen,
  onClose,
  posts,
  currentUser,
  onSelectPost,
  onNavigateToTab,
  initialQuery = '',
}) => {
  const { currentTheme, isGhost, isBlack, isWhite } = useTheme();
  const [query, setQuery] = useState<string>(initialQuery);
  const [activeFilter, setActiveFilter] = useState<'all' | 'posts' | 'users'>('all');
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  // Load recent searches from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          setRecentSearches(parsed.slice(0, 10));
        }
      }
    } catch {
      // ignore
    }
  }, [isOpen]);

  // Focus input on open
  useEffect(() => {
    if (isOpen) {
      if (initialQuery) {
        setQuery(initialQuery);
      }
      const t = setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
      return () => clearTimeout(t);
    }
  }, [isOpen, initialQuery]);

  // Lock body scroll when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = 'unset';
      };
    }
  }, [isOpen]);

  const saveSearchTerm = (term: string) => {
    const trimmed = term.trim();
    if (!trimmed) return;
    try {
      const updated = [trimmed, ...recentSearches.filter((s) => s.toLowerCase() !== trimmed.toLowerCase())].slice(0, 10);
      setRecentSearches(updated);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  const removeSearchItem = (term: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const updated = recentSearches.filter((s) => s !== term);
      setRecentSearches(updated);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  const clearAllRecent = () => {
    try {
      setRecentSearches([]);
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
  };

  const handleExecuteSearch = (termToSearch?: string) => {
    const finalTerm = (termToSearch !== undefined ? termToSearch : query).trim();
    if (finalTerm) {
      saveSearchTerm(finalTerm);
      if (termToSearch !== undefined) {
        setQuery(termToSearch);
      }
    }
  };

  const handleClear = () => {
    setQuery('');
    inputRef.current?.focus();
  };

  // Distinct users matching query
  const matchedUsers = useMemo(() => {
    const q = query.toLowerCase().trim();
    if (!q) return [];
    const map = new Map<string, { id: string; name: string; avatar: string; ghostedId: string }>();

    posts.forEach((p) => {
      if (!p.authorId) return;
      const nameMatch = p.authorName?.toLowerCase().includes(q);
      const ghostIdMatch = p.authorGhostedId?.toLowerCase().includes(q);
      if (nameMatch || ghostIdMatch) {
        if (!map.has(p.authorId)) {
          map.set(p.authorId, {
            id: p.authorId,
            name: p.authorName || 'Anonymous Ghost',
            avatar: p.authorAvatar || '👻',
            ghostedId: p.authorGhostedId || '',
          });
        }
      }
    });

    return Array.from(map.values());
  }, [posts, query]);

  // Matched posts
  const matchedPosts = useMemo(() => {
    const q = query.toLowerCase().trim();
    if (!q) return [];
    return posts.filter((p) => {
      const matchesText = Boolean(p.text && p.text.toLowerCase().includes(q));
      const matchesAuthor = Boolean(p.authorName && p.authorName.toLowerCase().includes(q));
      const matchesGhostId = Boolean(p.authorGhostedId && p.authorGhostedId.toLowerCase().includes(q));
      return matchesText || matchesAuthor || matchesGhostId;
    });
  }, [posts, query]);

  if (!isOpen) return null;

  const accentColor = isGhost ? '#00F5FF' : isBlack ? '#FF2A55' : '#1877F2';
  const headerBg = isGhost ? '#0A0A12' : isBlack ? '#121212' : '#FFFFFF';
  const pageBg = isGhost ? '#05050A' : isBlack ? '#000000' : '#F7F8FA';
  const inputBg = isGhost ? '#141424' : isBlack ? '#1E1E1E' : '#F0F2F5';
  const itemHoverBg = isGhost ? '#16162a' : isBlack ? '#1F1F1F' : '#E4E6EB';

  const totalResults = matchedPosts.length + matchedUsers.length;

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col transition-colors duration-200 animate-in fade-in"
      style={{ backgroundColor: pageBg, color: currentTheme.cardText }}
    >
      {/* TOP HEADER: Back arrow, Search input, Search text button */}
      <div
        className="w-full border-b px-3 py-2.5 sm:py-3 flex items-center gap-2 sm:gap-3 sticky top-0 z-20 shadow-xs"
        style={{
          backgroundColor: headerBg,
          borderColor: currentTheme.border,
        }}
      >
        {/* Back button */}
        <button
          type="button"
          onClick={onClose}
          className="p-1.5 -ml-1 rounded-full transition hover:opacity-75 cursor-pointer active:scale-95"
          style={{ color: currentTheme.cardText }}
          aria-label="Back"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>

        {/* Search input container */}
        <div
          className="flex-1 flex items-center rounded-full px-3 py-1.5 sm:py-2 border transition-all"
          style={{
            backgroundColor: inputBg,
            borderColor: query ? accentColor : currentTheme.border,
          }}
        >
          <Search
            className="w-4 h-4 mr-2.5 flex-shrink-0 opacity-70"
            style={{ color: query ? accentColor : currentTheme.cardSubtext }}
          />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                handleExecuteSearch();
              }
            }}
            placeholder="What's haunting you?..."
            className="w-full bg-transparent text-sm focus:outline-none font-medium placeholder:font-normal"
            style={{
              color: currentTheme.cardText,
            }}
          />
          {query && (
            <button
              type="button"
              onClick={handleClear}
              className="p-0.5 rounded-full hover:opacity-80 transition cursor-pointer ml-1 text-gray-400 hover:text-gray-200"
              aria-label="Clear text"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Right Search Button */}
        <button
          type="button"
          onClick={() => handleExecuteSearch()}
          className="px-2 py-1 text-sm font-bold transition hover:opacity-80 cursor-pointer active:scale-95 flex-shrink-0"
          style={{ color: accentColor }}
        >
          Search
        </button>
      </div>

      {/* FILTER TABS (When user has entered search) */}
      {query.trim().length > 0 && (
        <div
          className="w-full border-b px-4 py-2 flex items-center space-x-3 text-xs font-semibold overflow-x-auto no-scrollbar"
          style={{
            backgroundColor: headerBg,
            borderColor: currentTheme.border,
          }}
        >
          <button
            type="button"
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1.5 rounded-full transition cursor-pointer ${
              activeFilter === 'all' ? 'text-white' : 'opacity-70 hover:opacity-100'
            }`}
            style={{
              backgroundColor: activeFilter === 'all' ? accentColor : 'transparent',
              color: activeFilter === 'all' ? '#FFFFFF' : currentTheme.cardText,
            }}
          >
            All ({totalResults})
          </button>
          <button
            type="button"
            onClick={() => setActiveFilter('posts')}
            className={`px-3 py-1.5 rounded-full transition cursor-pointer ${
              activeFilter === 'posts' ? 'text-white' : 'opacity-70 hover:opacity-100'
            }`}
            style={{
              backgroundColor: activeFilter === 'posts' ? accentColor : 'transparent',
              color: activeFilter === 'posts' ? '#FFFFFF' : currentTheme.cardText,
            }}
          >
            Whispers & Confessions ({matchedPosts.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveFilter('users')}
            className={`px-3 py-1.5 rounded-full transition cursor-pointer ${
              activeFilter === 'users' ? 'text-white' : 'opacity-70 hover:opacity-100'
            }`}
            style={{
              backgroundColor: activeFilter === 'users' ? accentColor : 'transparent',
              color: activeFilter === 'users' ? '#FFFFFF' : currentTheme.cardText,
            }}
          >
            Ghosted Peers ({matchedUsers.length})
          </button>
        </div>
      )}

      {/* MAIN BODY AREA */}
      <div className="flex-1 overflow-y-auto px-4 py-4 max-w-2xl mx-auto w-full space-y-6">
        {/* STATE 1: EMPTY QUERY (Show Recent Searches + What's Haunting You Topics, strictly NO dummy sample celebrity names) */}
        {!query.trim() && (
          <div className="space-y-6">
            {/* RECENT SEARCHES */}
            {recentSearches.length > 0 && (
              <div className="space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider opacity-60">
                    Recent Searches
                  </span>
                  <button
                    type="button"
                    onClick={clearAllRecent}
                    className="text-xs opacity-60 hover:opacity-100 flex items-center space-x-1 transition cursor-pointer"
                    style={{ color: currentTheme.cardSubtext }}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Clear all</span>
                  </button>
                </div>

                <div className="space-y-1">
                  {recentSearches.map((term, idx) => (
                    <div
                      key={idx}
                      onClick={() => handleExecuteSearch(term)}
                      className="flex items-center justify-between p-2.5 rounded-xl cursor-pointer transition"
                      style={{
                        backgroundColor: 'transparent',
                      }}
                      onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = itemHoverBg)}
                      onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'transparent')}
                    >
                      <div className="flex items-center space-x-3 overflow-hidden">
                        <Clock className="w-4 h-4 opacity-50 flex-shrink-0" />
                        <span className="text-sm font-medium truncate">{term}</span>
                      </div>
                      <button
                        type="button"
                        onClick={(e) => removeSearchItem(term, e)}
                        className="p-1 rounded-full opacity-40 hover:opacity-100 transition cursor-pointer"
                        title="Remove"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* WHAT'S HAUNTING YOU - EXPLORE THE VOID TOPICS */}
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Sparkles className="w-4 h-4" style={{ color: accentColor }} />
                <h3 className="text-xs font-bold uppercase tracking-wider opacity-75">
                  What's haunting you in The Void
                </h3>
              </div>
              <p className="text-xs opacity-60 leading-relaxed">
                Explore real whispers, anonymous confessions, and ghosted echoes across the void.
              </p>

              <div className="flex flex-wrap gap-2 pt-1">
                {VOID_TOPICS.map((topic, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleExecuteSearch(topic.query)}
                    className="px-3.5 py-2 rounded-xl text-xs font-medium border transition-all cursor-pointer active:scale-95 flex items-center space-x-1.5"
                    style={{
                      backgroundColor: inputBg,
                      borderColor: currentTheme.border,
                      color: currentTheme.cardText,
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.borderColor = accentColor;
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.borderColor = currentTheme.border;
                    }}
                  >
                    <span>{topic.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* GHOSTED VOID BANNER */}
            <div
              className="p-4 rounded-2xl border text-center space-y-2 mt-4"
              style={{
                backgroundColor: isGhost ? '#0d0d1a' : isBlack ? '#161616' : '#F0F2F5',
                borderColor: currentTheme.border,
              }}
            >
              <div className="w-10 h-10 rounded-full mx-auto flex items-center justify-center text-xl shadow-xs"
                style={{ backgroundColor: isGhost ? 'rgba(0, 245, 255, 0.15)' : 'rgba(255, 42, 85, 0.15)' }}
              >
                👻
              </div>
              <h4 className="text-sm font-bold">Safe & Anonymous Void</h4>
              <p className="text-xs opacity-60 max-w-sm mx-auto">
                Search by keyword, secret mood, or @ghost_id to uncover what others are whispering.
              </p>
            </div>
          </div>
        )}

        {/* STATE 2: ACTIVE QUERY RESULTS */}
        {query.trim().length > 0 && (
          <div className="space-y-6">
            {/* MATCHED USERS / GHOST PEERS (if 'all' or 'users') */}
            {(activeFilter === 'all' || activeFilter === 'users') && matchedUsers.length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider opacity-60 flex items-center space-x-1.5">
                    <User className="w-3.5 h-3.5" />
                    <span>Ghosted Peers ({matchedUsers.length})</span>
                  </h4>
                </div>

                <div className="space-y-2">
                  {matchedUsers.map((u) => (
                    <div
                      key={u.id}
                      className="p-3 rounded-2xl border flex items-center justify-between transition shadow-xs"
                      style={{
                        backgroundColor: currentTheme.card,
                        borderColor: currentTheme.border,
                      }}
                    >
                      <div className="flex items-center space-x-3 min-w-0">
                        <div className="w-11 h-11 rounded-full overflow-hidden flex items-center justify-center text-xl bg-gray-800 flex-shrink-0">
                          {u.avatar && (u.avatar.startsWith('http') || u.avatar.startsWith('data:')) ? (
                            <img src={u.avatar} alt="" className="w-full h-full object-cover" />
                          ) : (
                            <span>{u.avatar || '👻'}</span>
                          )}
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-bold truncate">{u.name}</p>
                          {u.ghostedId && (
                            <p
                              className="text-xs font-mono font-medium truncate"
                              style={{ color: accentColor }}
                            >
                              @{u.ghostedId}
                            </p>
                          )}
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          if (onNavigateToTab) {
                            onNavigateToTab('whispers');
                          }
                        }}
                        className="px-3 py-1.5 rounded-full text-xs font-semibold flex items-center space-x-1 transition cursor-pointer active:scale-95 flex-shrink-0"
                        style={{
                          backgroundColor: isGhost ? 'rgba(0, 245, 255, 0.15)' : 'rgba(255, 42, 85, 0.15)',
                          color: accentColor,
                          border: `1px solid ${accentColor}40`,
                        }}
                      >
                        <Send className="w-3 h-3" />
                        <span>Whisper 🤫</span>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* MATCHED POSTS (if 'all' or 'posts') */}
            {(activeFilter === 'all' || activeFilter === 'posts') && matchedPosts.length > 0 && (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider opacity-60 flex items-center space-x-1.5">
                    <Flame className="w-3.5 h-3.5" />
                    <span>Whispers & Posts ({matchedPosts.length})</span>
                  </h4>
                </div>

                <div className="space-y-3">
                  {matchedPosts.map((post) => (
                    <div
                      key={post.id}
                      onClick={() => {
                        if (onSelectPost) {
                          onSelectPost(post);
                        }
                        onClose();
                      }}
                      className="p-3.5 rounded-2xl border transition-all cursor-pointer shadow-xs hover:border-cyan-500/50 space-y-2.5"
                      style={{
                        backgroundColor: currentTheme.card,
                        borderColor: currentTheme.border,
                      }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2.5">
                          <div className="w-7 h-7 rounded-full overflow-hidden flex items-center justify-center text-sm bg-gray-800">
                            {post.authorAvatar &&
                            (post.authorAvatar.startsWith('http') || post.authorAvatar.startsWith('data:')) ? (
                              <img src={post.authorAvatar} alt="" className="w-full h-full object-cover" />
                            ) : (
                              <span>{post.authorAvatar || '👻'}</span>
                            )}
                          </div>
                          <div>
                            <span className="text-xs font-bold">{post.authorName || 'Anonymous Ghost'}</span>
                            {post.authorGhostedId && (
                              <span className="text-[10px] opacity-60 ml-1.5 font-mono">
                                @{post.authorGhostedId}
                              </span>
                            )}
                          </div>
                        </div>
                        <ChevronRight className="w-4 h-4 opacity-40" />
                      </div>

                      {/* Post text */}
                      <p className="text-xs sm:text-sm leading-relaxed line-clamp-3">
                        {post.text}
                      </p>

                      {/* Media preview if any */}
                      {post.mediaUrl && (
                        <div className="w-full h-32 rounded-xl overflow-hidden bg-black/40 relative">
                          {post.mediaType === 'video' ? (
                            <div className="w-full h-full flex items-center justify-center bg-black/60 text-white text-xs">
                              🎥 Video attached
                            </div>
                          ) : (
                            <img
                              src={post.mediaUrl}
                              alt=""
                              className="w-full h-full object-cover"
                            />
                          )}
                        </div>
                      )}

                      {/* Footer stats */}
                      <div className="flex items-center justify-between pt-1 text-[11px] opacity-60">
                        <div className="flex items-center space-x-4">
                          <span className="flex items-center space-x-1">
                            <Heart className="w-3.5 h-3.5 text-rose-500" />
                            <span>{post.likesCount || 0}</span>
                          </span>
                          <span className="flex items-center space-x-1">
                            <MessageCircle className="w-3.5 h-3.5 text-cyan-400" />
                            <span>{post.commentsCount || 0}</span>
                          </span>
                        </div>
                        <span className="text-[10px]">Tap to open whisper</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* EMPTY STATE */}
            {totalResults === 0 && (
              <div
                className="p-8 rounded-3xl border text-center space-y-3 mt-6"
                style={{
                  backgroundColor: currentTheme.card,
                  borderColor: currentTheme.border,
                }}
              >
                <div className="w-14 h-14 rounded-full mx-auto flex items-center justify-center text-3xl bg-gray-800/40">
                  👻
                </div>
                <h4 className="text-base font-bold">No echoes in the void</h4>
                <p className="text-xs opacity-60 max-w-xs mx-auto">
                  Nothing matched "<strong>{query}</strong>". Try a different keyword or explore unspoken topics.
                </p>
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={handleClear}
                    className="px-4 py-2 rounded-full text-xs font-semibold cursor-pointer transition active:scale-95"
                    style={{
                      backgroundColor: accentColor,
                      color: '#FFFFFF',
                    }}
                  >
                    Clear Search
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
