import React, { useState, useEffect } from 'react';
import { UserProfile } from '../types';
import { generateGhostedId, generateGhostedNumber } from '../utils/idGenerator';
import { auth, googleProvider, db } from '../firebase';
import { signInWithPopup } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { ArrowRight, ArrowLeft, Check, Sparkles, AlertCircle, Minus, Plus } from 'lucide-react';

interface OnboardingFlowProps {
  onComplete: (profile: UserProfile) => void;
}

const INTERESTS_LIST = [
  'Music',
  'Luxury',
  'Studying',
  'Movies',
  'Gaming',
  'Football',
  'Heartbreak',
  'Family',
  'Anxiety',
  'Depression',
  'Relationship',
  'School Stress',
  'Money',
  'Sex & Love',
  'LGBTQ+',
  'Career',
  'Religion',
  'Fitness',
  'Memes',
  'Crypto',
  'Fashion',
  'Travel',
  'Books',
  'Art',
  'Tech',
] as const;

export const OnboardingFlow: React.FC<OnboardingFlowProps> = ({ onComplete }) => {
  // Steps 1 to 4
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [isSigningIn, setIsSigningIn] = useState<boolean>(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Authenticated user state from Google
  const [userUid, setUserUid] = useState<string>('');
  const [userEmail, setUserEmail] = useState<string>('');
  const [userPhotoURL, setUserPhotoURL] = useState<string>('');

  // Step 2: Real Name & Display Alias
  const [firstName, setFirstName] = useState<string>('');
  const [lastName, setLastName] = useState<string>('');
  const [displayName, setDisplayName] = useState<string>('');
  const [isCustomUsername, setIsCustomUsername] = useState<boolean>(false);

  // Step 3: Age
  const [age, setAge] = useState<number | ''>(21);
  const [ageError, setAgeError] = useState<string | null>(null);

  // Step 4: Interests
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Auto-generate username when first name changes (if user hasn't edited manually)
  useEffect(() => {
    if (!isCustomUsername) {
      const cleanFirst = firstName.trim().replace(/[^a-zA-Z0-9]/g, '');
      if (cleanFirst) {
        const randomNum = Math.floor(100 + Math.random() * 900);
        setDisplayName(`${cleanFirst}_${randomNum}`);
      } else {
        setDisplayName('');
      }
    }
  }, [firstName, isCustomUsername]);

  // STEP 1: GOOGLE SIGN-IN WITH ACCOUNT PICKER
  const handleGoogleSignIn = async () => {
    setAuthError(null);
    setIsSigningIn(true);
    try {
      googleProvider.setCustomParameters({
        prompt: 'select_account',
      });
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;
      if (!fbUser) {
        throw new Error('No user returned from Google sign in');
      }

      setUserUid(fbUser.uid);
      setUserEmail(fbUser.email || '');
      setUserPhotoURL(fbUser.photoURL || '');

      // Check if user already exists in Firestore users collection
      const userDocRef = doc(db, 'users', fbUser.uid);
      const userSnap = await getDoc(userDocRef);

      if (userSnap.exists()) {
        const existingData = userSnap.data();
        if (existingData?.isOnboarded) {
          const profile: UserProfile = {
            id: fbUser.uid,
            uid: fbUser.uid,
            name: existingData.fullName || existingData.displayName || fbUser.displayName || 'Ghosted User',
            firstName: existingData.firstName || '',
            lastName: existingData.lastName || '',
            fullName: existingData.fullName || '',
            displayName: existingData.displayName || '',
            email: existingData.email || fbUser.email || '',
            avatarUrl: existingData.photoURL || fbUser.photoURL || '',
            photoURL: existingData.photoURL || fbUser.photoURL || '',
            age: existingData.age,
            interests: existingData.interests || [],
            ghostedId: existingData.ghostedId || generateGhostedId(),
            ghostedNumber: existingData.ghostedNumber || generateGhostedNumber(),
            isOnboarded: true,
            onboardingCompleted: true,
            country: existingData.country || 'Nigeria',
            createdAt: existingData.createdAt || new Date().toISOString(),
          };
          onComplete(profile);
          return;
        }
      }

      // New user or not yet onboarded -> Pre-populate names from Google profile
      if (fbUser.displayName) {
        const parts = fbUser.displayName.trim().split(' ');
        const first = parts[0] || '';
        const last = parts.slice(1).join(' ') || '';
        setFirstName(first);
        setLastName(last);
        const randomNum = Math.floor(100 + Math.random() * 900);
        setDisplayName(`${first || 'Ghost'}_${randomNum}`);
      } else {
        const randomNum = Math.floor(100 + Math.random() * 900);
        setDisplayName(`Ghost_${randomNum}`);
      }

      setStep(2);
    } catch (err: any) {
      console.error('Google Sign-in error:', err);
      if (err.code === 'auth/popup-closed-by-user') {
        setAuthError('Sign in was cancelled. Please select an account to continue.');
      } else if (err.code === 'auth/popup-blocked') {
        setAuthError('Sign-in popup was blocked by browser. Please allow popups and try again.');
      } else {
        setAuthError(err.message || 'Unable to sign in with Google. Please try again.');
      }
    } finally {
      setIsSigningIn(false);
    }
  };

  // STEP 2: SET REAL NAME
  const isStep2Valid = firstName.trim().length >= 2 && lastName.trim().length >= 2;

  const handleStep2Continue = async () => {
    if (!isStep2Valid) return;
    const trimmedFirst = firstName.trim();
    const trimmedLast = lastName.trim();
    const finalFullName = `${trimmedFirst} ${trimmedLast}`;
    const finalDisplayName = displayName.trim() || `${trimmedFirst}_${Math.floor(100 + Math.random() * 900)}`;

    try {
      if (userUid) {
        await setDoc(
          doc(db, 'users', userUid),
          {
            uid: userUid,
            email: userEmail,
            firstName: trimmedFirst,
            lastName: trimmedLast,
            fullName: finalFullName,
            displayName: finalDisplayName,
            photoURL: userPhotoURL,
            isOnboarded: false,
            createdAt: new Date().toISOString(),
          },
          { merge: true }
        );
      }
    } catch (err) {
      console.warn('Could not save step 2 draft:', err);
    }
    setStep(3);
  };

  // STEP 3: SET AGE
  const handleAgeChange = (val: number | '') => {
    setAge(val);
    if (val === '') {
      setAgeError('Please enter your age');
    } else if (val < 13) {
      setAgeError('You must be 13+');
    } else if (val > 99) {
      setAgeError('Please enter a valid age under 100');
    } else {
      setAgeError(null);
    }
  };

  const handleStep3Continue = async () => {
    if (age === '' || age < 13 || age > 99) {
      setAgeError('You must be 13+');
      return;
    }
    try {
      if (userUid) {
        await setDoc(
          doc(db, 'users', userUid),
          {
            age: Number(age),
          },
          { merge: true }
        );
      }
    } catch (err) {
      console.warn('Could not save step 3 draft:', err);
    }
    setStep(4);
  };

  // STEP 4: INTERESTS SCREEN
  const toggleInterest = (interest: string) => {
    setSelectedInterests((prev) =>
      prev.includes(interest) ? prev.filter((i) => i !== interest) : [...prev, interest]
    );
  };

  const handleFinishOnboarding = async () => {
    if (selectedInterests.length < 3) return;
    setIsSubmitting(true);

    const gid = generateGhostedId();
    const gnum = generateGhostedNumber(gid);
    const trimmedFirst = firstName.trim();
    const trimmedLast = lastName.trim();
    const finalFullName = `${trimmedFirst} ${trimmedLast}`;
    const finalDisplayName = displayName.trim() || `${trimmedFirst}_${Math.floor(100 + Math.random() * 900)}`;

    const userPayload = {
      uid: userUid,
      email: userEmail,
      firstName: trimmedFirst,
      lastName: trimmedLast,
      fullName: finalFullName,
      displayName: finalDisplayName,
      age: Number(age),
      interests: selectedInterests,
      photoURL: userPhotoURL,
      ghostedId: gid,
      ghostedNumber: gnum,
      isOnboarded: true,
      onboardingCompleted: true,
      createdAt: new Date().toISOString(),
      country: 'Nigeria',
      city: 'Lagos',
    };

    try {
      if (userUid) {
        await setDoc(doc(db, 'users', userUid), userPayload, { merge: true });
      }
    } catch (err) {
      console.error('Error saving onboarded user to Firestore:', err);
    }

    const profile: UserProfile = {
      id: userUid || `usr-${Date.now()}`,
      uid: userUid,
      name: finalFullName,
      firstName: trimmedFirst,
      lastName: trimmedLast,
      fullName: finalFullName,
      displayName: finalDisplayName,
      email: userEmail,
      avatarUrl: userPhotoURL,
      photoURL: userPhotoURL,
      age: Number(age),
      interests: selectedInterests,
      ghostedId: gid,
      ghostedNumber: gnum,
      isOnboarded: true,
      onboardingCompleted: true,
      country: 'Nigeria',
      createdAt: userPayload.createdAt,
    };

    setIsSubmitting(false);
    onComplete(profile);
  };

  return (
    <div className="w-full min-h-screen bg-[#070512] text-white flex flex-col justify-center items-center p-3 sm:p-6 relative overflow-x-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 -left-32 w-80 h-80 bg-purple-600/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-32 w-80 h-80 bg-violet-600/15 rounded-full blur-3xl pointer-events-none" />

      {/* Main card */}
      <div className="w-full max-w-md bg-white text-zinc-900 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-purple-950/40 relative z-10 transition-all duration-300">
        {/* Step indicator header */}
        <div className="flex items-center justify-between mb-6 pb-4 border-b border-zinc-100">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-xl bg-purple-700 text-white flex items-center justify-center font-bold text-base shadow-md shadow-purple-700/30">
              👻
            </div>
            <div>
              <span className="font-extrabold text-base tracking-tight text-zinc-900">GHOSTED</span>
              <span className="block text-[10px] text-zinc-400 font-medium -mt-0.5">The Anonymous Network</span>
            </div>
          </div>
          <div className="flex items-center space-x-1.5 px-3 py-1 rounded-full bg-zinc-100 text-xs font-semibold text-zinc-600">
            <span>Step {step} of 4</span>
          </div>
        </div>

        {/* STEP 1: GOOGLE SIGN-IN */}
        {step === 1 && (
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <div className="w-16 h-16 rounded-3xl bg-purple-50 text-purple-700 flex items-center justify-center mx-auto text-3xl shadow-inner border border-purple-100">
                👻
              </div>
              <h1 className="text-2xl font-black text-zinc-900 tracking-tight">
                Welcome to Ghosted
              </h1>
              <p className="text-xs text-zinc-500 max-w-xs mx-auto leading-relaxed">
                Connect with honesty, vent anonymously in THE VOID, and chat securely without revealing who you are.
              </p>
            </div>

            {authError && (
              <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-start space-x-2.5">
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <div className="leading-snug">{authError}</div>
              </div>
            )}

            <div className="space-y-3 pt-2">
              <button
                type="button"
                onClick={handleGoogleSignIn}
                disabled={isSigningIn}
                className="w-full py-3.5 px-5 rounded-2xl bg-zinc-900 hover:bg-black text-white font-bold text-sm shadow-xl shadow-zinc-900/20 transition-all flex items-center justify-center space-x-3 cursor-pointer disabled:opacity-60 active:scale-[0.99]"
              >
                {isSigningIn ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <div className="w-6 h-6 rounded-full bg-white flex items-center justify-center flex-shrink-0 shadow-sm p-1">
                    <svg className="w-4 h-4" viewBox="0 0 24 24">
                      <path
                        fill="#4285F4"
                        d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.17 0 9.97 0 12s.45 3.83 1.25 5.42l4.03-3.15z"
                      />
                      <path
                        fill="#EA4335"
                        d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                      />
                    </svg>
                  </div>
                )}
                <span>{isSigningIn ? 'Opening Google Account Picker...' : 'Continue with Google'}</span>
              </button>
              <p className="text-[11px] text-center text-zinc-400 font-medium px-4 leading-relaxed">
                Choose any Google account on your device. Existing users sign in immediately; new users setup their profile.
              </p>
            </div>
          </div>
        )}

        {/* STEP 2: SET REAL NAME */}
        {step === 2 && (
          <div className="space-y-5">
            <div>
              <h2 className="text-xl font-black text-zinc-900 tracking-tight">
                What is your real name?
              </h2>
              <p className="text-xs text-zinc-500 mt-1">
                Use your real name so people trust you
              </p>
            </div>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1.5">
                    First Name <span className="text-purple-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    placeholder="David"
                    className="w-full px-3.5 py-3 bg-zinc-50 border border-zinc-200 rounded-2xl text-zinc-900 placeholder-zinc-400 text-sm focus:outline-none focus:ring-2 focus:ring-purple-600 focus:bg-white transition"
                  />
                  {firstName.length > 0 && firstName.trim().length < 2 && (
                    <span className="text-[10px] text-rose-500 mt-1 block">Min 2 characters</span>
                  )}
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-700 mb-1.5">
                    Last Name <span className="text-purple-600">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    placeholder="Nwosu"
                    className="w-full px-3.5 py-3 bg-zinc-50 border border-zinc-200 rounded-2xl text-zinc-900 placeholder-zinc-400 text-sm focus:outline-none focus:ring-2 focus:ring-purple-600 focus:bg-white transition"
                  />
                  {lastName.length > 0 && lastName.trim().length < 2 && (
                    <span className="text-[10px] text-rose-500 mt-1 block">Min 2 characters</span>
                  )}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-bold text-zinc-700">
                    Display Username <span className="text-zinc-400 font-normal">(Auto-generated, editable)</span>
                  </label>
                </div>
                <div className="relative">
                  <span className="absolute left-3.5 top-3.5 text-zinc-400 font-bold text-sm">@</span>
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => {
                      setDisplayName(e.target.value);
                      setIsCustomUsername(true);
                    }}
                    placeholder="David_482"
                    className="w-full pl-8 pr-3.5 py-3 bg-zinc-50 border border-zinc-200 rounded-2xl text-zinc-900 font-medium placeholder-zinc-400 text-sm focus:outline-none focus:ring-2 focus:ring-purple-600 focus:bg-white transition"
                  />
                </div>
                <p className="text-[11px] text-zinc-400 mt-1.5">
                  e.g. David_482. You can customize this handle anytime.
                </p>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleStep2Continue}
                  disabled={!isStep2Valid}
                  className="w-full py-3.5 px-6 rounded-2xl bg-purple-700 hover:bg-purple-800 disabled:bg-zinc-200 disabled:text-zinc-400 disabled:cursor-not-allowed text-white font-bold text-sm shadow-xl shadow-purple-700/20 transition flex items-center justify-center space-x-2 active:scale-[0.99] cursor-pointer"
                >
                  <span>Continue</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: SET AGE */}
        {step === 3 && (
          <div className="space-y-5">
            <div>
              <h2 className="text-xl font-black text-zinc-900 tracking-tight">
                How old are you?
              </h2>
              <p className="text-xs text-zinc-500 mt-1">
                We use this to keep GHOSTED safe
              </p>
            </div>
            <div className="space-y-5">
              <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-5 flex flex-col items-center justify-center space-y-3">
                <span className="text-xs font-bold uppercase tracking-wider text-zinc-400">Your Age</span>
                <div className="flex items-center space-x-4">
                  <button
                    type="button"
                    onClick={() => {
                      const cur = typeof age === 'number' ? age : 21;
                      handleAgeChange(Math.max(13, cur - 1));
                    }}
                    className="w-10 h-10 rounded-full bg-white border border-zinc-200 text-zinc-700 flex items-center justify-center hover:bg-zinc-100 active:scale-95 transition shadow-sm font-bold cursor-pointer"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <input
                    type="number"
                    min={13}
                    max={99}
                    value={age}
                    onChange={(e) => {
                      const val = e.target.value === '' ? '' : parseInt(e.target.value, 10);
                      handleAgeChange(isNaN(val as number) ? '' : val);
                    }}
                    className="w-24 text-center py-2 text-3xl font-black text-zinc-900 bg-transparent border-b-2 border-purple-600 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const cur = typeof age === 'number' ? age : 21;
                      handleAgeChange(Math.min(99, cur + 1));
                    }}
                    className="w-10 h-10 rounded-full bg-white border border-zinc-200 text-zinc-700 flex items-center justify-center hover:bg-zinc-100 active:scale-95 transition shadow-sm font-bold cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                <span className="text-xs text-zinc-400 font-medium">Min 13, Max 99</span>
              </div>

              {ageError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-600 text-xs flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span className="font-semibold">{ageError}</span>
                </div>
              )}

              <div className="flex items-center space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="py-3 px-4 rounded-2xl border border-zinc-200 text-zinc-600 hover:bg-zinc-100 text-xs font-bold transition flex items-center space-x-1 cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back</span>
                </button>
                <button
                  type="button"
                  onClick={handleStep3Continue}
                  disabled={age === '' || age < 13 || age > 99}
                  className="flex-1 py-3.5 px-6 rounded-2xl bg-purple-700 hover:bg-purple-800 disabled:bg-zinc-200 disabled:text-zinc-400 disabled:cursor-not-allowed text-white font-bold text-sm shadow-xl shadow-purple-700/20 transition flex items-center justify-center space-x-2 active:scale-[0.99] cursor-pointer"
                >
                  <span>Continue</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* STEP 4: INTERESTS SCREEN */}
        {step === 4 && (
          <div className="space-y-4">
            <div>
              <h2 className="text-xl font-black text-zinc-900 tracking-tight">
                What are you interested in?
              </h2>
              <p className="text-xs text-zinc-500 mt-1">
                Pick at least 3 - we will show you stuff you care about in THE VOID
              </p>
            </div>

            <div className="flex items-center justify-between px-1">
              <span className={`text-xs font-bold ${selectedInterests.length >= 3 ? 'text-purple-700' : 'text-zinc-500'}`}>
                {selectedInterests.length}/25 selected
              </span>
              {selectedInterests.length < 3 && (
                <span className="text-[11px] text-amber-600 font-semibold">
                  Pick {3 - selectedInterests.length} more
                </span>
              )}
            </div>

            <div className="max-h-[300px] overflow-y-auto pr-1 py-1 grid grid-cols-2 sm:grid-cols-3 gap-2 scrollbar-thin">
              {INTERESTS_LIST.map((interest) => {
                const isSelected = selectedInterests.includes(interest);
                return (
                  <button
                    key={interest}
                    type="button"
                    onClick={() => toggleInterest(interest)}
                    className={`py-2 px-3 rounded-xl text-xs font-semibold transition-all border text-left flex items-center justify-between cursor-pointer ${
                      isSelected
                        ? 'bg-purple-700 border-purple-700 text-white shadow-md shadow-purple-700/25'
                        : 'bg-zinc-50 border-zinc-200 text-zinc-700 hover:border-purple-300 hover:bg-purple-50/50'
                    }`}
                  >
                    <span className="truncate">{interest}</span>
                    {isSelected && <Check className="w-3.5 h-3.5 flex-shrink-0 ml-1 text-white" />}
                  </button>
                );
              })}
            </div>

            <div className="flex items-center space-x-3 pt-3 border-t border-zinc-100">
              <button
                type="button"
                onClick={() => setStep(3)}
                className="py-3 px-4 rounded-2xl border border-zinc-200 text-zinc-600 hover:bg-zinc-100 text-xs font-bold transition flex items-center space-x-1 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back</span>
              </button>
              <button
                type="button"
                onClick={handleFinishOnboarding}
                disabled={selectedInterests.length < 3 || isSubmitting}
                className="flex-1 py-3.5 px-6 rounded-2xl bg-zinc-900 hover:bg-black disabled:bg-zinc-200 disabled:text-zinc-400 disabled:cursor-not-allowed text-white font-bold text-sm shadow-xl shadow-zinc-900/20 transition flex items-center justify-center space-x-2 active:scale-[0.99] cursor-pointer"
              >
                {isSubmitting ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <span>Enter THE VOID</span>
                    <Sparkles className="w-4 h-4 text-purple-300" />
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
