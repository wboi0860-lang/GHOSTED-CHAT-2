import React, { useState, useEffect } from 'react';
import {
  Lock,
  Unlock,
  Sparkles,
  Clock,
  Heart,
  Eye,
  CheckCircle2,
  Mail,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import {
  subscribeInboxMessages,
  revealUnknownMessageIdentity,
} from '../services/ghostService';
import { InboxMessageDoc, UserProfile } from '../types';

interface SecretInboxSectionProps {
  currentUser: UserProfile;
}

export const SecretInboxSection: React.FC<SecretInboxSectionProps> = ({ currentUser }) => {
  const { currentTheme, isBlack, isGhost } = useTheme();
  const [messages, setMessages] = useState<InboxMessageDoc[]>([]);
  const [isRevealingId, setIsRevealingId] = useState<string | null>(null);
  const [isExpanded, setIsExpanded] = useState(true);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    if (!currentUser.id) return;
    const unsub = subscribeInboxMessages(currentUser.id, (msgs) => {
      setMessages(msgs);
    });
    return () => unsub();
  }, [currentUser.id]);

  const handleReveal = async (msg: InboxMessageDoc) => {
    setIsRevealingId(msg.id);
    const res = await revealUnknownMessageIdentity(
      msg.id,
      currentUser.displayName || currentUser.name || 'Anonymous Peer'
    );
    setIsRevealingId(null);

    if (res.success) {
      setToastMessage('Identity unlocked! The sender was notified.');
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  const unrevealedCount = messages.filter((m) => !m.is_revealed).length;

  return (
    <div
      className="p-3.5 sm:p-4 rounded-2xl border shadow-md space-y-3 theme-card transition-colors duration-300"
      style={{
        backgroundColor: currentTheme.card,
        borderColor: currentTheme.border,
        color: currentTheme.cardText,
      }}
    >
      {/* Toast Alert */}
      {toastMessage && (
        <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-400 text-xs font-bold flex items-center space-x-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between cursor-pointer" onClick={() => setIsExpanded(!isExpanded)}>
        <div className="flex items-center space-x-2.5">
          <div
            className="w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs shadow-xs border"
            style={{
              backgroundColor: isGhost ? '#00F5FF' : isBlack ? '#000000' : '#FFFFFF',
              color: isGhost ? '#00F5FF' : isBlack ? '#FFFFFF' : '#000000',
              borderColor: currentTheme.border,
            }}
          >
            <Mail className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs sm:text-sm font-black flex items-center space-x-2" style={{ color: currentTheme.cardText }}>
              <span>Secret Whisper Inbox</span>
              {messages.length > 0 && (
                <span
                  className="text-[10px] px-2 py-0.5 rounded-full font-mono font-bold border"
                  style={{
                    backgroundColor: unrevealedCount > 0 ? '#10B981' : isBlack ? '#E5E7EB' : '#141414',
                    color: unrevealedCount > 0 ? '#FFFFFF' : currentTheme.cardText,
                    borderColor: currentTheme.border,
                  }}
                >
                  {messages.length} {unrevealedCount > 0 ? `(${unrevealedCount} secret)` : ''}
                </span>
              )}
            </h3>
            <p className="text-[10px]" style={{ color: currentTheme.cardSubtext }}>
              Anonymous reconnection notes sent directly to your Ghosted identity
            </p>
          </div>
        </div>

        <button
          type="button"
          className="p-1 rounded-lg opacity-70 hover:opacity-100 transition"
          style={{ color: currentTheme.cardText }}
        >
          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
      </div>

      {isExpanded && (
        <div className="space-y-2 pt-1 border-t" style={{ borderColor: currentTheme.border }}>
          {messages.length === 0 ? (
            <div
              className="py-5 px-3 rounded-xl border text-center space-y-1.5"
              style={{
                backgroundColor: isBlack ? '#F9FAFB' : '#141414',
                borderColor: currentTheme.border,
              }}
            >
              <div className="text-xl">👻</div>
              <p className="text-xs font-semibold" style={{ color: currentTheme.cardText }}>
                Your Secret Inbox is quiet
              </p>
              <p className="text-[10px] max-w-xs mx-auto leading-relaxed" style={{ color: currentTheme.cardSubtext }}>
                When other registered Ghosted users send you an anonymous whisper, it will appear here safely. You can reveal their identity at any time.
              </p>
            </div>
          ) : (
            <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className="p-3 rounded-xl border space-y-2 transition shadow-xs"
                  style={{
                    backgroundColor: isBlack ? '#FFFFFF' : '#111111',
                    borderColor: currentTheme.border,
                  }}
                >
                  <div className="flex items-center justify-between text-[11px]">
                    <div className="flex items-center space-x-1.5">
                      <span
                        className="px-2 py-0.5 rounded-full font-bold text-[10px] border"
                        style={{
                          backgroundColor: isBlack ? '#F3F4F6' : '#222222',
                          borderColor: currentTheme.border,
                          color: currentTheme.cardText,
                        }}
                      >
                        {msg.mood || 'Miss You'}
                      </span>
                      {msg.relationship && (
                        <span className="opacity-70 text-[10px]" style={{ color: currentTheme.cardSubtext }}>
                          • {msg.relationship}
                        </span>
                      )}
                    </div>
                    <span className="font-mono text-[10px] opacity-70" style={{ color: currentTheme.cardSubtext }}>
                      {new Date(msg.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                    </span>
                  </div>

                  {/* Message body */}
                  <p className="text-xs sm:text-sm font-serif italic leading-relaxed" style={{ color: currentTheme.cardText }}>
                    "{msg.message}"
                  </p>

                  {/* Identity State and Reveal Button */}
                  <div className="flex items-center justify-between pt-1 border-t" style={{ borderColor: currentTheme.border }}>
                    <div className="flex items-center space-x-1.5 text-xs">
                      {msg.is_revealed ? (
                        <div className="flex items-center space-x-1 text-emerald-400 font-bold text-[11px]">
                          <Unlock className="w-3.5 h-3.5" />
                          <span>Revealed: {msg.sender_name_hidden || 'Ghost Soul'}</span>
                        </div>
                      ) : (
                        <div className="flex items-center space-x-1 text-amber-400 text-[11px] font-medium">
                          <Lock className="w-3.5 h-3.5" />
                          <span>From: Anonymous Ghost</span>
                        </div>
                      )}
                    </div>

                    {!msg.is_revealed && (
                      <button
                        type="button"
                        onClick={() => handleReveal(msg)}
                        disabled={isRevealingId === msg.id}
                        className="px-3 py-1 rounded-xl font-bold text-[10px] transition flex items-center space-x-1 cursor-pointer active:scale-95 border"
                        style={{
                          backgroundColor: currentTheme.btnPrimaryBg,
                          color: currentTheme.btnPrimaryText,
                          borderColor: currentTheme.border,
                        }}
                      >
                        {isRevealingId === msg.id ? (
                          <span>Revealing...</span>
                        ) : (
                          <>
                            <Eye className="w-3 h-3" />
                            <span>Reveal Identity</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
