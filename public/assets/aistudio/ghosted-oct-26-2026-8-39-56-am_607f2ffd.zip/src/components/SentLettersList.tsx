import React, { useState, useEffect, useRef } from 'react';
import { SavedLetter } from '../types';
import {
  Mail,
  Eye,
  Flame,
  Clock,
  Copy,
  Check,
  Calendar,
  Lock,
  Unlock,
  Bell,
  Phone,
  Linkedin,
  MessageSquare,
  Smartphone,
  Share2,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  HeartHandshake,
  Send,
} from 'lucide-react';

import { useTheme } from '../context/ThemeContext';

interface SentLettersListProps {
  letters: SavedLetter[];
  onPreviewLetter: (letterId: string) => void;
  onComposeClick: () => void;
  onLetterUpdated?: (updatedLetter: SavedLetter) => void;
}

const DEMO_GHOST_POSTS: SavedLetter[] = [];

export const SentLettersList: React.FC<SentLettersListProps> = ({
  letters,
  onPreviewLetter,
  onComposeClick,
  onLetterUpdated,
}) => {
  const { currentTheme, isWhite, isBlack, isGhost } = useTheme();
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [revealingId, setRevealingId] = useState<string | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  // Use user's real letters only (no fake samples)
  const posts = letters;
  const isSampleFeed = false;

  // Ensure current index is within bounds
  useEffect(() => {
    if (currentIndex >= posts.length) {
      setCurrentIndex(Math.max(0, posts.length - 1));
    }
  }, [posts.length, currentIndex]);

  // Touch swipe support for Instagram-style sliding
  const touchStartXRef = useRef<number | null>(null);
  const touchStartYRef = useRef<number | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartXRef.current = e.touches[0].clientX;
    touchStartYRef.current = e.touches[0].clientY;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartXRef.current === null) return;
    const diffX = e.changedTouches[0].clientX - touchStartXRef.current;
    const diffY = touchStartYRef.current !== null ? e.changedTouches[0].clientY - touchStartYRef.current : 0;

    // Trigger only if horizontal swipe is dominant
    if (Math.abs(diffX) > 40 && Math.abs(diffX) > Math.abs(diffY)) {
      if (diffX < 0) {
        goToNext();
      } else {
        goToPrev();
      }
    }
    touchStartXRef.current = null;
    touchStartYRef.current = null;
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
        goToNext();
      } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
        goToPrev();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  });

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % posts.length);
  };

  const goToPrev = () => {
    setCurrentIndex((prev) => (prev - 1 + posts.length) % posts.length);
  };

  const copyLink = (id: string, link: string) => {
    navigator.clipboard.writeText(link);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleManualReveal = async (letterId: string) => {
    setRevealingId(letterId);
    try {
      const res = await fetch(`/api/letters/${letterId}/reveal`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({}),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to reveal identity.');
      }
      if (onLetterUpdated && data.letter) {
        onLetterUpdated(data.letter);
      }
    } catch (err: any) {
      alert(err.message || 'Error revealing identity.');
    } finally {
      setRevealingId(null);
    }
  };

  const cleanPhone = (phone?: string) => (phone || '').replace(/[^0-9]/g, '');

  const cleanLinkedInUrl = (input?: string) => {
    if (!input) return '#';
    const trimmed = input.trim();
    if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) return trimmed;
    if (trimmed.includes('linkedin.com')) return `https://${trimmed}`;
    return `https://www.linkedin.com/in/${trimmed.replace('@', '')}`;
  };

  const currentPost = posts[currentIndex];
  if (posts.length === 0 || !currentPost) {
    return (
      <div className="max-w-xl mx-auto w-full flex flex-col items-center space-y-4">
        {/* Feed Header */}
        <div className="w-full flex items-center justify-between px-2">
          <div className="flex items-center space-x-2">
            <div
              className="w-8 h-8 rounded-xl border flex items-center justify-center"
              style={{
                backgroundColor: isBlack ? '#F3F4F6' : '#141414',
                borderColor: currentTheme.border,
                color: currentTheme.cardText,
              }}
            >
              <Mail className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold" style={{ color: currentTheme.textOutside }}>
                Ghosted Feed
              </h2>
              <p className="text-[11px]" style={{ color: currentTheme.textOutsideSub }}>Anonymous messages & whispers</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onComposeClick}
            className="py-1.5 px-3 rounded-xl font-bold text-xs shadow-md transition flex items-center space-x-1 cursor-pointer active:scale-95 border"
            style={{
              backgroundColor: currentTheme.btnPrimaryBg,
              color: currentTheme.btnPrimaryText,
              borderColor: currentTheme.border,
            }}
          >
            <Send className="w-3 h-3" />
            <span>+ Send Anonymous message</span>
          </button>
        </div>

        <div
          className="w-full max-w-[500px] aspect-square rounded-3xl border p-8 shadow-2xl flex flex-col items-center justify-center text-center space-y-4 theme-card"
          style={{
            backgroundColor: currentTheme.card,
            color: currentTheme.cardText,
            borderColor: currentTheme.border,
          }}
        >
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center text-3xl border"
            style={{
              borderColor: currentTheme.border,
              backgroundColor: isBlack ? '#F3F4F6' : '#141414',
            }}
          >
            🤫
          </div>
          <h3 className="text-base font-bold" style={{ color: currentTheme.cardText }}>
            No Anonymous Messages Yet
          </h3>
          <p className="text-xs max-w-xs leading-relaxed" style={{ color: currentTheme.cardSubtext }}>
            Send an anonymous message directly to another Ghosted user. Receiver will not know your identity unless you choose to reveal it.
          </p>
          <button
            type="button"
            onClick={onComposeClick}
            className="py-2.5 px-5 rounded-2xl font-bold text-xs shadow-md transition flex items-center space-x-2 cursor-pointer active:scale-95 border"
            style={{
              backgroundColor: currentTheme.btnPrimaryBg,
              color: currentTheme.btnPrimaryText,
              borderColor: currentTheme.border,
            }}
          >
            <Send className="w-4 h-4" />
            <span>Send Anonymous message</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto w-full flex flex-col items-center space-y-4">
      {/* Feed Header */}
      <div className="w-full flex items-center justify-between px-2">
        <div className="flex items-center space-x-2">
          <div
            className="w-8 h-8 rounded-xl border flex items-center justify-center"
            style={{
              backgroundColor: isBlack ? '#F3F4F6' : '#141414',
              borderColor: currentTheme.border,
              color: currentTheme.cardText,
            }}
          >
            <Mail className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold" style={{ color: currentTheme.textOutside }}>
              Ghosted Feed
            </h2>
            <p className="text-[11px]" style={{ color: currentTheme.textOutsideSub }}>1 big squared post per screen • Slide to explore</p>
          </div>
        </div>

        {/* Send Anonymous message button */}
        <button
          type="button"
          onClick={onComposeClick}
          className="py-1.5 px-3 rounded-xl font-bold text-xs shadow-md transition flex items-center space-x-1 cursor-pointer active:scale-95 border"
          style={{
            backgroundColor: currentTheme.btnPrimaryBg,
            color: currentTheme.btnPrimaryText,
            borderColor: currentTheme.border,
          }}
        >
          <Send className="w-3 h-3" />
          <span>+ Send Anonymous message</span>
        </button>
      </div>

      {/* THE BIG SQUARED POST (INSTAGRAM STYLE - 1 PER SCREEN) */}
      <div
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        className="w-full max-w-[500px] aspect-square rounded-3xl border p-5 sm:p-6 shadow-2xl backdrop-blur-2xl flex flex-col justify-between relative overflow-hidden group select-none transition-all duration-300 theme-card"
        style={{
          backgroundColor: currentTheme.card,
          color: currentTheme.cardText,
          borderColor: currentTheme.border,
        }}
      >
        {/* Ambient Mood Glow in the square background */}
        <div
          className={`absolute -top-24 -right-24 w-60 h-60 rounded-full blur-3xl pointer-events-none opacity-30 ${
            currentPost.mood === 'Apology'
              ? 'bg-blue-500'
              : currentPost.mood === 'Miss You'
              ? 'bg-purple-500'
              : currentPost.mood === 'Closure'
              ? 'bg-indigo-500'
              : currentPost.mood === 'Thank You'
              ? 'bg-emerald-500'
              : 'bg-amber-500'
          }`}
        />

        {/* 1. SQUARE POST HEADER (Instagram Style) */}
        <div className="flex items-center justify-between pb-3 border-b relative z-10" style={{ borderColor: currentTheme.border }}>
          <div className="flex items-center space-x-3">
            {/* Instagram story-styled ring around Ghost avatar */}
            <div className="w-11 h-11 rounded-full p-[2px] bg-gradient-to-tr from-amber-400 via-pink-500 to-purple-600 flex items-center justify-center flex-shrink-0 shadow-md">
              <div
                className="w-full h-full rounded-full flex items-center justify-center text-lg font-bold"
                style={{
                  backgroundColor: isBlack ? '#FFFFFF' : '#000000',
                  color: currentTheme.cardText,
                }}
              >
                {currentPost.mood === 'Apology' && '🕊️'}
                {currentPost.mood === 'Miss You' && '💌'}
                {currentPost.mood === 'Closure' && '🍂'}
                {currentPost.mood === 'Thank You' && '🌱'}
                {currentPost.mood === 'Just Checking In' && '☕'}
              </div>
            </div>
            <div className="min-w-0">
              <div className="flex items-center space-x-1.5">
                <h3 className="font-bold text-sm truncate max-w-[170px] sm:max-w-[210px]" style={{ color: currentTheme.cardText }}>
                  To: {currentPost.recipientName}
                </h3>
                <span className="text-[10px]" style={{ color: currentTheme.cardSubtext }}>•</span>
                <span className="text-[10px] font-mono" style={{ color: currentTheme.cardSubtext }}>
                  {new Date(currentPost.createdAt).toLocaleDateString(undefined, {
                    month: 'short',
                    day: 'numeric',
                  })}
                </span>
              </div>
              <p className="text-[11px] truncate" style={{ color: currentTheme.cardSubtext }}>
                {currentPost.relationship} • Mood: {currentPost.mood}
              </p>
            </div>
          </div>

          {/* Status Badge */}
          <div className="flex items-center space-x-1 flex-shrink-0">
            {currentPost.status === 'pending' && (
              <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-400/30 px-2 py-0.5 rounded-full font-bold flex items-center space-x-1">
                <Clock className="w-2.5 h-2.5" />
                <span>Awaiting</span>
              </span>
            )}
            {currentPost.status === 'viewed' && (
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-2 py-0.5 rounded-full font-bold flex items-center space-x-1">
                <Eye className="w-2.5 h-2.5" />
                <span>Unlocked</span>
              </span>
            )}
            {currentPost.status === 'declined' && (
              <span className="text-[10px] bg-rose-500/20 text-rose-300 border border-rose-400/30 px-2 py-0.5 rounded-full font-bold flex items-center space-x-1">
                <Flame className="w-2.5 h-2.5" />
                <span>Burned</span>
              </span>
            )}
          </div>
        </div>

        {/* 2. SQUARE POST CENTER CANVAS (Deep, Immersive Message Card) */}
        <div className="flex-1 flex flex-col justify-center items-center text-center p-3 sm:p-5 relative z-10 overflow-y-auto scrollbar-none my-auto">
          <span className="text-4xl font-serif leading-none select-none mb-1 opacity-25" style={{ color: currentTheme.cardText }}>“</span>
          <p className="text-sm sm:text-base font-serif italic leading-relaxed max-w-sm line-clamp-6" style={{ color: currentTheme.cardText }}>
            {currentPost.letter}
          </p>
          <span className="text-4xl font-serif leading-none select-none mt-1 opacity-25" style={{ color: currentTheme.cardText }}>”</span>

          {/* Metadata badges inside the square */}
          <div className="mt-3 flex flex-wrap items-center justify-center gap-1.5 text-[10px]">
            {/* Identity Status */}
            <span
              className="px-2 py-0.5 rounded-lg border flex items-center space-x-1 font-semibold"
              style={{
                backgroundColor: currentPost.recipientRequestedReveal || currentPost.isManuallyRevealed
                  ? 'rgba(16, 185, 129, 0.15)'
                  : isBlack ? '#F3F4F6' : '#141414',
                borderColor: currentPost.recipientRequestedReveal || currentPost.isManuallyRevealed
                  ? 'rgba(16, 185, 129, 0.3)'
                  : currentTheme.border,
                color: currentPost.recipientRequestedReveal || currentPost.isManuallyRevealed
                  ? '#10B981'
                  : currentTheme.cardText,
              }}
            >
              {currentPost.recipientRequestedReveal || currentPost.isManuallyRevealed ? (
                <>
                  <Unlock className="w-3 h-3 text-emerald-400" />
                  <span>Identity Revealed</span>
                </>
              ) : (
                <>
                  <Lock className="w-3 h-3" />
                  <span>Ghosted Anonymous</span>
                </>
              )}
            </span>

            {/* Anonymous Message badge */}
            <span
              className="px-2 py-0.5 rounded-lg border font-mono flex items-center space-x-1"
              style={{
                backgroundColor: isBlack ? '#F3F4F6' : '#141414',
                borderColor: currentTheme.border,
                color: currentTheme.cardText,
              }}
            >
              <span>🤫 Anonymous Message</span>
            </span>
          </div>
        </div>

        {/* 3. SQUARE POST FOOTER (Instagram Action Bar) */}
        <div className="pt-3 border-t relative z-10 space-y-2" style={{ borderColor: currentTheme.border }}>
          {/* Action Buttons */}
          <div className="flex items-center justify-between">
            {/* Left Icons: View / Preview & Copy Link */}
            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={() => onPreviewLetter(currentPost.id)}
                className="py-1.5 px-3 rounded-xl font-bold text-xs shadow-md transition flex items-center space-x-1.5 cursor-pointer active:scale-95 border"
                style={{
                  backgroundColor: currentTheme.btnPrimaryBg,
                  color: currentTheme.btnPrimaryText,
                  borderColor: currentTheme.border,
                }}
                title="Preview full letter in recipient view"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>View Letter</span>
              </button>
              <button
                type="button"
                onClick={() => copyLink(currentPost.id, currentPost.uniqueLink)}
                className="py-1.5 px-3 rounded-xl font-semibold text-xs border transition flex items-center space-x-1.5 cursor-pointer active:scale-95"
                style={{
                  backgroundColor: isBlack ? '#F3F4F6' : '#141414',
                  color: currentTheme.cardText,
                  borderColor: currentTheme.border,
                }}
                title="Copy encrypted secret link"
              >
                {copiedId === currentPost.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedId === currentPost.id ? 'Copied' : 'Share Link'}</span>
              </button>
            </div>

            {/* Right Icons: Direct Delivery Launchers */}
            <div className="flex items-center space-x-1.5">
              {currentPost.recipientPhone && (
                <>
                  <a
                    href={`sms:${currentPost.recipientPhone}?body=${encodeURIComponent(
                      `Hi ${currentPost.recipientName}, a private reconnection message is waiting for you on Ghosted: ${currentPost.uniqueLink}`
                    )}`}
                    className="p-1.5 rounded-xl bg-emerald-600/30 hover:bg-emerald-600 text-emerald-200 transition"
                    title="Open SMS"
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                  </a>
                  <a
                    href={`https://wa.me/${cleanPhone(currentPost.recipientPhone)}?text=${encodeURIComponent(
                      `Hi ${currentPost.recipientName}, a private reconnection message is waiting for you on Ghosted: ${currentPost.uniqueLink}`
                    )}`}
                    target="_blank"
                    rel="noreferrer"
                    className="p-1.5 rounded-xl bg-green-600/30 hover:bg-green-600 text-green-200 transition"
                    title="Open WhatsApp"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                  </a>
                </>
              )}
              {currentPost.recipientLinkedIn && (
                <a
                  href={cleanLinkedInUrl(currentPost.recipientLinkedIn)}
                  target="_blank"
                  rel="noreferrer"
                  className="p-1.5 rounded-xl bg-blue-600/30 hover:bg-blue-600 text-blue-200 transition"
                  title="Open LinkedIn"
                >
                  <Linkedin className="w-3.5 h-3.5" />
                </a>
              )}
              {currentPost.recipientEmail && (
                <a
                  href={`mailto:${currentPost.recipientEmail}?subject=${encodeURIComponent(
                    'Private reconnection message on Ghosted'
                  )}&body=${encodeURIComponent(
                    `Hi ${currentPost.recipientName},\n\nYou have a private reconnection message waiting for you on Ghosted: ${currentPost.uniqueLink}`
                  )}`}
                  className="p-1.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600 text-indigo-200 transition"
                  title="Open Email"
                >
                  <Mail className="w-3.5 h-3.5" />
                </a>
              )}
            </div>
          </div>

          {/* Reveal button if recipient requested identity */}
          {currentPost.recipientRequestedReveal && !currentPost.isManuallyRevealed && (
            <div className="p-2 rounded-xl bg-indigo-950/70 border border-indigo-400/40 text-xs text-indigo-200 flex items-center justify-between gap-2">
              <div className="flex items-center space-x-1.5 text-[11px]">
                <Bell className="w-3.5 h-3.5 text-indigo-400 animate-bounce flex-shrink-0" />
                <span>Recipient requested your identity</span>
              </div>
              <button
                type="button"
                onClick={() => handleManualReveal(currentPost.id)}
                disabled={revealingId === currentPost.id}
                className="py-1 px-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-[10px] font-bold cursor-pointer"
              >
                {revealingId === currentPost.id ? 'Revealing...' : 'Reveal Identity'}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* INSTAGRAM SLIDE NAVIGATION CONTROLS */}
      <div className="w-full max-w-[500px] flex items-center justify-between px-2 pt-1">
        <button
          type="button"
          onClick={goToPrev}
          className="py-2 px-3.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/15 text-white text-xs font-bold transition flex items-center space-x-1 cursor-pointer active:scale-95 shadow-md"
          title="Slide to previous square post"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Previous</span>
        </button>

        {/* Instagram-Style Post Pagination Dots */}
        <div className="flex flex-col items-center space-y-1">
          <div className="flex items-center space-x-1.5">
            {posts.map((_, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setCurrentIndex(idx)}
                className={`transition-all duration-300 rounded-full cursor-pointer ${
                  currentIndex === idx
                    ? 'w-6 h-2 bg-gradient-to-r from-purple-500 to-indigo-500 shadow-sm'
                    : 'w-2 h-2 bg-white/25 hover:bg-white/40'
                }`}
                title={`Jump to post ${idx + 1}`}
              />
            ))}
          </div>
          <span className="text-[10px] text-purple-300/70 font-mono">
            {currentIndex + 1} of {posts.length}
          </span>
        </div>

        <button
          type="button"
          onClick={goToNext}
          className="py-2 px-3.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/15 text-white text-xs font-bold transition flex items-center space-x-1 cursor-pointer active:scale-95 shadow-md"
          title="Slide to next square post"
        >
          <span>Next</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <p className="text-[11px] text-purple-300/50 text-center select-none">
        Tip: Swipe left/right or use keyboard arrows to slide to the next square page
      </p>
    </div>
  );
};
