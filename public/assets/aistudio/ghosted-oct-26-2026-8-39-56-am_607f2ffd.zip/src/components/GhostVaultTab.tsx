import React, { useState, useEffect, useRef } from 'react';
import {
  UserProfile,
  GhostVaultDoc,
  VaultCategory,
  VaultLockType,
  VaultKeyRequest,
  VaultChatMessage,
  VaultRatingSubmission,
} from '../types';
import { db } from '../firebase';
import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  onSnapshot,
  updateDoc,
  deleteDoc,
  addDoc,
  query,
  orderBy,
  limit,
} from 'firebase/firestore';
import { playVaultUnlockChime } from '../utils/audioTones';
import { SmartAdInterstitial } from './SmartAdInterstitial';
import { shouldShowAd } from '../utils/adManager';
import {
  Lock,
  Unlock,
  KeyRound,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Flame,
  Clock,
  Heart,
  CloudRain,
  Home,
  EyeOff,
  Send,
  MessageSquare,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  X,
  Star,
  ThumbsUp,
  ThumbsDown,
  UserCheck,
  Radio,
  Copy,
  Check,
  HelpCircle,
  Timer,
  ChevronRight,
  RefreshCw,
} from 'lucide-react';

interface GhostVaultTabProps {
  user: UserProfile;
  isNigeria: boolean;
  onUpdateUser?: (updated: UserProfile) => void;
}

const CATEGORIES: { id: VaultCategory; label: string; icon: any; color: string; desc: string }[] = [
  {
    id: 'Heartbreak',
    label: 'Heartbreak',
    icon: Heart,
    color: 'from-rose-500/20 to-pink-500/10 border-rose-500/40 text-rose-300',
    desc: 'Unspoken grief, breakup wounds, love that ended silently.',
  },
  {
    id: 'Anxiety',
    label: 'Anxiety',
    icon: CloudRain,
    color: 'from-indigo-500/20 to-purple-500/10 border-indigo-500/40 text-indigo-300',
    desc: 'Racing thoughts, panic, overwhelming heaviness.',
  },
  {
    id: 'Family',
    label: 'Family',
    icon: Home,
    color: 'from-amber-500/20 to-orange-500/10 border-amber-500/40 text-amber-300',
    desc: 'Household friction, generational silence, distant parents.',
  },
  {
    id: 'Secret',
    label: 'Secret',
    icon: EyeOff,
    color: 'from-emerald-500/20 to-teal-500/10 border-emerald-500/40 text-emerald-300',
    desc: 'Things you have never confessed out loud to anyone alive.',
  },
];

const QUICK_COMFORT_RESPONSES = [
  'I hear you, and you are not alone. 🤍',
  'Take your time. There is no rush here. 🌱',
  'Your feelings are completely valid. 💫',
  'Breathe. You survived that day. ✨',
  'Thank you for trusting me with this truth. 🕊️',
];

export const GhostVaultTab: React.FC<GhostVaultTabProps> = ({
  user,
  isNigeria,
  onUpdateUser,
}) => {
  const [vaults, setVaults] = useState<GhostVaultDoc[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<VaultCategory | 'ALL'>('ALL');
  const [filterView, setFilterView] = useState<'all' | 'my_vaults' | 'my_keys' | 'active_chats'>('all');
  const [isLoading, setIsLoading] = useState(true);

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newCategory, setNewCategory] = useState<VaultCategory>('Heartbreak');
  const [newVentText, setNewVentText] = useState('');
  const [newLockType, setNewLockType] = useState<VaultLockType>('time_lock');
  const [newTimeDuration, setNewTimeDuration] = useState<'1hr' | '24hr'>('24hr');
  const [isSubmittingVault, setIsSubmittingVault] = useState(false);
  const [isVaultAdOpen, setIsVaultAdOpen] = useState(false);

  const [requestKeyModalVault, setRequestKeyModalVault] = useState<GhostVaultDoc | null>(null);
  const [keyRequestNote, setKeyRequestNote] = useState('I am here to listen with an open, non-judgmental heart.');
  const [isRequestingKey, setIsRequestingKey] = useState(false);

  const [reviewRequestsVault, setReviewRequestsVault] = useState<GhostVaultDoc | null>(null);

  const [activeChatVault, setActiveChatVault] = useState<GhostVaultDoc | null>(null);
  const [chatMessages, setChatMessages] = useState<VaultChatMessage[]>([]);
  const [chatInputText, setChatInputText] = useState('');
  const [timeRemainingSeconds, setTimeRemainingSeconds] = useState<number>(15 * 60);
  const [isScreenshotWarningVisible, setIsScreenshotWarningVisible] = useState(false);

  const [ratingModalData, setRatingModalData] = useState<{
    isOpen: boolean;
    vaultId: string;
    listenerId: string;
    listenerGhostedId: string;
  }>({
    isOpen: false,
    vaultId: '',
    listenerId: '',
    listenerGhostedId: '',
  });
  const [selectedRating, setSelectedRating] = useState<'supportive' | 'neutral' | 'unsupportive'>('supportive');
  const [ratingFeedback, setRatingFeedback] = useState('');
  const [isSubmittingRating, setIsSubmittingRating] = useState(false);
  const [ratingSuccessToast, setRatingSuccessToast] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const userTrustScore = user.trustScore ?? 95;

  useEffect(() => {
    setIsLoading(true);
    try {
      const vaultsColRef = collection(db, 'vaults');
      const unsubscribe = onSnapshot(
        vaultsColRef,
        (snapshot) => {
          const list: GhostVaultDoc[] = [];
          snapshot.forEach((d) => {
            const data = d.data() as GhostVaultDoc;
            if (data && data.status !== 'burned') {
              list.push({ ...data, id: d.id });
            }
          });
          list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
          setVaults(list);
          setIsLoading(false);
        },
        (error) => {
          console.warn('Firestore onSnapshot error for vaults:', error);
          loadLocalVaults();
          setIsLoading(false);
        }
      );
      return () => unsubscribe();
    } catch (err) {
      console.warn('Fallback loading local vaults:', err);
      loadLocalVaults();
      setIsLoading(false);
    }
  }, []);

  const loadLocalVaults = () => {
    try {
      const saved = localStorage.getItem('ghosted_local_vaults');
      if (saved) {
        setVaults(JSON.parse(saved));
      } else {
        const initialSeeds: GhostVaultDoc[] = [
          {
            id: 'vault-seed-1',
            authorId: 'usr-soul-heartbreak',
            authorGhostedId: 'Ghost #4819',
            category: 'Heartbreak',
            ventText:
              'We lived together for three years. Yesterday she packed her bags while I was asleep and left her keys on the counter with zero note. I do not know how to exist in this quiet apartment.',
            lockType: 'trust_lock',
            timeLockDuration: '24hr',
            isLocked: true,
            burnAfterRead: true,
            canScreenshot: false,
            status: 'locked',
            keyRequests: [],
            createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
            expiresAt: new Date(Date.now() + 3600000 * 22).toISOString(),
          },
          {
            id: 'vault-seed-2',
            authorId: 'usr-soul-anxiety',
            authorGhostedId: 'Ghost #7204',
            category: 'Anxiety',
            ventText:
              'My chest feels like someone clamped it in a vice. I keep pretending at work that I have my life together, but every morning on the train I have to fight off a full panic attack.',
            lockType: 'one_soul',
            isLocked: true,
            burnAfterRead: true,
            canScreenshot: false,
            status: 'locked',
            keyRequests: [],
            createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
            expiresAt: new Date(Date.now() + 3600000 * 19).toISOString(),
          },
          {
            id: 'vault-seed-3',
            authorId: 'usr-soul-secret',
            authorGhostedId: 'Ghost #9155',
            category: 'Secret',
            ventText:
              'I told my entire family I got the promotion and relocation in London. The truth is I was laid off two months ago and I have been sitting in hotel lobbies pretending to work so they do not worry.',
            lockType: 'time_lock',
            timeLockDuration: '1hr',
            isLocked: true,
            burnAfterRead: true,
            canScreenshot: false,
            status: 'locked',
            keyRequests: [],
            createdAt: new Date(Date.now() - 1800000).toISOString(),
            expiresAt: new Date(Date.now() + 1800000).toISOString(),
          },
        ];
        setVaults(initialSeeds);
        localStorage.setItem('ghosted_local_vaults', JSON.stringify(initialSeeds));
      }
    } catch {}
  };

  const saveLocalVaults = (updated: GhostVaultDoc[]) => {
    setVaults(updated);
    try {
      localStorage.setItem('ghosted_local_vaults', JSON.stringify(updated));
    } catch {}
  };

  useEffect(() => {
    if (!activeChatVault) return;
    try {
      const messagesColRef = collection(db, 'vaults', activeChatVault.id, 'messages');
      const q = query(messagesColRef, orderBy('createdAt', 'asc'));
      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          const msgs: VaultChatMessage[] = [];
          snapshot.forEach((d) => {
            msgs.push({ id: d.id, ...(d.data() as any) });
          });
          setChatMessages(msgs);
        },
        (error) => {
          console.warn('Messages onSnapshot error:', error);
          const localKey = `vault_chat_${activeChatVault.id}`;
          const saved = localStorage.getItem(localKey);
          if (saved) setChatMessages(JSON.parse(saved));
        }
      );
      return () => unsubscribe();
    } catch (err) {
      console.warn('Fallback messages error:', err);
    }
  }, [activeChatVault?.id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  useEffect(() => {
    if (!activeChatVault) return;
    const calcSeconds = () => {
      if (activeChatVault.chatExpiresAt) {
        const remaining = Math.max(
          0,
          Math.floor((new Date(activeChatVault.chatExpiresAt).getTime() - Date.now()) / 1000)
        );
        return remaining;
      }
      return 15 * 60;
    };
    setTimeRemainingSeconds(calcSeconds());
    const intervalId = setInterval(() => {
      const remaining = calcSeconds();
      setTimeRemainingSeconds(remaining);
      if (remaining <= 0) {
        clearInterval(intervalId);
        handleBurnAndExitChat(activeChatVault, true);
      }
    }, 1000);
    return () => clearInterval(intervalId);
  }, [activeChatVault?.id, activeChatVault?.chatExpiresAt]);

  useEffect(() => {
    if (!activeChatVault) return;
    const handleVisibilityChange = () => {
      if (document.hidden) {
        setIsScreenshotWarningVisible(true);
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'PrintScreen' || (e.ctrlKey && e.key === 'p')) {
        setIsScreenshotWarningVisible(true);
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [activeChatVault]);

  const handleCreateVault = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVentText.trim()) return;
    setIsSubmittingVault(true);

    const vaultId = `vault-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const nowIso = new Date().toISOString();
    const durationHours = newTimeDuration === '1hr' ? 1 : 24;
    const expiresAt = new Date(Date.now() + durationHours * 3600000).toISOString();

    const newVault: GhostVaultDoc = {
      id: vaultId,
      authorId: user.id,
      authorGhostedId: user.ghostedId || `Ghost #${Math.floor(1000 + Math.random() * 9000)}`,
      category: newCategory,
      ventText: newVentText.trim().slice(0, 500),
      lockType: newLockType,
      timeLockDuration: newLockType === 'time_lock' ? newTimeDuration : undefined,
      isLocked: true,
      burnAfterRead: true,
      canScreenshot: false,
      status: 'locked',
      keyRequests: [],
      createdAt: nowIso,
      expiresAt,
    };

    try {
      await setDoc(doc(db, 'vaults', vaultId), newVault);
    } catch (err) {
      console.warn('Firestore setDoc failed, saving to local state:', err);
    }

    saveLocalVaults([newVault, ...vaults]);
    playVaultUnlockChime();
    setNewVentText('');
    setIsCreateModalOpen(false);
    setIsSubmittingVault(false);

    if (shouldShowAd(user, isNigeria)) {
      setIsVaultAdOpen(true);
    }
  };

  const handleSendKeyRequest = async () => {
    if (!requestKeyModalVault) return;
    setIsRequestingKey(true);
    const requestItem: VaultKeyRequest = {
      id: `req-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      requesterId: user.id,
      requesterGhostedId: user.ghostedId || `Ghost #${Math.floor(1000 + Math.random() * 9000)}`,
      requesterTrustScore: userTrustScore,
      note: keyRequestNote.trim(),
      requestedAt: new Date().toISOString(),
      status: 'pending',
    };

    const updatedRequests = [...(requestKeyModalVault.keyRequests || []), requestItem];
    try {
      await updateDoc(doc(db, 'vaults', requestKeyModalVault.id), {
        keyRequests: updatedRequests,
      });
    } catch (err) {
      console.warn('Firestore updateDoc failed for key request, using local fallback:', err);
    }

    const updatedVaults = vaults.map((v) =>
      v.id === requestKeyModalVault.id ? { ...v, keyRequests: updatedRequests } : v
    );
    saveLocalVaults(updatedVaults);
    setIsRequestingKey(false);
    setRequestKeyModalVault(null);
  };

  const handleApproveKey = async (vault: GhostVaultDoc, req: VaultKeyRequest) => {
    const nowIso = new Date().toISOString();
    const chatExpiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString();
    const updatedRequests = (vault.keyRequests || []).map((r) =>
      r.id === req.id ? { ...r, status: 'approved' as const } : r
    );

    const updatedVault: GhostVaultDoc = {
      ...vault,
      status: 'unlocked',
      currentListenerId: req.requesterId,
      currentListenerGhostedId: req.requesterGhostedId,
      unlockedAt: nowIso,
      chatExpiresAt,
      keyRequests: updatedRequests,
    };

    try {
      await updateDoc(doc(db, 'vaults', vault.id), {
        status: 'unlocked',
        currentListenerId: req.requesterId,
        currentListenerGhostedId: req.requesterGhostedId,
        unlockedAt: nowIso,
        chatExpiresAt,
        keyRequests: updatedRequests,
      });
    } catch (err) {
      console.warn('Firestore updateDoc failed, local fallback:', err);
    }

    const updatedList = vaults.map((v) => (v.id === vault.id ? updatedVault : v));
    saveLocalVaults(updatedList);
    playVaultUnlockChime();
    setReviewRequestsVault(null);
    setActiveChatVault(updatedVault);
  };

  const handleSendMessage = async (e?: React.FormEvent, customText?: string) => {
    if (e) e.preventDefault();
    const textToSend = customText || chatInputText;
    if (!textToSend.trim() || !activeChatVault) return;

    const isVenter = activeChatVault.authorId === user.id;
    const msgId = `msg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const newMsg: VaultChatMessage = {
      id: msgId,
      vaultId: activeChatVault.id,
      senderId: user.id,
      senderRole: isVenter ? 'venter' : 'listener',
      senderGhostedId: user.ghostedId || `Ghost #${Math.floor(1000 + Math.random() * 9000)}`,
      text: textToSend.trim(),
      createdAt: new Date().toISOString(),
    };

    try {
      await addDoc(collection(db, 'vaults', activeChatVault.id, 'messages'), newMsg);
    } catch (err) {
      console.warn('Firestore addDoc failed, local fallback:', err);
      const localKey = `vault_chat_${activeChatVault.id}`;
      const saved = [...chatMessages, newMsg];
      localStorage.setItem(localKey, JSON.stringify(saved));
      setChatMessages(saved);
    }
    setChatInputText('');
  };

  const handleBurnAndExitChat = async (vault: GhostVaultDoc, isNaturalTimeout = false) => {
    const isVenter = vault.authorId === user.id;
    const listenerId = isVenter ? vault.currentListenerId : vault.authorId;
    const listenerGhostedId = isVenter ? vault.currentListenerGhostedId || 'Supportive Ghost' : vault.authorGhostedId;

    try {
      await updateDoc(doc(db, 'vaults', vault.id), {
        status: 'burned',
        isLocked: true,
      });
      const msgsSnapshot = await getDocs(collection(db, 'vaults', vault.id, 'messages'));
      msgsSnapshot.forEach(async (d) => {
        try {
          await deleteDoc(d.ref);
        } catch {}
      });
    } catch (err) {
      console.warn('Firestore burn cleanup failed, local fallback:', err);
    }

    const updatedList = vaults.filter((v) => v.id !== vault.id);
    saveLocalVaults(updatedList);
    try {
      localStorage.removeItem(`vault_chat_${vault.id}`);
    } catch {}

    setActiveChatVault(null);
    setChatMessages([]);

    if (listenerId && listenerId !== user.id) {
      setRatingModalData({
        isOpen: true,
        vaultId: vault.id,
        listenerId,
        listenerGhostedId,
      });
    }
  };

  const handleSubmitRating = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmittingRating(true);
    const submission: VaultRatingSubmission = {
      vaultId: ratingModalData.vaultId,
      raterId: user.id,
      listenerId: ratingModalData.listenerId,
      isSupportive: selectedRating === 'supportive',
      ratingType: selectedRating,
      feedbackNote: ratingFeedback.trim() || undefined,
      createdAt: new Date().toISOString(),
    };

    try {
      await addDoc(collection(db, 'vault_ratings'), submission);
      const delta = selectedRating === 'supportive' ? 5 : selectedRating === 'neutral' ? 2 : -10;
      const listenerDocRef = doc(db, 'users', ratingModalData.listenerId);
      const listenerSnap = await getDoc(listenerDocRef);
      if (listenerSnap.exists()) {
        const curScore = listenerSnap.data()?.trustScore ?? 95;
        const newScore = Math.max(10, Math.min(100, curScore + delta));
        await updateDoc(listenerDocRef, { trustScore: newScore });
      }
    } catch (err) {
      console.warn('Firestore rating save failed:', err);
    }

    setIsSubmittingRating(false);
    setRatingModalData({ isOpen: false, vaultId: '', listenerId: '', listenerGhostedId: '' });
    setRatingFeedback('');
    setRatingSuccessToast(true);
    setTimeout(() => setRatingSuccessToast(false), 4000);
  };

  const formatTimeMinutesSeconds = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const filteredVaults = vaults.filter((v) => {
    if (selectedCategory !== 'ALL' && v.category !== selectedCategory) return false;
    if (filterView === 'my_vaults') {
      return v.authorId === user.id;
    }
    if (filterView === 'my_keys') {
      return (v.keyRequests || []).some((r) => r.requesterId === user.id);
    }
    if (filterView === 'active_chats') {
      return (
        v.status === 'unlocked' &&
        (v.authorId === user.id || v.currentListenerId === user.id)
      );
    }
    return true;
  });

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-300 pb-12">
      {/* AMBIENT CALM HEADER */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-[#130d36] via-[#0d0926] to-[#08051a] border border-purple-500/30 p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-60 h-60 bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -mb-8 -ml-8 w-60 h-60 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2.5 max-w-xl">
            <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-emerald-500/20 to-teal-500/20 border border-emerald-400/40 px-3.5 py-1.5 rounded-full text-xs font-bold text-emerald-300">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Ghost Vault • Locked Support Space</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center space-x-2.5">
              <span>Vault 🗝️</span>
              <span className="text-xs sm:text-sm font-semibold text-purple-300/80 px-2.5 py-1 rounded-xl bg-white/5 border border-white/10">
                15-Min Safe Haven
              </span>
            </h1>
            <p className="text-sm sm:text-base font-semibold text-emerald-300/90 italic tracking-wide">
              "This vault is safe. No judgement. No trace."
            </p>
            <p className="text-xs text-purple-200/80 leading-relaxed">
              Pour out raw heartbreak, anxiety, family friction, or secrets into an encrypted vault.
              Peers request a key to listen. Approved conversations auto-incinerate after 15 minutes.
            </p>
            <div className="flex flex-wrap items-center gap-2 pt-1 text-[11px] text-purple-300 font-medium">
              <span className="flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-black/40 border border-white/10">
                <Flame className="w-3.5 h-3.5 text-amber-400" />
                <span>Burn After Read: Active</span>
              </span>
              <span className="flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-black/40 border border-white/10">
                <EyeOff className="w-3.5 h-3.5 text-indigo-400" />
                <span>Zero Screenshots</span>
              </span>
              <span className="flex items-center space-x-1.5 px-2.5 py-1 rounded-lg bg-black/40 border border-white/10">
                <Timer className="w-3.5 h-3.5 text-emerald-400" />
                <span>15-Min Ephemeral Chat</span>
              </span>
            </div>
          </div>

          <div className="w-full md:w-auto flex flex-col items-center sm:items-end space-y-3">
            <button
              type="button"
              onClick={() => setIsCreateModalOpen(true)}
              className="w-full sm:w-auto py-3.5 px-6 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-emerald-600 hover:from-purple-500 hover:to-emerald-500 text-white font-bold text-xs shadow-xl shadow-purple-600/30 transition flex items-center justify-center space-x-2 active:scale-95 cursor-pointer"
            >
              <KeyRound className="w-4 h-4 text-amber-300" />
              <span>Create Vault</span>
              <Lock className="w-3.5 h-3.5 text-white/80" />
            </button>
            <div className="flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-black/40 border border-white/10 text-xs text-purple-200">
              <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              <span className="text-[11px] text-purple-300">My Trust Score:</span>
              <span className="font-mono font-bold text-amber-300">{userTrustScore}%</span>
            </div>
          </div>
        </div>
      </div>

      {ratingSuccessToast && (
        <div className="p-3.5 rounded-2xl bg-emerald-950/80 border border-emerald-400/50 text-emerald-200 text-xs flex items-center space-x-2.5 animate-in fade-in duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>Thank you. Your rating builds community trust and keeps the Ghost Vault safe.</span>
        </div>
      )}

      {/* FILTER PILLS & CATEGORIES */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          {[
            { id: 'all', label: 'All Safe Vaults' },
            {
              id: 'my_vaults',
              label: `My Vaults (${vaults.filter((v) => v.authorId === user.id).length})`,
            },
            {
              id: 'my_keys',
              label: `Requested Keys (${vaults.filter((v) => (v.keyRequests || []).some((r) => r.requesterId === user.id)).length})`,
            },
            {
              id: 'active_chats',
              label: `Active 15m Chats (${vaults.filter((v) => v.status === 'unlocked' && (v.authorId === user.id || v.currentListenerId === user.id)).length})`,
            },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setFilterView(t.id as any)}
              className={`py-2 px-3.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
                filterView === t.id
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/25'
                  : 'bg-white/5 hover:bg-white/10 text-purple-300/80'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-white/5">
          <button
            type="button"
            onClick={() => setSelectedCategory('ALL')}
            className={`py-1.5 px-3 rounded-lg text-xs font-medium transition cursor-pointer ${
              selectedCategory === 'ALL'
                ? 'bg-white/15 text-white font-bold'
                : 'text-purple-300/70 hover:text-white'
            }`}
          >
            All Categories
          </button>
          {CATEGORIES.map((c) => {
            const Icon = c.icon;
            const isSel = selectedCategory === c.id;
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => setSelectedCategory(c.id)}
                className={`flex items-center space-x-1.5 py-1.5 px-3 rounded-lg text-xs font-medium transition cursor-pointer ${
                  isSel
                    ? 'bg-white/20 text-white font-bold border border-white/20'
                    : 'text-purple-300/70 hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{c.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* VAULTS LIST */}
      {isLoading ? (
        <div className="py-16 text-center space-y-3">
          <div className="w-8 h-8 border-2 border-purple-400 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs text-purple-300/70">Connecting to encrypted Ghost Vaults...</p>
        </div>
      ) : filteredVaults.length === 0 ? (
        <div className="p-10 rounded-3xl bg-black/30 border border-white/10 text-center space-y-4">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-purple-500/10 border border-purple-400/20 flex items-center justify-center text-purple-300">
            <Lock className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">No Vaults Found</h3>
            <p className="text-xs text-purple-300/70 max-w-sm mx-auto mt-1">
              Be the first to speak into the silence. Create a locked vault to receive safe, anonymous support.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setIsCreateModalOpen(true)}
            className="py-2.5 px-5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs transition"
          >
            + Create a Safe Vault
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredVaults.map((vault) => {
            const catInfo = CATEGORIES.find((c) => c.id === vault.category) || CATEGORIES[0];
            const CatIcon = catInfo.icon;
            const isOwner = vault.authorId === user.id;
            const hasRequested = (vault.keyRequests || []).some((r) => r.requesterId === user.id);
            const myRequest = (vault.keyRequests || []).find((r) => r.requesterId === user.id);
            const isApproved =
              vault.status === 'unlocked' &&
              (isOwner || vault.currentListenerId === user.id || myRequest?.status === 'approved');
            const pendingRequestsCount = (vault.keyRequests || []).filter((r) => r.status === 'pending').length;

            return (
              <div
                key={vault.id}
                className="relative rounded-3xl bg-gradient-to-b from-[#161036]/90 to-[#0e0a24]/90 border border-white/10 p-5 sm:p-6 space-y-4 shadow-xl hover:border-purple-500/40 transition group flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span
                      className={`inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-[11px] font-bold border ${catInfo.color}`}
                    >
                      <CatIcon className="w-3.5 h-3.5" />
                      <span>{vault.category}</span>
                    </span>
                    <span className="inline-flex items-center space-x-1 text-[10px] text-purple-300/80 bg-black/40 px-2.5 py-0.5 rounded-lg border border-white/10 font-mono">
                      {vault.lockType === 'time_lock' && (
                        <>
                          <Clock className="w-3 h-3 text-amber-400" />
                          <span>Time Lock ({vault.timeLockDuration || '24hr'})</span>
                        </>
                      )}
                      {vault.lockType === 'trust_lock' && (
                        <>
                          <ShieldCheck className="w-3 h-3 text-emerald-400" />
                          <span>Trust Lock (80%+)</span>
                        </>
                      )}
                      {vault.lockType === 'one_soul' && (
                        <>
                          <UserCheck className="w-3 h-3 text-indigo-400" />
                          <span>One Soul Only</span>
                        </>
                      )}
                    </span>
                  </div>

                  <div className="relative">
                    <div className="p-4 rounded-2xl bg-black/40 border border-white/5 space-y-2">
                      <p className="text-xs text-white/90 leading-relaxed font-normal whitespace-pre-wrap">
                        {isOwner || isApproved
                          ? vault.ventText
                          : `${vault.ventText.slice(0, 160)}...`}
                      </p>
                      {!isOwner && !isApproved && (
                        <div className="pt-2 border-t border-white/5 flex items-center space-x-1.5 text-[10px] text-amber-300 font-medium">
                          <Lock className="w-3 h-3" />
                          <span>Locked by Author • Request Key to hold space & read full vent</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-white/5 space-y-3">
                  <div className="flex items-center justify-between text-[11px] text-purple-300/70">
                    <span className="flex items-center space-x-1 font-mono">
                      <Radio className="w-3 h-3 text-emerald-400" />
                      <span>{vault.authorGhostedId}</span>
                    </span>
                    <span>
                      {new Date(vault.createdAt).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>

                  {isApproved ? (
                    <button
                      type="button"
                      onClick={() => setActiveChatVault(vault)}
                      className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-xs shadow-lg shadow-emerald-500/20 transition flex items-center justify-center space-x-2 cursor-pointer animate-pulse"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Open 15-Min Safe Chat (Unlocked)</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  ) : isOwner ? (
                    <div className="flex items-center space-x-2">
                      <button
                        type="button"
                        onClick={() => setReviewRequestsVault(vault)}
                        className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center space-x-1.5 cursor-pointer ${
                          pendingRequestsCount > 0
                            ? 'bg-amber-500 hover:bg-amber-400 text-gray-950 font-black shadow-lg shadow-amber-500/25'
                            : 'bg-white/10 hover:bg-white/15 text-purple-200'
                        }`}
                      >
                        <KeyRound className="w-3.5 h-3.5" />
                        <span>
                          {pendingRequestsCount > 0
                            ? `${pendingRequestsCount} Key Requests!`
                            : 'Review Keys (0)'}
                        </span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleBurnAndExitChat(vault, false)}
                        className="py-2.5 px-3 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 text-xs font-semibold transition"
                        title="Burn Vault Now"
                      >
                        <Flame className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : hasRequested ? (
                    <div className="py-2.5 px-4 rounded-xl bg-purple-500/15 border border-purple-500/30 text-center text-xs text-purple-300 flex items-center justify-center space-x-2">
                      <Clock className="w-3.5 h-3.5 text-amber-400" />
                      <span>Key Requested • Awaiting Owner Approval</span>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setRequestKeyModalVault(vault)}
                      className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs shadow transition flex items-center justify-center space-x-2 cursor-pointer active:scale-98"
                    >
                      <KeyRound className="w-3.5 h-3.5 text-amber-300" />
                      <span>Request Key to Hold Space</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* MODAL 1: CREATE VAULT */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-lg my-8 bg-gradient-to-b from-[#18123b] via-[#1b1542] to-[#120d2e] border border-purple-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl text-white space-y-6">
            <button
              type="button"
              onClick={() => setIsCreateModalOpen(false)}
              className="absolute top-5 right-5 p-1.5 rounded-full hover:bg-white/10 text-white/70 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="space-y-1">
              <div className="inline-flex items-center space-x-1.5 text-[10px] font-bold text-emerald-300 uppercase tracking-wider bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-400/30">
                <Lock className="w-3 h-3 text-emerald-400" />
                <span>Locked Ephemeral Support Space</span>
              </div>
              <h2 className="text-xl font-bold text-white">Create a Ghost Vault</h2>
              <p className="text-xs text-emerald-300/90 italic">
                "This vault is safe. No judgement. No trace."
              </p>
            </div>

            <form onSubmit={handleCreateVault} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-purple-200 mb-2">
                  Select Category <span className="text-rose-400">*</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {CATEGORIES.map((c) => {
                    const Icon = c.icon;
                    const isSel = newCategory === c.id;
                    return (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => setNewCategory(c.id)}
                        className={`p-3 rounded-2xl border text-left transition flex items-start space-x-2.5 cursor-pointer ${
                          isSel
                            ? 'bg-purple-600/40 border-purple-400 shadow-md text-white'
                            : 'bg-black/40 border-white/10 text-purple-200/70 hover:border-white/20'
                        }`}
                      >
                        <Icon className={`w-4 h-4 mt-0.5 ${isSel ? 'text-amber-400' : 'text-purple-400'}`} />
                        <div>
                          <div className="text-xs font-bold text-white">{c.label}</div>
                          <div className="text-[10px] text-purple-300/70 leading-tight mt-0.5 line-clamp-1">
                            {c.desc}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-purple-200">
                    Write Your Vent <span className="text-rose-400">*</span>
                  </label>
                  <span
                    className={`text-[11px] font-mono font-bold ${
                      newVentText.length >= 480 ? 'text-amber-400' : 'text-purple-300/70'
                    }`}
                  >
                    {newVentText.length}/500 chars
                  </span>
                </div>
                <textarea
                  required
                  rows={5}
                  maxLength={500}
                  value={newVentText}
                  onChange={(e) => setNewVentText(e.target.value.slice(0, 500))}
                  placeholder="Speak into the dark without fear. What has been hurting you that you cannot say anywhere else?..."
                  className="w-full p-4 bg-black/40 border border-white/15 rounded-2xl text-white text-xs placeholder-purple-300/40 focus:outline-none focus:ring-2 focus:ring-purple-400 leading-relaxed resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-purple-200 mb-2">
                  Choose Lock Type <span className="text-rose-400">*</span>
                </label>
                <div className="space-y-2">
                  {[
                    {
                      id: 'time_lock' as VaultLockType,
                      title: 'Time Lock',
                      desc: 'Auto-burns after 1 hour or 24 hours if no listener is approved.',
                      icon: Clock,
                    },
                    {
                      id: 'trust_lock' as VaultLockType,
                      title: 'Trust Lock',
                      desc: 'Only verified supportive ghosts (Trust Score ≥ 80%) can request key.',
                      icon: ShieldCheck,
                    },
                    {
                      id: 'one_soul' as VaultLockType,
                      title: 'One Soul',
                      desc: 'Exactly 1 listener only. Permanently seals to all others upon key approval.',
                      icon: UserCheck,
                    },
                  ].map((lt) => {
                    const Icon = lt.icon;
                    const isSel = newLockType === lt.id;
                    return (
                      <div
                        key={lt.id}
                        onClick={() => setNewLockType(lt.id)}
                        className={`p-3 rounded-2xl border transition cursor-pointer flex items-center justify-between ${
                          isSel
                            ? 'bg-purple-600/30 border-purple-400 text-white'
                            : 'bg-black/30 border-white/10 text-purple-200/70 hover:border-white/20'
                        }`}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={`p-2 rounded-xl ${isSel ? 'bg-purple-500/20 text-amber-300' : 'bg-white/5 text-purple-400'}`}>
                            <Icon className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="text-xs font-bold text-white">{lt.title}</div>
                            <div className="text-[10px] text-purple-300/70">{lt.desc}</div>
                          </div>
                        </div>
                        {lt.id === 'time_lock' && isSel && (
                          <div className="flex items-center space-x-1 bg-black/50 p-1 rounded-xl border border-white/10">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setNewTimeDuration('1hr');
                              }}
                              className={`px-2 py-1 rounded-lg text-[10px] font-bold ${
                                newTimeDuration === '1hr' ? 'bg-amber-400 text-gray-950' : 'text-purple-300'
                              }`}
                            >
                              1 Hr
                            </button>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setNewTimeDuration('24hr');
                              }}
                              className={`px-2 py-1 rounded-lg text-[10px] font-bold ${
                                newTimeDuration === '24hr' ? 'bg-amber-400 text-gray-950' : 'text-purple-300'
                              }`}
                            >
                              24 Hr
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="p-3 bg-black/40 rounded-2xl border border-white/10 text-[11px] text-purple-300/80 space-y-1">
                <div className="flex items-center space-x-1.5 text-emerald-300 font-semibold">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Vault Privacy Flags Active</span>
                </div>
                <p>• isLocked = true • burnAfterRead = true • canScreenshot = false</p>
                <p>• Once approved, a temporary anonymous chat opens for 15 minutes, then auto-deletes.</p>
              </div>

              <button
                type="submit"
                disabled={isSubmittingVault || !newVentText.trim()}
                className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-emerald-600 hover:from-purple-500 hover:to-emerald-500 text-white font-bold text-xs shadow-xl shadow-purple-600/30 transition flex items-center justify-center space-x-2 active:scale-98 disabled:opacity-50 cursor-pointer"
              >
                {isSubmittingVault ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Sealing into Ghost Vault...</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-3.5 h-3.5" />
                    <span>Seal Vault & Request Support</span>
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: REQUEST KEY */}
      {requestKeyModalVault && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-md my-8 bg-gradient-to-b from-[#18123b] to-[#110c2a] border border-amber-400/40 rounded-3xl p-6 sm:p-8 shadow-2xl text-white space-y-5">
            <button
              type="button"
              onClick={() => setRequestKeyModalVault(null)}
              className="absolute top-5 right-5 p-1.5 rounded-full hover:bg-white/10 text-white/70 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="space-y-1">
              <div className="inline-flex items-center space-x-1.5 text-[10px] font-bold text-amber-300 uppercase tracking-wider bg-amber-400/10 px-2.5 py-1 rounded-full border border-amber-400/30">
                <KeyRound className="w-3 h-3 text-amber-400" />
                <span>Request Key to Listen</span>
              </div>
              <h3 className="text-lg font-bold text-white">Offer Support to this Soul</h3>
              <p className="text-xs text-purple-200/80">
                The author will see your Ghosted ID and Trust Score. If approved, a temporary 15-minute chat opens.
              </p>
            </div>

            <div className="p-3 bg-black/40 rounded-2xl border border-white/10 flex items-center justify-between text-xs">
              <div>
                <span className="text-[10px] text-purple-300 block">Your Persona:</span>
                <span className="font-mono font-bold text-white">{user.ghostedId || 'Supportive Ghost'}</span>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-purple-300 block">Trust Score:</span>
                <span className="font-bold text-amber-300">{userTrustScore}% ⭐</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-purple-200 mb-1.5">
                Compassionate Note to the Author (Optional)
              </label>
              <input
                type="text"
                value={keyRequestNote}
                onChange={(e) => setKeyRequestNote(e.target.value)}
                placeholder="I am here to listen with an open, non-judgmental heart."
                className="w-full px-4 py-2.5 bg-black/40 border border-white/15 rounded-xl text-white text-xs placeholder-purple-300/40 focus:outline-none focus:ring-2 focus:ring-amber-400"
              />
            </div>

            <div className="text-[11px] text-emerald-300/90 leading-relaxed bg-emerald-500/10 p-3 rounded-2xl border border-emerald-400/20">
              🛡️ <strong>Sacred Trust Policy:</strong> Ghost Vault sessions are strictly supportive. Harassment or toxic replies result in immediate trust score revocation.
            </div>

            <button
              type="button"
              onClick={handleSendKeyRequest}
              disabled={isRequestingKey}
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-amber-400 via-orange-500 to-amber-500 hover:from-amber-500 hover:to-orange-600 text-gray-950 font-black text-xs shadow-xl shadow-amber-500/20 transition flex items-center justify-center space-x-2 active:scale-98 disabled:opacity-50 cursor-pointer"
            >
              {isRequestingKey ? (
                <span>Submitting Key Request...</span>
              ) : (
                <>
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>Send Key Request to Owner</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* MODAL 3: REVIEW KEY REQUESTS */}
      {reviewRequestsVault && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-lg my-8 bg-gradient-to-b from-[#18123b] to-[#120d2e] border border-purple-500/40 rounded-3xl p-6 sm:p-8 shadow-2xl text-white space-y-5">
            <button
              type="button"
              onClick={() => setReviewRequestsVault(null)}
              className="absolute top-5 right-5 p-1.5 rounded-full hover:bg-white/10 text-white/70 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="space-y-1">
              <div className="inline-flex items-center space-x-1.5 text-[10px] font-bold text-amber-300 uppercase tracking-wider bg-amber-400/10 px-2.5 py-1 rounded-full border border-amber-400/30">
                <KeyRound className="w-3 h-3 text-amber-400" />
                <span>Review Key Requests ({reviewRequestsVault.keyRequests?.length || 0})</span>
              </div>
              <h3 className="text-xl font-bold text-white">Supportive Souls Offering to Listen</h3>
              <p className="text-xs text-purple-200/80">
                Approve a supportive ghost to unlock this vault and open a temporary 15-minute chat.
              </p>
            </div>

            <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
              {(reviewRequestsVault.keyRequests || []).length === 0 ? (
                <div className="p-8 text-center bg-black/30 rounded-2xl border border-white/10 text-xs text-purple-300/70">
                  No souls have requested a key for this vault yet. We will notify you when someone offers support.
                </div>
              ) : (
                (reviewRequestsVault.keyRequests || []).map((req) => (
                  <div
                    key={req.id}
                    className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-300 flex items-center justify-center font-bold text-xs">
                          👻
                        </div>
                        <div>
                          <div className="text-xs font-bold text-white">{req.requesterGhostedId}</div>
                          <div className="text-[10px] text-purple-300/70">
                            Requested {new Date(req.requestedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </div>
                        </div>
                      </div>
                      <span className="text-[11px] font-bold text-amber-300 bg-amber-400/10 px-2.5 py-1 rounded-lg border border-amber-400/20">
                        {req.requesterTrustScore}% Trust Score ⭐
                      </span>
                    </div>
                    {req.note && (
                      <p className="text-xs text-purple-200/90 italic bg-white/5 p-2.5 rounded-xl border border-white/5">
                        "{req.note}"
                      </p>
                    )}
                    <div className="flex items-center space-x-2 pt-1">
                      <button
                        type="button"
                        onClick={() => handleApproveKey(reviewRequestsVault, req)}
                        className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-xs shadow-md transition flex items-center justify-center space-x-1.5 cursor-pointer"
                      >
                        <Unlock className="w-3.5 h-3.5" />
                        <span>Approve Key & Open 15m Chat</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* MODAL 4: TEMPORARY 15-MINUTE SUPPORT CHAT */}
      {activeChatVault && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/90 backdrop-blur-xl select-none">
          <div className="pointer-events-none fixed inset-0 opacity-5 flex flex-col items-center justify-center rotate-[-25deg] select-none text-white text-3xl font-black uppercase tracking-widest z-0">
            <span>GHOST VAULT • ZERO TRACE • AUTO-INCINERATE</span>
            <span>NO SCREENSHOTS ALLOWED • 15 MIN EXPIRE</span>
          </div>
          <div className="relative z-10 w-full max-w-2xl h-[92vh] max-h-[850px] bg-gradient-to-b from-[#160f38] via-[#110d2c] to-[#0a071c] border border-emerald-400/50 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-white">
            <div className="p-4 sm:p-5 bg-black/60 border-b border-white/10 flex items-center justify-between gap-3">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-300">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h3 className="text-sm font-bold text-white">Ghost Vault Support Chat</h3>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-md font-bold">
                      Active
                    </span>
                  </div>
                  <p className="text-[11px] text-emerald-300/80 italic">
                    "This vault is safe. No judgement. No trace."
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <div
                  className={`px-3 py-1.5 rounded-xl border flex items-center space-x-1.5 font-mono font-black text-xs ${
                    timeRemainingSeconds <= 120
                      ? 'bg-rose-500/20 border-rose-500/50 text-rose-300 animate-pulse'
                      : timeRemainingSeconds <= 300
                      ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                      : 'bg-emerald-500/20 border-emerald-400/40 text-emerald-300'
                  }`}
                  title="Auto-delete timer"
                >
                  <Timer className="w-3.5 h-3.5" />
                  <span>{formatTimeMinutesSeconds(timeRemainingSeconds)}</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleBurnAndExitChat(activeChatVault, false)}
                  className="py-1.5 px-3 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/30 text-rose-300 text-xs font-semibold transition flex items-center space-x-1 cursor-pointer"
                  title="End and Burn Chat Now"
                >
                  <Flame className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Burn & Exit</span>
                </button>
              </div>
            </div>

            <div className="p-3 bg-black/40 border-b border-white/5 text-xs text-purple-200/90 flex items-start space-x-2">
              <span className="text-[10px] font-bold text-amber-300 uppercase tracking-wider bg-amber-400/10 px-2 py-0.5 rounded-md border border-amber-400/20 flex-shrink-0">
                {activeChatVault.category} Vent
              </span>
              <p className="text-[11px] text-purple-200/80 italic line-clamp-2">
                "{activeChatVault.ventText}"
              </p>
            </div>

            {isScreenshotWarningVisible && (
              <div className="p-2.5 bg-rose-950/90 border-b border-rose-500 text-rose-200 text-xs flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <ShieldAlert className="w-4 h-4 text-rose-400 flex-shrink-0" />
                  <span>Screenshots and recordings violate Vault sanctity. Zero trace enforced.</span>
                </div>
                <button
                  type="button"
                  onClick={() => setIsScreenshotWarningVisible(false)}
                  className="text-xs text-rose-300 hover:text-white"
                >
                  Dismiss
                </button>
              </div>
            )}

            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3">
              <div className="p-3.5 rounded-2xl bg-black/40 border border-emerald-400/20 text-center text-xs text-emerald-200/80 space-y-1">
                <p className="font-semibold text-emerald-300">Sanctuary Connected</p>
                <p className="text-[11px] text-purple-300/70">
                  You are speaking with {activeChatVault.authorId === user.id ? 'Supportive Ghost' : 'Soul in Vault'}.
                  This session self-destructs when the timer reaches 00:00.
                </p>
              </div>
              {chatMessages.map((msg) => {
                const isMe = msg.senderId === user.id;
                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} space-y-1`}
                  >
                    <div className="flex items-center space-x-1 text-[10px] text-purple-300/60 px-1">
                      <span>{isMe ? 'You' : msg.senderRole === 'venter' ? 'Soul in Vault' : 'Supportive Ghost'}</span>
                      <span>•</span>
                      <span>{new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                    <div
                      className={`max-w-[85%] sm:max-w-[75%] p-3.5 rounded-2xl text-xs leading-relaxed ${
                        isMe
                          ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-tr-sm shadow-md'
                          : 'bg-black/60 border border-white/10 text-white rounded-tl-sm shadow-md'
                      }`}
                    >
                      {msg.text}
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            <div className="px-3 sm:px-4 py-2 bg-black/40 border-t border-white/5 overflow-x-auto flex items-center space-x-1.5 text-xs">
              <span className="text-[10px] text-purple-300/70 flex-shrink-0 font-medium">Quick Prompts:</span>
              {QUICK_COMFORT_RESPONSES.map((txt, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => handleSendMessage(undefined, txt)}
                  className="px-2.5 py-1 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[11px] text-purple-200 flex-shrink-0 transition cursor-pointer"
                >
                  {txt}
                </button>
              ))}
            </div>

            <form onSubmit={handleSendMessage} className="p-3 sm:p-4 bg-black/60 border-t border-white/10 flex items-center space-x-2">
              <input
                type="text"
                value={chatInputText}
                onChange={(e) => setChatInputText(e.target.value)}
                placeholder="Type your message with empathy... (Enter to send)"
                className="flex-1 px-4 py-3 bg-black/50 border border-white/15 rounded-2xl text-white text-xs placeholder-purple-300/40 focus:outline-none focus:ring-2 focus:ring-emerald-400"
              />
              <button
                type="submit"
                disabled={!chatInputText.trim()}
                className="p-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold transition shadow-lg disabled:opacity-40 cursor-pointer"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 5: POST-CHAT RATING */}
      {ratingModalData.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-md my-8 bg-gradient-to-b from-[#18123b] to-[#110c2a] border border-emerald-400/40 rounded-3xl p-6 sm:p-8 shadow-2xl text-white space-y-6 text-center">
            <div className="w-16 h-16 rounded-3xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center mx-auto text-emerald-400 shadow-xl shadow-emerald-950/40">
              <Star className="w-8 h-8 fill-emerald-400" />
            </div>
            <div className="space-y-1">
              <h3 className="text-xl font-bold text-white">Was this ghost supportive?</h3>
              <p className="text-xs text-purple-200/80">
                Your rating directly shapes their community Trust Score and ensures the Ghost Vault remains safe.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-2.5">
              {[
                {
                  id: 'supportive' as const,
                  label: 'Yes, deeply supportive',
                  sub: '+10 Trust',
                  icon: ThumbsUp,
                  color: 'border-emerald-400/50 bg-emerald-500/15 text-emerald-300',
                },
                {
                  id: 'neutral' as const,
                  label: 'Neutral / listened',
                  sub: '+5 Trust',
                  icon: Sparkles,
                  color: 'border-purple-400/50 bg-purple-500/15 text-purple-300',
                },
                {
                  id: 'unsupportive' as const,
                  label: 'No / felt unsafe',
                  sub: '-15 Trust',
                  icon: ThumbsDown,
                  color: 'border-rose-400/50 bg-rose-500/15 text-rose-300',
                },
              ].map((r) => {
                const Icon = r.icon;
                const isSel = selectedRating === r.id;
                return (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => setSelectedRating(r.id)}
                    className={`p-3 rounded-2xl border text-center transition flex flex-col items-center justify-center space-y-1.5 cursor-pointer ${
                      isSel ? `${r.color} ring-2 ring-emerald-400 font-bold` : 'bg-black/40 border-white/10 text-purple-200/60'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="text-[11px] leading-tight">{r.label}</span>
                    <span className="text-[9px] font-mono opacity-80">{r.sub}</span>
                  </button>
                );
              })}
            </div>

            <div className="text-left">
              <label className="block text-xs font-semibold text-purple-200 mb-1">
                Optional Feedback / Thank You Note
              </label>
              <input
                type="text"
                value={ratingFeedback}
                onChange={(e) => setRatingFeedback(e.target.value)}
                placeholder="e.g. Thank you for validating my grief."
                className="w-full px-4 py-2.5 bg-black/40 border border-white/15 rounded-xl text-white text-xs placeholder-purple-300/40 focus:outline-none focus:ring-2 focus:ring-emerald-400"
              />
            </div>

            <button
              type="button"
              onClick={handleSubmitRating}
              disabled={isSubmittingRating}
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-xs shadow-xl shadow-emerald-500/20 transition flex items-center justify-center space-x-2 active:scale-98 disabled:opacity-50 cursor-pointer"
            >
              {isSubmittingRating ? (
                <span>Recording Trust Rating...</span>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Submit Trust Rating</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* SMART AD INTERSTITIAL */}
      <SmartAdInterstitial
        context="vault"
        isOpen={isVaultAdOpen}
        onClose={() => setIsVaultAdOpen(false)}
      />
    </div>
  );
};
