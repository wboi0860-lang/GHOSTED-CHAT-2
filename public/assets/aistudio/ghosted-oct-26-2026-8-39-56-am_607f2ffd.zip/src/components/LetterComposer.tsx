import React, { useState, useMemo } from 'react';
import {
  UserProfile,
  MoodType,
  RelationshipType,
  MemoryAttachment,
  SavedLetter,
  SafetyCheckResult,
  DeliveryChannel,
} from '../types';
import {
  Sparkles,
  Send,
  Calendar,
  Clock,
  Image,
  Video,
  X,
  ShieldAlert,
  ShieldCheck,
  Check,
  Copy,
  ExternalLink,
  Eye,
  AlertTriangle,
  Lightbulb,
  UserCheck,
  Phone,
  Linkedin,
  Mail,
  MessageSquare,
  Share2,
  SendHorizontal,
  Smartphone,
  CheckCircle2,
  Globe,
  Search,
} from 'lucide-react';

import { useTheme } from '../context/ThemeContext';

interface LetterComposerProps {
  user: UserProfile;
  dailySendsRemaining: number;
  onLetterCreated: (letter: SavedLetter) => void;
  onPreviewLetter: (letterId: string) => void;
}

export interface CountryItem {
  code: string;
  name: string;
  flag: string;
  dialCode: string;
  sample: string;
  localPrefix: string;
}

export const COUNTRIES: CountryItem[] = [
  { code: 'NG', name: 'Nigeria', flag: '🇳🇬', dialCode: '+234', sample: '801 234 5678', localPrefix: '0' },
  { code: 'US', name: 'United States', flag: '🇺🇸', dialCode: '+1', sample: '(212) 234-5678', localPrefix: '1' },
  { code: 'GB', name: 'United Kingdom', flag: '🇬🇧', dialCode: '+44', sample: '7911 123456', localPrefix: '0' },
  { code: 'CA', name: 'Canada', flag: '🇨🇦', dialCode: '+1', sample: '(416) 234-5678', localPrefix: '1' },
  { code: 'GH', name: 'Ghana', flag: '🇬🇭', dialCode: '+233', sample: '24 123 4567', localPrefix: '0' },
  { code: 'KE', name: 'Kenya', flag: '🇰🇪', dialCode: '+254', sample: '712 345 678', localPrefix: '0' },
  { code: 'ZA', name: 'South Africa', flag: '🇿🇦', dialCode: '+27', sample: '82 123 4567', localPrefix: '0' },
  { code: 'IN', name: 'India', flag: '🇮🇳', dialCode: '+91', sample: '98765 43210', localPrefix: '0' },
  { code: 'AE', name: 'United Arab Emirates', flag: '🇦🇪', dialCode: '+971', sample: '50 123 4567', localPrefix: '0' },
  { code: 'SA', name: 'Saudi Arabia', flag: '🇸🇦', dialCode: '+966', sample: '50 123 4567', localPrefix: '0' },
  { code: 'AU', name: 'Australia', flag: '🇦🇺', dialCode: '+61', sample: '412 345 678', localPrefix: '0' },
  { code: 'DE', name: 'Germany', flag: '🇩🇪', dialCode: '+49', sample: '151 12345678', localPrefix: '0' },
  { code: 'FR', name: 'France', flag: '🇫🇷', dialCode: '+33', sample: '6 12 34 56 78', localPrefix: '0' },
  { code: 'ES', name: 'Spain', flag: '🇪🇸', dialCode: '+34', sample: '612 34 56 78', localPrefix: '0' },
  { code: 'IT', name: 'Italy', flag: '🇮🇹', dialCode: '+39', sample: '312 345 6789', localPrefix: '0' },
  { code: 'BR', name: 'Brazil', flag: '🇧🇷', dialCode: '+55', sample: '11 91234-5678', localPrefix: '0' },
];

const MOODS: { type: MoodType; label: string; icon: string; description: string }[] = [
  { type: 'Apology', label: 'Apology', icon: '🕊️', description: 'Taking accountability, seeking peace without pressure' },
  { type: 'Miss You', label: 'Miss You', icon: '💌', description: 'Warm nostalgia and shared memories' },
  { type: 'Closure', label: 'Closure', icon: '🍂', description: 'Polite resolution, honoring past chapters' },
  { type: 'Thank You', label: 'Thank You', icon: '🌱', description: 'Gratitude for past support or kindness' },
  { type: 'Just Checking In', label: 'Just Checking In', icon: '☕', description: 'Casual, low-pressure hello' },
];

export const LetterComposer: React.FC<LetterComposerProps> = ({
  user,
  dailySendsRemaining,
  onLetterCreated,
  onPreviewLetter,
}) => {
  const { currentTheme, isWhite, isBlack, isGhost } = useTheme();
  // Form state
  const [recipientName, setRecipientName] = useState('');
  const [recipientGhostedId, setRecipientGhostedId] = useState('');
  const [relationship, setRelationship] = useState<RelationshipType>(user.primaryRelationship || 'Friend');
  const [mood, setMood] = useState<MoodType>('Miss You');
  const [letterText, setLetterText] = useState('');
  const [memories, setMemories] = useState<MemoryAttachment[]>([]);

  // Delivery channels state (defaults to direct anonymous link & in-app unknown message)
  const [deliveryChannel, setDeliveryChannel] = useState<DeliveryChannel>('direct_link');
  const [recipientPhone, setRecipientPhone] = useState('');
  const [recipientLinkedIn, setRecipientLinkedIn] = useState('');
  const [recipientEmail, setRecipientEmail] = useState('');

  // Country selector & suggestions for phone
  const [selectedCountry, setSelectedCountry] = useState<CountryItem>(COUNTRIES[0]); // Default Nigeria (+234)
  const [showCountryDropdown, setShowCountryDropdown] = useState(false);
  const [countrySearch, setCountrySearch] = useState('');

  // Calendar scheduler state
  const [isScheduled, setIsScheduled] = useState(false);
  const [scheduledDate, setScheduledDate] = useState(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  });
  const [scheduledTime, setScheduledTime] = useState('18:00');

  // Safety checker state
  const [isCheckingSafety, setIsCheckingSafety] = useState(false);
  const [safetyResult, setSafetyResult] = useState<SafetyCheckResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Success state
  const [createdLetter, setCreatedLetter] = useState<SavedLetter | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedNote, setCopiedNote] = useState<string | null>(null);
  const [simulatedRelayStatus, setSimulatedRelayStatus] = useState<string | null>(null);

  // Filtered countries for search
  const filteredCountries = useMemo(() => {
    if (!countrySearch.trim()) return COUNTRIES;
    const q = countrySearch.toLowerCase();
    return COUNTRIES.filter(
      (c) => c.name.toLowerCase().includes(q) || c.dialCode.includes(q) || c.code.toLowerCase().includes(q)
    );
  }, [countrySearch]);

  // Detect country from typed phone number
  const detectedCountry = useMemo(() => {
    const clean = recipientPhone.trim();
    if (!clean.startsWith('+')) return null;
    return COUNTRIES.find((c) => clean.startsWith(c.dialCode)) || null;
  }, [recipientPhone]);

  // Suggested international number if user typed local number
  const suggestedNumber = useMemo(() => {
    const raw = recipientPhone.trim().replace(/[\s-()]/g, '');
    if (!raw) return null;
    // Already has + prefix
    if (raw.startsWith('+')) return null;
    // If starts with local prefix '0' (e.g. 08012345678 for Nigeria)
    if (raw.startsWith('0')) {
      const stripped = raw.substring(1);
      return `${selectedCountry.dialCode} ${stripped}`;
    }
    // If starts with raw digits without 0 and without +
    if (/^\d{7,12}$/.test(raw)) {
      return `${selectedCountry.dialCode} ${raw}`;
    }
    return null;
  }, [recipientPhone, selectedCountry]);

  // Handle Gallery Uploads (max 3 files, 50MB)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    if (memories.length + files.length > 3) {
      alert('You can attach a maximum of 3 memories (photos/videos) per letter.');
      return;
    }
    const currentTotalSize = memories.reduce((acc, m) => acc + m.size, 0);
    let newTotalSize = currentTotalSize;
    const fileList = Array.from(files);
    for (const file of fileList) {
      newTotalSize += file.size;
      if (newTotalSize > 52428800) {
        alert('Total memory attachment size exceeds 50MB limit.');
        return;
      }
    }
    fileList.forEach((file) => {
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = reader.result as string;
        setMemories((prev) => [
          ...prev,
          {
            id: `mem-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            name: file.name,
            size: file.size,
            type: file.type.startsWith('video') ? 'video' : 'image',
            dataUrl,
          },
        ]);
      };
      reader.readAsDataURL(file);
    });
    e.target.value = '';
  };

  const removeMemory = (id: string) => {
    setMemories((prev) => prev.filter((m) => m.id !== id));
  };

  const applyCountrySelection = (c: CountryItem) => {
    setSelectedCountry(c);
    setShowCountryDropdown(false);
    // If phone is empty, set dial code
    if (!recipientPhone.trim()) {
      setRecipientPhone(`${c.dialCode} `);
      return;
    }
    // If phone currently has another dial code, replace it
    const existingCountry = COUNTRIES.find((item) => recipientPhone.trim().startsWith(item.dialCode));
    if (existingCountry) {
      const remainder = recipientPhone.trim().slice(existingCountry.dialCode.length).trim();
      setRecipientPhone(`${c.dialCode} ${remainder}`);
    } else if (recipientPhone.trim().startsWith('0')) {
      setRecipientPhone(`${c.dialCode} ${recipientPhone.trim().substring(1)}`);
    } else if (!recipientPhone.trim().startsWith('+')) {
      setRecipientPhone(`${c.dialCode} ${recipientPhone.trim()}`);
    }
  };

  const applySuggestedNumber = () => {
    if (suggestedNumber) {
      setRecipientPhone(suggestedNumber);
    }
  };

  // Perform Gemini AI Cross-Checker
  const runSafetyCheckAndSend = async () => {
    setErrorMessage(null);
    setSafetyResult(null);

    if (!recipientName.trim()) {
      setErrorMessage('Please specify who you are sending this anonymous message to.');
      return;
    }

    if (!letterText.trim() || letterText.trim().length < 15) {
      setErrorMessage('Please write a message of at least 15 characters.');
      return;
    }

    if (dailySendsRemaining <= 0) {
      setErrorMessage('Daily send limit reached (3 messages maximum per 24 hours). Reconnecting requires care and boundaries.');
      return;
    }

    setIsCheckingSafety(true);

    try {
      // 1. Call server-side Gemini safety cross-checker
      const safetyResponse = await fetch('/api/safety-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          letter: letterText,
          mood,
          recipientName,
          relationship,
        }),
      });

      const checkData: SafetyCheckResult = await safetyResponse.json();
      setSafetyResult(checkData);

      if (!checkData.safe) {
        setIsCheckingSafety(false);
        return;
      }

      // 2. Safe! Proceed to save letter
      // Sender identity starts anonymous; recipient alone has the right to request identity
      const payload = {
        senderId: user.id,
        senderGhostedId: user.ghostedId,
        senderName: user.name,
        senderCity: user.city,
        senderCountry: user.stateCountry,
        recipientName: recipientName.trim(),
        recipientGhostedId: recipientGhostedId.trim() || undefined,
        relationship,
        mood,
        letter: letterText.trim(),
        memories,
        revealIdentity: false, // Receiver has exclusive right to request identity
        deliveryChannel,
        recipientPhone: recipientPhone.trim() || undefined,
        recipientLinkedIn: recipientLinkedIn.trim() || undefined,
        recipientEmail: recipientEmail.trim() || undefined,
        scheduledAt: isScheduled ? `${scheduledDate}T${scheduledTime}:00` : undefined,
        safetyCheck: checkData,
      };

      const sendResponse = await fetch('/api/letters', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!sendResponse.ok) {
        const errJson = await sendResponse.json();
        throw new Error(errJson.error || 'Failed to dispatch letter.');
      }

      const result = await sendResponse.json();
      setCreatedLetter(result.letter);
      onLetterCreated(result.letter);
    } catch (err: any) {
      setErrorMessage(err.message || 'Error executing safety cross-check.');
    } finally {
      setIsCheckingSafety(false);
    }
  };

  const applyAISuggestion = () => {
    if (safetyResult?.suggestion) {
      setLetterText(safetyResult.suggestion);
      setSafetyResult(null);
    }
  };

  const copyLink = (link: string) => {
    navigator.clipboard.writeText(link);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const copyCustomNote = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedNote(label);
    setTimeout(() => setCopiedNote(null), 2200);
  };

  const triggerSimulatedRelay = (channelName: string) => {
    setSimulatedRelayStatus(`Dispatching via Ghosted encrypted relay to ${channelName}...`);
    setTimeout(() => {
      setSimulatedRelayStatus(`Delivered successfully! Recipient invitation sent.`);
      setTimeout(() => setSimulatedRelayStatus(null), 4000);
    }, 1200);
  };

  const resetForm = () => {
    setRecipientName('');
    setRecipientGhostedId('');
    setRecipientPhone('');
    setRecipientLinkedIn('');
    setRecipientEmail('');
    setLetterText('');
    setMemories([]);
    setSafetyResult(null);
    setCreatedLetter(null);
    setSimulatedRelayStatus(null);
  };

  // Helper texts for delivery
  const getSmsText = () => {
    const link = createdLetter?.uniqueLink || 'http://ghosted.app';
    return `Hi ${recipientName || 'there'}, someone who misses you left a private message for you on Ghosted. View or decline it here: ${link}`;
  };

  const getLinkedInText = () => {
    const link = createdLetter?.uniqueLink || 'http://ghosted.app';
    return `Hi ${recipientName || 'there'}, hope you're doing well! Someone in your past circle left a discreet personal reconnection note for you on Ghosted: ${link}. You can privately review or decline it without any pressure.`;
  };

  const getEmailSubject = () => {
    return `Someone who misses you left a private message for you on Ghosted`;
  };

  const getEmailBody = () => {
    const link = createdLetter?.uniqueLink || 'http://ghosted.app';
    return `Hello ${recipientName || 'there'},\n\nSomeone from your past has reached out to reconnect with you on Ghosted.\n\nThey have left a private, consent-first reconnection letter for you. You can review the message or decline it (which permanently deletes it) using the link below:\n\n${link}\n\nGhosted guarantees emotional safety, zero harassment, and strict privacy.`;
  };

  const cleanPhoneForWhatsApp = (phone: string) => {
    return phone.replace(/[^0-9]/g, '');
  };

  const cleanLinkedInUrl = (input: string) => {
    const trimmed = input.trim();
    if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
      return trimmed;
    }
    if (trimmed.includes('linkedin.com')) {
      return `https://${trimmed}`;
    }
    return `https://www.linkedin.com/in/${trimmed.replace('@', '')}`;
  };

  return (
    <div className="max-w-3xl mx-auto space-y-4">
      {/* Top Quota Notice & Anti-Harassment Banner */}
      <div
        className="flex flex-wrap items-center justify-between gap-2.5 p-3 sm:p-3.5 rounded-2xl border transition-colors duration-300 shadow-sm"
        style={{
          backgroundColor: currentTheme.card,
          borderColor: currentTheme.border,
          color: currentTheme.cardText,
        }}
      >
        <div className="flex items-center space-x-2.5">
          <div
            className="w-7 h-7 rounded-xl flex items-center justify-center font-bold text-xs border"
            style={{
              backgroundColor: isBlack ? '#F3F4F6' : '#141414',
              borderColor: currentTheme.border,
              color: currentTheme.cardText,
            }}
          >
            {dailySendsRemaining > 50 ? '∞' : dailySendsRemaining}
          </div>
          <div>
            <p className="text-xs font-semibold" style={{ color: currentTheme.cardText }}>
              {dailySendsRemaining > 50 ? 'Daily Send Limit: Unlimited (VIP Experience Active)' : `Daily Send Limit: ${dailySendsRemaining}/3 Remaining`}
            </p>
            <p className="text-[10px]" style={{ color: currentTheme.cardSubtext }}>Anti-harassment boundaries enforced</p>
          </div>
        </div>
        <div className="flex items-center space-x-1.5 text-[10px] sm:text-[11px] text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/30">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Gemini AI Moderation Active</span>
        </div>
      </div>

      {/* Main Drafting Card */}
      <div
        className="border rounded-3xl p-4 sm:p-5 shadow-2xl space-y-4 theme-card transition-colors duration-300"
        style={{
          backgroundColor: currentTheme.card,
          borderColor: currentTheme.border,
          color: currentTheme.cardText,
        }}
      >
        <div>
          <h2 className="text-base sm:text-lg font-bold flex items-center space-x-2" style={{ color: currentTheme.cardText }}>
            <span>Send Anonymous messages 🤫</span>
            <span
              className="text-[10px] px-2 py-0.5 rounded-full font-normal border"
              style={{
                backgroundColor: isBlack ? '#F3F4F6' : '#141414',
                color: currentTheme.cardText,
                borderColor: currentTheme.border,
              }}
            >
              Anonymous Whisper
            </span>
          </h2>
          <p className="text-xs mt-0.5" style={{ color: currentTheme.cardSubtext }}>
            Send an anonymous message directly to another Ghosted user. Receiver will not know your identity unless you choose to reveal it.
          </p>
        </div>

        {/* 1. Recipient info */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-medium mb-1" style={{ color: currentTheme.cardText }}>
              Recipient Ghost Name <span className="text-rose-400">*</span>
            </label>
            <input
              type="text"
              value={recipientName}
              onChange={(e) => setRecipientName(e.target.value)}
              placeholder="e.g. Phantom_Vision or Ghost#8902"
              className="w-full px-3.5 py-2.5 border rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#1877F2]"
              style={{
                backgroundColor: isBlack ? '#F3F4F6' : '#141414',
                color: currentTheme.cardText,
                borderColor: currentTheme.border,
              }}
            />
          </div>
          <div>
            <label className="block text-xs font-medium mb-1" style={{ color: currentTheme.cardText }}>
              Their Ghosted ID / Number (Optional)
            </label>
            <input
              type="text"
              value={recipientGhostedId}
              onChange={(e) => setRecipientGhostedId(e.target.value)}
              placeholder="e.g. Ghost#1234 or GH-4829-1029"
              className="w-full px-3.5 py-2.5 border rounded-xl text-xs sm:text-sm font-mono focus:outline-none focus:ring-2 focus:ring-[#1877F2]"
              style={{
                backgroundColor: isBlack ? '#F3F4F6' : '#141414',
                color: currentTheme.cardText,
                borderColor: currentTheme.border,
              }}
            />
          </div>
        </div>

        {/* 2. Mood & Intention */}
        <div>
          <label className="block text-xs font-medium mb-1" style={{ color: currentTheme.cardText }}>
            Select Your Mood & Intention <span className="text-rose-400">*</span>
          </label>
          <div className="flex flex-wrap gap-1.5">
            {MOODS.map((m) => {
              const isSelected = mood === m.type;
              return (
                <button
                  key={m.type}
                  type="button"
                  onClick={() => setMood(m.type)}
                  className={`py-1.5 px-3 rounded-xl text-xs font-medium transition flex items-center space-x-1 border cursor-pointer active:scale-95 ${
                    isSelected ? 'shadow-md scale-[1.02]' : 'opacity-85 hover:opacity-100'
                  }`}
                  style={{
                    backgroundColor: isSelected
                      ? (isGhost ? '#00F5FF' : isBlack ? '#000000' : '#FFFFFF')
                      : (isBlack ? '#F3F4F6' : '#141414'),
                    color: isSelected
                      ? (isGhost ? '#000000' : isBlack ? '#FFFFFF' : '#000000')
                      : currentTheme.cardText,
                    borderColor: currentTheme.border,
                  }}
                >
                  <span>{m.icon}</span>
                  <span>{m.label}</span>
                </button>
              );
            })}
          </div>
          <p className="text-[10px] mt-1 italic" style={{ color: currentTheme.cardSubtext }}>
            "{MOODS.find((m) => m.type === mood)?.description}"
          </p>
        </div>

        {/* 4. Relationship Selector */}
        <div>
          <label className="block text-xs font-medium mb-1" style={{ color: currentTheme.cardText }}>
            Relationship Category
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {(['Friend', 'Family', 'Ex-Partner', 'Other'] as RelationshipType[]).map((rel) => {
              const isSelected = relationship === rel;
              return (
                <button
                  key={rel}
                  type="button"
                  onClick={() => setRelationship(rel)}
                  className={`py-1.5 px-2.5 rounded-xl text-xs font-medium border text-center transition cursor-pointer active:scale-95 ${
                    isSelected ? 'shadow-md font-bold' : 'opacity-85 hover:opacity-100'
                  }`}
                  style={{
                    backgroundColor: isSelected
                      ? (isGhost ? '#00F5FF' : isBlack ? '#000000' : '#FFFFFF')
                      : (isBlack ? '#F3F4F6' : '#141414'),
                    color: isSelected
                      ? (isGhost ? '#000000' : isBlack ? '#FFFFFF' : '#000000')
                      : currentTheme.cardText,
                    borderColor: currentTheme.border,
                  }}
                >
                  {rel}
                </button>
              );
            })}
          </div>
        </div>

        {/* 5. Text Area: Write your letter */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="text-xs font-medium" style={{ color: currentTheme.cardText }}>
              Write your letter <span className="text-rose-400">*</span>
            </label>
            <span className="text-[10px]" style={{ color: currentTheme.cardSubtext }}>{letterText.length} characters</span>
          </div>
          <textarea
            rows={4}
            value={letterText}
            onChange={(e) => setLetterText(e.target.value)}
            placeholder="Write candidly and gently. Share what you appreciate, offer an apology if due, or express that you miss their presence free of demands or blame..."
            className="w-full p-3 border rounded-2xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#1877F2] leading-relaxed resize-y"
            style={{
              backgroundColor: isBlack ? '#FFFFFF' : '#000000',
              color: currentTheme.cardText,
              borderColor: currentTheme.border,
            }}
          />
        </div>

        {/* 6. GALLERY SECTION: Add Memory (Photo / Video) */}
        <div className="space-y-2 pt-1 border-t" style={{ borderColor: currentTheme.border }}>
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xs font-semibold flex items-center space-x-1" style={{ color: currentTheme.cardText }}>
                <Image className="w-3.5 h-3.5 text-[#1877F2]" />
                <span>Memory Gallery</span>
              </h3>
              <p className="text-[10px]" style={{ color: currentTheme.cardSubtext }}>
                Attach shared memories (Max 3 files, 50MB total)
              </p>
            </div>
            <label
              className="cursor-pointer py-1.5 px-3 rounded-xl border text-xs font-medium flex items-center space-x-1 transition active:scale-95"
              style={{
                backgroundColor: isBlack ? '#F3F4F6' : '#141414',
                color: currentTheme.cardText,
                borderColor: currentTheme.border,
              }}
            >
              <Sparkles className="w-3 h-3 text-[#1877F2]" />
              <span>Add Memory</span>
              <input
                type="file"
                multiple
                accept="image/*,video/*"
                onChange={handleFileUpload}
                disabled={memories.length >= 3}
                className="hidden"
              />
            </label>
          </div>

          {/* Preview grid */}
          {memories.length > 0 && (
            <div className="grid grid-cols-3 gap-2">
              {memories.map((mem) => (
                <div
                  key={mem.id}
                  className="relative group rounded-xl overflow-hidden border aspect-video flex items-center justify-center"
                  style={{
                    backgroundColor: isBlack ? '#F3F4F6' : '#141414',
                    borderColor: currentTheme.border,
                  }}
                >
                  {mem.type === 'video' ? (
                    <div className="relative w-full h-full flex items-center justify-center bg-black/40">
                      <video src={mem.dataUrl} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                        <Video className="w-5 h-5 text-white/90" />
                      </div>
                    </div>
                  ) : (
                    <img src={mem.dataUrl} alt={mem.name} className="w-full h-full object-cover" />
                  )}
                  <div className="absolute bottom-1 left-1 right-1 flex items-center justify-between bg-black/70 px-1 py-0.5 rounded text-[9px] text-white backdrop-blur-sm">
                    <span className="truncate max-w-[60px]">{mem.name}</span>
                    <span>{(mem.size / (1024 * 1024)).toFixed(1)}M</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeMemory(mem.id)}
                    className="absolute top-1 right-1 p-0.5 rounded-full bg-rose-600/80 hover:bg-rose-600 text-white shadow transition cursor-pointer"
                  >
                    <X className="w-2.5 h-2.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* 7. CALENDAR SCHEDULER: Scheduled Delivery */}
        <div className="space-y-2 pt-1 border-t" style={{ borderColor: currentTheme.border }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-1.5">
              <Calendar className="w-3.5 h-3.5 text-[#1877F2]" />
              <div>
                <p className="text-xs font-semibold" style={{ color: currentTheme.cardText }}>Calendar Scheduler</p>
                <p className="text-[10px]" style={{ color: currentTheme.cardSubtext }}>
                  Deliver immediately upon opening or hold until specific date
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsScheduled(!isScheduled)}
              className="py-1 px-2.5 rounded-xl text-[11px] font-semibold border transition cursor-pointer"
              style={{
                backgroundColor: isScheduled
                  ? (isGhost ? '#00F5FF' : isBlack ? '#000000' : '#FFFFFF')
                  : (isBlack ? '#F3F4F6' : '#141414'),
                color: isScheduled
                  ? (isGhost ? '#000000' : isBlack ? '#FFFFFF' : '#000000')
                  : currentTheme.cardText,
                borderColor: currentTheme.border,
              }}
            >
              {isScheduled ? 'Scheduled Active' : 'Deliver Immediately'}
            </button>
          </div>

          {isScheduled && (
            <div
              className="grid grid-cols-2 gap-2 p-2.5 rounded-xl border animate-in fade-in duration-200"
              style={{
                backgroundColor: isBlack ? '#F9FAFB' : '#141414',
                borderColor: currentTheme.border,
              }}
            >
              <div>
                <label className="block text-[10px] font-medium mb-0.5" style={{ color: currentTheme.cardText }}>
                  Delivery Date
                </label>
                <input
                  type="date"
                  value={scheduledDate}
                  onChange={(e) => setScheduledDate(e.target.value)}
                  min={new Date().toISOString().split('T')[0]}
                  className="w-full px-2 py-1 border rounded-lg text-xs focus:outline-none"
                  style={{
                    backgroundColor: isBlack ? '#FFFFFF' : '#000000',
                    color: currentTheme.cardText,
                    borderColor: currentTheme.border,
                  }}
                />
              </div>
              <div>
                <label className="block text-[10px] font-medium mb-0.5" style={{ color: currentTheme.cardText }}>
                  Delivery Time
                </label>
                <input
                  type="time"
                  value={scheduledTime}
                  onChange={(e) => setScheduledTime(e.target.value)}
                  className="w-full px-2 py-1 border rounded-lg text-xs focus:outline-none"
                  style={{
                    backgroundColor: isBlack ? '#FFFFFF' : '#000000',
                    color: currentTheme.cardText,
                    borderColor: currentTheme.border,
                  }}
                />
              </div>
            </div>
          )}
        </div>

        {/* 8. RECEIVER-CONTROLLED IDENTITY DISCLOSURE */}
        <div
          className="p-3 sm:p-3.5 rounded-2xl border space-y-1.5"
          style={{
            backgroundColor: isBlack ? '#F9FAFB' : '#141414',
            borderColor: currentTheme.border,
          }}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-1.5">
              <UserCheck className="w-3.5 h-3.5 text-[#1877F2]" />
              <span className="text-xs font-semibold" style={{ color: currentTheme.cardText }}>Receiver-Controlled Identity Rights</span>
            </div>
            <span
              className="text-[9px] px-2 py-0.5 rounded-full border font-medium"
              style={{
                backgroundColor: isBlack ? '#E5E7EB' : '#000000',
                color: currentTheme.cardText,
                borderColor: currentTheme.border,
              }}
            >
              Receiver's Right
            </span>
          </div>
          <p className="text-[11px] leading-relaxed" style={{ color: currentTheme.cardSubtext }}>
            To prevent unwanted pressure, your message is delivered completely anonymously. The receiver alone possesses the exclusive right to request your identity after reading your letter.
          </p>
          <div
            className="p-2 rounded-xl border flex items-center space-x-1.5 text-[10px]"
            style={{
              backgroundColor: isBlack ? '#FFFFFF' : '#000000',
              borderColor: currentTheme.border,
              color: currentTheme.cardSubtext,
            }}
          >
            <ShieldCheck className="w-3 h-3 text-emerald-400 flex-shrink-0" />
            <span>Your name ({user.name}) and Ghosted ID ({user.ghostedId}) remain confidential unless the recipient explicitly asks to view it.</span>
          </div>
        </div>

        {/* AI Cross-Checker Flag Warning Card (If safe: false) */}
        {safetyResult && !safetyResult.safe && (
          <div className="p-3.5 rounded-2xl bg-rose-950/80 border border-rose-500/60 text-white space-y-2 animate-in fade-in duration-200">
            <div className="flex items-start space-x-2 text-rose-300">
              <ShieldAlert className="w-4 h-4 flex-shrink-0 mt-0.5 text-rose-400" />
              <div>
                <h4 className="font-bold text-xs text-rose-200">AI Safety Cross-Checker Blocked Delivery</h4>
                <p className="text-[11px] text-rose-300/90 mt-0.5">{safetyResult.reason}</p>
              </div>
            </div>
            {safetyResult.flags && safetyResult.flags.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {safetyResult.flags.map((flag, idx) => (
                  <span
                    key={idx}
                    className="text-[9px] bg-rose-900/60 text-rose-200 px-2 py-0.5 rounded border border-rose-400/40"
                  >
                    {flag}
                  </span>
                ))}
              </div>
            )}
            {safetyResult.suggestion && (
              <div className="p-2 rounded-xl bg-black/40 border border-amber-400/30 text-amber-100 text-xs space-y-1">
                <div className="flex items-center space-x-1 font-semibold text-amber-300 text-[10px]">
                  <Lightbulb className="w-3 h-3" />
                  <span>Empathetic AI Alternative Suggestion:</span>
                </div>
                <p className="italic text-[10px] leading-relaxed">"{safetyResult.suggestion}"</p>
                <button
                  type="button"
                  onClick={applyAISuggestion}
                  className="py-1 px-2 rounded-lg bg-amber-400/20 hover:bg-amber-400/30 text-amber-200 font-semibold border border-amber-400/40 transition text-[9px] cursor-pointer"
                >
                  Adopt AI Suggestion
                </button>
              </div>
            )}
          </div>
        )}

        {/* Error notification */}
        {errorMessage && (
          <div className="p-2.5 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-200 text-xs flex items-center space-x-2">
            <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Action Button: AI Cross-Check & Send */}
        <div>
          <button
            type="button"
            onClick={runSafetyCheckAndSend}
            disabled={isCheckingSafety || dailySendsRemaining <= 0}
            className="w-full py-3.5 px-4 rounded-2xl font-bold text-xs sm:text-sm shadow-xl transition flex items-center justify-center space-x-2 active:scale-[0.99] disabled:opacity-50 border cursor-pointer"
            style={{
              backgroundColor: currentTheme.btnPrimaryBg,
              color: currentTheme.btnPrimaryText,
              borderColor: currentTheme.border,
            }}
          >
            {isCheckingSafety ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                <span>Checking Safety via AI...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-3.5 h-3.5" />
                <span>Send Anonymous Message 🤫</span>
                <Send className="w-3.5 h-3.5" />
              </>
            )}
          </button>
          <p className="text-[10px] text-center mt-1.5" style={{ color: currentTheme.cardSubtext }}>
            Checked for threats, manipulation, harassment, and explicit content prior to transmission.
          </p>
        </div>
      </div>

      {/* SUCCESS MODAL / DISPATCH CARD */}
      {createdLetter && (
        <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-b from-purple-900/70 to-indigo-950/90 border border-purple-400/50 shadow-2xl space-y-3.5 animate-in fade-in zoom-in-95 duration-200">
          <div className="flex items-center space-x-2.5 text-emerald-400">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 flex items-center justify-center border border-emerald-400/30">
              <Check className="w-4 h-4 text-emerald-300" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-white">Anonymous Message Verified & Secured 🤫</h3>
              <p className="text-[10px] sm:text-[11px] text-purple-200/80">
                End-to-end encrypted and completely anonymous. Sent to: <strong>{createdLetter.recipientName}</strong>
              </p>
            </div>
          </div>

          {createdLetter.scheduledAt && (
            <div className="p-3 rounded-2xl bg-amber-950/40 border border-amber-400/40 text-amber-200 text-xs flex items-center space-x-2">
              <Clock className="w-4 h-4 text-amber-300 flex-shrink-0" />
              <div>
                <span className="font-bold">Scheduled Delivery Active:</span>
                <p className="text-[11px] text-amber-100/90">
                  Will unlock automatically for recipient on {new Date(createdLetter.scheduledAt).toLocaleDateString()} at {new Date(createdLetter.scheduledAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.
                </p>
              </div>
            </div>
          )}

          {/* Raw Access Link Card */}
          <div className="p-3 rounded-2xl bg-black/40 border border-white/10 space-y-1.5">
            <span className="text-[10px] text-purple-300 font-semibold uppercase tracking-wider">
              Secret Recipient Access Link
            </span>
            <div className="flex items-center justify-between bg-black/50 p-2 rounded-xl border border-white/10">
              <span className="font-mono text-[11px] text-purple-200 truncate mr-2">
                {createdLetter.uniqueLink}
              </span>
              <button
                type="button"
                onClick={() => copyLink(createdLetter.uniqueLink)}
                className="px-2.5 py-1 rounded-lg bg-purple-600/50 hover:bg-purple-600 text-xs text-white font-medium flex items-center space-x-1 flex-shrink-0 transition cursor-pointer"
              >
                <Copy className="w-3 h-3" />
                <span>{copiedLink ? 'Copied!' : 'Copy Link'}</span>
              </button>
            </div>
            <p className="text-[10px] text-purple-300/80">
              Share this link directly or let your recipient find it via their Ghosted ID inbox.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={() => onPreviewLetter(createdLetter.id)}
              className="py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold flex items-center justify-center space-x-1.5 border border-white/20 transition cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5 text-purple-300" />
              <span>Preview Recipient Experience</span>
            </button>
            <button
              type="button"
              onClick={resetForm}
              className="py-2.5 px-3 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-200 text-xs font-semibold flex items-center justify-center space-x-1.5 border border-purple-400/30 transition cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send Another Anonymous Message</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
