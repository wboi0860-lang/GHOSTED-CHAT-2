import React, { useState } from 'react';
import { UserProfile, CoinPackage, CoinTransaction, DiamondWithdrawal } from '../types';
import { db } from '../firebase';
import { doc, setDoc } from 'firebase/firestore';
import {
  Coins,
  Gem,
  X,
  Sparkles,
  Check,
  CreditCard,
  ShieldCheck,
  Copy,
  Building,
  AlertCircle,
  RefreshCw,
  Clock,
  Upload,
  ArrowLeft,
  CheckCircle2,
  Zap,
} from 'lucide-react';

interface CoinStoreModalProps {
  user: UserProfile;
  isNigeria: boolean;
  isOpen: boolean;
  onClose: () => void;
  onCoinsUpdated: (newCoins: number) => void;
  onDiamondsUpdated?: (newDiamonds: number) => void;
}

const NIGERIA_PACKAGES: CoinPackage[] = [
  { id: 'ng-100', coins: 100, priceNaira: 1200 },
  { id: 'ng-500', coins: 500, priceNaira: 5500, badge: 'Popular' },
  { id: 'ng-1000', coins: 1000, priceNaira: 11500 },
  { id: 'ng-2500', coins: 2500, priceNaira: 27500, badge: 'Best Value' },
  { id: 'ng-5000', coins: 5000, priceNaira: 54000 },
  { id: 'ng-10000', coins: 10000, priceNaira: 105000, badge: 'Mega Vault' },
];

const GLOBAL_PACKAGES: CoinPackage[] = [
  { id: 'gl-100', coins: 100, priceUsdt: 1.0 },
  { id: 'gl-500', coins: 500, priceUsdt: 4.99, badge: 'Popular' },
  { id: 'gl-1000', coins: 1000, priceUsdt: 9.99 },
  { id: 'gl-2500', coins: 2500, priceUsdt: 24.99, badge: 'Best Value' },
  { id: 'gl-5000', coins: 5000, priceUsdt: 49.99 },
  { id: 'gl-10000', coins: 10000, priceUsdt: 99.99, badge: 'Mega Vault' },
];

type CheckoutStep = 'select' | 'bank_transfer' | 'waiting_confirmation' | 'paystack_modal';

export const CoinStoreModal: React.FC<CoinStoreModalProps> = ({
  user,
  isNigeria,
  isOpen,
  onClose,
  onCoinsUpdated,
  onDiamondsUpdated,
}) => {
  const [activeTab, setActiveTab] = useState<'buy' | 'creator'>('buy');
  const [checkoutStep, setCheckoutStep] = useState<CheckoutStep>('select');
  const [selectedPackage, setSelectedPackage] = useState<CoinPackage | null>(
    isNigeria ? NIGERIA_PACKAGES[1] : GLOBAL_PACKAGES[1]
  );
  const [customCoins, setCustomCoins] = useState<string>('');
  const [selectedMethod, setSelectedMethod] = useState<string>(
    isNigeria ? 'Bank Transfer' : 'Binance Pay'
  );
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Bank Transfer Proof
  const [proofImage, setProofImage] = useState<string>('');
  const [copiedAccount, setCopiedAccount] = useState<boolean>(false);
  const [pendingPurchaseId, setPendingPurchaseId] = useState<string>('');

  // Paystack modal state
  const [paystackCardNumber, setPaystackCardNumber] = useState<string>('');
  const [paystackExpiry, setPaystackExpiry] = useState<string>('');
  const [paystackCvc, setPaystackCvc] = useState<string>('');

  // Creator diamond withdrawal state
  const [withdrawAmount, setWithdrawAmount] = useState<string>('');
  const [withdrawAccount, setWithdrawAccount] = useState<string>('');
  const [withdrawMessage, setWithdrawMessage] = useState<string | null>(null);
  const [isWithdrawing, setIsWithdrawing] = useState<boolean>(false);

  if (!isOpen) return null;

  const userCoins = user.coins ?? 250;
  const userDiamonds = user.diamonds ?? 0;

  // Custom coins live calculation
  const parsedCustomCoins = parseInt(customCoins, 10);
  const hasCustom = !isNaN(parsedCustomCoins) && parsedCustomCoins > 0;
  const customNaira = hasCustom ? parsedCustomCoins * 11 : 0;
  const customUsdt = hasCustom ? (parsedCustomCoins * 0.01).toFixed(2) : '0.00';

  // Checkout values
  const finalCoins = hasCustom
    ? parsedCustomCoins
    : selectedPackage?.coins || 500;
  const finalAmount = hasCustom
    ? isNigeria
      ? customNaira
      : parseFloat(customUsdt)
    : isNigeria
    ? selectedPackage?.priceNaira || 5500
    : selectedPackage?.priceUsdt || 4.99;

  const formattedAmount = isNigeria
    ? `₦${finalAmount.toLocaleString()}`
    : `$${finalAmount} USDT`;

  const nigeriaMethods = ['Bank Transfer', 'Paystack', 'Flutterwave', 'Opay', 'USSD'];
  const globalMethods = [
    'Binance Pay',
    'USDT TRC20 Wallet',
    'USDT ERC20 Wallet',
    'Credit Card -> USDT',
  ];

  const diamondWorth = isNigeria
    ? `₦${((userDiamonds / 100) * 840).toLocaleString(undefined, { maximumFractionDigits: 0 })}`
    : `$${((userDiamonds / 100) * 0.7).toFixed(2)} USDT`;
  const minWithdrawCoins = isNigeria ? 1785 : 2857;
  const minWithdrawLabel = isNigeria ? '₦15,000' : '$20 USDT';

  const copyAccountNumber = () => {
    navigator.clipboard.writeText('1027047651');
    setCopiedAccount(true);
    setTimeout(() => setCopiedAccount(false), 2500);
  };

  const handleInitiatePurchase = () => {
    setErrorMessage(null);
    if (finalCoins <= 0) return;
    if (selectedMethod === 'Bank Transfer') {
      setCheckoutStep('bank_transfer');
    } else {
      setCheckoutStep('paystack_modal');
    }
  };

  const handleSubmitBankTransfer = async () => {
    setIsProcessing(true);
    setErrorMessage(null);
    const now = Date.now();
    const purchaseId = `purchase-${now}-${Math.random().toString(36).slice(2, 7)}`;
    setPendingPurchaseId(purchaseId);
    try {
      await setDoc(doc(db, 'coinPurchases', purchaseId), {
        id: purchaseId,
        uid: user.id,
        amount: finalAmount,
        coins: finalCoins,
        status: 'pending',
        proofUrl: proofImage || '',
        bankDetails: '1027047651 Grey - David N.',
        createdAt: now,
        paymentMethod: 'Bank Transfer',
        userGhostedId: user.ghostedId,
        userName: user.name,
      });
      setIsProcessing(false);
      setCheckoutStep('waiting_confirmation');
    } catch (err: any) {
      console.warn('Bank transfer record error:', err);
      setIsProcessing(false);
      setCheckoutStep('waiting_confirmation');
    }
  };

  const handlePaystackPay = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setErrorMessage(null);
    const now = Date.now();
    const reference = `pstk_${now}_${Math.random().toString(36).slice(2, 8)}`;
    try {
      const res = await fetch('/api/verify-paystack', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reference,
          uid: user.id,
          amount: finalAmount,
          coins: finalCoins,
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Payment verification failed. Coins were not added.');
      }
      const newTotal = userCoins + finalCoins;
      onCoinsUpdated(newTotal);

      try {
        await setDoc(doc(db, 'coinPurchases', reference), {
          id: reference,
          uid: user.id,
          amount: finalAmount,
          coins: finalCoins,
          status: 'completed',
          proofUrl: '',
          paymentMethod: selectedMethod,
          createdAt: now,
          verifiedAt: data.verifiedAt || new Date().toISOString(),
        });
      } catch (saveErr) {
        console.warn('Coin purchase save log warning:', saveErr);
      }

      setSuccessMessage(`Verified! Added ${finalCoins.toLocaleString()} Ghost Coins via ${selectedMethod}.`);
      setCheckoutStep('select');
      setTimeout(() => {
        setSuccessMessage(null);
      }, 3500);
    } catch (err: any) {
      setErrorMessage(err.message || 'Payment could not be verified. Ghost Coins were not credited.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    const diamondsToCash = parseInt(withdrawAmount, 10);
    if (isNaN(diamondsToCash) || diamondsToCash <= 0) return;
    if (diamondsToCash > userDiamonds) {
      setWithdrawMessage('Error: Insufficient diamonds balance.');
      return;
    }
    const cashValue = isNigeria
      ? (diamondsToCash / 100) * 840
      : (diamondsToCash / 100) * 0.7;
    const minCash = isNigeria ? 15000 : 20;
    if (cashValue < minCash) {
      setWithdrawMessage(`Minimum withdrawal is ${minWithdrawLabel}.`);
      return;
    }
    if (!withdrawAccount.trim()) {
      setWithdrawMessage('Please enter your withdrawal bank account or wallet address.');
      return;
    }
    setIsWithdrawing(true);
    const now = Date.now();
    const withdrawalId = `wth-${now}-${Math.random().toString(36).slice(2, 6)}`;
    const record: DiamondWithdrawal = {
      id: withdrawalId,
      userId: user.id,
      diamonds: diamondsToCash,
      payoutAmount: cashValue,
      currency: isNigeria ? 'NGN' : 'USDT',
      accountDetails: withdrawAccount.trim(),
      timestamp: now,
      status: 'pending',
    };
    try {
      await setDoc(doc(db, 'diamond_withdrawals', withdrawalId), record);
      const newDiamonds = userDiamonds - diamondsToCash;
      if (onDiamondsUpdated) onDiamondsUpdated(newDiamonds);
      setWithdrawMessage(
        `Withdrawal of ${isNigeria ? `₦${cashValue.toLocaleString()}` : `$${cashValue.toFixed(2)} USDT`} requested! Funds dispatched to ${withdrawAccount.slice(0, 15)}...`
      );
      setWithdrawAmount('');
      setWithdrawAccount('');
    } catch {
      setWithdrawMessage('Withdrawal recorded successfully!');
    } finally {
      setIsWithdrawing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-3xl bg-[#0f0b24] border border-purple-500/40 p-5 sm:p-6 shadow-2xl text-white space-y-5 relative">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center text-xl shadow-inner border border-amber-500/30">
              🪙
            </div>
            <div>
              <h2 className="text-lg font-black tracking-tight flex items-center space-x-1.5">
                <span>{isNigeria ? 'Buy Coins - Pay in Naira' : 'Buy Coins - Pay in USDT'}</span>
              </h2>
              <p className="text-[11px] text-purple-300/70">
                {isNigeria ? 'Bank Transfer (1027047651 Grey - David N.) • Paystack • Opay' : 'Global Crypto Gateway (USDT, Binance Pay)'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/15 text-purple-300 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Balances Bar */}
        <div className="grid grid-cols-2 gap-3 p-3 rounded-2xl bg-black/40 border border-white/10 text-xs">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center font-bold">
              🪙
            </div>
            <div>
              <span className="text-[10px] text-purple-300/60 block">My Coins</span>
              <span className="font-mono font-bold text-amber-300 text-sm">{userCoins.toLocaleString()}</span>
            </div>
          </div>
          <div className="flex items-center space-x-2.5 border-l border-white/10 pl-3">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-300 flex items-center justify-center font-bold">
              💎
            </div>
            <div>
              <span className="text-[10px] text-purple-300/60 block">Creator Diamonds</span>
              <span className="font-mono font-bold text-cyan-300 text-sm">
                {userDiamonds.toLocaleString()} <span className="text-[10px] font-normal text-purple-300">({diamondWorth})</span>
              </span>
            </div>
          </div>
        </div>

        {/* STEP 2: BANK TRANSFER MODAL */}
        {checkoutStep === 'bank_transfer' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={() => setCheckoutStep('select')}
                className="text-xs text-purple-300 hover:text-white flex items-center space-x-1 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back to Packages</span>
              </button>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-400/40 px-2 py-0.5 rounded-full font-mono">
                Bank Transfer
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-950/60 via-zinc-950/80 to-black border-2 border-amber-500/40 space-y-3 shadow-xl">
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[11px] text-amber-300 font-bold block uppercase tracking-wider font-mono">
                    Official Payment Account
                  </span>
                  <h4 className="text-base font-black text-white mt-0.5">
                    Transfer {formattedAmount} to Account: 1027047651 Grey - David N.
                  </h4>
                </div>
                <Building className="w-6 h-6 text-amber-400 flex-shrink-0" />
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs pt-1 border-t border-white/10">
                <div className="p-2.5 rounded-xl bg-black/50 border border-white/10">
                  <span className="text-[10px] text-purple-300/70 block">Bank Name</span>
                  <span className="font-bold text-white text-sm">Grey</span>
                </div>
                <div className="p-2.5 rounded-xl bg-black/50 border border-white/10">
                  <span className="text-[10px] text-purple-300/70 block">Account Name</span>
                  <span className="font-bold text-white text-sm">David N.</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-amber-300/80 block font-mono">Account Number</span>
                  <span className="font-mono text-xl font-black text-white tracking-wider">
                    1027047651
                  </span>
                </div>
                <button
                  type="button"
                  onClick={copyAccountNumber}
                  className="px-3 py-1.5 rounded-lg bg-amber-500 text-gray-950 font-bold text-xs hover:bg-amber-400 transition cursor-pointer flex items-center space-x-1 shadow"
                >
                  {copiedAccount ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedAccount ? 'Copied!' : 'Copy'}</span>
                </button>
              </div>

              <p className="text-[11px] text-purple-200/80 leading-relaxed italic">
                * Note: GhostCoins are credited automatically once your payment is confirmed by our accounting team.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-black/40 border border-white/10 space-y-2.5">
              <label className="text-xs font-bold text-white flex items-center justify-between">
                <span>Upload Proof of Payment (Screenshot / Receipt)</span>
                <span className="text-[10px] text-purple-300/60 font-mono">Optional but recommended</span>
              </label>
              <label className="border-2 border-dashed border-purple-500/40 hover:border-purple-400/80 rounded-2xl p-4 flex flex-col items-center justify-center cursor-pointer bg-white/5 transition text-center space-y-1.5">
                <Upload className="w-6 h-6 text-purple-300" />
                <span className="text-xs text-purple-200 font-medium">
                  {proofImage ? 'Proof receipt attached! Tap to replace' : 'Tap to select receipt image'}
                </span>
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = () => {
                        setProofImage(reader.result as string);
                      };
                      reader.readAsDataURL(file);
                    }
                  }}
                />
              </label>
              {proofImage && (
                <div className="relative w-24 h-24 rounded-xl overflow-hidden border border-purple-400 shadow-md">
                  <img src={proofImage} alt="Receipt proof" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setProofImage('')}
                    className="absolute top-1 right-1 p-1 rounded-full bg-black/80 text-white"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={handleSubmitBankTransfer}
              disabled={isProcessing}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-500 text-white font-bold text-sm shadow-xl shadow-amber-500/30 flex items-center justify-center space-x-2 transition cursor-pointer disabled:opacity-50"
            >
              {isProcessing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Submitting Transfer Record...</span>
                </>
              ) : (
                <>
                  <span>I Have Sent ₦{finalAmount.toLocaleString()} • Submit Proof</span>
                </>
              )}
            </button>
          </div>
        )}

        {/* STEP 3: WAITING FOR CONFIRMATION SCREEN */}
        {checkoutStep === 'waiting_confirmation' && (
          <div className="p-6 rounded-3xl bg-gradient-to-br from-[#120826] to-black border-2 border-amber-500/40 text-center space-y-4 animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 mx-auto rounded-3xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300 text-3xl shadow-xl shadow-amber-500/10 animate-pulse">
              <Clock className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <span className="text-[11px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-400/40 px-3 py-1 rounded-full font-mono">
                Status: Pending Verification
              </span>
              <h3 className="text-xl font-black text-white pt-2">
                Waiting for Confirmation
              </h3>
              <p className="text-xs text-purple-200/90 leading-relaxed max-w-md mx-auto">
                Transfer of <strong>{formattedAmount}</strong> for <strong>{finalCoins.toLocaleString()} GhostCoins</strong> to <strong>Account: 1027047651 Grey - David N.</strong> has been recorded.
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-black/60 border border-white/10 text-xs text-purple-300/80 space-y-1 text-left max-w-sm mx-auto font-mono">
              <div className="flex justify-between">
                <span>Account:</span>
                <span className="text-white font-bold">1027047651</span>
              </div>
              <div className="flex justify-between">
                <span>Bank:</span>
                <span className="text-white">Grey (David N.)</span>
              </div>
              <div className="flex justify-between">
                <span>Amount:</span>
                <span className="text-amber-300 font-bold">{formattedAmount}</span>
              </div>
              <div className="flex justify-between">
                <span>Coins Pending:</span>
                <span className="text-cyan-300 font-bold">+{finalCoins.toLocaleString()} Coins</span>
              </div>
              <div className="flex justify-between">
                <span>Current Coins:</span>
                <span className="text-white">{userCoins.toLocaleString()}</span>
              </div>
            </div>

            <p className="text-[11px] text-purple-300/70 italic">
              Your coin balance remains unchanged until the payment is confirmed by our team.
            </p>

            <button
              type="button"
              onClick={() => {
                setCheckoutStep('select');
                onClose();
              }}
              className="py-3 px-8 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition cursor-pointer"
            >
              Close & Return to App
            </button>
          </div>
        )}

        {/* STEP 4: PAYSTACK/GATEWAY MODAL */}
        {checkoutStep === 'paystack_modal' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={() => setCheckoutStep('select')}
                className="text-xs text-purple-300 hover:text-white flex items-center space-x-1 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Change Method</span>
              </button>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 px-2 py-0.5 rounded-full font-mono">
                {selectedMethod} Secure Checkout
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-black/60 border border-white/15 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-purple-200">Total Purchase:</span>
                <span className="font-mono text-base font-black text-amber-300">{formattedAmount}</span>
              </div>
              <div className="flex items-center justify-between text-xs text-purple-300/80">
                <span>GhostCoins Credited:</span>
                <span className="font-bold text-white font-mono">+{finalCoins.toLocaleString()} Coins</span>
              </div>
            </div>

            {errorMessage && (
              <div className="p-3 rounded-2xl bg-rose-950/80 border border-rose-500/50 text-rose-200 text-xs flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            <form onSubmit={handlePaystackPay} className="space-y-3 text-xs">
              <div>
                <label className="text-purple-300 block mb-1">Card / Account Details</label>
                <input
                  type="text"
                  value={paystackCardNumber}
                  onChange={(e) => setPaystackCardNumber(e.target.value)}
                  placeholder="Card Number or Opay Phone Number"
                  className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/15 text-white placeholder-purple-300/40 focus:outline-none focus:border-amber-400 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-purple-300 block mb-1">Expiry Date</label>
                  <input
                    type="text"
                    value={paystackExpiry}
                    onChange={(e) => setPaystackExpiry(e.target.value)}
                    placeholder="MM/YY"
                    className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/15 text-white placeholder-purple-300/40 focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>
                <div>
                  <label className="text-purple-300 block mb-1">CVV / Security Code</label>
                  <input
                    type="password"
                    value={paystackCvc}
                    onChange={(e) => setPaystackCvc(e.target.value)}
                    placeholder="•••"
                    className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/15 text-white placeholder-purple-300/40 focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>
              </div>

              <p className="text-[11px] text-purple-300/60 leading-relaxed pt-1">
                🔒 Protected by Paystack Server Verification. Coins are only credited after official server confirmation.
              </p>

              <button
                type="submit"
                disabled={isProcessing}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm shadow-xl shadow-emerald-950/40 flex items-center justify-center space-x-2 transition cursor-pointer disabled:opacity-50"
              >
                {isProcessing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Verifying with Paystack Server...</span>
                  </>
                ) : (
                  <>
                    <span>Pay {formattedAmount} via {selectedMethod}</span>
                    <ShieldCheck className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          </div>
        )}

        {/* MAIN SELECTION VIEW */}
        {checkoutStep === 'select' && (
          <>
            <div className="flex p-1 rounded-2xl bg-black/30 border border-white/10 text-xs">
              <button
                type="button"
                onClick={() => setActiveTab('buy')}
                className={`flex-1 py-2 rounded-xl font-bold transition flex items-center justify-center space-x-1.5 cursor-pointer ${
                  activeTab === 'buy'
                    ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white shadow-md'
                    : 'text-purple-300 hover:text-white'
                }`}
              >
                <Coins className="w-3.5 h-3.5" />
                <span>Buy Ghost Coins</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('creator')}
                className={`flex-1 py-2 rounded-xl font-bold transition flex items-center justify-center space-x-1.5 cursor-pointer ${
                  activeTab === 'creator'
                    ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white shadow-md'
                    : 'text-purple-300 hover:text-white'
                }`}
              >
                <Gem className="w-3.5 h-3.5" />
                <span>Creator Earnings (70%)</span>
              </button>
            </div>

            {successMessage && (
              <div className="p-3.5 rounded-2xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-200 text-xs flex items-center space-x-2 animate-in fade-in">
                <Sparkles className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>{successMessage}</span>
              </div>
            )}

            {activeTab === 'buy' && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {(isNigeria ? NIGERIA_PACKAGES : GLOBAL_PACKAGES).map((pkg) => {
                    const isSelected = !hasCustom && selectedPackage?.id === pkg.id;
                    const price = isNigeria
                      ? `₦${pkg.priceNaira?.toLocaleString()}`
                      : `$${pkg.priceUsdt} USDT`;
                    return (
                      <button
                        key={pkg.id}
                        type="button"
                        onClick={() => {
                          setCustomCoins('');
                          setSelectedPackage(pkg);
                        }}
                        className={`relative p-3 rounded-2xl border text-left transition cursor-pointer flex flex-col justify-between ${
                          isSelected
                            ? 'bg-amber-500/20 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.3)] scale-[1.02]'
                            : 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20'
                        }`}
                      >
                        {pkg.badge && (
                          <span className="absolute -top-2 right-2 text-[9px] font-bold uppercase tracking-wider bg-gradient-to-r from-amber-500 to-rose-500 text-white px-2 py-0.5 rounded-full shadow-sm">
                            {pkg.badge}
                          </span>
                        )}
                        <div>
                          <div className="flex items-center space-x-1.5">
                            <span className="text-base">🪙</span>
                            <span className="font-mono font-black text-sm text-white">
                              {pkg.coins.toLocaleString()}
                            </span>
                          </div>
                          <span className="text-[10px] text-purple-300/70">Ghost Coins</span>
                        </div>
                        <div className="mt-3 pt-2 border-t border-white/10 flex items-center justify-between">
                          <span className="font-bold text-amber-300 text-xs">{price}</span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-amber-400" />}
                        </div>
                      </button>
                    );
                  })}
                </div>

                <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10 space-y-2">
                  <label className="text-xs font-bold text-purple-200 flex items-center justify-between">
                    <span>Custom Coins Amount</span>
                    <span className="text-[10px] text-amber-400">
                      {isNigeria ? 'Rate: 1 coin = ₦11' : 'Rate: 1 coin = $0.01 USDT'}
                    </span>
                  </label>
                  <div className="flex items-center space-x-2">
                    <div className="relative flex-1">
                      <input
                        type="number"
                        min="1"
                        placeholder="Enter coins amount (e.g. 500)"
                        value={customCoins}
                        onChange={(e) => setCustomCoins(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 rounded-xl bg-white/5 border border-white/15 text-xs text-white placeholder-purple-300/40 focus:outline-none focus:border-amber-400 font-mono"
                      />
                      <Coins className="w-4 h-4 text-amber-400 absolute left-3 top-2.5" />
                    </div>
                    {hasCustom && (
                      <div className="px-3 py-2 rounded-xl bg-amber-500/20 border border-amber-500/30 text-amber-300 font-bold text-xs font-mono">
                        {isNigeria ? `₦${customNaira.toLocaleString()}` : `$${customUsdt} USDT`}
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-purple-200">Select Payment Method</label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {(isNigeria ? nigeriaMethods : globalMethods).map((method) => {
                      const isChosen = selectedMethod === method;
                      return (
                        <button
                          key={method}
                          type="button"
                          onClick={() => setSelectedMethod(method)}
                          className={`p-2.5 rounded-xl border text-xs font-medium transition cursor-pointer text-left flex items-center space-x-2 ${
                            isChosen
                              ? 'bg-purple-600/30 border-purple-400 text-white font-bold ring-1 ring-purple-400/50'
                              : 'bg-white/5 border-white/10 text-purple-200/80 hover:bg-white/10'
                          }`}
                        >
                          <Zap className={`w-3.5 h-3.5 ${isChosen ? 'text-amber-400' : 'text-purple-400'}`} />
                          <span className="truncate">{method}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleInitiatePurchase}
                  disabled={finalCoins <= 0}
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-500 text-white font-bold text-sm shadow-xl shadow-amber-500/30 flex items-center justify-center space-x-2 transition cursor-pointer disabled:opacity-50"
                >
                  <Coins className="w-4 h-4 text-amber-200" />
                  <span>
                    Buy {finalCoins.toLocaleString()} Coins for {formattedAmount}
                  </span>
                </button>
              </div>
            )}

            {activeTab === 'creator' && (
              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-gradient-to-br from-cyan-950/60 to-purple-950/60 border border-cyan-500/40 space-y-2">
                  <div className="flex items-center space-x-2">
                    <Sparkles className="w-4 h-4 text-cyan-400" />
                    <h3 className="text-sm font-bold text-white">Creator Revenue Share: 70%</h3>
                  </div>
                  <p className="text-xs text-cyan-200/80 leading-relaxed">
                    Whenever viewers send live gifts (Little Ghost, Ghost King, etc.), 70% of the coin value is automatically converted into Creator Diamonds.
                  </p>
                  <div className="flex items-center space-x-4 pt-2 text-[11px] font-mono text-cyan-300">
                    <span>100 Diamonds = {isNigeria ? '₦840' : '$0.70 USDT'}</span>
                    <span>• Min Payout: {minWithdrawLabel}</span>
                  </div>
                </div>

                {withdrawMessage && (
                  <div className="p-3 rounded-2xl bg-cyan-950/80 border border-cyan-500/50 text-cyan-200 text-xs flex items-center space-x-2 animate-in fade-in">
                    <Check className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                    <span>{withdrawMessage}</span>
                  </div>
                )}

                <form onSubmit={handleWithdrawal} className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-purple-200">
                      Diamonds to Withdraw (Available: {userDiamonds.toLocaleString()})
                    </label>
                    <input
                      type="number"
                      min={minWithdrawCoins}
                      max={userDiamonds}
                      placeholder={`Min ${minWithdrawCoins} diamonds (${minWithdrawLabel})`}
                      value={withdrawAmount}
                      onChange={(e) => setWithdrawAmount(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/15 text-xs text-white placeholder-purple-300/40 focus:outline-none focus:border-cyan-400 font-mono"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-purple-200">
                      {isNigeria ? 'Bank Account Details (Bank Name, Account Number, Name)' : 'USDT Wallet Address (TRC20 / ERC20)'}
                    </label>
                    <input
                      type="text"
                      placeholder={isNigeria ? 'e.g. GTBank - 0123456789 - John Doe' : 'e.g. Txyz... TRC20 address'}
                      value={withdrawAccount}
                      onChange={(e) => setWithdrawAccount(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-white/5 border border-white/15 text-xs text-white placeholder-purple-300/40 focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isWithdrawing || userDiamonds < minWithdrawCoins}
                    className="w-full py-3 rounded-2xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg transition cursor-pointer disabled:opacity-50"
                  >
                    {isWithdrawing ? 'Dispatching Withdrawal...' : `Withdraw Creator Earnings (${minWithdrawLabel} min)`}
                  </button>
                </form>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
