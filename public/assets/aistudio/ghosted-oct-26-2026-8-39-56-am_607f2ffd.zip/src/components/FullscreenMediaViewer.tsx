import React, { useState, useEffect, useRef } from 'react';
import { GhostPost, UserProfile } from '../types';
import { db } from '../firebase';
import { doc, updateDoc, increment } from 'firebase/firestore';
import {
  ArrowLeft,
  Heart,
  MessageCircle,
  Send,
  Download,
  Volume2,
  VolumeX,
  Play,
  Pause,
  MoreVertical,
  Share2,
  Bookmark,
  Sparkles,
  Lock,
  Globe,
  Trash2,
} from 'lucide-react';

interface FullscreenMediaViewerProps {
  post: GhostPost;
  user: UserProfile;
  isOpen: boolean;
  onClose: () => void;
  onLikeToggle?: (post: GhostPost) => void;
  onDownload?: (post: GhostPost) => void;
  onOpenComments?: (post: GhostPost) => void;
  onShare?: (post: GhostPost) => void;
  onDelete?: (post: GhostPost) => void;
}

export const FullscreenMediaViewer: React.FC<FullscreenMediaViewerProps> = ({
  post,
  user,
  isOpen,
  onClose,
  onLikeToggle,
  onDownload,
  onOpenComments,
  onShare,
  onDelete,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [showFloatingHeart, setShowFloatingHeart] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const lastTapRef = useRef<number>(0);

  const [localLiked, setLocalLiked] = useState<boolean>(Boolean(post.likedBy?.includes(user.id)));
  const [localLikesCount, setLocalLikesCount] = useState<number>(post.likedBy?.length ?? (post.likesCount || 0));
  const [localSharesCount, setLocalSharesCount] = useState<number>(post.shares_count ?? post.sharesCount ?? 0);

  useEffect(() => {
    setLocalLiked(Boolean(post.likedBy?.includes(user.id)));
    setLocalLikesCount(post.likedBy?.length ?? (post.likesCount || 0));
    setLocalSharesCount(post.shares_count ?? post.sharesCount ?? 0);
  }, [post.id, post.likedBy, post.likesCount, post.shares_count, post.sharesCount, user.id]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleLike = () => {
    const nextLiked = !localLiked;
    setLocalLiked(nextLiked);
    setLocalLikesCount((prev) => (nextLiked ? prev + 1 : Math.max(0, prev - 1)));
    if (nextLiked) {
      setShowFloatingHeart(true);
      setTimeout(() => setShowFloatingHeart(false), 900);
    }
    if (onLikeToggle) {
      onLikeToggle(post);
    }
  };

  const handleDownload = () => {
    if (onDownload) {
      onDownload(post);
    } else if (post.mediaUrl) {
      const a = document.createElement('a');
      a.href = post.mediaUrl;
      const isVid =
        post.mediaType === 'video' ||
        post.mediaUrl.includes('.mp4') ||
        post.mediaUrl.includes('.webm') ||
        post.mediaUrl.startsWith('data:video');
      a.download = `ghosted_${post.id}.${isVid ? 'mp4' : 'jpg'}`;
      a.target = '_blank';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      showToast('Saved media to gallery 📥');
    }
  };

  const handleShare = async () => {
    const shareUrl = post.mediaUrl || window.location.href;
    const shareText = post.text ? `${post.text}\nShared from GHOSTED` : 'Shared from GHOSTED';

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Ghosted Whisper',
          text: shareText,
          url: shareUrl,
        });
        // User tapped share > app and completed: increment shares count
        setLocalSharesCount((prev) => prev + 1);
        try {
          await updateDoc(doc(db, 'posts', post.id), {
            shares_count: increment(1),
            sharesCount: increment(1),
          });
        } catch (e) {
          console.warn('Share increment warning:', e);
        }
        showToast('Shared via app! 🚀');
        if (onShare) {
          onShare(post);
        }
      } catch (err: any) {
        if (err?.name !== 'AbortError') {
          console.warn('Share error:', err);
        }
      }
    } else {
      navigator.clipboard.writeText(shareUrl);
      showToast('Media post link copied to clipboard 📋');
    }
  };

  // Add to Recently Watched in localStorage
  useEffect(() => {
    if (!isOpen || !post) return;
    try {
      const key = `ghosted_recently_watched_${user.id}`;
      const saved = localStorage.getItem(key);
      const list: GhostPost[] = saved ? JSON.parse(saved) : [];
      const filtered = list.filter((p) => p.id !== post.id);
      const updated = [{ ...post, watchedAt: Date.now() }, ...filtered].slice(0, 50);
      localStorage.setItem(key, JSON.stringify(updated));
    } catch (err) {
      console.warn('Recently watched save error:', err);
    }
  }, [isOpen, post.id, user.id]);

  // Phone Back Button (popstate) integration
  useEffect(() => {
    if (!isOpen) return;
    window.history.pushState({ modal: 'fullscreen_media', postId: post.id }, '');
    const handlePopState = () => {
      onClose();
    };
    window.addEventListener('popstate', handlePopState);
    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, [isOpen, post.id, onClose]);

  const handleBackButtonClick = () => {
    if (window.history.state && window.history.state.modal === 'fullscreen_media') {
      window.history.back();
    } else {
      onClose();
    }
  };

  const togglePlayPause = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const handleDoubleTap = () => {
    const now = Date.now();
    if (now - lastTapRef.current < 400) {
      handleLike();
    }
    lastTapRef.current = now;
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const isVideo =
    post.mediaType === 'video' ||
    Boolean(
      post.mediaUrl &&
        (post.mediaUrl.includes('.mp4') ||
          post.mediaUrl.includes('.webm') ||
          post.mediaUrl.includes('.mov') ||
          post.mediaUrl.startsWith('data:video/'))
    );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[10002] bg-black flex flex-col justify-between overflow-hidden select-none animate-in fade-in duration-200">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-full bg-zinc-900/90 border border-zinc-700/80 text-white text-xs font-semibold shadow-2xl flex items-center space-x-2 animate-in fade-in slide-in-from-top duration-200">
          <Sparkles className="w-4 h-4 text-cyan-400 flex-shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Floating Heart on Double Tap */}
      {showFloatingHeart && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-50 animate-in zoom-in-50 fade-in duration-200">
          <Heart className="w-28 h-28 text-rose-500 fill-rose-500 drop-shadow-[0_0_30px_rgba(244,63,94,0.95)] animate-bounce" />
        </div>
      )}

      {/* TOP HEADER BAR */}
      <div className="absolute top-0 left-0 right-0 z-40 p-4 bg-gradient-to-b from-black/90 via-black/50 to-transparent flex items-center justify-between">
        <button
          type="button"
          data-back-dismissible="true"
          onClick={handleBackButtonClick}
          className="p-2 rounded-full bg-black/60 hover:bg-black/90 text-white border border-white/20 transition active:scale-95 cursor-pointer shadow-lg flex items-center space-x-1.5"
          title="Back to previous page"
        >
          <ArrowLeft className="w-5 h-5 stroke-[2.5]" />
          <span className="text-xs font-bold pr-1 hidden sm:inline">Back</span>
        </button>

        <div className="flex items-center space-x-2.5 px-3 py-1.5 rounded-full bg-black/60 backdrop-blur-md border border-white/10">
          <div className="w-7 h-7 rounded-full bg-purple-600/40 flex items-center justify-center text-xs font-bold text-white overflow-hidden">
            {post.authorAvatar ? (
              <img src={post.authorAvatar} alt="" className="w-full h-full object-cover" />
            ) : (
              '👻'
            )}
          </div>
          <div className="text-left">
            <span className="text-xs font-bold text-white block truncate max-w-[130px]">
              {post.authorName}
            </span>
            <span className="text-[10px] text-purple-300/80 font-mono">
              {post.audience === 'private' ? '🔒 Private' : '🌌 The Void'}
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {(post.authorId === user.id || post.userId === user.id || (user.uid && (post.authorId === user.uid || post.userId === user.uid))) && onDelete && (
            <button
              type="button"
              onClick={() => {
                if (window.confirm('Delete this post permanently from your profile and feed?')) {
                  onDelete(post);
                }
              }}
              className="p-2 rounded-full bg-rose-600/30 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/40 transition active:scale-95 cursor-pointer shadow-lg"
              title="Delete post"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          )}

          <button
            type="button"
            onClick={handleDownload}
            className="p-2 rounded-full bg-black/60 hover:bg-black/90 text-emerald-400 border border-white/20 transition active:scale-95 cursor-pointer shadow-lg"
            title="Download to gallery"
          >
            <Download className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* MAIN CONTENT MEDIA */}
      <div
        className="flex-1 w-full h-full flex items-center justify-center relative overflow-hidden bg-black"
        onClick={handleDoubleTap}
      >
        {isVideo ? (
          <div className="relative w-full h-full flex items-center justify-center">
            <video
              ref={videoRef}
              src={post.mediaUrl}
              autoPlay
              loop
              playsInline
              muted={isMuted}
              onTimeUpdate={() => {
                if (videoRef.current) {
                  setCurrentTime(videoRef.current.currentTime);
                  setDuration(videoRef.current.duration || 0);
                }
              }}
              className="w-full h-full object-contain max-h-screen"
            />
            <div
              onClick={(e) => {
                e.stopPropagation();
                togglePlayPause();
              }}
              className="absolute inset-0 flex items-center justify-center cursor-pointer"
            >
              {!isPlaying && (
                <div className="w-16 h-16 rounded-full bg-black/60 border border-white/20 backdrop-blur-md flex items-center justify-center text-white shadow-2xl animate-in zoom-in-75 duration-150">
                  <Play className="w-8 h-8 fill-white ml-1" />
                </div>
              )}
            </div>
            <div className="absolute bottom-20 right-4 z-30 flex items-center space-x-2">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsMuted(!isMuted);
                }}
                className="p-2.5 rounded-full bg-black/70 backdrop-blur-md text-white border border-white/20 hover:bg-black/90 transition shadow-lg cursor-pointer"
                title={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted ? <VolumeX className="w-5 h-5 text-white" /> : <Volume2 className="w-5 h-5 text-cyan-400" />}
              </button>
            </div>
          </div>
        ) : post.mediaUrl ? (
          <div className="relative w-full h-full flex items-center justify-center p-2">
            <img
              src={post.mediaUrl}
              alt=""
              className="w-full h-full object-contain max-h-screen"
            />
            {post.isEnhanced && (
              <div className="absolute top-20 right-5 px-2.5 py-1 rounded-xl bg-purple-600/90 text-white font-extrabold text-xs tracking-wide shadow-2xl border border-purple-300/40 flex items-center space-x-1.5 backdrop-blur-md z-30 pointer-events-none">
                <span>✨ HD</span>
              </div>
            )}
          </div>
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-8 bg-gradient-to-br from-[#1b0d38] via-[#0f0722] to-black text-center space-y-4">
            <span className="text-5xl block animate-pulse">🌌</span>
            <p className="text-lg sm:text-2xl font-medium text-white max-w-lg leading-relaxed whitespace-pre-wrap select-text">
              "{post.text}"
            </p>
          </div>
        )}
      </div>

      {/* BOTTOM ACTION BAR (OMITTING DESCRIPTION ON MEDIA POSTS AS REQUESTED) */}
      <div className="absolute bottom-0 left-0 right-0 z-40 p-4 bg-gradient-to-t from-black/95 via-black/70 to-transparent space-y-3">
        {isVideo && duration > 0 && (
          <div className="max-w-lg mx-auto px-2 space-y-1">
            <div className="w-full h-1 bg-white/20 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full transition-all duration-100"
                style={{ width: `${(currentTime / duration) * 100}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[10px] text-zinc-400 font-mono">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>
        )}

        <div className="max-w-lg mx-auto flex items-center justify-between px-2 pt-1">
          <div className="flex items-center space-x-5">
            {/* LIKE */}
            <button
              type="button"
              onClick={handleLike}
              className="flex items-center space-x-1.5 text-white hover:text-rose-400 transition cursor-pointer active:scale-90"
              title="Like post"
            >
              <Heart
                className={`w-6 h-6 transition ${
                  localLiked ? 'fill-rose-500 text-rose-500 scale-110' : ''
                }`}
              />
              <span className="text-xs font-bold font-mono">{localLikesCount}</span>
            </button>

            {/* COMMENT */}
            <button
              type="button"
              onClick={() => onOpenComments && onOpenComments(post)}
              className="flex items-center space-x-1.5 text-white hover:text-purple-300 transition cursor-pointer active:scale-90"
              title="Comment on post"
            >
              <MessageCircle className="w-6 h-6" />
              <span className="text-xs font-bold font-mono">{post.commentsCount || 0}</span>
            </button>

            {/* SHARE */}
            <button
              type="button"
              onClick={handleShare}
              className="flex items-center space-x-1.5 text-white hover:text-cyan-300 transition cursor-pointer active:scale-90"
              title="Share post"
            >
              <Send className="w-5 h-5 -rotate-12" />
              <span className="text-xs font-bold font-mono">{localSharesCount}</span>
            </button>
          </div>

          {/* DOWNLOAD */}
          <button
            type="button"
            onClick={handleDownload}
            className="px-4 py-2 rounded-full bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/40 text-emerald-300 hover:text-emerald-200 text-xs font-bold flex items-center space-x-1.5 transition active:scale-95 cursor-pointer shadow-lg"
            title="Download media to gallery"
          >
            <Download className="w-4 h-4" />
            <span>Save to Gallery</span>
          </button>
        </div>
      </div>
    </div>
  );
};
