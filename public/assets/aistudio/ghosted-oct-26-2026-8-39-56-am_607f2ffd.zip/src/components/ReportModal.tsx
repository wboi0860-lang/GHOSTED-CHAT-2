import React, { useState } from 'react';
import { AlertOctagon, ShieldAlert, CheckCircle2, X } from 'lucide-react';

interface ReportModalProps {
  targetGhostedId?: string;
  letterId?: string;
  onClose: () => void;
  onReportSubmitted: () => void;
}

const REPORT_REASONS = [
  'Harassment or Persistent Unwanted Advances',
  'Hostile Tone, Threats, or Intimidation',
  'Emotional Blackmail or Manipulation',
  'Sexual or Inappropriate Content',
  'Impersonation or False Identity',
  'Other Policy Violation',
];

export const ReportModal: React.FC<ReportModalProps> = ({
  targetGhostedId,
  letterId,
  onClose,
  onReportSubmitted,
}) => {
  const [selectedReason, setSelectedReason] = useState(REPORT_REASONS[0]);
  const [details, setDetails] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const res = await fetch('/api/report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetGhostedId: targetGhostedId || 'Unknown',
          reason: `${selectedReason}: ${details}`,
          letterId,
        }),
      });
      if (!res.ok) {
        throw new Error('Failed to record report.');
      }
      setSubmitted(true);
      setTimeout(() => {
        onReportSubmitted();
        onClose();
      }, 1800);
    } catch {
      alert('Error submitting report. The sender has been blocked locally.');
      onReportSubmitted();
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-md bg-gradient-to-b from-[#1b173e] via-[#221e4a] to-[#161332] border border-rose-500/30 rounded-3xl p-6 shadow-2xl text-white">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-white/10 text-white/70 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          <div className="py-8 text-center space-y-3 animate-in fade-in duration-200">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
            <h3 className="text-lg font-bold text-white">User Blocked & Reported</h3>
            <p className="text-xs text-purple-200/80">
              Ghosted ID {targetGhostedId || 'this user'} has been permanently blocked. You will never receive messages or calls from them.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex items-center space-x-3 text-rose-400">
              <div className="w-10 h-10 rounded-2xl bg-rose-500/20 flex items-center justify-center border border-rose-500/40">
                <AlertOctagon className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-base text-white">Report & Block User</h3>
                <p className="text-xs text-rose-300/80">Ghosted Zero-Harassment Safeguard</p>
              </div>
            </div>

            <p className="text-xs text-purple-200/80 leading-relaxed">
              Reporting immediately severs all communication. Their Ghosted ID will be flagged for review and blocked from contacting you forever.
            </p>

            <div>
              <label className="block text-xs font-semibold text-purple-200 mb-1.5">
                Select Reason:
              </label>
              <select
                value={selectedReason}
                onChange={(e) => setSelectedReason(e.target.value)}
                className="w-full p-2.5 bg-black/40 border border-white/20 rounded-xl text-xs text-white focus:outline-none focus:ring-2 focus:ring-rose-400"
              >
                {REPORT_REASONS.map((r) => (
                  <option key={r} value={r} className="bg-gray-900 text-white">
                    {r}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-purple-200 mb-1.5">
                Additional Context (Optional):
              </label>
              <textarea
                rows={3}
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                placeholder="Briefly describe what happened..."
                className="w-full p-3 bg-black/40 border border-white/20 rounded-xl text-xs text-white placeholder-purple-300/40 focus:outline-none focus:ring-2 focus:ring-rose-400 resize-none"
              />
            </div>

            <div className="pt-2 flex items-center space-x-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-medium text-white transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-xs font-bold text-white shadow-lg shadow-rose-900/50 transition disabled:opacity-50"
              >
                {isSubmitting ? 'Submitting...' : 'Block & Report'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
