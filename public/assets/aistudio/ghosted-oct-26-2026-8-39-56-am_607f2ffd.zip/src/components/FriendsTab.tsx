import React, { useState } from 'react';
import { UserProfile } from '../types';
import {
  Users,
  UserPlus,
  Search,
  MessageCircle,
  Phone,
  Share2,
  Copy,
  Check,
  X,
  Sparkles,
  MoreVertical,
  UserX,
} from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface FriendsTabProps {
  user: UserProfile;
  isNigeria?: boolean;
  onNavigateToTab?: (tab: string) => void;
  onOpenChatWithUser?: (friendId: string, friendName: string) => void;
  onStartCallWithUser?: (friendNumber: string, friendName: string) => void;
}

export interface GhostFriend {
  id: string;
  name: string;
  ghostedId: string;
  ghostedNumber?: string;
  avatarUrl?: string;
  status?: string;
  isOnline?: boolean;
  lastActive?: string;
}

const DEFAULT_SUGGESTIONS: GhostFriend[] = [
  {
    id: 'sug-1',
    name: 'Phantom Vision',
    ghostedId: 'GH-8902-7711',
    ghostedNumber: '+00-GH-89027711',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80',
    status: 'Whispering in THE VOID 🌌',
    isOnline: true,
  },
  {
    id: 'sug-2',
    name: 'Midnight Wanderer',
    ghostedId: 'GH-3391-4422',
    ghostedNumber: '+00-GH-33914422',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=250&q=80',
    status: 'Late night wanderer 🕯️',
    isOnline: true,
  },
  {
    id: 'sug-3',
    name: 'Cipher Soul',
    ghostedId: 'GH-1092-9901',
    ghostedNumber: '+00-GH-10929901',
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=250&q=80',
    status: 'Listening to silence 🎧',
    isOnline: false,
    lastActive: '10m ago',
  },
];

export const FriendsTab: React.FC<FriendsTabProps> = ({
  user,
  onNavigateToTab,
  onOpenChatWithUser,
  onStartCallWithUser,
}) => {
  const { currentTheme, isWhite, isBlack, isGhost } = useTheme();

  const [friends, setFriends] = useState<GhostFriend[]>(() => {
    try {
      const saved = localStorage.getItem(`ghosted_friends_${user.id}`);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddFriendModal, setShowAddFriendModal] = useState(false);
  const [addFriendInput, setAddFriendInput] = useState('');
  const [copiedId, setCopiedId] = useState(false);
  const [copiedNumber, setCopiedNumber] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [activeTabSection, setActiveTabSection] = useState<'all' | 'suggestions'>('all');
  const [activeMenuFriendId, setActiveMenuFriendId] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  const handleAddFriend = (friend: GhostFriend) => {
    if (friends.some((f) => f.ghostedId === friend.ghostedId)) {
      showToast(`${friend.name} is already your friend.`);
      return;
    }
    const updated = [friend, ...friends];
    setFriends(updated);
    try {
      localStorage.setItem(`ghosted_friends_${user.id}`, JSON.stringify(updated));
    } catch {}
    showToast(`Added ${friend.name} to Stealth Friends! 👻`);
  };

  const handleRemoveFriend = (friendId: string) => {
    const updated = friends.filter((f) => f.id !== friendId);
    setFriends(updated);
    try {
      localStorage.setItem(`ghosted_friends_${user.id}`, JSON.stringify(updated));
    } catch {}
    setActiveMenuFriendId(null);
    showToast('Friend connection removed.');
  };

  const handleManualAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = addFriendInput.trim();
    if (!clean) return;
    if (clean.toLowerCase() === user.ghostedId.toLowerCase()) {
      showToast('You cannot add yourself as friend.');
      return;
    }

    const match = DEFAULT_SUGGESTIONS.find(
      (s) => s.ghostedId.toLowerCase() === clean.toLowerCase() || s.name.toLowerCase() === clean.toLowerCase()
    );
    if (match) {
      handleAddFriend(match);
      setAddFriendInput('');
      setShowAddFriendModal(false);
      return;
    }

    const newFriend: GhostFriend = {
      id: `usr-${Date.now()}`,
      name: clean.startsWith('GH-') ? `Ghost (${clean})` : clean,
      ghostedId: clean.toUpperCase(),
      ghostedNumber: `+00-${clean.replace(/[^0-9A-Za-z]/g, '')}`,
      status: 'Connected on Ghosted 👻',
      isOnline: true,
    };
    handleAddFriend(newFriend);
    setAddFriendInput('');
    setShowAddFriendModal(false);
  };

  const copyText = (txt: string, isNumber: boolean) => {
    navigator.clipboard.writeText(txt);
    if (isNumber) {
      setCopiedNumber(true);
      setTimeout(() => setCopiedNumber(false), 2000);
    } else {
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    }
  };

  const handleShareMyLink = () => {
    const text = `Connect with me on GHOSTED! Handle: @${user.ghostedId} (${user.name}) • Ghosted Number: ${user.ghostedNumber}`;
    const url = window.location.href;
    if (navigator.share) {
      navigator.share({ title: `${user.name} on Ghosted`, text, url }).catch(() => {});
    } else {
      navigator.clipboard.writeText(`${text}\n${url}`);
      showToast('Profile credentials link copied!');
    }
  };

  const filteredFriends = friends.filter(
    (f) =>
      f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.ghostedId.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="w-full max-w-2xl mx-auto px-4 space-y-4 pb-24 animate-in fade-in duration-200">
      {/* Toast Alert */}
      {toastMessage && (
        <div
          className="fixed top-18 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-full text-xs font-bold shadow-2xl flex items-center space-x-2 animate-in fade-in slide-in-from-top duration-200 border"
          style={{
            backgroundColor: currentTheme.card,
            color: currentTheme.cardText,
            borderColor: currentTheme.border,
          }}
        >
          <Sparkles className="w-4 h-4 text-cyan-400 flex-shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Header - Always visible with currentTheme.textOutside */}
      <div className="flex items-center justify-between pt-2">
        <div className="flex items-center space-x-2.5">
          <div
            className="w-10 h-10 rounded-2xl flex items-center justify-center shadow-md border"
            style={{
              backgroundColor: isGhost ? '#00F5FF' : isBlack ? '#FFFFFF' : '#000000',
              color: isGhost ? '#000000' : isBlack ? '#000000' : '#FFFFFF',
              borderColor: currentTheme.border,
            }}
          >
            <Users className="w-5 h-5 stroke-[2.2]" />
          </div>
          <div>
            {/* Friends Header: "Friends 0" visible in ALL themes */}
            <h2
              className="text-lg font-black tracking-tight flex items-center space-x-2"
              style={{ color: currentTheme.textOutside }}
            >
              <span>Friends</span>
              <span
                className="text-xs px-2.5 py-0.5 rounded-full font-mono font-bold shadow-xs border"
                style={{
                  backgroundColor: currentTheme.card,
                  color: currentTheme.cardText,
                  borderColor: currentTheme.border,
                }}
              >
                {friends.length}
              </span>
            </h2>
            <p className="text-[11px] font-medium" style={{ color: currentTheme.textOutsideSub }}>
              Stealth Connections & Mutual Whispers
            </p>
          </div>
        </div>

        {/* Add Friend Button */}
        <button
          type="button"
          onClick={() => setShowAddFriendModal(true)}
          className="px-3.5 py-2 rounded-xl font-bold text-xs flex items-center space-x-1.5 shadow-md transition active:scale-95 cursor-pointer border"
          style={{
            backgroundColor: currentTheme.btnPrimaryBg,
            color: currentTheme.btnPrimaryText,
            borderColor: currentTheme.border,
          }}
        >
          <UserPlus className="w-4 h-4 stroke-[2.5]" />
          <span>Add Friend</span>
        </button>
      </div>

      {/* Search Bar: bg = card color, text = card text color */}
      <div className="relative w-full">
        <Search
          className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2"
          style={{ color: currentTheme.cardSubtext }}
        />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search friends by name or Ghosted ID..."
          className="w-full pl-10 pr-10 py-2.5 rounded-2xl focus:outline-none text-xs font-medium transition shadow-xs"
          style={{
            backgroundColor: currentTheme.searchBg,
            color: currentTheme.searchText,
            border: `1px solid ${currentTheme.searchBorder}`,
          }}
        />
        {searchQuery && (
          <button
            type="button"
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 cursor-pointer opacity-70 hover:opacity-100"
            style={{ color: currentTheme.searchText }}
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Section Tabs */}
      <div className="flex items-center space-x-2 border-b pb-2" style={{ borderColor: currentTheme.border }}>
        <button
          type="button"
          onClick={() => setActiveTabSection('all')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer border ${
            activeTabSection === 'all'
              ? 'shadow-sm scale-102'
              : 'opacity-70 hover:opacity-100 border-transparent'
          }`}
          style={{
            backgroundColor: activeTabSection === 'all' ? currentTheme.card : 'transparent',
            color: activeTabSection === 'all' ? currentTheme.cardText : currentTheme.textOutside,
            borderColor: activeTabSection === 'all' ? currentTheme.border : 'transparent',
          }}
        >
          All Friends ({friends.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTabSection('suggestions')}
          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer border ${
            activeTabSection === 'suggestions'
              ? 'shadow-sm scale-102'
              : 'opacity-70 hover:opacity-100 border-transparent'
          }`}
          style={{
            backgroundColor: activeTabSection === 'suggestions' ? currentTheme.card : 'transparent',
            color: activeTabSection === 'suggestions' ? currentTheme.cardText : currentTheme.textOutside,
            borderColor: activeTabSection === 'suggestions' ? currentTheme.border : 'transparent',
          }}
        >
          Discover ({DEFAULT_SUGGESTIONS.length})
        </button>
      </div>

      {/* All Friends List */}
      {activeTabSection === 'all' && (
        <div className="space-y-2.5">
          {filteredFriends.length === 0 ? (
            /* "No friends yet" Card: EXACT USER SPECIFICATION */
            <div
              className="py-12 text-center rounded-3xl p-6 space-y-3.5 theme-card shadow-lg"
              style={{
                backgroundColor: currentTheme.card,
                color: currentTheme.cardText,
                borderColor: currentTheme.border,
              }}
            >
              <div
                className="w-14 h-14 rounded-full flex items-center justify-center mx-auto border"
                style={{
                  backgroundColor: isWhite ? '#141414' : isBlack ? '#F3F4F6' : '#15151F',
                  borderColor: currentTheme.border,
                  color: currentTheme.cardSubtext,
                }}
              >
                <Users className="w-6 h-6 stroke-[1.8]" />
              </div>
              <h4 className="text-base font-bold" style={{ color: currentTheme.cardText }}>
                No friends yet
              </h4>
              <p className="text-xs max-w-xs mx-auto leading-relaxed" style={{ color: currentTheme.cardSubtext }}>
                Connect with stealth contacts using their Ghosted ID or discover active members from THE VOID!
              </p>
              <button
                type="button"
                onClick={() => setActiveTabSection('suggestions')}
                className="px-5 py-2.5 rounded-xl font-bold text-xs transition active:scale-95 cursor-pointer shadow-md inline-block border"
                style={{
                  backgroundColor: currentTheme.btnPrimaryBg,
                  color: currentTheme.btnPrimaryText,
                  borderColor: currentTheme.border,
                }}
              >
                Discover Creators & Friends
              </button>
            </div>
          ) : (
            filteredFriends.map((friend) => (
              <div
                key={friend.id}
                className="p-3.5 rounded-2xl transition flex items-center justify-between gap-2 shadow-sm theme-card"
                style={{
                  backgroundColor: currentTheme.card,
                  color: currentTheme.cardText,
                  borderColor: currentTheme.border,
                }}
              >
                <div className="flex items-center space-x-3 min-w-0">
                  <div className="relative flex-shrink-0">
                    <div
                      className="w-11 h-11 rounded-2xl overflow-hidden flex items-center justify-center text-base font-bold shadow-inner border"
                      style={{
                        backgroundColor: isBlack ? '#F3F4F6' : '#141414',
                        borderColor: currentTheme.border,
                        color: currentTheme.cardText,
                      }}
                    >
                      {friend.avatarUrl ? (
                        <img src={friend.avatarUrl} alt={friend.name} className="w-full h-full object-cover" />
                      ) : (
                        '👻'
                      )}
                    </div>
                    {friend.isOnline && (
                      <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 border-2 border-current" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center space-x-1.5">
                      <h4 className="text-xs font-bold truncate" style={{ color: currentTheme.cardText }}>
                        {friend.name}
                      </h4>
                      <span
                        className="text-[10px] font-mono"
                        style={{ color: isGhost ? '#00F5FF' : currentTheme.cardSubtext }}
                      >
                        @{friend.ghostedId}
                      </span>
                    </div>
                    <p className="text-[11px] line-clamp-1" style={{ color: currentTheme.cardSubtext }}>
                      {friend.status || 'Connected on Ghosted'}
                    </p>
                  </div>
                </div>

                {/* Friend Actions */}
                <div className="flex items-center space-x-1.5 flex-shrink-0">
                  {/* Chat Message Button */}
                  <button
                    type="button"
                    onClick={() => {
                      if (onOpenChatWithUser) {
                        onOpenChatWithUser(friend.id, friend.name);
                      } else if (onNavigateToTab) {
                        onNavigateToTab('phone_calls');
                      }
                    }}
                    className="p-2 rounded-xl border transition cursor-pointer active:scale-95"
                    style={{
                      backgroundColor: isBlack ? '#F3F4F6' : '#171717',
                      color: currentTheme.cardText,
                      borderColor: currentTheme.border,
                    }}
                    title="Send whisper / chat"
                  >
                    <MessageCircle className="w-4 h-4" />
                  </button>

                  {/* Call Button */}
                  <button
                    type="button"
                    onClick={() => {
                      if (onStartCallWithUser && friend.ghostedNumber) {
                        onStartCallWithUser(friend.ghostedNumber, friend.name);
                      } else if (onNavigateToTab) {
                        onNavigateToTab('phone_calls');
                      }
                    }}
                    className="p-2 rounded-xl border transition cursor-pointer active:scale-95"
                    style={{
                      backgroundColor: isBlack ? '#F3F4F6' : '#171717',
                      color: isGhost ? '#00F5FF' : currentTheme.cardText,
                      borderColor: currentTheme.border,
                    }}
                    title="Ghost Call"
                  >
                    <Phone className="w-4 h-4" />
                  </button>

                  {/* 3 dots remove option */}
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() => setActiveMenuFriendId(activeMenuFriendId === friend.id ? null : friend.id)}
                      className="p-1.5 rounded-xl transition cursor-pointer opacity-70 hover:opacity-100"
                      style={{ color: currentTheme.cardText }}
                    >
                      <MoreVertical className="w-4 h-4" />
                    </button>
                    {activeMenuFriendId === friend.id && (
                      <div
                        className="absolute right-0 top-8 z-30 w-36 rounded-2xl border p-1.5 shadow-2xl text-xs space-y-1 theme-card"
                        style={{
                          backgroundColor: currentTheme.card,
                          color: currentTheme.cardText,
                          borderColor: currentTheme.border,
                        }}
                      >
                        <button
                          type="button"
                          onClick={() => handleRemoveFriend(friend.id)}
                          className="w-full text-left p-2 rounded-xl hover:bg-rose-500/20 text-rose-400 flex items-center space-x-1.5 font-medium transition cursor-pointer"
                        >
                          <UserX className="w-3.5 h-3.5" />
                          <span>Remove Friend</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Discover / Suggestions */}
      {activeTabSection === 'suggestions' && (
        <div className="space-y-2.5">
          <p className="text-[11px] font-medium px-1" style={{ color: currentTheme.textOutsideSub }}>
            Creators & Active Members in THE VOID
          </p>
          {DEFAULT_SUGGESTIONS.map((creator) => {
            const isAlreadyFriend = friends.some((f) => f.ghostedId === creator.ghostedId);
            return (
              <div
                key={creator.id}
                className="p-3.5 rounded-2xl flex items-center justify-between gap-2 shadow-sm theme-card"
                style={{
                  backgroundColor: currentTheme.card,
                  color: currentTheme.cardText,
                  borderColor: currentTheme.border,
                }}
              >
                <div className="flex items-center space-x-3 min-w-0">
                  <div
                    className="w-11 h-11 rounded-2xl overflow-hidden flex items-center justify-center text-base font-bold shadow-inner flex-shrink-0 border"
                    style={{
                      backgroundColor: isBlack ? '#F3F4F6' : '#141414',
                      borderColor: currentTheme.border,
                    }}
                  >
                    <img src={creator.avatarUrl} alt={creator.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold truncate" style={{ color: currentTheme.cardText }}>
                      {creator.name}
                    </h4>
                    <span
                      className="text-[10px] font-mono block"
                      style={{ color: isGhost ? '#00F5FF' : currentTheme.cardSubtext }}
                    >
                      @{creator.ghostedId}
                    </span>
                    <span className="text-[10px] block" style={{ color: currentTheme.cardSubtext }}>
                      {creator.status}
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleAddFriend(creator)}
                  disabled={isAlreadyFriend}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-bold transition active:scale-95 flex items-center space-x-1 cursor-pointer flex-shrink-0 border"
                  style={{
                    backgroundColor: isAlreadyFriend
                      ? isBlack
                        ? '#E5E7EB'
                        : '#262626'
                      : currentTheme.btnPrimaryBg,
                    color: isAlreadyFriend ? currentTheme.cardSubtext : currentTheme.btnPrimaryText,
                    borderColor: currentTheme.border,
                  }}
                >
                  {isAlreadyFriend ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Friends</span>
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-3.5 h-3.5" />
                      <span>Add</span>
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* ADD FRIEND MODAL */}
      {showAddFriendModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div
            className="relative w-full max-w-sm rounded-3xl p-6 text-center space-y-4 shadow-2xl theme-card"
            style={{
              backgroundColor: currentTheme.card,
              color: currentTheme.cardText,
              borderColor: currentTheme.border,
            }}
          >
            <button
              type="button"
              onClick={() => setShowAddFriendModal(false)}
              className="absolute top-4 right-4 p-1.5 rounded-full cursor-pointer opacity-70 hover:opacity-100"
              style={{ color: currentTheme.cardText }}
            >
              <X className="w-5 h-5" />
            </button>
            <div
              className="w-14 h-14 rounded-full flex items-center justify-center mx-auto border"
              style={{
                backgroundColor: isGhost ? '#00F5FF' : isBlack ? '#000000' : '#FFFFFF',
                color: isGhost ? '#000000' : isBlack ? '#FFFFFF' : '#000000',
                borderColor: currentTheme.border,
              }}
            >
              <UserPlus className="w-7 h-7 stroke-[2.2]" />
            </div>
            <div>
              <h3 className="text-base font-bold" style={{ color: currentTheme.cardText }}>
                Add a Friend
              </h3>
              <p className="text-xs mt-0.5" style={{ color: currentTheme.cardSubtext }}>
                Enter their Ghosted ID or handle
              </p>
            </div>
            <form onSubmit={handleManualAddSubmit} className="space-y-3">
              <input
                type="text"
                value={addFriendInput}
                onChange={(e) => setAddFriendInput(e.target.value)}
                placeholder="e.g. GH-8902-7711 or Name..."
                className="w-full px-4 py-2.5 rounded-2xl focus:outline-none text-xs font-mono font-medium border"
                style={{
                  backgroundColor: currentTheme.searchBg,
                  color: currentTheme.searchText,
                  borderColor: currentTheme.border,
                }}
                autoFocus
              />
              <button
                type="submit"
                className="w-full py-2.5 rounded-xl font-bold text-xs shadow-md transition active:scale-95 cursor-pointer border"
                style={{
                  backgroundColor: currentTheme.btnPrimaryBg,
                  color: currentTheme.btnPrimaryText,
                  borderColor: currentTheme.border,
                }}
              >
                Add Friend Connection
              </button>
            </form>
            <div className="pt-2 border-t space-y-2 text-left" style={{ borderColor: currentTheme.border }}>
              <span
                className="text-[10px] uppercase font-mono tracking-wider block"
                style={{ color: currentTheme.cardSubtext }}
              >
                Your Credentials to Share
              </span>
              <div
                className="flex items-center justify-between p-2.5 rounded-xl border text-xs"
                style={{
                  backgroundColor: isBlack ? '#F9FAFB' : '#141414',
                  borderColor: currentTheme.border,
                }}
              >
                <span className="font-mono font-bold" style={{ color: currentTheme.cardText }}>
                  {user.ghostedId}
                </span>
                <button
                  type="button"
                  onClick={() => copyText(user.ghostedId, false)}
                  className="px-2.5 py-1 rounded-lg border text-[11px] font-semibold cursor-pointer active:scale-95"
                  style={{
                    backgroundColor: currentTheme.card,
                    color: currentTheme.cardText,
                    borderColor: currentTheme.border,
                  }}
                >
                  {copiedId ? 'Copied ✓' : 'Copy'}
                </button>
              </div>
              <div
                className="flex items-center justify-between p-2.5 rounded-xl border text-xs"
                style={{
                  backgroundColor: isBlack ? '#F9FAFB' : '#141414',
                  borderColor: currentTheme.border,
                }}
              >
                <span
                  className="font-mono font-bold"
                  style={{ color: isGhost ? '#00F5FF' : currentTheme.cardText }}
                >
                  {user.ghostedNumber}
                </span>
                <button
                  type="button"
                  onClick={() => copyText(user.ghostedNumber, true)}
                  className="px-2.5 py-1 rounded-lg border text-[11px] font-semibold cursor-pointer active:scale-95"
                  style={{
                    backgroundColor: currentTheme.card,
                    color: currentTheme.cardText,
                    borderColor: currentTheme.border,
                  }}
                >
                  {copiedNumber ? 'Copied ✓' : 'Copy'}
                </button>
              </div>
            </div>
            <button
              type="button"
              onClick={handleShareMyLink}
              className="w-full py-2.5 rounded-xl font-semibold text-xs flex items-center justify-center space-x-2 transition cursor-pointer border"
              style={{
                backgroundColor: isBlack ? '#F3F4F6' : '#171717',
                color: currentTheme.cardText,
                borderColor: currentTheme.border,
              }}
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Share My Ghosted Link</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
