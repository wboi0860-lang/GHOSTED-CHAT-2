import React from 'react';
import { TikTokDownloadProgress } from '../utils/tiktokDownloader';
import { Check, X, Download, Share2, Sparkles, AlertCircle } from 'lucide-react';

interface TikTokDownloadModalProps {
  isOpen: boolean;
  progressState: TikTokDownloadProgress | null;
  onClose: () => void;
  postAuthorName?: string;
}

export const TikTokDownloadModal: React.FC<TikTokDownloadModalProps> = ({
  isOpen,
  progressState,
  onClose,
  postAuthorName,
}) => {
  if (!isOpen || !progressState) return null;

  const isCompleted = progressState.status === 'completed';
  const isError = progressState.status === 'error';
  const radius = 38;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progressState.progress / 100) * circumference;

  return (
    <div className="fixed inset-0 z-[10010] flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="w-full max-w-xs bg-[#121214] text-white rounded-3xl p-6 shadow-2xl border border-white/10 text-center space-y-4 relative overflow-hidden animate-in zoom-in-95 duration-200"
        style={{
          boxShadow: '0 20px 50px rgba(0,0,0,0.8), 0 0 40px rgba(24,119,242,0.15)',
        }}
      >
        {/* Close / Dismiss button (top-right) */}
        {(isCompleted || isError) && (
          <button
            type="button"
            onClick={onClose}
            className="absolute top-3.5 right-3.5 p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white/80 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        {/* CIRCULAR PROGRESS INDICATOR (TIKTOK STYLE) */}
        <div className="relative w-28 h-28 mx-auto flex items-center justify-center my-2">
          {/* Background Ring */}
          <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r={radius}
              stroke="rgba(255, 255, 255, 0.12)"
              strokeWidth="7"
              fill="transparent"
            />
            {/* Dynamic Progress Ring */}
            <circle
              cx="50"
              cy="50"
              r={radius}
              stroke={isCompleted ? '#10B981' : isError ? '#EF4444' : '#1877F2'}
              strokeWidth="7"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              fill="transparent"
              className="transition-all duration-200 ease-out"
            />
          </svg>

          {/* Center Content */}
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            {isCompleted ? (
              <div className="w-12 h-12 rounded-full bg-emerald-500 text-white flex items-center justify-center animate-in zoom-in-50 duration-200 shadow-lg shadow-emerald-500/30">
                <Check className="w-7 h-7 stroke-[3]" />
              </div>
            ) : isError ? (
              <div className="w-12 h-12 rounded-full bg-rose-500 text-white flex items-center justify-center animate-in zoom-in-50 duration-200">
                <AlertCircle className="w-6 h-6 stroke-[2.5]" />
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center">
                <span className="text-2xl animate-pulse">👻</span>
                <span className="text-xs font-black font-mono mt-0.5 tracking-tight text-white">
                  {progressState.progress}%
                </span>
              </div>
            )}
          </div>
        </div>

        {/* STATUS TITLE & SUBTEXT */}
        <div className="space-y-1">
          <h4 className="text-base font-bold text-white tracking-tight">
            {isCompleted
              ? 'Saved to Device! 🎬'
              : isError
              ? 'Download Failed'
              : progressState.message || 'Saving video...'}
          </h4>
          <p className="text-xs text-white/60 line-clamp-1">
            {isCompleted
              ? 'Saved in Downloads with TikTok watermark'
              : isError
              ? progressState.error || 'Please try again'
              : postAuthorName
              ? `Watermarking @${postAuthorName.replace(/\s+/g, '_').toLowerCase()}`
              : 'Applying Ghosted watermark'}
          </p>
        </div>

        {/* TIKTOK BRANDING BADGE */}
        <div className="py-1 px-3 rounded-full bg-white/5 border border-white/10 text-[10px] text-white/70 flex items-center justify-center space-x-1.5 w-fit mx-auto">
          <Sparkles className="w-3 h-3 text-[#1877F2]" />
          <span>TikTok-Style Watermark System</span>
        </div>

        {/* ACTION BUTTONS ON COMPLETION */}
        {isCompleted && (
          <div className="pt-2 flex items-center justify-center space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="w-full py-2.5 px-4 rounded-xl bg-[#1877F2] hover:bg-[#166FE5] text-white text-xs font-bold transition shadow-md cursor-pointer active:scale-95"
            >
              Done
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
