import React, { useState, useEffect, useRef } from 'react';
import {
  collection,
  doc,
  setDoc,
  updateDoc,
  onSnapshot,
  query,
  where,
  addDoc,
  Unsubscribe,
} from 'firebase/firestore';
import { db, triggerIncomingCallAlert } from '../firebase';
import { FirestoreCallDoc } from '../types';
import {
  PhoneRingTonePlayer,
  playConnectedChime,
  playHangupTone,
  playDtmfTone,
  stopAllActiveRingtones,
} from '../utils/audioTones';
import {
  Smartphone,
  Phone,
  PhoneCall,
  PhoneOff,
  Mic,
  MicOff,
  Bell,
  Clock,
  ShieldCheck,
  Radio,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Volume2,
  RefreshCw,
  Zap,
} from 'lucide-react';

export const DualDeviceCallTester: React.FC = () => {
  // Device 1 (Caller) profile
  const deviceA = {
    id: 'Ghost#0001',
    name: 'Ghosted Alpha',
    phone: 'Ghost#0001',
  };

  // Device 2 (Receiver) profile
  const deviceB = {
    id: 'Ghost#0002',
    name: 'Ghosted Beta',
    phone: 'Ghost#0002',
  };

  // Active call state on Device A
  const [callAState, setCallAState] = useState<'idle' | 'calling' | 'connected' | 'ended' | 'timeout' | 'declined'>('idle');
  const [activeCallIdA, setActiveCallIdA] = useState<string | null>(null);
  const [callDurationA, setCallDurationA] = useState<number>(0);
  const [timeoutSecondsA, setTimeoutSecondsA] = useState<number>(30);
  const [isMutedA, setIsMutedA] = useState<boolean>(false);

  // Active incoming call on Device B (via Firestore real-time listener)
  const [incomingCallB, setIncomingCallB] = useState<FirestoreCallDoc | null>(null);
  const [callBState, setCallBState] = useState<'idle' | 'ringing' | 'connected' | 'ended' | 'timeout' | 'declined'>('idle');
  const [activeCallIdB, setActiveCallIdB] = useState<string | null>(null);
  const [callDurationB, setCallDurationB] = useState<number>(0);
  const [timeoutSecondsB, setTimeoutSecondsB] = useState<number>(30);
  const [isMutedB, setIsMutedB] = useState<boolean>(false);

  // Ringtone players
  const ringTonePlayerCaller = useRef<PhoneRingTonePlayer>(new PhoneRingTonePlayer());
  const ringTonePlayerReceiver = useRef<PhoneRingTonePlayer>(new PhoneRingTonePlayer());

  // Firestore Event Logs for transparency
  const [eventLogs, setEventLogs] = useState<Array<{ id: string; time: string; text: string; type: 'info' | 'success' | 'warn' | 'error' }>>([]);

  const addLog = (text: string, type: 'info' | 'success' | 'warn' | 'error' = 'info') => {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    setEventLogs((prev) => [{ id: Math.random().toString(), time, text, type }, ...prev.slice(0, 49)]);
  };

  // Timer intervals
  const timeoutTimerRefA = useRef<NodeJS.Timeout | null>(null);
  const timeoutTimerRefB = useRef<NodeJS.Timeout | null>(null);
  const durationTimerRefA = useRef<NodeJS.Timeout | null>(null);
  const durationTimerRefB = useRef<NodeJS.Timeout | null>(null);

  // 1. DEVICE B REAL-TIME FIRESTORE LISTENER
  useEffect(() => {
    addLog(`[Device B] Initializing Firestore onSnapshot listener for receiverId = '${deviceB.id}' & status = 'ringing'`, 'info');
    const callsCol = collection(db, 'calls');
    const q = query(
      callsCol,
      where('receiverId', '==', deviceB.id),
      where('status', '==', 'ringing')
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        if (snapshot.empty) {
          if (callBState === 'ringing') {
            ringTonePlayerReceiver.current.stop();
            setCallBState('idle');
            setIncomingCallB(null);
          }
          return;
        }

        // We have an incoming ringing call
        const docSnap = snapshot.docs[0];
        const data = { ...docSnap.data(), id: docSnap.id } as FirestoreCallDoc & { senderId?: string };

        // Top guard: ignore own calls
        if (data.callerId === deviceB.id || data.senderId === deviceB.id) {
          addLog(`[Device B] SELF CALL BLOCKED: Ignored own call from same ID (${data.callerId})`, 'info');
          return;
        }

        addLog(`[Device B] Firestore incoming call detected! ID: ${data.id}, Caller: ${data.callerName} (${data.callerId})`, 'warn');
        setIncomingCallB(data);
        setActiveCallIdB(data.id);
        setCallBState('ringing');
        setTimeoutSecondsB(30);

        // Start receiver ringtone & vibration
        ringTonePlayerReceiver.current.start();
        triggerIncomingCallAlert(data.callerName, data.callerId);

        // Start 30s countdown on receiver UI
        if (timeoutTimerRefB.current) clearInterval(timeoutTimerRefB.current);
        let remaining = 30;
        timeoutTimerRefB.current = setInterval(() => {
          remaining -= 1;
          setTimeoutSecondsB(remaining);
          if (remaining <= 0) {
            clearInterval(timeoutTimerRefB.current!);
          }
        }, 1000);
      },
      (err) => {
        addLog(`[Device B] Firestore listener error: ${err.message}`, 'error');
      }
    );

    return () => {
      unsubscribe();
      ringTonePlayerReceiver.current.stop();
      ringTonePlayerCaller.current.stop();
      stopAllActiveRingtones();
      if (timeoutTimerRefB.current) clearInterval(timeoutTimerRefB.current);
    };
  }, []);

  // 2. DEVICE A INITIATES CALL (User A calls User B)
  const handleDeviceAStartCall = async (callType: 'voice' | 'video' = 'voice') => {
    if (deviceA.id === deviceB.id) {
      addLog(`[SELF CALL BLOCKED] deviceA.id == deviceB.id`, 'warn');
      alert('SELF CALL BLOCKED: Device A cannot call itself.');
      return;
    }

    try {
      playDtmfTone('1');
      addLog(`[Device A] Creating call document in 'calls' collection with callerId='${deviceA.id}', receiverId='${deviceB.id}', status='ringing'`, 'info');
      setCallAState('calling');
      setCallDurationA(0);
      setTimeoutSecondsA(30);

      // Start telephone ring tone for caller
      ringTonePlayerCaller.current.start();

      // Create document in Firestore 'calls' collection
      const callsCol = collection(db, 'calls');
      const newCallRef = doc(callsCol);
      const callId = newCallRef.id;
      setActiveCallIdA(callId);

      // WebRTC simulated Offer SDP
      const callData: FirestoreCallDoc = {
        id: callId,
        callerId: deviceA.id,
        callerName: deviceA.name,
        callerPhone: deviceA.phone,
        receiverId: deviceB.id,
        receiverName: deviceB.name,
        status: 'ringing',
        callType,
        createdAt: Date.now(),
        offer: {
          type: 'offer',
          sdp: `v=0\r\no=caller 123456 2 IN IP4 127.0.0.1\r\ns=Ghosted Call\r\nt=0 0\r\nm=audio 54312 RTP/AVP 0\r\na=rtpmap:0 PCMU/8000`,
        },
        answer: null,
      };

      await setDoc(newCallRef, callData);
      addLog(`[Firestore] Call doc written successfully: /calls/${callId} (status: ringing)`, 'success');

      // 30-second timeout countdown on Device A
      let remaining = 30;
      if (timeoutTimerRefA.current) clearInterval(timeoutTimerRefA.current);
      timeoutTimerRefA.current = setInterval(async () => {
        remaining -= 1;
        setTimeoutSecondsA(remaining);
        if (remaining <= 0) {
          clearInterval(timeoutTimerRefA.current!);
          addLog(`[Device A] 30-second timeout reached! No answer from Device B. Updating status to 'timeout'`, 'error');
          ringTonePlayerCaller.current.stop();
          playHangupTone();
          try {
            await updateDoc(doc(db, 'calls', callId), {
              status: 'timeout',
              endedAt: Date.now(),
            });
          } catch {
            // ignore
          }
          setCallAState('timeout');
        }
      }, 1000);

      // Device A listens to its own call doc to detect when receiver presses Answer
      const unsubCallA = onSnapshot(newCallRef, (snap) => {
        const data = snap.data() as FirestoreCallDoc | undefined;
        if (!data) return;

        if (data.status === 'answered') {
          addLog(`[Device A] Firestore snapshot: Receiver answered call ${callId}! WebRTC audio connected.`, 'success');
          ringTonePlayerCaller.current.stop();
          playConnectedChime();
          if (timeoutTimerRefA.current) clearInterval(timeoutTimerRefA.current);
          setCallAState('connected');

          // Start duration timer
          if (durationTimerRefA.current) clearInterval(durationTimerRefA.current);
          durationTimerRefA.current = setInterval(() => {
            setCallDurationA((prev) => prev + 1);
          }, 1000);
        } else if (data.status === 'declined') {
          addLog(`[Device A] Firestore snapshot: Call declined by Device B`, 'warn');
          ringTonePlayerCaller.current.stop();
          playHangupTone();
          if (timeoutTimerRefA.current) clearInterval(timeoutTimerRefA.current);
          setCallAState('declined');
          unsubCallA();
        } else if (data.status === 'ended') {
          addLog(`[Device A] Firestore snapshot: Call ended by Device B`, 'info');
          ringTonePlayerCaller.current.stop();
          playHangupTone();
          if (timeoutTimerRefA.current) clearInterval(timeoutTimerRefA.current);
          if (durationTimerRefA.current) clearInterval(durationTimerRefA.current);
          setCallAState('ended');
          unsubCallA();
        } else if (data.status === 'timeout') {
          ringTonePlayerCaller.current.stop();
          playHangupTone();
          setCallAState('timeout');
          unsubCallA();
        }
      });
    } catch (err: unknown) {
      addLog(`[Device A] Error starting call: ${(err as Error).message}`, 'error');
      ringTonePlayerCaller.current.stop();
      setCallAState('idle');
    }
  };

  // 3. DEVICE B PRESSES "ANSWER" BUTTON
  const handleDeviceBAnswerCall = async () => {
    if (!activeCallIdB) return;
    try {
      addLog(`[Device B] User pressed Answer button! Stopping ringtone and updating status='answered' in Firestore`, 'success');
      ringTonePlayerReceiver.current.stop();
      playConnectedChime();
      if (timeoutTimerRefB.current) clearInterval(timeoutTimerRefB.current);

      const callRef = doc(db, 'calls', activeCallIdB);
      await updateDoc(callRef, {
        status: 'answered',
        answeredAt: Date.now(),
        answer: {
          type: 'answer',
          sdp: `v=0\r\no=receiver 654321 2 IN IP4 127.0.0.1\r\ns=Ghosted Answer\r\nt=0 0\r\nm=audio 54312 RTP/AVP 0\r\na=rtpmap:0 PCMU/8000`,
        },
      });

      addLog(`[Firestore] Call doc updated with status='answered' & WebRTC answer SDP`, 'success');
      setCallBState('connected');
      setCallDurationB(0);

      // Start duration counter on Device B
      if (durationTimerRefB.current) clearInterval(durationTimerRefB.current);
      durationTimerRefB.current = setInterval(() => {
        setCallDurationB((prev) => prev + 1);
      }, 1000);

      // Listen for remote hangup from Device A
      const unsubCallB = onSnapshot(callRef, (snap) => {
        const data = snap.data() as FirestoreCallDoc | undefined;
        if (!data) return;

        if (data.status === 'ended') {
          addLog(`[Device B] Remote caller ended the call`, 'info');
          playHangupTone();
          if (durationTimerRefB.current) clearInterval(durationTimerRefB.current);
          setCallBState('ended');
          setIncomingCallB(null);
          unsubCallB();
        }
      });
    } catch (err: unknown) {
      addLog(`[Device B] Error answering call: ${(err as Error).message}`, 'error');
    }
  };

  // 4. DEVICE B PRESSES "DECLINE" BUTTON
  const handleDeviceBDeclineCall = async () => {
    if (!activeCallIdB) return;
    try {
      addLog(`[Device B] User declined call! Updating status='declined' in Firestore`, 'warn');
      ringTonePlayerReceiver.current.stop();
      playHangupTone();
      if (timeoutTimerRefB.current) clearInterval(timeoutTimerRefB.current);

      const callRef = doc(db, 'calls', activeCallIdB);
      await updateDoc(callRef, {
        status: 'declined',
        endedAt: Date.now(),
      });

      setCallBState('idle');
      setIncomingCallB(null);
    } catch (err: unknown) {
      addLog(`[Device B] Error declining call: ${(err as Error).message}`, 'error');
    }
  };

  // 5. HANG UP ACTIVE CALL (Device A or Device B)
  const handleHangUp = async (fromDevice: 'A' | 'B') => {
    const callId = fromDevice === 'A' ? activeCallIdA : activeCallIdB;
    addLog(`[Device ${fromDevice}] Hanging up active call`, 'info');
    ringTonePlayerCaller.current.stop();
    ringTonePlayerReceiver.current.stop();
    playHangupTone();

    if (timeoutTimerRefA.current) clearInterval(timeoutTimerRefA.current);
    if (timeoutTimerRefB.current) clearInterval(timeoutTimerRefB.current);
    if (durationTimerRefA.current) clearInterval(durationTimerRefA.current);
    if (durationTimerRefB.current) clearInterval(durationTimerRefB.current);

    if (callId) {
      try {
        await updateDoc(doc(db, 'calls', callId), {
          status: 'ended',
          endedAt: Date.now(),
        });
      } catch {
        // ignore
      }
    }

    setCallAState('idle');
    setCallBState('idle');
    setIncomingCallB(null);
    setActiveCallIdA(null);
    setActiveCallIdB(null);
    setCallDurationA(0);
    setCallDurationB(0);
  };

  // Format seconds to mm:ss
  const formatTime = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-purple-900/80 via-indigo-900/70 to-purple-950/80 border border-purple-400/40 shadow-xl backdrop-blur-md">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-400/30 flex items-center justify-center text-purple-300">
              <Zap className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-base font-bold text-white">Dual-Device Firestore Signaling Simulator</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/20 border border-emerald-400/30 text-emerald-300">
                  Live Firestore Active
                </span>
              </div>
              <p className="text-xs text-purple-200/80">
                Testing Device A (Caller) calling Device B (Receiver) in real time via Firebase Firestore 'calls' collection.
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <a
              href={`${window.location.pathname}?device=b`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-xl bg-purple-500/20 hover:bg-purple-500/40 border border-purple-400/30 text-purple-200 text-xs font-semibold flex items-center space-x-1.5 transition"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Open Device B in New Tab</span>
            </a>
          </div>
        </div>
      </div>

      {/* Dual Phones Mockup Display */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* PHONE 1: DEVICE A (CALLER) */}
        <div className="bg-slate-900/90 rounded-3xl border-2 border-purple-500/40 shadow-2xl p-5 flex flex-col justify-between min-h-[480px] relative overflow-hidden backdrop-blur-xl">
          {/* Phone Top Notch & Header */}
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-purple-500/20">
              <div className="flex items-center space-x-2">
                <Smartphone className="w-4 h-4 text-purple-400" />
                <span className="text-xs font-bold text-white tracking-wide uppercase">Device A (Caller)</span>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                {deviceA.id}
              </span>
            </div>
            <div className="mt-3 flex items-center justify-between">
              <div>
                <p className="text-sm font-bold text-white">{deviceA.name}</p>
                <p className="text-xs text-purple-300/70 font-mono">{deviceA.phone}</p>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                Online
              </span>
            </div>
          </div>

          {/* Device A Center State */}
          <div className="my-auto py-6 text-center space-y-4">
            {callAState === 'idle' && (
              <div className="space-y-4">
                <div className="w-20 h-20 mx-auto rounded-full bg-purple-500/10 border-2 border-purple-400/30 flex items-center justify-center text-purple-300">
                  <Phone className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-base font-bold text-white">Ready to Place Call</h4>
                  <p className="text-xs text-purple-200/70 mt-1">
                    Target: <span className="text-purple-300 font-semibold">{deviceB.name}</span> ({deviceB.id})
                  </p>
                </div>
                <div className="flex justify-center space-x-3 pt-2">
                  <button
                    type="button"
                    onClick={() => handleDeviceAStartCall('voice')}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm shadow-lg shadow-emerald-500/30 flex items-center space-x-2 transition cursor-pointer"
                  >
                    <PhoneCall className="w-4 h-4" />
                    <span>Call Device B</span>
                  </button>
                </div>
              </div>
            )}

            {callAState === 'calling' && (
              <div className="space-y-4">
                <div className="relative w-24 h-24 mx-auto flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full bg-emerald-500/20 animate-ping" />
                  <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white shadow-xl shadow-purple-500/40">
                    <PhoneCall className="w-8 h-8 animate-bounce" />
                  </div>
                </div>
                <div>
                  <p className="text-xs uppercase font-bold tracking-wider text-emerald-400">Ringing Receiver...</p>
                  <h4 className="text-lg font-bold text-white mt-1">{deviceB.name}</h4>
                  <p className="text-xs text-purple-300 font-mono">{deviceB.id}</p>
                </div>

                {/* 30-Second Timeout Progress */}
                <div className="bg-slate-800/80 rounded-xl p-3 border border-purple-500/30 max-w-xs mx-auto">
                  <div className="flex items-center justify-between text-xs text-purple-200 mb-1">
                    <span className="flex items-center space-x-1">
                      <Clock className="w-3.5 h-3.5 text-amber-400" />
                      <span>30s Auto-Timeout:</span>
                    </span>
                    <span className="font-mono font-bold text-amber-300">{timeoutSecondsA}s remaining</span>
                  </div>
                  <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
                    <div
                      className="bg-amber-400 h-full transition-all duration-1000"
                      style={{ width: `${(timeoutSecondsA / 30) * 100}%` }}
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1 text-center">
                    Will auto-cancel call if Device B does not answer
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => handleHangUp('A')}
                  className="px-4 py-2 rounded-xl bg-red-600/90 hover:bg-red-500 text-white font-bold text-xs flex items-center space-x-1.5 mx-auto transition cursor-pointer"
                >
                  <PhoneOff className="w-4 h-4" />
                  <span>Cancel Call</span>
                </button>
              </div>
            )}

            {callAState === 'connected' && (
              <div className="space-y-4">
                <div className="w-20 h-20 mx-auto rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center text-emerald-400 shadow-xl shadow-emerald-500/30">
                  <Phone className="w-8 h-8" />
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-400/30">
                    WebRTC Audio Connected
                  </span>
                  <h4 className="text-lg font-bold text-white mt-2">{deviceB.name}</h4>
                  <p className="font-mono text-xl font-bold text-purple-200 mt-1">{formatTime(callDurationA)}</p>
                </div>

                {/* Audio Equalizer Visualizer */}
                <div className="flex items-center justify-center space-x-1 py-2">
                  {[40, 80, 60, 100, 75, 45, 90].map((h, i) => (
                    <div
                      key={i}
                      className="w-1.5 bg-emerald-400 rounded-full animate-pulse"
                      style={{ height: `${h * 0.3}px`, animationDelay: `${i * 120}ms` }}
                    />
                  ))}
                </div>

                <div className="flex items-center justify-center space-x-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsMutedA(!isMutedA)}
                    className={`p-3 rounded-2xl border transition ${
                      isMutedA
                        ? 'bg-amber-500/20 border-amber-400/50 text-amber-300'
                        : 'bg-purple-500/20 border-purple-400/40 text-purple-200'
                    }`}
                    title={isMutedA ? 'Unmute' : 'Mute'}
                  >
                    {isMutedA ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleHangUp('A')}
                    className="p-3.5 rounded-2xl bg-red-600 hover:bg-red-500 text-white shadow-lg shadow-red-500/40 transition cursor-pointer"
                    title="End Call"
                  >
                    <PhoneOff className="w-5 h-5" />
                  </button>
                </div>
              </div>
            )}

            {(callAState === 'declined' || callAState === 'timeout' || callAState === 'ended') && (
              <div className="space-y-4">
                <div className="w-16 h-16 mx-auto rounded-full bg-slate-800 flex items-center justify-center text-slate-400">
                  <PhoneOff className="w-7 h-7" />
                </div>
                <div>
                  <h4 className="text-base font-bold text-white">
                    {callAState === 'timeout' && 'Call Timed Out'}
                    {callAState === 'declined' && 'Call Declined'}
                    {callAState === 'ended' && 'Call Ended'}
                  </h4>
                  <p className="text-xs text-purple-300/70 mt-1">
                    {callAState === 'timeout' && 'No answer after 30 seconds from Device B.'}
                    {callAState === 'declined' && 'Recipient declined the call request.'}
                    {callAState === 'ended' && 'The call was disconnected.'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setCallAState('idle')}
                  className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs transition"
                >
                  Back to Dialer
                </button>
              </div>
            )}
          </div>

          {/* Bottom Footer Info */}
          <div className="pt-3 border-t border-purple-500/20 flex items-center justify-between text-[11px] text-purple-300/60">
            <span>Signaling: Firestore /calls</span>
            <span>Audio: WebRTC Peer</span>
          </div>
        </div>

        {/* PHONE 2: DEVICE B (RECEIVER) */}
        <div className="bg-slate-900/90 rounded-3xl border-2 border-indigo-500/40 shadow-2xl p-5 flex flex-col justify-between min-h-[480px] relative overflow-hidden backdrop-blur-xl">
          {/* Header */}
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-indigo-500/20">
              <div className="flex items-center space-x-2">
                <Smartphone className="w-4 h-4 text-indigo-400" />
                <span className="text-xs font-bold text-white tracking-wide uppercase">Device B (Receiver)</span>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                {deviceB.id}
              </span>
            </div>
            <div className="mt-3 flex items-center justify-between">
              <div>
                <p className="text-sm font-bold text-white">{deviceB.name}</p>
                <p className="text-xs text-indigo-300/70 font-mono">{deviceB.phone}</p>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 flex items-center space-x-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>Listening (Real-Time)</span>
              </span>
            </div>
          </div>

          {/* Device B Center State */}
          <div className="my-auto py-6 text-center space-y-4">
            {callBState === 'idle' && (
              <div className="space-y-3">
                <div className="w-20 h-20 mx-auto rounded-full bg-indigo-500/10 border-2 border-indigo-400/30 flex items-center justify-center text-indigo-300">
                  <Radio className="w-8 h-8 animate-pulse text-indigo-400" />
                </div>
                <div>
                  <h4 className="text-base font-bold text-white">Listening for Incoming Calls</h4>
                  <p className="text-xs text-indigo-200/70 mt-1 max-w-xs mx-auto">
                    Real-time Firestore listener active on <code className="text-indigo-300">{deviceB.id}</code>. When Device A calls, incoming call screen will ring automatically.
                  </p>
                </div>
              </div>
            )}

            {callBState === 'ringing' && incomingCallB && (
              <div className="space-y-4">
                {/* Incoming Call Notification Banner */}
                <div className="p-2.5 rounded-xl bg-purple-500/20 border border-purple-400/40 text-left flex items-center space-x-2.5 text-xs text-purple-200 animate-pulse">
                  <Bell className="w-4 h-4 text-amber-300 shrink-0" />
                  <div>
                    <span className="font-bold text-white">FCM Push Notification:</span> Incoming Ghosted call from {incomingCallB.callerName}
                  </div>
                </div>

                <div className="relative w-24 h-24 mx-auto flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full bg-purple-500/20 animate-ping" />
                  <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-xl shadow-purple-500/40">
                    <Volume2 className="w-8 h-8 animate-bounce text-amber-300" />
                  </div>
                </div>

                <div>
                  <p className="text-xs uppercase font-bold tracking-wider text-amber-300 flex items-center justify-center space-x-1">
                    <span>Incoming Call Ringing...</span>
                  </p>
                  <h4 className="text-lg font-bold text-white mt-1">{incomingCallB.callerName}</h4>
                  <p className="text-xs text-purple-300 font-mono">{incomingCallB.callerId}</p>
                </div>

                {/* 30-Second Timeout Progress */}
                <div className="bg-slate-800/80 rounded-xl p-3 border border-indigo-500/30 max-w-xs mx-auto">
                  <div className="flex items-center justify-between text-xs text-indigo-200 mb-1">
                    <span className="flex items-center space-x-1">
                      <Clock className="w-3.5 h-3.5 text-amber-400" />
                      <span>30s Auto-Timeout:</span>
                    </span>
                    <span className="font-mono font-bold text-amber-300">{timeoutSecondsB}s left</span>
                  </div>
                  <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
                    <div
                      className="bg-amber-400 h-full transition-all duration-1000"
                      style={{ width: `${(timeoutSecondsB / 30) * 100}%` }}
                    />
                  </div>
                </div>

                {/* ANSWER & DECLINE BUTTONS */}
                <div className="flex items-center justify-center space-x-4 pt-2">
                  <button
                    type="button"
                    onClick={handleDeviceBDeclineCall}
                    className="flex-1 max-w-[130px] py-3 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm shadow-lg shadow-red-500/30 flex items-center justify-center space-x-2 transition cursor-pointer"
                  >
                    <PhoneOff className="w-4 h-4" />
                    <span>Decline</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleDeviceBAnswerCall}
                    className="flex-1 max-w-[140px] py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm shadow-xl shadow-emerald-500/40 flex items-center justify-center space-x-2 transition cursor-pointer animate-pulse"
                  >
                    <Phone className="w-4 h-4" />
                    <span>Answer</span>
                  </button>
                </div>
              </div>
            )}

            {callBState === 'connected' && (
              <div className="space-y-4">
                <div className="w-20 h-20 mx-auto rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center text-emerald-400 shadow-xl shadow-emerald-500/30">
                  <Phone className="w-8 h-8" />
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-400/30">
                    Call Answered & Active
                  </span>
                  <h4 className="text-lg font-bold text-white mt-2">{deviceA.name}</h4>
                  <p className="font-mono text-xl font-bold text-indigo-200 mt-1">{formatTime(callDurationB)}</p>
                </div>

                {/* Audio Equalizer Visualizer */}
                <div className="flex items-center justify-center space-x-1 py-2">
                  {[50, 90, 70, 100, 60, 80, 50].map((h, i) => (
                    <div
                      key={i}
                      className="w-1.5 bg-emerald-400 rounded-full animate-pulse"
                      style={{ height: `${h * 0.3}px`, animationDelay: `${i * 100}ms` }}
                    />
                  ))}
                </div>

                <div className="flex items-center justify-center space-x-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsMutedB(!isMutedB)}
                    className={`p-3 rounded-2xl border transition ${
                      isMutedB
                        ? 'bg-amber-500/20 border-amber-400/50 text-amber-300'
                        : 'bg-indigo-500/20 border-indigo-400/40 text-indigo-200'
                    }`}
                    title={isMutedB ? 'Unmute' : 'Mute'}
                  >
                    {isMutedB ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleHangUp('B')}
                    className="p-3.5 rounded-2xl bg-red-600 hover:bg-red-500 text-white shadow-lg shadow-red-500/40 transition cursor-pointer"
                    title="End Call"
                  >
                    <PhoneOff className="w-5 h-5" />
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Bottom Footer Info */}
          <div className="pt-3 border-t border-indigo-500/20 flex items-center justify-between text-[11px] text-indigo-300/60">
            <span>Ringtone & Vibration Ready</span>
            <span>Status: {callBState.toUpperCase()}</span>
          </div>
        </div>
      </div>

      {/* Real-Time Firestore Signaling Event Log Stream */}
      <div className="p-5 rounded-2xl bg-slate-900/90 border border-purple-500/30 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Radio className="w-4 h-4 text-purple-400 animate-pulse" />
            <h4 className="text-sm font-bold text-white">Live Firestore Signaling Audit Stream</h4>
          </div>
          <span className="text-[10px] text-purple-300 font-mono">
            Collection: <code className="text-amber-300 font-bold">/calls</code>
          </span>
        </div>
        <div className="max-h-48 overflow-y-auto space-y-2 font-mono text-xs pr-2">
          {eventLogs.length === 0 ? (
            <p className="text-slate-500 text-xs italic">
              No events recorded yet. Click "Call Device B" above to test the real-time Firestore signaling workflow.
            </p>
          ) : (
            eventLogs.map((log) => (
              <div
                key={log.id}
                className={`p-2 rounded-lg border text-[11px] flex items-start space-x-2 ${
                  log.type === 'success'
                    ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                    : log.type === 'warn'
                    ? 'bg-amber-950/40 border-amber-500/30 text-amber-300'
                    : log.type === 'error'
                    ? 'bg-red-950/40 border-red-500/30 text-red-300'
                    : 'bg-slate-800/60 border-purple-500/20 text-purple-200'
                }`}
              >
                <span className="text-slate-500 shrink-0">[{log.time}]</span>
                <span className="flex-1 break-all">{log.text}</span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
