import React, { useState, useEffect, useRef } from 'react';
import {
  UserProfile,
  GhostedChatMessage,
  GhostedConversation,
  SavedLetter,
} from '../types';
import {
  MessageSquare,
  Users,
  Star,
  Mail,
  Send,
  Phone,
  Video,
  Search,
  Plus,
  Flame,
  Check,
  CheckCheck,
  PhoneCall,
  Clock,
  Sparkles,
  ArrowLeft,
  MoreVertical,
  X,
  UserPlus,
  Inbox,
  Trash2,
  BookmarkCheck,
  MessageCircle,
  ExternalLink,
  Lock,
  Minimize2,
  EyeOff,
  Ghost,
  KeyRound,
  Shield,
} from 'lucide-react';
import { SPOOKY_FONTS, convertToSpookyFont } from '../utils/spookyFonts';
import {
  collection,
  doc,
  setDoc,
  onSnapshot,
  query,
  where,
  addDoc,
  orderBy,
  limit,
} from 'firebase/firestore';
import { db } from '../firebase';
import { SmartAdInterstitial } from './SmartAdInterstitial';
import { shouldShowAd } from '../utils/adManager';
import { checkIsNigeria } from '../utils/countryDetection';
import { useTheme } from '../context/ThemeContext';

export type ChatSection = 'all' | 'unread' | 'favourite' | 'groups';

interface ChatHubProps {
  user: UserProfile;
  letters?: SavedLetter[];
  onStartCall: (contactId: string, contactName: string, type: 'voice' | 'video') => void;
  onSelectContactForDialer?: (id: string, name: string, phone: string) => void;
  forcedSection?: ChatSection;
  onNavigateSection?: (section: ChatSection) => void;
  onSlideNext?: () => void;
  onSlidePrev?: () => void;
  sharedConversations?: GhostedConversation[];
  setSharedConversations?: React.Dispatch<React.SetStateAction<GhostedConversation[]>>;
  sharedMessages?: Record<string, GhostedChatMessage[]>;
  setSharedMessages?: React.Dispatch<React.SetStateAction<Record<string, GhostedChatMessage[]>>>;
  selectedChatId?: string | null;
  setSelectedChatId?: (id: string | null) => void;
  isPrimaryListener?: boolean;
}

export const ChatHub: React.FC<ChatHubProps> = ({
  user,
  letters = [],
  onStartCall,
  onSelectContactForDialer,
  forcedSection,
  onNavigateSection,
  onSlideNext,
  onSlidePrev,
  sharedConversations,
  setSharedConversations,
  sharedMessages,
  setSharedMessages,
  selectedChatId: propSelectedChatId,
  setSelectedChatId: propSetSelectedChatId,
  isPrimaryListener = true,
}) => {
  const { currentTheme, isWhite, isBlack, isGhost } = useTheme();
  const [activeSection, setActiveSection] = useState<ChatSection>(forcedSection || 'all');
  useEffect(() => {
    if (forcedSection) {
      setActiveSection(forcedSection);
    }
  }, [forcedSection]);

  const handleSectionChange = (sec: ChatSection) => {
    setActiveSection(sec);
    if (onNavigateSection) {
      onNavigateSection(sec);
    }
  };

  const [searchQuery, setSearchQuery] = useState('');
  const [localSelectedChatId, setLocalSelectedChatId] = useState<string | null>(null);
  const selectedChatId = propSelectedChatId !== undefined ? propSelectedChatId : localSelectedChatId;
  const setSelectedChatId = propSetSelectedChatId || setLocalSelectedChatId;

  const [isCreateGroupOpen, setIsCreateGroupOpen] = useState(false);
  const [isGroupAdOpen, setIsGroupAdOpen] = useState(false);
  const [isNewChatOpen, setIsNewChatOpen] = useState(false);
  const [isAddMemberOpen, setIsAddMemberOpen] = useState(false);

  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupTopic, setNewGroupTopic] = useState('');
  const [selectedGroupMembers, setSelectedGroupMembers] = useState<string[]>([]);
  const [customMemberInput, setCustomMemberInput] = useState('');

  const [newChatTargetId, setNewChatTargetId] = useState('');
  const [newChatTargetName, setNewChatTargetName] = useState('');
  const [newChatTargetPhone, setNewChatTargetPhone] = useState('');

  const [addMemberId, setAddMemberId] = useState('');
  const [addMemberName, setAddMemberName] = useState('');

  const [messageInput, setMessageInput] = useState('');
  const [burnTimerSeconds, setBurnTimerSeconds] = useState<number | null>(null);
  const [isSending, setIsSending] = useState(false);
  const messagesScrollRef = useRef<HTMLDivElement | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // 4 Pill Action States
  const ghostBlurInputRef = useRef<HTMLInputElement>(null);
  const [showFontMenu, setShowFontMenu] = useState<boolean>(false);
  const [showVaultModal, setShowVaultModal] = useState<boolean>(false);
  const [vaultPinInput, setVaultPinInput] = useState<string>('');
  const [vaultSavedPin, setVaultSavedPin] = useState<string>(() => {
    return localStorage.getItem(`ghosted_vault_pin_${user.id}`) || '';
  });
  const [isVaultUnlocked, setIsVaultUnlocked] = useState<boolean>(false);
  const [vaultEntries, setVaultEntries] = useState<Array<{ id: string; text: string; date: string }>>(() => {
    try {
      const s = localStorage.getItem(`ghosted_vault_entries_${user.id}`);
      return s ? JSON.parse(s) : [];
    } catch {
      return [];
    }
  });

  // 1. Text Compressor: compress long typed message to 280 chars for The Void
  const handleCompressText = () => {
    if (!messageInput.trim()) {
      showToast('Type a message first to compress for The Void 🌌');
      return;
    }
    if (messageInput.trim().length <= 280) {
      showToast(`Already Void-ready (${messageInput.trim().length}/280 chars) ✨`);
      return;
    }
    let text = messageInput.trim().replace(/\s+/g, ' ');
    text = text
      .replace(/\b(to be honest|tbh)\b/gi, 'tbh')
      .replace(/\b(in my opinion|imo)\b/gi, 'imo')
      .replace(/\b(by the way|btw)\b/gi, 'btw')
      .replace(/\b(as far as i know|afaik)\b/gi, 'afaik')
      .replace(/\b(i do not know|idk)\b/gi, 'idk')
      .replace(/\b(right now|rn)\b/gi, 'rn')
      .replace(/\b(for what it's worth|fwiw)\b/gi, 'fwiw');

    if (text.length > 280) {
      const cut = text.slice(0, 277);
      const lastSpace = cut.lastIndexOf(' ');
      text = (lastSpace > 220 ? cut.slice(0, lastSpace) : cut) + '...';
    }
    setMessageInput(text);
    showToast(`Compressed to 280 chars for The Void ✨ (${text.length} chars)`);
  };

  // 2. Ghost Blur: pick image, blur faces before sending
  const handleGhostBlurFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDim = 800;
        let w = img.width;
        let h = img.height;
        if (w > maxDim || h > maxDim) {
          if (w > h) {
            h = Math.round((h * maxDim) / w);
            w = maxDim;
          } else {
            w = Math.round((w * maxDim) / h);
            h = maxDim;
          }
        }
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        ctx.drawImage(img, 0, 0, w, h);

        const faceBoxW = Math.round(w * 0.46);
        const faceBoxH = Math.round(h * 0.36);
        const faceBoxX = Math.round((w - faceBoxW) / 2);
        const faceBoxY = Math.round(h * 0.16);

        const sampleCanvas = document.createElement('canvas');
        sampleCanvas.width = 12;
        sampleCanvas.height = 10;
        const sampleCtx = sampleCanvas.getContext('2d');
        if (sampleCtx) {
          sampleCtx.drawImage(canvas, faceBoxX, faceBoxY, faceBoxW, faceBoxH, 0, 0, 12, 10);
          ctx.imageSmoothingEnabled = false;
          ctx.drawImage(sampleCanvas, 0, 0, 12, 10, faceBoxX, faceBoxY, faceBoxW, faceBoxH);
        }

        ctx.fillStyle = 'rgba(0, 0, 0, 0.78)';
        ctx.fillRect(faceBoxX, faceBoxY + Math.round(faceBoxH * 0.32), faceBoxW, Math.round(faceBoxH * 0.36));
        ctx.fillStyle = '#00F5FF';
        ctx.font = 'bold 13px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('👻 GHOST BLUR', faceBoxX + faceBoxW / 2, faceBoxY + Math.round(faceBoxH * 0.56));

        setMessageInput((prev) => (prev ? `${prev} [Ghost Blur Photo Attached]` : '[Ghost Blur Photo Attached]'));
        showToast('Ghost Blur applied 👻 Face privacy protected');
      };
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  };

  // 3. Ghost Fonts: convert typed text to 5 spooky anonymous fonts
  const handleApplySpookyFont = (fontId: 'gothic' | 'mono' | 'bubble' | 'script' | 'vapor') => {
    if (!messageInput.trim()) {
      const sample = convertToSpookyFont('Ghost whisper', fontId);
      setMessageInput(sample + ' ');
      showToast('Ghost font activated! Type your whisper 👻');
      setShowFontMenu(false);
      return;
    }
    const converted = convertToSpookyFont(messageInput, fontId);
    setMessageInput(converted);
    showToast('Converted to spooky font ✨');
    setShowFontMenu(false);
  };

  // 4. Vault: save to private Vault with 4-digit PIN, local encrypted storage
  const handleSaveToVault = (textToSave?: string) => {
    const text = (textToSave || messageInput).trim();
    if (!text) {
      showToast('No message to save in vault');
      return;
    }
    const newEntry = {
      id: `vault-${Date.now()}`,
      text,
      date: new Date().toLocaleDateString(undefined, {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
    };
    const updated = [newEntry, ...vaultEntries];
    setVaultEntries(updated);
    try {
      localStorage.setItem(`ghosted_vault_entries_${user.id}`, JSON.stringify(updated));
    } catch {}
    showToast('Saved to private Vault 🔐');
  };

  const availableContacts = letters
    .filter((l) => l.recipientName)
    .map((l) => ({
      ghostedId: l.recipientGhostedId || `GH-${l.id.slice(0, 8).toUpperCase()}`,
      name: l.recipientName,
      phone: l.recipientPhone || '',
    }))
    .filter((c) => c.ghostedId !== user.ghostedId);

  const getDefaultConversations = (): GhostedConversation[] => [];

  const [localConversations, setLocalConversations] = useState<GhostedConversation[]>(() => {
    const storageKey = `ghosted_convos_${user.ghostedId}`;
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return getDefaultConversations();
  });

  const conversations = sharedConversations ?? localConversations;
  const setConversations = setSharedConversations ?? setLocalConversations;

  useEffect(() => {
    if (sharedConversations) return;
    const storageKey = `ghosted_convos_${user.ghostedId}`;
    try {
      localStorage.setItem(storageKey, JSON.stringify(conversations));
    } catch {}
  }, [conversations, user.ghostedId, sharedConversations]);

  const getDefaultMessages = (): Record<string, GhostedChatMessage[]> => ({});
  const [localMessages, setLocalMessages] = useState<Record<string, GhostedChatMessage[]>>(() => {
    const storageKey = `ghosted_msgs_${user.ghostedId}`;
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed === 'object') return parsed;
      }
    } catch {}
    return getDefaultMessages();
  });

  const messagesByConvo = sharedMessages ?? localMessages;
  const setMessagesByConvo = setSharedMessages ?? setLocalMessages;

  useEffect(() => {
    if (sharedMessages) return;
    const storageKey = `ghosted_msgs_${user.ghostedId}`;
    try {
      localStorage.setItem(storageKey, JSON.stringify(messagesByConvo));
    } catch {}
  }, [messagesByConvo, user.ghostedId, sharedMessages]);

  useEffect(() => {
    if (!user?.ghostedId || !isPrimaryListener) return;
    try {
      const messagesCol = collection(db, 'chat_messages');
      const q = query(messagesCol, limit(50));
      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          snapshot.docChanges().forEach((change) => {
            if (change.type === 'added') {
              const data = change.doc.data() as GhostedChatMessage;
              if (
                data &&
                data.id &&
                (data.receiverGhostedId === user.ghostedId ||
                  data.isGroupMessage ||
                  data.conversationId)
              ) {
                const convoKey = data.conversationId || `chat-${data.senderGhostedId}`;
                setMessagesByConvo((prev) => {
                  const existingList = prev[convoKey] || [];
                  if (existingList.some((m) => m.id === data.id)) return prev;
                  return {
                    ...prev,
                    [convoKey]: [...existingList, data],
                  };
                });
                setConversations((prev) =>
                  prev.map((c) => {
                    if (c.id === convoKey || c.targetGhostedId === data.senderGhostedId) {
                      const isCurrentlyOpen = selectedChatId === c.id;
                      return {
                        ...c,
                        lastMessageText: data.text,
                        lastMessageTimestamp: data.timestamp || 'Just now',
                        unreadCount: isCurrentlyOpen ? 0 : c.unreadCount + 1,
                        updatedAt: Date.now(),
                      };
                    }
                    return c;
                  })
                );
              }
            }
          });
        },
        (err) => {
          console.warn('Firestore chat_messages listener note:', err);
        }
      );
      return () => unsubscribe();
    } catch (err) {
      console.warn('Firestore setup note for chat:', err);
    }
  }, [user.ghostedId, selectedChatId]);

  useEffect(() => {
    if (selectedChatId && messagesScrollRef.current) {
      messagesScrollRef.current.scrollTop = messagesScrollRef.current.scrollHeight;
    }
  }, [selectedChatId, messagesByConvo]);

  const activeConversation = conversations.find((c) => c.id === selectedChatId) || null;
  const currentMessages = selectedChatId ? messagesByConvo[selectedChatId] || [] : [];

  const handleSelectConversation = (convo: GhostedConversation) => {
    setSelectedChatId(convo.id);
    if (!convo.isGroup && convo.targetGhostedId && onSelectContactForDialer) {
      onSelectContactForDialer(convo.targetGhostedId, convo.name, convo.targetPhone || '');
    }
    setConversations((prev) =>
      prev.map((c) => (c.id === convo.id ? { ...c, unreadCount: 0 } : c))
    );
    setMessagesByConvo((prev) => {
      const list = prev[convo.id] || [];
      const updated = list.map((m) => ({ ...m, isRead: true }));
      return { ...prev, [convo.id]: updated };
    });
  };

  const handleToggleFavourite = (convoId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setConversations((prev) =>
      prev.map((c) => (c.id === convoId ? { ...c, isFavourite: !c.isFavourite } : c))
    );
  };

  const handleToggleUnread = (convoId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setConversations((prev) =>
      prev.map((c) =>
        c.id === convoId
          ? { ...c, unreadCount: c.unreadCount > 0 ? 0 : 1 }
          : c
      )
    );
  };

  const handleMarkAllRead = () => {
    setConversations((prev) => prev.map((c) => ({ ...c, unreadCount: 0 })));
    setMessagesByConvo((prev) => {
      const next: Record<string, GhostedChatMessage[]> = {};
      Object.keys(prev).forEach((key) => {
        next[key] = prev[key].map((m) => ({ ...m, isRead: true }));
      });
      return next;
    });
  };

  const handleSendMessage = async (
    e?: React.FormEvent,
    channel: 'in_app' | 'sms' | 'whatsapp' = 'in_app'
  ) => {
    if (e) e.preventDefault();
    if (!activeConversation) return;
    const textToSend = messageInput.trim();
    if (!textToSend) return;

    if (channel === 'sms' && activeConversation.targetPhone) {
      const cleanPhone = activeConversation.targetPhone.replace(/[^0-9+]/g, '');
      window.location.href = `sms:${cleanPhone}?body=${encodeURIComponent(textToSend)}`;
    }
    if (channel === 'whatsapp' && activeConversation.targetPhone) {
      const cleanPhone = activeConversation.targetPhone.replace(/[^0-9]/g, '');
      window.open(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(textToSend)}`, '_blank');
    }

    setIsSending(true);
    const now = new Date();
    const timeFormatted = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const msgId = `msg-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const newMsg: GhostedChatMessage = {
      id: msgId,
      senderGhostedId: user.ghostedId,
      senderName: user.name,
      receiverGhostedId: activeConversation.targetGhostedId || activeConversation.id,
      conversationId: activeConversation.id,
      recipientPhone: activeConversation.targetPhone,
      channel,
      text: textToSend,
      timestamp: timeFormatted,
      isDelivered: true,
      isRead: true,
      isGroupMessage: activeConversation.isGroup,
    };

    setMessagesByConvo((prev) => ({
      ...prev,
      [activeConversation.id]: [...(prev[activeConversation.id] || []), newMsg],
    }));

    setConversations((prev) =>
      prev.map((c) =>
        c.id === activeConversation.id
          ? {
              ...c,
              lastMessageText: textToSend,
              lastMessageTimestamp: timeFormatted,
              updatedAt: Date.now(),
            }
          : c
      )
    );

    setMessageInput('');

    if (burnTimerSeconds) {
      setTimeout(() => {
        setMessagesByConvo((prev) => ({
          ...prev,
          [activeConversation.id]: (prev[activeConversation.id] || []).filter((m) => m.id !== msgId),
        }));
      }, burnTimerSeconds * 1000);
    }

    try {
      await addDoc(collection(db, 'chat_messages'), {
        ...newMsg,
        createdAt: Date.now(),
      });
    } catch (err) {
      console.warn('Firestore message broadcast note:', err);
    }

    try {
      await fetch('/api/chat/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderGhostedId: user.ghostedId,
          senderName: user.name,
          receiverGhostedId: activeConversation.targetGhostedId || activeConversation.id,
          conversationId: activeConversation.id,
          recipientPhone: activeConversation.targetPhone,
          text: textToSend,
          channel,
          isGroupMessage: activeConversation.isGroup,
        }),
      });
    } catch {
      // local already handled
    } finally {
      setIsSending(false);
    }
  };

  const handleCreateGroup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName.trim()) return;

    const groupId = `group-${Date.now().toString(36)}`;
    const membersList = [
      { ghostedId: user.ghostedId, name: `${user.name} (You)` },
      ...selectedGroupMembers.map((mId) => {
        const found = availableContacts.find((c) => c.ghostedId === mId);
        return {
          ghostedId: mId,
          name: found ? found.name : mId,
        };
      }),
    ];

    const colors = [
      'from-purple-600 to-indigo-600',
      'from-emerald-600 to-teal-600',
      'from-pink-600 to-rose-600',
      'from-cyan-600 to-blue-600',
      'from-amber-600 to-orange-600',
    ];
    const pickedColor = colors[Math.floor(Math.random() * colors.length)];

    const newGroup: GhostedConversation = {
      id: groupId,
      name: newGroupName.trim(),
      isGroup: true,
      groupMembers: membersList,
      isFavourite: false,
      unreadCount: 0,
      lastMessageText: `Group created by ${user.name}. Topic: ${newGroupTopic.trim() || 'Encrypted discussions'}`,
      lastMessageTimestamp: 'Just now',
      color: pickedColor,
      updatedAt: Date.now(),
    };

    const initialWelcomeMessage: GhostedChatMessage = {
      id: `msg-${Date.now()}-welcome`,
      senderGhostedId: user.ghostedId,
      senderName: user.name,
      receiverGhostedId: groupId,
      conversationId: groupId,
      text: `🔒 Created group "${newGroupName.trim()}". End-to-end encrypted across all members.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      channel: 'in_app',
      isDelivered: true,
      isRead: true,
      isGroupMessage: true,
    };

    setConversations((prev) => [newGroup, ...prev]);
    setMessagesByConvo((prev) => ({
      ...prev,
      [groupId]: [initialWelcomeMessage],
    }));

    setNewGroupName('');
    setNewGroupTopic('');
    setIsCreateGroupOpen(false);
    setActiveSection('groups');
    setSelectedChatId(groupId);

    const isNigeria = checkIsNigeria(user.userCountry || user.country || user.stateCountry);
    if (shouldShowAd(user, isNigeria)) {
      setIsGroupAdOpen(true);
    }
  };

  const handleStartNewChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChatTargetId.trim()) return;

    const contactId = newChatTargetId.trim();
    const displayName = newChatTargetName.trim() || `User (${contactId})`;
    const convoId = `chat-${contactId.replace(/[^a-zA-Z0-9]/g, '-').toLowerCase()}`;

    const existing = conversations.find((c) => c.targetGhostedId === contactId || c.id === convoId);
    if (existing) {
      setSelectedChatId(existing.id);
      setIsNewChatOpen(false);
      return;
    }

    const newConvo: GhostedConversation = {
      id: convoId,
      name: displayName,
      targetGhostedId: contactId,
      targetPhone: newChatTargetPhone.trim() || '+1 (555) 000-0000',
      isGroup: false,
      isFavourite: false,
      unreadCount: 0,
      lastMessageText: 'Started a new private conversation.',
      lastMessageTimestamp: 'Just now',
      color: 'from-purple-500 to-indigo-500',
      updatedAt: Date.now(),
    };

    setConversations((prev) => [newConvo, ...prev]);
    setMessagesByConvo((prev) => ({ ...prev, [convoId]: [] }));
    setNewChatTargetId('');
    setNewChatTargetName('');
    setNewChatTargetPhone('');
    setIsNewChatOpen(false);
    setSelectedChatId(convoId);
  };

  const handleAddMemberToGroup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeConversation || !activeConversation.isGroup || !addMemberId.trim()) return;

    const newMemberGhostedId = addMemberId.trim();
    const newMemberDisplayName = addMemberName.trim() || newMemberGhostedId;
    const updatedMembers = [
      ...(activeConversation.groupMembers || []),
      { ghostedId: newMemberGhostedId, name: newMemberDisplayName },
    ];

    setConversations((prev) =>
      prev.map((c) =>
        c.id === activeConversation.id ? { ...c, groupMembers: updatedMembers } : c
      )
    );

    const announcement: GhostedChatMessage = {
      id: `msg-${Date.now()}-added`,
      senderGhostedId: user.ghostedId,
      senderName: user.name,
      receiverGhostedId: activeConversation.id,
      conversationId: activeConversation.id,
      text: `👥 ${newMemberDisplayName} was added to the group.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isDelivered: true,
      isRead: true,
      isGroupMessage: true,
    };

    setMessagesByConvo((prev) => ({
      ...prev,
      [activeConversation.id]: [...(prev[activeConversation.id] || []), announcement],
    }));

    setAddMemberId('');
    setAddMemberName('');
    setIsAddMemberOpen(false);
  };

  const filteredConversations = conversations
    .filter((c) => {
      if (searchQuery.trim()) {
        const queryLower = searchQuery.toLowerCase();
        const matchesName = c.name.toLowerCase().includes(queryLower);
        const matchesTargetId = c.targetGhostedId?.toLowerCase().includes(queryLower);
        const matchesLastMsg = c.lastMessageText.toLowerCase().includes(queryLower);
        if (!matchesName && !matchesTargetId && !matchesLastMsg) return false;
      }
      if (activeSection === 'all') return true;
      if (activeSection === 'unread') return c.unreadCount > 0;
      if (activeSection === 'favourite') return c.isFavourite;
      if (activeSection === 'groups') return c.isGroup;
      return true;
    })
    .sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));

  const counts = {
    all: conversations.length,
    unread: conversations.filter((c) => c.unreadCount > 0).length,
    favourite: conversations.filter((c) => c.isFavourite).length,
    groups: conversations.filter((c) => c.isGroup).length,
  };

  return (
    <div className="space-y-4">
      {toastMessage && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 p-3 rounded-2xl bg-[#1877F2] text-white text-xs font-bold flex items-center space-x-2 shadow-2xl animate-in fade-in slide-in-from-top duration-200">
          <Sparkles className="w-4 h-4 text-amber-300 flex-shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* ACTIVE CONVERSATION MESSAGING WINDOW */}
      {selectedChatId && activeConversation ? (
        <div
          data-active-chat="true"
          className="p-4 sm:p-5 rounded-3xl border shadow-2xl space-y-4 animate-in fade-in duration-150 theme-card transition-colors duration-300"
          style={{
            backgroundColor: currentTheme.card,
            color: currentTheme.cardText,
            borderColor: currentTheme.border,
          }}
        >
          <div
            className="flex flex-wrap items-center justify-between gap-3 pb-3.5 border-b transition-colors duration-300"
            style={{ borderColor: currentTheme.border }}
          >
            <div className="flex items-center space-x-3">
              <button
                type="button"
                onClick={() => setSelectedChatId(null)}
                className="p-2 rounded-xl border transition cursor-pointer flex items-center space-x-1"
                style={{
                  backgroundColor: isBlack ? '#F3F4F6' : '#171717',
                  borderColor: currentTheme.border,
                  color: currentTheme.cardText,
                }}
                title={`Back to ${activeSection.toUpperCase()} section`}
              >
                <ArrowLeft className="w-4 h-4" />
                <span className="hidden sm:inline text-xs font-semibold capitalize">
                  {activeSection}
                </span>
              </button>
              <div
                className={`w-11 h-11 rounded-2xl bg-gradient-to-tr ${
                  activeConversation.color || 'from-purple-600 to-indigo-600'
                } flex items-center justify-center text-white font-bold shadow-md shadow-purple-900/30 text-sm flex-shrink-0`}
              >
                {activeConversation.isGroup ? (
                  <Users className="w-5 h-5" />
                ) : (
                  activeConversation.name.charAt(0)
                )}
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h3
                    className="font-bold text-sm sm:text-base flex items-center space-x-1.5"
                    style={{ color: currentTheme.cardText }}
                  >
                    <span>{activeConversation.name}</span>
                    {activeConversation.isGroup && (
                      <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.2 rounded-full border border-indigo-400/30 font-semibold">
                        Group
                      </span>
                    )}
                  </h3>
                </div>
                <p className="text-[11px] font-mono" style={{ color: currentTheme.cardSubtext }}>
                  {activeConversation.isGroup
                    ? `${activeConversation.groupMembers?.length || 0} members • Encrypted Group`
                    : activeConversation.targetGhostedId || 'Ghosted Verified Contact'}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={() => handleToggleFavourite(activeConversation.id)}
                className={`p-2 rounded-xl border transition ${
                  activeConversation.isFavourite
                    ? 'bg-amber-500/20 border-amber-400/40 text-amber-300 shadow-md shadow-amber-900/30'
                    : 'bg-white/5 border-white/10 text-purple-300 hover:text-amber-300'
                }`}
                title={
                  activeConversation.isFavourite
                    ? 'Remove from Favourites'
                    : 'Add to Favourite Section'
                }
              >
                <Star
                  className={`w-4 h-4 ${
                    activeConversation.isFavourite ? 'fill-amber-400 text-amber-400' : ''
                  }`}
                />
              </button>

              {activeConversation.isGroup && (
                <button
                  type="button"
                  onClick={() => setIsAddMemberOpen(true)}
                  className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-purple-300 hover:text-white transition"
                  title="Add Member to Group"
                >
                  <UserPlus className="w-4 h-4" />
                </button>
              )}

              {!activeConversation.isGroup && activeConversation.targetGhostedId && (
                <button
                  type="button"
                  onClick={() =>
                    onStartCall(
                      activeConversation.targetGhostedId!,
                      activeConversation.name,
                      'voice'
                    )
                  }
                  className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md shadow-emerald-900/40 flex items-center space-x-1.5 transition cursor-pointer"
                  title="Start WebRTC Voice Call via Firestore signaling"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Call</span>
                </button>
              )}

              {!activeConversation.isGroup && activeConversation.targetGhostedId && (
                <button
                  type="button"
                  onClick={() =>
                    onStartCall(
                      activeConversation.targetGhostedId!,
                      activeConversation.name,
                      'video'
                    )
                  }
                  className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md shadow-indigo-900/40 flex items-center space-x-1.5 transition cursor-pointer"
                  title="Start Encrypted Video Call"
                >
                  <Video className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Video</span>
                </button>
              )}
            </div>
          </div>

          {activeConversation.isGroup && activeConversation.groupMembers && (
            <div className="flex flex-wrap items-center gap-1.5 p-2.5 rounded-2xl bg-black/40 border border-white/5 text-[11px]">
              <span className="text-purple-300 font-semibold mr-1">Members:</span>
              {activeConversation.groupMembers.map((m) => (
                <span
                  key={m.ghostedId}
                  className="px-2 py-0.5 rounded-lg bg-white/5 border border-white/10 text-purple-200 font-mono text-[10px]"
                >
                  {m.name}
                </span>
              ))}
              <button
                type="button"
                onClick={() => setIsAddMemberOpen(true)}
                className="text-[10px] text-indigo-300 hover:text-white underline font-semibold ml-auto"
              >
                + Add Member
              </button>
            </div>
          )}

          <div
            ref={messagesScrollRef}
            className="min-h-[420px] max-h-[62dvh] overflow-y-auto space-y-3 p-3.5 rounded-2xl bg-[#0b141a]/95 border border-white/10 pr-2 scrollbar-thin"
          >
            <div className="my-1.5 p-2 rounded-xl bg-[#182229] border border-amber-500/20 text-center max-w-sm mx-auto shadow-sm">
              <p className="text-[11px] text-amber-200/90 leading-relaxed flex items-center justify-center space-x-1.5">
                <Lock className="w-3 h-3 text-amber-400 inline flex-shrink-0" />
                <span>Messages and calls are end-to-end encrypted. No one outside of this chat can read or listen to them.</span>
              </p>
            </div>

            {currentMessages.length === 0 ? (
              <div className="h-64 flex flex-col items-center justify-center text-zinc-400 text-xs text-center space-y-2">
                <MessageSquare className="w-10 h-10 opacity-30 text-[#00a884]" />
                <p className="font-semibold text-white">This conversation is secure & ready</p>
                <p className="text-[11px] text-zinc-400 max-w-xs">
                  Send your first encrypted in-app message, native SMS, or WhatsApp note.
                </p>
              </div>
            ) : (
              currentMessages.map((msg) => {
                const isMe = msg.senderGhostedId === user.ghostedId;
                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                  >
                    {activeConversation.isGroup && !isMe && (
                      <span className="text-[10px] font-semibold text-emerald-400 mb-0.5 px-1 font-mono">
                        {msg.senderName || msg.senderGhostedId}
                      </span>
                    )}
                    <div
                      className="max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed shadow-md border"
                      style={{
                        backgroundColor: isMe
                          ? (isGhost ? '#00F5FF' : isBlack ? '#000000' : '#0866FF')
                          : (isBlack ? '#F3F4F6' : '#1F1F2E'),
                        color: isMe
                          ? (isGhost ? '#000000' : '#FFFFFF')
                          : (isBlack ? '#000000' : '#FFFFFF'),
                        borderColor: currentTheme.border,
                      }}
                    >
                      <p className="whitespace-pre-wrap">{msg.text}</p>
                      <div className="flex items-center justify-end space-x-1.5 mt-1 text-[10px] opacity-70">
                        <span>{msg.timestamp}</span>
                        {msg.channel && (
                          <span className="font-mono bg-black/20 px-1 rounded uppercase text-[8px]">
                            {msg.channel}
                          </span>
                        )}
                        {isMe && (
                          <CheckCheck className="w-3.5 h-3.5 text-cyan-400 inline-block" />
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          <form onSubmit={(e) => handleSendMessage(e, 'in_app')} className="space-y-2">
            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                placeholder={`Message ${activeConversation.name}...`}
                className="flex-1 px-4 py-3 rounded-2xl text-xs focus:outline-none transition border"
                style={{
                  backgroundColor: isBlack ? '#F3F4F6' : '#141414',
                  color: currentTheme.cardText,
                  borderColor: currentTheme.border,
                }}
              />
              <button
                type="submit"
                disabled={isSending || !messageInput.trim()}
                className="p-3 disabled:opacity-40 rounded-2xl shadow-md transition flex-shrink-0 cursor-pointer border"
                style={{
                  backgroundColor: currentTheme.btnPrimaryBg,
                  color: currentTheme.btnPrimaryText,
                  borderColor: currentTheme.border,
                }}
                title="Send In-App Encrypted Message"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>

            {/* 4 PILL BUTTONS: Equal size, small font, fit in one row */}
            <div className="grid grid-cols-4 gap-1.5 w-full pt-1">
              {/* Hidden file input for Ghost Blur */}
              <input
                ref={ghostBlurInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleGhostBlurFile}
              />

              {/* 1. Text Compressor - green icon */}
              <button
                type="button"
                onClick={handleCompressText}
                className="hover:text-white flex items-center justify-center space-x-1 bg-white/5 hover:bg-white/10 px-1 py-1.5 rounded-xl border border-white/10 text-[10px] font-semibold text-zinc-300 transition active:scale-95 cursor-pointer shadow-xs truncate"
                title="Compress to 280 chars for The Void"
              >
                <Minimize2 className="w-3 h-3 text-emerald-400 flex-shrink-0" />
                <span className="truncate">Compress</span>
              </button>

              {/* 2. Ghost Blur - cyan blur icon */}
              <button
                type="button"
                onClick={() => ghostBlurInputRef.current?.click()}
                className="hover:text-white flex items-center justify-center space-x-1 bg-white/5 hover:bg-white/10 px-1 py-1.5 rounded-xl border border-white/10 text-[10px] font-semibold text-zinc-300 transition active:scale-95 cursor-pointer shadow-xs truncate"
                title="Pick image and blur faces before sending"
              >
                <EyeOff className="w-3 h-3 text-cyan-400 flex-shrink-0" />
                <span className="truncate">Ghost Blur</span>
              </button>

              {/* 3. Ghost Fonts - green ghost/bubble icon */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowFontMenu((prev) => !prev)}
                  className={`w-full flex items-center justify-center space-x-1 px-1 py-1.5 rounded-xl border transition active:scale-95 text-[10px] font-semibold cursor-pointer shadow-xs truncate ${
                    showFontMenu
                      ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-300'
                      : 'bg-white/5 hover:bg-white/10 border-white/10 text-zinc-300 hover:text-white'
                  }`}
                  title="Convert typed text to 5 spooky anonymous fonts"
                >
                  <Ghost className="w-3 h-3 text-emerald-400 flex-shrink-0" />
                  <span className="truncate">Ghost Fonts</span>
                </button>

                {showFontMenu && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setShowFontMenu(false)} />
                    <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 z-50 w-44 rounded-2xl bg-[#15151F] border border-[#2A2A3F] p-1.5 shadow-2xl space-y-1 animate-in fade-in zoom-in-95 duration-150">
                      <div className="px-2 py-1 text-[10px] font-bold text-zinc-400 uppercase tracking-wider border-b border-white/5 flex items-center justify-between">
                        <span>5 Spooky Fonts</span>
                        <Ghost className="w-3 h-3 text-emerald-400" />
                      </div>
                      {SPOOKY_FONTS.map((font) => (
                        <button
                          key={font.id}
                          type="button"
                          onClick={() => handleApplySpookyFont(font.id)}
                          className="w-full text-left px-2 py-1.5 rounded-xl hover:bg-white/10 text-xs text-white flex items-center justify-between cursor-pointer transition"
                        >
                          <span className="text-[11px] font-medium text-zinc-300">{font.name}</span>
                          <span className="text-xs text-emerald-300 font-bold">{font.preview}</span>
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </div>

              {/* 4. Vault - red flame/lock icon */}
              <button
                type="button"
                onClick={() => setShowVaultModal(true)}
                className="hover:text-white flex items-center justify-center space-x-1 bg-white/5 hover:bg-white/10 px-1 py-1.5 rounded-xl border border-white/10 text-[10px] font-semibold text-zinc-300 transition active:scale-95 cursor-pointer shadow-xs truncate"
                title="Save to private Vault with 4-digit PIN, local encrypted storage"
              >
                <Lock className="w-3 h-3 text-rose-400 flex-shrink-0" />
                <span className="truncate">Vault</span>
              </button>
            </div>

              <button
                type="button"
                onClick={() => {
                  handleToggleUnread(activeConversation.id);
                  setSelectedChatId(null);
                }}
                className="text-[10px] text-purple-300 hover:text-white underline"
              >
                Mark as Unread & Exit
              </button>
          </form>
        </div>
      ) : (
        /* MAIN CHAT HUB */
        <div
          className="p-4 sm:p-5 rounded-3xl border shadow-xl space-y-4 theme-card transition-colors duration-300"
          style={{
            backgroundColor: currentTheme.card,
            color: currentTheme.cardText,
            borderColor: currentTheme.border,
          }}
        >
          {/* Search Bar - Full Width matching Friends search bar */}
          <div className="relative w-full">
            <Search
              className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
              style={{ color: currentTheme.cardSubtext }}
            />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search chats, groups, messages..."
              className="w-full pl-10 pr-10 py-2.5 rounded-2xl text-xs font-medium focus:outline-none transition border shadow-xs"
              style={{
                backgroundColor: currentTheme.searchBg,
                color: currentTheme.searchText,
                borderColor: currentTheme.searchBorder,
              }}
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 cursor-pointer opacity-70 hover:opacity-100"
                style={{ color: currentTheme.searchText }}
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="space-y-1.5 pr-1">
            {filteredConversations.length === 0 ? (
              <div
                className="p-8 text-center rounded-2xl border space-y-3 transition-colors duration-300"
                style={{
                  backgroundColor: isBlack ? '#F9FAFB' : '#141414',
                  borderColor: currentTheme.border,
                }}
              >
                {activeSection === 'unread' ? (
                  <>
                    <div className="w-12 h-12 mx-auto rounded-full bg-emerald-500/20 text-[#25D366] flex items-center justify-center">
                      <BookmarkCheck className="w-6 h-6" />
                    </div>
                    <h4 className="font-bold text-sm" style={{ color: currentTheme.cardText }}>
                      All Caught Up!
                    </h4>
                    <p className="text-xs max-w-xs mx-auto" style={{ color: currentTheme.cardSubtext }}>
                      There are no unread messages right now. All your chats have been read.
                    </p>
                    <button
                      type="button"
                      onClick={() => setActiveSection('all')}
                      className="px-4 py-2 rounded-xl text-xs font-semibold inline-block transition cursor-pointer border"
                      style={{
                        backgroundColor: currentTheme.btnPrimaryBg,
                        color: currentTheme.btnPrimaryText,
                        borderColor: currentTheme.border,
                      }}
                    >
                      View All Chats
                    </button>
                  </>
                ) : activeSection === 'favourite' ? (
                  <>
                    <div className="w-12 h-12 mx-auto rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center">
                      <Star className="w-6 h-6 fill-amber-400 text-amber-400" />
                    </div>
                    <h4 className="font-bold text-sm" style={{ color: currentTheme.cardText }}>
                      No Favourite Chats Yet
                    </h4>
                    <p className="text-xs max-w-xs mx-auto" style={{ color: currentTheme.cardSubtext }}>
                      Tap the star icon on any conversation in the All section to pin it here!
                    </p>
                    <button
                      type="button"
                      onClick={() => setActiveSection('all')}
                      className="px-4 py-2 rounded-xl text-xs font-semibold inline-block transition cursor-pointer border"
                      style={{
                        backgroundColor: currentTheme.btnPrimaryBg,
                        color: currentTheme.btnPrimaryText,
                        borderColor: currentTheme.border,
                      }}
                    >
                      Browse All Chats
                    </button>
                  </>
                ) : activeSection === 'groups' ? (
                  <>
                    <div className="w-12 h-12 mx-auto rounded-full bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
                      <Users className="w-6 h-6" />
                    </div>
                    <h4 className="font-bold text-sm" style={{ color: currentTheme.cardText }}>
                      No Group Chats Yet
                    </h4>
                    <p className="text-xs max-w-xs mx-auto" style={{ color: currentTheme.cardSubtext }}>
                      Group conversations will appear here once active.
                    </p>
                  </>
                ) : (
                  <>
                    <div
                      className="w-12 h-12 mx-auto rounded-full flex items-center justify-center border"
                      style={{
                        backgroundColor: isBlack ? '#FFFFFF' : '#000000',
                        borderColor: currentTheme.border,
                        color: currentTheme.cardSubtext,
                      }}
                    >
                      <MessageSquare className="w-6 h-6" />
                    </div>
                    <h4 className="font-bold text-sm" style={{ color: currentTheme.cardText }}>
                      No Conversations Found
                    </h4>
                    <p className="text-xs" style={{ color: currentTheme.cardSubtext }}>
                      Try searching with another keyword or connect with a friend from the Friends tab.
                    </p>
                  </>
                )}
              </div>
            ) : (
              filteredConversations.map((convo) => (
                <div
                  key={convo.id}
                  onClick={() => handleSelectConversation(convo)}
                  className="p-3 sm:p-3.5 rounded-2xl border transition flex items-center justify-between gap-3 cursor-pointer group active:scale-[0.99] duration-200"
                  style={{
                    backgroundColor: isBlack ? '#F9FAFB' : '#141414',
                    borderColor: currentTheme.border,
                  }}
                >
                  <div className="flex items-center space-x-3.5 min-w-0 flex-1">
                    <div className="relative flex-shrink-0">
                      <div
                        className={`w-12 h-12 rounded-full bg-gradient-to-tr ${
                          convo.color || 'from-emerald-600 to-teal-700'
                        } flex items-center justify-center text-white font-bold text-base shadow-md border`}
                        style={{ borderColor: currentTheme.border }}
                      >
                        {convo.isGroup ? <Users className="w-5 h-5 text-white" /> : convo.name.charAt(0)}
                      </div>
                      {convo.isGroup ? (
                        <span className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full bg-[#00a884] border-2 border-black flex items-center justify-center text-[8px] font-bold text-white">
                          G
                        </span>
                      ) : (
                        <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-[#25D366] border-2 border-black" />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <div className="flex items-center space-x-1.5 min-w-0">
                          <h4
                            className="font-semibold text-sm sm:text-base truncate transition hover:underline"
                            style={{ color: currentTheme.cardText }}
                          >
                            {convo.name}
                          </h4>
                          {convo.isGroup && (
                            <span
                              className="text-[9px] px-1.5 py-0.2 rounded-md font-semibold border flex-shrink-0"
                              style={{
                                backgroundColor: isBlack ? '#E5E7EB' : '#1A1A1A',
                                color: currentTheme.cardText,
                                borderColor: currentTheme.border,
                              }}
                            >
                              Group
                            </span>
                          )}
                        </div>
                        <span
                          className="text-[11px] font-mono flex-shrink-0"
                          style={{
                            color: convo.unreadCount > 0 ? '#25D366' : currentTheme.cardSubtext,
                          }}
                        >
                          {convo.lastMessageTimestamp}
                        </span>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center space-x-1 min-w-0 flex-1">
                          <CheckCheck className="w-3.5 h-3.5 text-[#53bdeb] flex-shrink-0 inline" />
                          <p
                            className="text-xs truncate font-medium"
                            style={{
                              color: convo.unreadCount > 0 ? currentTheme.cardText : currentTheme.cardSubtext,
                            }}
                          >
                            {convo.lastMessageText}
                          </p>
                        </div>
                        {convo.unreadCount > 0 && (
                          <span className="min-w-[20px] h-5 rounded-full bg-[#25D366] text-black font-bold text-[11px] flex items-center justify-center px-1.5 shadow-xs flex-shrink-0">
                            {convo.unreadCount}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div
                    className="flex items-center space-x-1 flex-shrink-0 ml-1"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <button
                      type="button"
                      onClick={(e) => handleToggleFavourite(convo.id, e)}
                      className={`p-2 rounded-xl transition cursor-pointer ${
                        convo.isFavourite
                          ? 'text-amber-400 hover:text-amber-300'
                          : 'text-zinc-500 hover:text-amber-300'
                      }`}
                      title={convo.isFavourite ? 'Unstar' : 'Add to Favourite Section'}
                    >
                      <Star
                        className={`w-4 h-4 ${
                          convo.isFavourite ? 'fill-amber-400 text-amber-400' : ''
                        }`}
                      />
                    </button>

                    {!convo.isGroup && convo.targetGhostedId && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onStartCall(convo.targetGhostedId!, convo.name, 'voice');
                        }}
                        className="p-2 rounded-xl text-zinc-400 hover:text-[#00a884] hover:bg-emerald-500/10 transition cursor-pointer"
                        title="Voice Call"
                      >
                        <Phone className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* MODAL: CREATE GROUP */}
      {isCreateGroupOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-purple-500/40 p-6 space-y-5 shadow-2xl relative">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center space-x-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">Create Group Chat</h3>
                  <p className="text-[11px] text-purple-300">
                    Encrypted group chat for multiple Ghosted IDs
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateGroupOpen(false)}
                className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-purple-300 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleCreateGroup} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-purple-200 mb-1">
                  Group Name *
                </label>
                <input
                  type="text"
                  required
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  placeholder="e.g. Privacy Advocates, Weekend Crew, Core Alpha"
                  className="w-full px-3.5 py-2.5 bg-black/40 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:ring-2 focus:ring-purple-400 placeholder-purple-300/40"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-purple-200 mb-1">
                  Topic / Purpose (Optional)
                </label>
                <input
                  type="text"
                  value={newGroupTopic}
                  onChange={(e) => setNewGroupTopic(e.target.value)}
                  placeholder="e.g. Encrypted file exchange and voice sessions"
                  className="w-full px-3.5 py-2.5 bg-black/40 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:ring-2 focus:ring-purple-400 placeholder-purple-300/40"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-purple-200 mb-2">
                  Select Members to Add
                </label>
                <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
                  {availableContacts.map((contact) => {
                    const isSelected = selectedGroupMembers.includes(contact.ghostedId);
                    return (
                      <div
                        key={contact.ghostedId}
                        onClick={() => {
                          setSelectedGroupMembers((prev) =>
                            isSelected
                              ? prev.filter((id) => id !== contact.ghostedId)
                              : [...prev, contact.ghostedId]
                          );
                        }}
                        className={`p-2.5 rounded-xl border flex items-center justify-between text-xs cursor-pointer transition ${
                          isSelected
                            ? 'bg-purple-600/20 border-purple-400/50 text-white'
                            : 'bg-white/5 border-white/10 text-purple-300 hover:bg-white/10'
                        }`}
                      >
                        <div>
                          <span className="font-semibold block">{contact.name}</span>
                          <span className="font-mono text-[10px] text-purple-400">
                            {contact.ghostedId}
                          </span>
                        </div>
                        <div
                          className={`w-5 h-5 rounded-md flex items-center justify-center border ${
                            isSelected
                              ? 'bg-purple-600 border-purple-400 text-white'
                              : 'border-white/20'
                          }`}
                        >
                          {isSelected && <Check className="w-3.5 h-3.5" />}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
              <div className="flex items-center space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsCreateGroupOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-purple-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!newGroupName.trim()}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 disabled:opacity-40 text-white text-xs font-bold shadow-lg shadow-indigo-900/40"
                >
                  Create Group
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: NEW 1-ON-1 CHAT */}
      {isNewChatOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-purple-500/40 p-6 space-y-5 shadow-2xl relative">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center space-x-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">New Direct Chat</h3>
                  <p className="text-[11px] text-purple-300">
                    Connect privately with any Ghosted user
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsNewChatOpen(false)}
                className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-purple-300 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleStartNewChat} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-purple-200 mb-1">
                  Recipient Ghosted ID *
                </label>
                <input
                  type="text"
                  required
                  value={newChatTargetId}
                  onChange={(e) => setNewChatTargetId(e.target.value)}
                  placeholder="Enter recipient Ghosted ID (e.g. GH-1020-3040)"
                  className="w-full px-3.5 py-2.5 bg-black/40 border border-white/15 rounded-xl text-white text-xs font-mono focus:outline-none focus:ring-2 focus:ring-purple-400 placeholder-purple-300/40"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-purple-200 mb-1">
                  Contact Name (Optional)
                </label>
                <input
                  type="text"
                  value={newChatTargetName}
                  onChange={(e) => setNewChatTargetName(e.target.value)}
                  placeholder="Enter contact name"
                  className="w-full px-3.5 py-2.5 bg-black/40 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:ring-2 focus:ring-purple-400 placeholder-purple-300/40"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-purple-200 mb-1">
                  Cell Phone for Direct SMS / WhatsApp (Optional)
                </label>
                <input
                  type="tel"
                  value={newChatTargetPhone}
                  onChange={(e) => setNewChatTargetPhone(e.target.value)}
                  placeholder="+[Country code] [Phone number]"
                  className="w-full px-3.5 py-2.5 bg-black/40 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:ring-2 focus:ring-purple-400 placeholder-purple-300/40"
                />
              </div>
              <div>
                <span className="text-[11px] text-purple-300 font-semibold block mb-1.5">
                  Or pick a known contact:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {availableContacts.map((c) => (
                    <button
                      type="button"
                      key={c.ghostedId}
                      onClick={() => {
                        setNewChatTargetId(c.ghostedId);
                        setNewChatTargetName(c.name);
                        setNewChatTargetPhone(c.phone);
                      }}
                      className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-[11px] text-purple-200 transition"
                    >
                      {c.name}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex items-center space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsNewChatOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-purple-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!newChatTargetId.trim()}
                  className="flex-1 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white text-xs font-bold shadow-lg shadow-purple-900/40"
                >
                  Start Chat
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD MEMBER TO EXISTING GROUP */}
      {isAddMemberOpen && activeConversation?.isGroup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-purple-500/40 p-6 space-y-4 shadow-2xl relative">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="font-bold text-white text-base">Add Member to Group</h3>
              <button
                type="button"
                onClick={() => setIsAddMemberOpen(false)}
                className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-purple-300 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAddMemberToGroup} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-purple-200 mb-1">
                  Member Ghosted ID *
                </label>
                <input
                  type="text"
                  required
                  value={addMemberId}
                  onChange={(e) => setAddMemberId(e.target.value)}
                  placeholder="Enter member Ghosted ID (e.g. GH-1020-3040)"
                  className="w-full px-3.5 py-2.5 bg-black/40 border border-white/15 rounded-xl text-white text-xs font-mono focus:outline-none focus:ring-2 focus:ring-purple-400 placeholder-purple-300/40"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-purple-200 mb-1">
                  Display Name (Optional)
                </label>
                <input
                  type="text"
                  value={addMemberName}
                  onChange={(e) => setAddMemberName(e.target.value)}
                  placeholder="Enter display name"
                  className="w-full px-3.5 py-2.5 bg-black/40 border border-white/15 rounded-xl text-white text-xs focus:outline-none focus:ring-2 focus:ring-purple-400 placeholder-purple-300/40"
                />
              </div>
              <div className="flex items-center space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddMemberOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-purple-300 text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!addMemberId.trim()}
                  className="flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white text-xs font-bold"
                >
                  Add
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* SMART AD INTERSTITIAL */}
      <SmartAdInterstitial
        context="group"
        isOpen={isGroupAdOpen}
        onClose={() => setIsGroupAdOpen(false)}
      />

      {/* MODAL: VAULT (4-Digit PIN & Encrypted Local Storage) */}
      {showVaultModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-rose-500/30 p-6 space-y-4 shadow-2xl relative text-white">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center space-x-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-rose-600 to-amber-600 flex items-center justify-center text-white shadow-md">
                  <Lock className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base flex items-center space-x-1.5">
                    <span>Ghost Private Vault</span>
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40">
                      {isVaultUnlocked ? 'UNLOCKED' : 'LOCKED'}
                    </span>
                  </h3>
                  <p className="text-[11px] text-zinc-400">
                    4-digit PIN protected local encrypted storage
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowVaultModal(false);
                  setVaultPinInput('');
                }}
                className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {!isVaultUnlocked ? (
              <div className="space-y-4 py-2">
                <div className="text-center space-y-1">
                  <div className="w-12 h-12 mx-auto rounded-full bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
                    <KeyRound className="w-6 h-6" />
                  </div>
                  <h4 className="font-semibold text-sm text-zinc-200">
                    {vaultSavedPin ? 'Enter 4-Digit Vault PIN' : 'Set a New 4-Digit Vault PIN'}
                  </h4>
                  <p className="text-xs text-zinc-400 max-w-xs mx-auto">
                    {vaultSavedPin
                      ? 'Enter your secret PIN to access saved whisper notes and encrypted messages.'
                      : 'Create a 4-digit security PIN to secure this device vault.'}
                  </p>
                </div>

                <div className="flex justify-center">
                  <input
                    type="password"
                    maxLength={4}
                    inputMode="numeric"
                    pattern="[0-9]*"
                    autoFocus
                    value={vaultPinInput}
                    onChange={(e) => setVaultPinInput(e.target.value.replace(/\D/g, '').slice(0, 4))}
                    placeholder="••••"
                    className="w-36 text-center tracking-[0.5em] text-2xl font-mono py-2.5 px-3 bg-black/50 border border-rose-500/40 rounded-xl focus:outline-none focus:ring-2 focus:ring-rose-500 text-white placeholder-zinc-600"
                  />
                </div>

                <div className="flex items-center space-x-2 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      if (vaultPinInput.length !== 4) {
                        showToast('Please enter a 4-digit PIN');
                        return;
                      }
                      if (!vaultSavedPin) {
                        setVaultSavedPin(vaultPinInput);
                        try {
                          localStorage.setItem(`ghosted_vault_pin_${user.id}`, vaultPinInput);
                        } catch {}
                        setIsVaultUnlocked(true);
                        setVaultPinInput('');
                        showToast('Vault PIN created! Vault Unlocked 🔐');
                      } else {
                        if (vaultPinInput === vaultSavedPin) {
                          setIsVaultUnlocked(true);
                          setVaultPinInput('');
                          showToast('Vault Unlocked 🔐');
                        } else {
                          showToast('Incorrect PIN. Access Denied ❌');
                        }
                      }
                    }}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white text-xs font-bold shadow-lg shadow-rose-950/50 transition cursor-pointer"
                  >
                    {vaultSavedPin ? 'Unlock Vault' : 'Set PIN & Unlock'}
                  </button>
                </div>

                {vaultSavedPin && (
                  <div className="text-center">
                    <button
                      type="button"
                      onClick={() => {
                        if (window.confirm('Reset PIN? This will reset your vault PIN on this device.')) {
                          setVaultSavedPin('');
                          try {
                            localStorage.removeItem(`ghosted_vault_pin_${user.id}`);
                          } catch {}
                          showToast('Vault PIN reset. Set a new PIN.');
                        }
                      }}
                      className="text-[11px] text-zinc-500 hover:text-rose-400 underline"
                    >
                      Reset Vault PIN
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-4">
                {messageInput.trim() && (
                  <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <span className="text-[10px] uppercase font-bold text-rose-300 block">Typed Whisper</span>
                      <p className="text-xs text-zinc-300 truncate font-mono">{messageInput}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleSaveToVault(messageInput)}
                      className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-[11px] font-bold flex-shrink-0 transition cursor-pointer"
                    >
                      Save to Vault
                    </button>
                  </div>
                )}

                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-zinc-300 flex items-center space-x-1.5">
                    <Shield className="w-3.5 h-3.5 text-rose-400" />
                    <span>Encrypted Notes ({vaultEntries.length})</span>
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setIsVaultUnlocked(false);
                      showToast('Vault Locked 🔒');
                    }}
                    className="text-[11px] text-rose-400 hover:text-rose-300 font-semibold cursor-pointer"
                  >
                    Lock Vault 🔒
                  </button>
                </div>

                <div className="max-h-56 overflow-y-auto space-y-2 pr-1">
                  {vaultEntries.length === 0 ? (
                    <div className="text-center py-8 rounded-2xl bg-black/30 border border-white/5 space-y-2">
                      <Lock className="w-6 h-6 mx-auto text-zinc-600" />
                      <p className="text-xs text-zinc-400">Vault is empty.</p>
                      <p className="text-[10px] text-zinc-500">Save secrets, drafts, or keys safely here.</p>
                    </div>
                  ) : (
                    vaultEntries.map((entry) => (
                      <div
                        key={entry.id}
                        className="p-3 rounded-2xl bg-black/40 border border-white/10 space-y-1.5 group hover:border-rose-500/30 transition"
                      >
                        <div className="flex items-center justify-between text-[10px] text-zinc-500 font-mono">
                          <span>{entry.date}</span>
                          <div className="flex items-center space-x-2">
                            <button
                              type="button"
                              onClick={() => {
                                setMessageInput((prev) => (prev ? `${prev} ${entry.text}` : entry.text));
                                setShowVaultModal(false);
                                showToast('Loaded into chat input 💬');
                              }}
                              className="text-emerald-400 hover:underline cursor-pointer"
                            >
                              Insert
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                navigator.clipboard.writeText(entry.text);
                                showToast('Copied to clipboard 📋');
                              }}
                              className="text-cyan-400 hover:underline cursor-pointer"
                            >
                              Copy
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                const updated = vaultEntries.filter((v) => v.id !== entry.id);
                                setVaultEntries(updated);
                                try {
                                  localStorage.setItem(`ghosted_vault_entries_${user.id}`, JSON.stringify(updated));
                                } catch {}
                                showToast('Entry deleted from vault');
                              }}
                              className="text-rose-400 hover:text-rose-300 cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5 inline" />
                            </button>
                          </div>
                        </div>
                        <p className="text-xs text-zinc-200 whitespace-pre-wrap break-words font-mono bg-black/30 p-2 rounded-xl border border-white/5">
                          {entry.text}
                        </p>
                      </div>
                    ))
                  )}
                </div>

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => setShowVaultModal(false)}
                    className="w-full py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-zinc-300 text-xs font-semibold cursor-pointer transition"
                  >
                    Close Vault
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* WhatsApp Floating Action Button (FAB) */}
      {!selectedChatId && (
        <div className="fixed bottom-20 right-5 sm:right-8 z-30 flex flex-col items-end space-y-2.5">
          <button
            type="button"
            onClick={() => setIsNewChatOpen(true)}
            className="w-14 h-14 rounded-full bg-[#00a884] hover:bg-[#008f6f] active:scale-95 text-white shadow-2xl shadow-emerald-950/80 flex items-center justify-center cursor-pointer transition-all border border-emerald-400/30"
            title="Start New Chat"
          >
            <MessageSquare className="w-6 h-6" />
          </button>
        </div>
      )}
    </div>
  );
};
