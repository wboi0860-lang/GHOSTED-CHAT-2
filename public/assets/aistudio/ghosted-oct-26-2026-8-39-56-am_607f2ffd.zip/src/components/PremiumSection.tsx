import React, { useState } from 'react';
import { UserProfile } from '../types';
import { isUserFromNigeria } from '../utils/theme';
import { db } from '../firebase';
import { doc, setDoc } from 'firebase/firestore';
import {
  Crown,
  Sparkles,
  CheckCircle2,
  Clock,
  ShieldCheck,
  CreditCard,
  Ban,
  Check,
  X,
  Zap,
} from 'lucide-react';

interface PremiumSectionProps {
  user: UserProfile;
  onUpgradeSuccess: (updatedUser: UserProfile) => void;
}

export const PremiumSection: React.FC<PremiumSectionProps> = ({
  user,
  onUpgradeSuccess,
}) => {
  const isNigeria = isUserFromNigeria(user);

  // VIP active check: Firebase isVIP && vipExpiry in future
  const isVipActive = Boolean(
    user.isVIP && (!user.vipExpiry || new Date(user.vipExpiry).getTime() > Date.now())
  );

  // Pricing: NG ₦300/day, Others $0.50/day
  const ratePerDay = isNigeria ? 300 : 0.50;
  const currencySymbol = isNigeria ? '₦' : '$';

  // Duration options in days
  const [selectedDays, setSelectedDays] = useState<number>(1);
  const [showCheckoutModal, setShowCheckoutModal] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Checkout inputs
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvc, setCvc] = useState('');
  const [cardError, setCardError] = useState<string | null>(null);

  const totalPrice = selectedDays * ratePerDay;
  const formattedTotal = isNigeria
    ? `₦${Math.round(totalPrice).toLocaleString()}`
    : `$${totalPrice.toFixed(2)}`;

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.replace(/\D/g, '').slice(0, 16);
    val = val.replace(/(.{4})/g, '$1 ').trim();
    setCardNumber(val);
  };

  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.replace(/\D/g, '').slice(0, 4);
    if (val.length >= 2) {
      val = `${val.slice(0, 2)}/${val.slice(2)}`;
    }
    setExpiry(val);
  };

  const handleCvcChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, '').slice(0, 4);
    setCvc(val);
  };

  const handleActivateVip = async () => {
    setIsProcessing(true);
    setCardError(null);
    try {
      const now = Date.now();
      // If already VIP, extend from current expiry; otherwise start from now
      const baseTime =
        isVipActive && user.vipExpiry && new Date(user.vipExpiry).getTime() > now
          ? new Date(user.vipExpiry).getTime()
          : now;
      const newExpiryTime = baseTime + selectedDays * 24 * 60 * 60 * 1000;
      const newExpiryIso = new Date(newExpiryTime).toISOString();

      // Persist in Firebase Firestore: isVIP, vipExpiry
      const userRef = doc(db, 'users', user.id);
      await setDoc(
        userRef,
        {
          isVIP: true,
          vipExpiry: newExpiryIso,
          isPremium: true,
          hasVIP: true,
        },
        { merge: true }
      );

      const updatedUser: UserProfile = {
        ...user,
        isVIP: true,
        vipExpiry: newExpiryIso,
        isPremium: true,
        hasVIP: true,
      };

      try {
        localStorage.setItem('ghosted_user_profile', JSON.stringify(updatedUser));
      } catch {}

      onUpgradeSuccess(updatedUser);
      setShowCheckoutModal(false);
      showToast(`VIP Active! All ADS stopped for ${selectedDays} day${selectedDays > 1 ? 's' : ''}.`);
    } catch (err: any) {
      console.error('Error saving VIP to Firestore:', err);
      setCardError(err.message || 'Failed to update VIP in Firestore. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Expiry details calculation
  let remainingText = '';
  if (isVipActive && user.vipExpiry) {
    const expTime = new Date(user.vipExpiry).getTime();
    const hoursLeft = Math.max(0, Math.round((expTime - Date.now()) / (1000 * 60 * 60)));
    const daysLeft = Math.floor(hoursLeft / 24);
    const hrs = hoursLeft % 24;
    remainingText = daysLeft > 0 ? `${daysLeft}d ${hrs}h remaining` : `${hrs}h remaining`;
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-24 animate-in fade-in duration-300">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="p-3 rounded-2xl bg-purple-950/90 border border-purple-500/50 text-purple-200 text-xs flex items-center space-x-2 animate-in fade-in duration-200 shadow-xl">
          <Sparkles className="w-4 h-4 text-amber-400 flex-shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* HERO CARD: VIP = STOP ADS ONLY */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-zinc-950 via-[#180e2f] to-[#0a0518] border border-amber-500/30 p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-60 h-60 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -mb-10 -ml-10 w-60 h-60 bg-purple-500/20 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-3 max-w-xl">
            <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-amber-400/20 to-purple-400/20 border border-amber-400/40 px-3.5 py-1.5 rounded-full text-xs font-bold text-amber-300">
              <Crown className="w-4 h-4 text-amber-400" />
              <span>GHOSTED VIP • STOP ADS</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              100% Ad-Free Browsing in THE VOID
            </h2>
            <p className="text-xs sm:text-sm text-purple-200/90 leading-relaxed">
              VIP has one clear purpose: <strong>Stop ADS</strong>. Reconnect letters, DTMF cloaked calls, 24h stories, and vault features are always free with no other payment.
            </p>
            <div className="pt-2 flex flex-wrap gap-2">
              <span className="text-[11px] font-bold text-amber-300 bg-amber-500/10 border border-amber-400/30 px-3 py-1 rounded-full flex items-center space-x-1.5">
                <Ban className="w-3.5 h-3.5 text-amber-400" />
                <span>Zero Ads in THE VOID</span>
              </span>
              <span className="text-[11px] font-bold text-purple-300 bg-purple-500/15 border border-purple-400/30 px-3 py-1 rounded-full flex items-center space-x-1.5">
                <Check className="w-3.5 h-3.5 text-purple-400" />
                <span>No Other Payment Needed</span>
              </span>
            </div>
          </div>

          {/* Current VIP Status Badge Card */}
          <div className="p-5 rounded-2xl bg-black/60 border border-amber-400/30 text-center w-full md:w-auto min-w-[260px] space-y-3 shadow-xl">
            <div className="w-12 h-12 mx-auto rounded-2xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-300 shadow-lg shadow-amber-500/20">
              <Crown className="w-6 h-6" />
            </div>
            <div>
              <div className="text-[11px] uppercase tracking-wider text-purple-300/70 font-mono">Current Status</div>
              <div className="text-base font-black text-white mt-0.5">
                {isVipActive ? 'VIP Active • No ADS' : 'Standard (ADS Active)'}
              </div>
              {isVipActive && user.vipExpiry && (
                <div className="text-[11px] text-amber-300 font-mono mt-1 flex items-center justify-center space-x-1">
                  <Clock className="w-3 h-3" />
                  <span>{remainingText}</span>
                </div>
              )}
            </div>
            <div
              className={`py-2 px-3.5 rounded-xl border text-xs font-bold flex items-center justify-center space-x-1.5 ${
                isVipActive
                  ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-300'
                  : 'bg-zinc-800/80 border-white/10 text-zinc-300'
              }`}
            >
              {isVipActive ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>All ADS Blocked</span>
                </>
              ) : (
                <span>ADS every 4 posts in THE VOID</span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* PRICING & STOP ADS ACTIVATION */}
      <div className="rounded-3xl bg-zinc-950/80 border border-white/10 p-6 space-y-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-4">
          <div>
            <h3 className="text-base font-bold text-white flex items-center space-x-2">
              <span>Select Stop ADS Duration</span>
              <span className="text-xs font-normal text-amber-400 font-mono">
                ({isNigeria ? '₦300/day' : '$0.50/day'})
              </span>
            </h3>
            <p className="text-xs text-purple-300/70">
              Saved directly to Firebase. Choose how long you want to remove ads.
            </p>
          </div>
          <span className="text-xs font-bold text-purple-200 bg-purple-900/40 border border-purple-500/30 px-3 py-1 rounded-full self-start sm:self-auto font-mono">
            {isNigeria ? '🇳🇬 Nigeria Rate: ₦300/day' : '🌍 International Rate: $0.50/day'}
          </span>
        </div>

        {/* Days Selection Pills */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { days: 1, label: '1 Day', note: isNigeria ? '₦300' : '$0.50' },
            { days: 3, label: '3 Days', note: isNigeria ? '₦900' : '$1.50' },
            { days: 7, label: '7 Days', note: isNigeria ? '₦2,100' : '$3.50', popular: true },
            { days: 30, label: '30 Days', note: isNigeria ? '₦9,000' : '$15.00', value: true },
          ].map((plan) => {
            const isSelected = selectedDays === plan.days;
            return (
              <button
                key={plan.days}
                type="button"
                onClick={() => setSelectedDays(plan.days)}
                className={`p-3.5 rounded-2xl border text-left transition cursor-pointer relative flex flex-col justify-between ${
                  isSelected
                    ? 'bg-amber-500/20 border-amber-400 shadow-lg shadow-amber-500/10 ring-1 ring-amber-400/50'
                    : 'bg-black/40 border-white/10 hover:border-white/20'
                }`}
              >
                {plan.popular && (
                  <span className="absolute -top-2.5 right-3 text-[9px] font-black uppercase tracking-wider bg-purple-600 text-white px-2 py-0.5 rounded-full shadow">
                    Popular
                  </span>
                )}
                {plan.value && (
                  <span className="absolute -top-2.5 right-3 text-[9px] font-black uppercase tracking-wider bg-emerald-600 text-white px-2 py-0.5 rounded-full shadow">
                    Best Value
                  </span>
                )}
                <div>
                  <span className="text-sm font-bold text-white block">{plan.label}</span>
                  <span className="text-xs text-purple-300/70 font-mono mt-0.5 block">
                    {plan.note}
                  </span>
                </div>
                <div className="mt-3 flex items-center justify-between text-[11px]">
                  <span className="text-zinc-400">Stop ADS</span>
                  <div
                    className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                      isSelected
                        ? 'border-amber-400 bg-amber-400 text-gray-950 font-bold'
                        : 'border-white/30'
                    }`}
                  >
                    {isSelected && <Check className="w-2.5 h-2.5" />}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Action Row */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2">
          <div>
            <span className="text-xs text-purple-300/70 block">Total Price:</span>
            <span className="text-2xl font-black text-amber-300 font-mono">
              {formattedTotal}
            </span>
            <span className="text-xs text-zinc-400 ml-2">
              for {selectedDays} day{selectedDays > 1 ? 's' : ''} Stop ADS
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={() => setShowCheckoutModal(true)}
              className="py-3 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-500 hover:from-amber-400 hover:to-orange-400 text-gray-950 font-extrabold text-sm shadow-xl shadow-amber-500/25 transition cursor-pointer flex items-center space-x-2 active:scale-95"
            >
              <CreditCard className="w-4 h-4" />
              <span>{isVipActive ? 'Extend VIP (Add Days)' : 'Stop ADS (Get VIP)'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* CLARIFICATION FOOTER */}
      <div className="p-4 rounded-2xl bg-black/40 border border-white/5 text-xs text-purple-300/70 flex items-start space-x-3">
        <ShieldCheck className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-bold text-white">VIP = ADS ONLY Guarantee</p>
          <p className="leading-relaxed">
            Ghosted does not charge for reconnection letters, calling, vault archives, or status updates. VIP is purely an ad-free pass that stops all ads in THE VOID and across the application.
          </p>
        </div>
      </div>

      {/* MODAL: STOP ADS VIP CHECKOUT */}
      {showCheckoutModal && (
        <div className="fixed inset-0 z-[10020] flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-md rounded-3xl bg-[#120924] border border-amber-500/40 p-6 space-y-5 text-white shadow-2xl relative">
            <button
              type="button"
              onClick={() => setShowCheckoutModal(false)}
              className="absolute top-4 right-4 p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-purple-200 transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="space-y-1">
              <div className="inline-flex items-center space-x-1.5 text-xs font-bold text-amber-300 bg-amber-500/20 px-2.5 py-0.5 rounded-full border border-amber-400/30">
                <Crown className="w-3.5 h-3.5" />
                <span>Stop ADS Checkout</span>
              </div>
              <h3 className="text-lg font-bold text-white">
                Confirm VIP Activation
              </h3>
              <p className="text-xs text-purple-200/80">
                Stop all ads in THE VOID for {selectedDays} day{selectedDays > 1 ? 's' : ''} ({formattedTotal}).
              </p>
            </div>

            {cardError && (
              <div className="p-2.5 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-200 text-xs">
                {cardError}
              </div>
            )}

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleActivateVip();
              }}
              className="space-y-3 text-xs"
            >
              <div>
                <label className="text-purple-300 block mb-1">Card Number (Optional / Demo)</label>
                <input
                  type="text"
                  value={cardNumber}
                  onChange={handleCardNumberChange}
                  placeholder="4242 •••• •••• 4242"
                  className="w-full px-3 py-2 rounded-xl bg-black/60 border border-white/15 text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-purple-300 block mb-1">Expiry</label>
                  <input
                    type="text"
                    value={expiry}
                    onChange={handleExpiryChange}
                    placeholder="MM/YY"
                    className="w-full px-3 py-2 rounded-xl bg-black/60 border border-white/15 text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>
                <div>
                  <label className="text-purple-300 block mb-1">CVC</label>
                  <input
                    type="password"
                    value={cvc}
                    onChange={handleCvcChange}
                    placeholder="•••"
                    className="w-full px-3 py-2 rounded-xl bg-black/60 border border-white/15 text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-purple-950/40 border border-purple-500/30 text-[11px] text-purple-200/80 flex items-center justify-between">
                <span>Total to pay:</span>
                <span className="font-bold text-amber-300 font-mono text-sm">{formattedTotal}</span>
              </div>

              <div className="flex items-center space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCheckoutModal(false)}
                  className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-purple-200 font-semibold cursor-pointer transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-purple-600 hover:from-amber-400 hover:to-purple-500 text-white font-bold cursor-pointer transition shadow-lg disabled:opacity-50 flex items-center justify-center space-x-1.5"
                >
                  {isProcessing ? (
                    <span>Saving to Firebase...</span>
                  ) : (
                    <>
                      <span>Pay & Stop ADS</span>
                      <Zap className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
