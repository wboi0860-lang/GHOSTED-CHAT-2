import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getFirestore,
  Firestore,
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
} from 'firebase/firestore';
import { getAuth, GoogleAuthProvider, Auth, signInAnonymously, onAuthStateChanged, User } from 'firebase/auth';
import { getStorage, FirebaseStorage } from 'firebase/storage';
import firebaseConfig from '../firebase-applet-config.json';

// Initialize Firebase
export const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// Initialize Auth
export const auth: Auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account',
});

// Initialize Storage
export const storage: FirebaseStorage = getStorage(app);

// Initialize Firestore with offline persistence targeting provisioned database ID
let firestoreDb: Firestore;
try {
  firestoreDb = firebaseConfig.firestoreDatabaseId
    ? initializeFirestore(
        app,
        {
          localCache: persistentLocalCache({
            tabManager: persistentMultipleTabManager(),
          }),
        },
        firebaseConfig.firestoreDatabaseId
      )
    : initializeFirestore(app, {
        localCache: persistentLocalCache({
          tabManager: persistentMultipleTabManager(),
        }),
      });
} catch {
  firestoreDb = firebaseConfig.firestoreDatabaseId
    ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
    : getFirestore(app);
}

export const db: Firestore = firestoreDb;

// Ensure user has a valid Firebase Auth session before publishing
export async function ensureAuthenticated(): Promise<User | null> {
  if (auth.currentUser) return auth.currentUser;
  try {
    const cred = await signInAnonymously(auth);
    return cred.user;
  } catch (err) {
    console.warn('Auto anonymous auth note:', err);
    return auth.currentUser;
  }
}

// Ensure auth session on client launch
if (typeof window !== 'undefined') {
  onAuthStateChanged(auth, (u) => {
    if (!u) {
      signInAnonymously(auth).catch(() => {});
    }
  });
}

// Web Push / FCM Notification Helper
export async function requestNotificationPermission(): Promise<boolean> {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return false;
  }
  try {
    if (Notification.permission === 'granted') {
      return true;
    }
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  } catch (err) {
    console.warn('Error requesting notification permission:', err);
    return false;
  }
}

/**
 * Trigger an incoming call alert (System Notification + vibration)
 */
export function triggerIncomingCallAlert(callerName: string, callerId: string): void {
  // Vibration API if supported
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate([500, 250, 500, 250, 800]);
    } catch {
      // ignore
    }
  }

  // System Notification / FCM simulated push alert
  if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
    try {
      const notif = new Notification(`Ghosted Call: ${callerName || callerId}`, {
        body: `Encrypted call incoming from ${callerId}. Tap to answer.`,
        icon: '/favicon.ico',
        tag: 'ghosted-incoming-call',
        requireInteraction: true,
      });
      notif.onclick = () => {
        window.focus();
        notif.close();
      };
    } catch {
      // Notification constructor might fail in some iframe environments
    }
  }
}
