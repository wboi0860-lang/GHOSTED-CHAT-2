import { GiftType } from '../types';

/**
 * Valid Lottie JSON data structures for the 6 Ghost gifts.
 * These can be fed directly to lottie-react without external network dependencies.
 */

// Helper to build a clean pulsing Lottie object
function makeLottie(colorRgb: [number, number, number], shapeType: string) {
  return {
    v: '5.5.7',
    fr: 30,
    ip: 0,
    op: 90,
    w: 300,
    h: 300,
    nm: shapeType,
    ddd: 0,
    assets: [],
    layers: [
      {
        ddd: 0,
        ind: 1,
        ty: 4,
        nm: 'Shape',
        sr: 1,
        ks: {
          o: { a: 0, k: 100 },
          r: {
            a: 1,
            k: [
              { t: 0, s: [0] },
              { t: 45, s: [10] },
              { t: 90, s: [0] },
            ],
          },
          p: { a: 0, k: [150, 150, 0] },
          a: { a: 0, k: [0, 0, 0] },
          s: {
            a: 1,
            k: [
              { t: 0, s: [90, 90, 100] },
              { t: 45, s: [115, 115, 100] },
              { t: 90, s: [90, 90, 100] },
            ],
          },
        },
        ao: 0,
        shapes: [
          {
            ty: 'gr',
            it: [
              {
                d: 1,
                ty: 'el',
                s: { a: 0, k: [140, 140] },
                p: { a: 0, k: [0, 0] },
                nm: 'Circle',
              },
              {
                ty: 'fl',
                c: { a: 0, k: [colorRgb[0] / 255, colorRgb[1] / 255, colorRgb[2] / 255, 1] },
                o: { a: 0, k: 85 },
                r: 1,
                bm: 0,
                nm: 'Fill',
              },
              {
                ty: 'st',
                c: { a: 0, k: [1, 1, 1, 1] },
                o: { a: 0, k: 90 },
                w: { a: 0, k: 6 },
                lc: 2,
                lj: 2,
                nm: 'Stroke',
              },
              {
                ty: 'tr',
                p: { a: 0, k: [0, 0] },
                a: { a: 0, k: [0, 0] },
                s: { a: 0, k: [100, 100] },
                r: { a: 0, k: 0 },
                o: { a: 0, k: 100 },
                sk: { a: 0, k: 0 },
                sa: { a: 0, k: 0 },
                nm: 'Transform',
              },
            ],
            nm: 'Group',
          },
        ],
        ip: 0,
        op: 90,
        st: 0,
        bm: 0,
      },
    ],
  };
}

export const LOTTIE_DATA: Record<GiftType, any> = {
  little_ghost: makeLottie([168, 85, 247], 'LittleGhost'),
  purple_smoke: makeLottie([139, 92, 246], 'PurpleSmoke'),
  haunted_eye: makeLottie([236, 72, 153], 'HauntedEye'),
  ghost_fire: makeLottie([249, 115, 22], 'GhostFire'),
  skull_rain: makeLottie([6, 182, 212], 'SkullRain'),
  ghost_king: makeLottie([234, 179, 8], 'GhostKing'),
};
