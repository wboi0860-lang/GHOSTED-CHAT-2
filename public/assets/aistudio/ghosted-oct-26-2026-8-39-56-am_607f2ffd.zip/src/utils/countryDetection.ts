import { UserProfile } from '../types';
import { db } from '../firebase';
import { doc, setDoc } from 'firebase/firestore';

export interface CountryVipResult {
  userCountry: string;
  isNigeria: boolean;
  hasVIP: boolean;
  isVIPFree: boolean;
}

/**
 * Determine if device/locale/profile indicators match Nigeria
 */
export function checkIsNigeria(countryOrTz?: string): boolean {
  if (!countryOrTz) return false;
  const val = countryOrTz.trim().toLowerCase();
  return (
    val === 'ng' ||
    val === 'nigeria' ||
    val.includes('nigeria') ||
    val.includes('lagos') ||
    val.includes('africa/lagos') ||
    val.includes('abuja') ||
    val.includes('enugu') ||
    val.includes('port harcourt') ||
    val.includes('ibadan')
  );
}

/**
 * Synchronous local check based on timezone, language and profile
 */
export function getInitialCountryAndVip(user?: UserProfile | null): CountryVipResult {
  let detectedCountry = user?.userCountry || user?.country || user?.stateCountry || '';
  const tz = typeof Intl !== 'undefined' ? Intl.DateTimeFormat().resolvedOptions().timeZone || '' : '';
  const lang = typeof navigator !== 'undefined' ? navigator.language || '' : '';

  let isNigeria = false;

  // 1. Check timezone contains "Lagos"
  if (tz.toLowerCase().includes('lagos')) {
    isNigeria = true;
    if (!detectedCountry) detectedCountry = 'Nigeria';
  }

  // 2. Check country == "NG" or "Nigeria"
  if (!isNigeria && detectedCountry && checkIsNigeria(detectedCountry)) {
    isNigeria = true;
    detectedCountry = 'Nigeria';
  }

  // 3. Check navigator.language
  if (!isNigeria && (lang.toUpperCase().includes('-NG') || lang.toUpperCase() === 'NG')) {
    isNigeria = true;
    detectedCountry = 'Nigeria';
  }

  // Default fallback if not detected
  if (!detectedCountry) {
    detectedCountry = isNigeria ? 'Nigeria' : 'United States';
  }

  const hasVIP = isNigeria ? true : Boolean(user?.hasVIP || user?.isPremium);
  const isVIPFree = isNigeria;

  return {
    userCountry: detectedCountry,
    isNigeria,
    hasVIP,
    isVIPFree,
  };
}

/**
 * Full detection using IP API https://ipapi.co/json/ with device locale fallback
 */
export async function detectUserCountry(user?: UserProfile | null): Promise<CountryVipResult> {
  const local = getInitialCountryAndVip(user);
  if (local.isNigeria) {
    return local;
  }

  // Try fetching IP API https://ipapi.co/json/
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3000);
    const res = await fetch('https://ipapi.co/json/', {
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    if (res.ok) {
      const data = await res.json();
      const countryCode = (data.country_code || '').toUpperCase();
      const countryName = data.country_name || '';
      const timezone = (data.timezone || '').toLowerCase();
      const isNigeriaFromIp =
        countryCode === 'NG' ||
        countryName.toLowerCase() === 'nigeria' ||
        timezone.includes('lagos');

      const finalCountry = isNigeriaFromIp ? 'Nigeria' : countryName || countryCode || local.userCountry;
      const isNigeria = isNigeriaFromIp;
      const isVIPFree = isNigeria;
      const hasVIP = isNigeria ? true : Boolean(user?.hasVIP || user?.isPremium);

      return {
        userCountry: finalCountry,
        isNigeria,
        hasVIP,
        isVIPFree,
      };
    }
  } catch (err) {
    // Timeout or network error, fallback to local detection
  }

  return local;
}

/**
 * Store userCountry and isVIPFree in Firestore user doc
 */
export async function storeUserCountryAndVipInFirestore(
  userId: string,
  userCountry: string,
  isVIPFree: boolean,
  hasVIP: boolean
): Promise<void> {
  if (!userId) return;
  try {
    const userDocRef = doc(db, 'users', userId);
    await setDoc(
      userDocRef,
      {
        userCountry,
        isVIPFree,
        hasVIP,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (err) {
    console.warn('Error saving userCountry and isVIPFree in Firestore:', err);
  }
}
