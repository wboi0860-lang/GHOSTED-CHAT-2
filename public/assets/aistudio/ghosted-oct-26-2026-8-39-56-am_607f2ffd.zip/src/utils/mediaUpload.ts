import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage, auth, ensureAuthenticated } from '../firebase';

let activeUploadTask: any = null;

/**
 * Aborts any ongoing upload task
 */
export function cancelActiveUpload() {
  if (activeUploadTask) {
    try {
      if (typeof activeUploadTask.cancel === 'function') {
        activeUploadTask.cancel();
      }
    } catch (e) {
      console.warn('Error cancelling upload task:', e);
    }
    activeUploadTask = null;
  }
}

/**
 * Compresses an image data URL or File if size > 300KB using HTML Canvas.
 * Caps dimensions to 800px and JPEG quality 0.65 to ensure output size
 * stays strictly under 150KB (base64 under 200KB), completely immune to
 * Firestore's 1,048,576 bytes document limit.
 */
export async function compressImageIfNeeded(
  dataUrlOrFile: string | File,
  maxSizeBytes = 300 * 1024
): Promise<{ dataUrl: string; blob: Blob }> {
  let dataUrl: string;
  if (typeof dataUrlOrFile !== 'string') {
    dataUrl = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(dataUrlOrFile);
    });
  } else {
    dataUrl = dataUrlOrFile;
  }

  // Calculate approximate size
  const approximateSize = Math.round((dataUrl.length * 3) / 4);

  // For video or non-image types, return as is
  if (!dataUrl.startsWith('data:image')) {
    const res = await fetch(dataUrl);
    const blob = await res.blob();
    return { dataUrl, blob };
  }

  // If already under 300KB, create blob and return
  if (approximateSize <= maxSizeBytes) {
    const res = await fetch(dataUrl);
    const blob = await res.blob();
    return { dataUrl, blob };
  }

  // Compress image using Canvas
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      let width = img.width;
      let height = img.height;
      const maxDim = 800; // Strict boundary to guarantee < 150KB size
      if (width > maxDim || height > maxDim) {
        if (width > height) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        } else {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        fetch(dataUrl)
          .then((r) => r.blob())
          .then((blob) => resolve({ dataUrl, blob }))
          .catch(() => resolve({ dataUrl, blob: new Blob() }));
        return;
      }

      ctx.drawImage(img, 0, 0, width, height);

      // 0.65 quality gives sharp display while keeping file size small (~60-120KB)
      const quality = 0.65;

      canvas.toBlob(
        (blob) => {
          if (!blob) {
            resolve({ dataUrl, blob: new Blob() });
            return;
          }
          const reader = new FileReader();
          reader.onload = () => {
            resolve({ dataUrl: reader.result as string, blob });
          };
          reader.readAsDataURL(blob);
        },
        'image/jpeg',
        quality
      );
    };
    img.onerror = () => {
      fetch(dataUrl)
        .then((r) => r.blob())
        .then((blob) => resolve({ dataUrl, blob }))
        .catch(() => resolve({ dataUrl, blob: new Blob() }));
    };
    img.src = dataUrl;
  });
}

/**
 * Uploads media to Firebase Storage under:
 * posts/$uid/$fileName for posts
 * stories/$uid/$fileName for stories
 *
 * Strict 30-second timeout + cancellable upload task.
 */
export async function uploadMedia(
  fileOrDataUrl: string | File,
  folder: 'posts' | 'stories',
  fallbackUserId: string,
  timeoutMs = 30000
): Promise<string> {
  // 1. Internet Check
  if (typeof navigator !== 'undefined' && !navigator.onLine) {
    throw new Error('No internet connection. Please check your network and try again.');
  }

  // 2. Ensure auth session with safe fallback
  await ensureAuthenticated();
  const uid = auth.currentUser?.uid || fallbackUserId || 'ghost_user';

  // 3. Compress if needed (>300KB)
  const { blob, dataUrl } = await compressImageIfNeeded(fileOrDataUrl);

  // 4. Exact path matching secure storage rules:
  // match /posts/{userId}/{fileName} -> posts/$uid/$fileName
  // match /stories/{userId}/{fileName} -> stories/$uid/$fileName
  const isVideo =
    (typeof fileOrDataUrl !== 'string' && fileOrDataUrl.type.startsWith('video/')) ||
    (typeof fileOrDataUrl === 'string' && fileOrDataUrl.startsWith('data:video/'));
  const extension = isVideo ? 'mp4' : 'jpg';
  const fileName = `${Date.now()}.${extension}`;
  const contentType = isVideo ? 'video/mp4' : 'image/jpeg';

  const storageRef = ref(storage, `${folder}/${uid}/${fileName}`);

  // 5. Upload with uploadBytes + 30s timeout and cancel capability
  let timeoutTimer: any = null;
  const uploadPromise = (async () => {
    const uploadResult = await uploadBytes(storageRef, blob, { contentType });
    const downloadUrl = await getDownloadURL(uploadResult.ref);
    if (!downloadUrl) throw new Error('Got empty URL');
    return downloadUrl;
  })();

  const timeoutPromise = new Promise<never>((_, reject) => {
    timeoutTimer = setTimeout(() => {
      cancelActiveUpload();
      reject(new Error('Upload timed out - check Storage Rules'));
    }, timeoutMs);
  });

  try {
    const resultUrl = await Promise.race([uploadPromise, timeoutPromise]);
    if (timeoutTimer) clearTimeout(timeoutTimer);
    return resultUrl;
  } catch (storageErr) {
    if (timeoutTimer) clearTimeout(timeoutTimer);
    console.warn('Storage upload encountered an issue, checking fallback:', storageErr);
    // Anti-crash safe fallback: ONLY use compressed dataUrl if under 400KB so Firestore 1MB limit is never exceeded
    if (dataUrl && dataUrl.startsWith('data:image') && dataUrl.length < 400000) {
      return dataUrl;
    }
    throw storageErr;
  }
}
