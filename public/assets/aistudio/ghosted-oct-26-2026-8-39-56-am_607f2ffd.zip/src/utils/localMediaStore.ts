import { GhostPost } from '../types';

const DB_NAME = 'ghosted_media_db';
const DB_VERSION = 1;
const MEDIA_STORE = 'media_blobs';
const POSTS_STORE = 'user_posts';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB not supported'));
      return;
    }
    const request = window.indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(MEDIA_STORE)) {
        db.createObjectStore(MEDIA_STORE, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(POSTS_STORE)) {
        db.createObjectStore(POSTS_STORE, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Saves a heavy media blob (video dataUrl or large image) to IndexedDB
 */
export async function saveLocalMediaBlob(postId: string, dataUrl: string): Promise<void> {
  if (!postId || !dataUrl) return;
  try {
    const db = await openDB();
    const tx = db.transaction(MEDIA_STORE, 'readwrite');
    const store = tx.objectStore(MEDIA_STORE);
    store.put({ id: postId, dataUrl, updatedAt: Date.now() });
  } catch (err) {
    console.warn('saveLocalMediaBlob note:', err);
  }
}

/**
 * Retrieves a media blob by postId from IndexedDB
 */
export async function getLocalMediaBlob(postId: string): Promise<string | null> {
  if (!postId) return null;
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const tx = db.transaction(MEDIA_STORE, 'readonly');
      const store = tx.objectStore(MEDIA_STORE);
      const req = store.get(postId);
      req.onsuccess = () => {
        resolve(req.result ? req.result.dataUrl : null);
      };
      req.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

/**
 * Saves a full user post object to IndexedDB so it never disappears on tab navigation
 */
export async function saveLocalUserPost(post: GhostPost): Promise<void> {
  if (!post || !post.id) return;
  try {
    const db = await openDB();
    const tx = db.transaction(POSTS_STORE, 'readwrite');
    const store = tx.objectStore(POSTS_STORE);
    store.put(post);
  } catch (err) {
    console.warn('saveLocalUserPost note:', err);
  }
}

/**
 * Retrieves all user posts preserved in IndexedDB
 */
export async function getLocalUserPosts(): Promise<GhostPost[]> {
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const tx = db.transaction(POSTS_STORE, 'readonly');
      const store = tx.objectStore(POSTS_STORE);
      const req = store.getAll();
      req.onsuccess = () => {
        resolve(Array.isArray(req.result) ? req.result : []);
      };
      req.onerror = () => resolve([]);
    });
  } catch {
    return [];
  }
}

/**
 * Deletes a post from IndexedDB permanently
 */
export async function deleteLocalUserPost(postId: string): Promise<void> {
  if (!postId) return;
  try {
    const db = await openDB();
    const tx = db.transaction([POSTS_STORE, MEDIA_STORE], 'readwrite');
    tx.objectStore(POSTS_STORE).delete(postId);
    tx.objectStore(MEDIA_STORE).delete(postId);
  } catch (err) {
    console.warn('deleteLocalUserPost note:', err);
  }
}

/**
 * Generates a lightweight JPEG thumbnail (< 30KB) from a video dataUrl or blob URL.
 * Used for instant Firestore persistence without exceeding the 1MB document limit.
 */
export async function generateVideoThumbnail(videoUrl: string): Promise<string> {
  if (!videoUrl) return '';
  return new Promise((resolve) => {
    try {
      const video = document.createElement('video');
      video.crossOrigin = 'anonymous';
      video.muted = true;
      video.playsInline = true;
      video.preload = 'metadata';

      const timer = setTimeout(() => {
        resolve('');
      }, 4000);

      video.onloadeddata = () => {
        try {
          video.currentTime = Math.min(0.5, (video.duration || 1) / 2);
        } catch {
          // fallback
        }
      };

      video.onseeked = () => {
        clearTimeout(timer);
        try {
          const canvas = document.createElement('canvas');
          const maxDim = 320;
          let w = video.videoWidth || 320;
          let h = video.videoHeight || 240;
          if (w > maxDim || h > maxDim) {
            if (w > h) {
              h = Math.round((h * maxDim) / w);
              w = maxDim;
            } else {
              w = Math.round((w * maxDim) / h);
              h = maxDim;
            }
          }
          canvas.width = Math.max(1, w);
          canvas.height = Math.max(1, h);
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(video, 0, 0, w, h);
            const thumb = canvas.toDataURL('image/jpeg', 0.65);
            resolve(thumb);
            return;
          }
        } catch (e) {
          console.warn('Thumbnail generation warning:', e);
        }
        resolve('');
      };

      video.onerror = () => {
        clearTimeout(timer);
        resolve('');
      };

      video.src = videoUrl;
    } catch {
      resolve('');
    }
  });
}
