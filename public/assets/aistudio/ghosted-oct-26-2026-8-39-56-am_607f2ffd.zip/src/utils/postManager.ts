import { db } from '../firebase';
import { doc, deleteDoc, updateDoc, collection, getDocs, query, where } from 'firebase/firestore';
import { deleteLocalUserPost } from './localMediaStore';

/**
 * Permanently deletes a post across all collections, comments, and local caches,
 * broadcasting an event so all active views (Home Feed, Profile, etc.) remove it immediately.
 */
export async function permanentlyDeletePost(postId: string, userId: string): Promise<void> {
  if (!postId) return;

  // 0. Remove from IndexedDB media store
  try {
    await deleteLocalUserPost(postId);
  } catch {}

  // 1. Mark isDeleted in Firestore first so real-time listeners across all devices immediately filter it
  try {
    await updateDoc(doc(db, 'posts', postId), { isDeleted: true });
  } catch {
    // If doc cannot be updated, proceed to deleteDoc directly
  }

  // 2. Permanently delete from 'posts' collection
  try {
    await deleteDoc(doc(db, 'posts', postId));
  } catch (err) {
    console.warn('deleteDoc error on posts:', err);
  }

  // 3. Permanently delete from fallback 'ghost_posts'
  try {
    await deleteDoc(doc(db, 'ghost_posts', postId));
  } catch {}

  // 4. Delete associated comments in 'post_comments'
  try {
    const commQuery = query(collection(db, 'post_comments'), where('postId', '==', postId));
    const commSnap = await getDocs(commQuery);
    const deletePromises = commSnap.docs.map((d) => deleteDoc(doc(db, 'post_comments', d.id)).catch(() => {}));
    await Promise.allSettled(deletePromises);
  } catch (err) {
    console.warn('Error deleting associated comments:', err);
  }

  // 5. Update local storage caches for instant UI synchronization
  try {
    const cachedFeed = localStorage.getItem('ghosted_cached_feed_posts');
    if (cachedFeed) {
      const parsed = JSON.parse(cachedFeed);
      if (Array.isArray(parsed)) {
        localStorage.setItem(
          'ghosted_cached_feed_posts',
          JSON.stringify(parsed.filter((p: any) => p.id !== postId))
        );
      }
    }

    if (userId) {
      const userCached = localStorage.getItem(`ghosted_user_posts_${userId}`);
      if (userCached) {
        const parsedUser = JSON.parse(userCached);
        if (Array.isArray(parsedUser)) {
          localStorage.setItem(
            `ghosted_user_posts_${userId}`,
            JSON.stringify(parsedUser.filter((p: any) => p.id !== postId))
          );
        }
      }

      const deletedIds: string[] = JSON.parse(
        localStorage.getItem(`ghosted_deleted_posts_${userId}`) || '[]'
      );
      if (!deletedIds.includes(postId)) {
        deletedIds.push(postId);
        localStorage.setItem(`ghosted_deleted_posts_${userId}`, JSON.stringify(deletedIds));
      }
    }
  } catch (storageErr) {
    console.warn('Error updating local storage on post delete:', storageErr);
  }

  // 6. Broadcast event across tabs/components so Feed & Profile state update immediately
  if (typeof window !== 'undefined') {
    window.dispatchEvent(
      new CustomEvent('ghosted_post_deleted', {
        detail: { postId },
      })
    );
  }
}
