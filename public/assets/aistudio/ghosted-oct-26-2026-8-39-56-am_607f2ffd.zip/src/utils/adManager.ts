import { UserProfile } from '../types';

export type AdTriggerContext = 'call' | 'vault' | 'group' | 'post';

export interface SponsorBrand {
  name: string;
  tagline: string;
  logo: string; // Emoji or short badge
  accentColor: string;
  ctaText: string;
  website: string;
}

export const SPONSOR_BRANDS: SponsorBrand[] = [
  {
    name: 'Flutterwave',
    tagline: 'Endless possibilities. Send & receive payments across Africa seamlessly.',
    logo: '🦋',
    accentColor: 'from-amber-500 to-orange-600',
    ctaText: 'Explore Flutterwave',
    website: 'https://flutterwave.com',
  },
  {
    name: 'MTN 5G Pulse',
    tagline: 'Everywhere you go. Connect with low latency on the fastest cellular grid.',
    logo: '🟡',
    accentColor: 'from-yellow-500 to-amber-600',
    ctaText: 'Upgrade to 5G',
    website: 'https://www.mtn.com',
  },
  {
    name: 'Chipper Cash',
    tagline: 'Move money borderless. Fast peer-to-peer transfers with zero hidden fees.',
    logo: '💚',
    accentColor: 'from-emerald-500 to-teal-600',
    ctaText: 'Claim Free Transfer',
    website: 'https://chippercash.com',
  },
  {
    name: 'PiggyVest',
    tagline: 'Better savings, smarter investments. Lock away funds with automated returns.',
    logo: '🐷',
    accentColor: 'from-blue-500 to-indigo-600',
    ctaText: 'Start Saving Now',
    website: 'https://piggyvest.com',
  },
  {
    name: 'Calm Sanctuary',
    tagline: 'Reduce anxiety and find emotional balance through 10-minute guided pauses.',
    logo: '🌿',
    accentColor: 'from-purple-500 to-pink-600',
    ctaText: 'Breathe Free',
    website: 'https://calm.com',
  },
];

const STORAGE_KEY_DATE = 'ghosted_ads_shown_date';
const STORAGE_KEY_COUNT = 'ghosted_ads_shown_count';
const STORAGE_KEY_LAST_TIME = 'ghosted_last_ad_time';

const MAX_ADS_PER_DAY = 6;
const COOLDOWN_MS = 12 * 60 * 1000; // 12 minutes

export const ADMOB_INTERSTITIAL_UNIT_ID = 'ca-app-pub-3940256099942544/1033173712';

function getTodayString(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function getAdsShownToday(): number {
  if (typeof window === 'undefined') return 0;
  const today = getTodayString();
  const savedDate = localStorage.getItem(STORAGE_KEY_DATE);
  if (savedDate !== today) {
    localStorage.setItem(STORAGE_KEY_DATE, today);
    localStorage.setItem(STORAGE_KEY_COUNT, '0');
    return 0;
  }
  const count = parseInt(localStorage.getItem(STORAGE_KEY_COUNT) || '0', 10);
  return isNaN(count) ? 0 : count;
}

export function getLastAdTime(): number {
  if (typeof window === 'undefined') return 0;
  const time = parseInt(localStorage.getItem(STORAGE_KEY_LAST_TIME) || '0', 10);
  return isNaN(time) ? 0 : time;
}

export function isVipActive(user?: UserProfile | null): boolean {
  if (!user) return false;
  if (!user.isVIP) return false;
  if (!user.vipExpiry) return true;
  const time = new Date(user.vipExpiry).getTime();
  return !isNaN(time) && time > Date.now();
}

/**
 * Checks whether an ad should be displayed based on user VIP status, location, daily limits, and 12-min cooldown.
 * Rules:
 * 1. If VIP active: NEVER show ad.
 * 2. If adsShownToday >= 6: skip ad.
 * 3. If lastAdTime < 12 mins ago: skip ad.
 */
export function shouldShowAd(user: UserProfile, isNigeria?: boolean): boolean {
  // If VIP active -> 100% ad-free experience (VIP = Stop ADS)
  if (isVipActive(user)) {
    return false;
  }

  // Check daily limit (max 6 per day)
  const countToday = getAdsShownToday();
  if (countToday >= MAX_ADS_PER_DAY) {
    return false;
  }

  // Check 12-minute cooldown
  const lastTime = getLastAdTime();
  if (lastTime > 0 && Date.now() - lastTime < COOLDOWN_MS) {
    return false;
  }

  return true;
}

export function recordAdShown(): void {
  if (typeof window === 'undefined') return;
  const today = getTodayString();
  const count = getAdsShownToday() + 1;
  localStorage.setItem(STORAGE_KEY_DATE, today);
  localStorage.setItem(STORAGE_KEY_COUNT, count.toString());
  localStorage.setItem(STORAGE_KEY_LAST_TIME, Date.now().toString());
}

export function getSponsoredTitle(context: AdTriggerContext, brandName: string): string {
  switch (context) {
    case 'call':
      return `This Ghost Call was kept free by ${brandName}`;
    case 'vault':
      return `This Ghost Vault was kept free by ${brandName}`;
    case 'group':
      return `This Ghost Group was kept free by ${brandName}`;
    case 'post':
      return `This Ghost Post was kept free by ${brandName}`;
  }
}
