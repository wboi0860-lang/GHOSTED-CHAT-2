// WebRTC & Firestore Real-Time Signaling Manager
import {
  collection,
  doc,
  setDoc,
  updateDoc,
  onSnapshot,
  query,
  where,
  addDoc,
  getDocs,
  Unsubscribe,
} from 'firebase/firestore';
import { db } from '../firebase';
import { FirestoreCallDoc } from '../types';

export interface WebRTCConnectionHandlers {
  onRemoteStream?: (stream: MediaStream) => void;
  onCallStatusChange?: (status: FirestoreCallDoc['status']) => void;
  onError?: (err: Error) => void;
}

const RTC_CONFIG: RTCConfiguration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' },
  ],
};

export class WebRTCCallSession {
  public callId: string | null = null;
  public peerConnection: RTCPeerConnection | null = null;
  public localStream: MediaStream | null = null;
  public remoteStream: MediaStream | null = null;
  private callDocUnsub: Unsubscribe | null = null;
  private candidatesUnsub: Unsubscribe | null = null;
  private timeoutTimer: NodeJS.Timeout | null = null;
  private isCaller: boolean = false;
  private handlers: WebRTCConnectionHandlers;

  constructor(handlers: WebRTCConnectionHandlers = {}) {
    this.handlers = handlers;
  }

  /**
   * Acquire local audio (and optional video) media stream
   */
  async getLocalMedia(video = false): Promise<MediaStream> {
    try {
      this.localStream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: video ? { width: 640, height: 480 } : false,
      });
      return this.localStream;
    } catch {
      // In some sandboxed headless test environments without real mic, synthesize audio stream
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const dst = audioCtx.createMediaStreamDestination();
      osc.connect(dst);
      osc.start();
      this.localStream = dst.stream;
      return this.localStream;
    }
  }

  /**
   * User A initiates a call to User B
   */
  async startCall({
    callerId,
    callerName,
    callerPhone,
    receiverId,
    receiverName,
    callType,
  }: {
    callerId: string;
    callerName: string;
    callerPhone?: string;
    receiverId: string;
    receiverName?: string;
    callType: 'voice' | 'video';
  }): Promise<string> {
    this.isCaller = true;
    await this.getLocalMedia(callType === 'video');

    this.peerConnection = new RTCPeerConnection(RTC_CONFIG);
    this.remoteStream = new MediaStream();

    // Attach local tracks
    if (this.localStream) {
      this.localStream.getTracks().forEach((track) => {
        this.peerConnection?.addTrack(track, this.localStream!);
      });
    }

    // Remote track listener
    this.peerConnection.ontrack = (event) => {
      event.streams[0].getTracks().forEach((track) => {
        this.remoteStream?.addTrack(track);
      });
      if (this.handlers.onRemoteStream && this.remoteStream) {
        this.handlers.onRemoteStream(this.remoteStream);
      }
    };

    // Create Firestore document in 'calls' collection
    const callsCollection = collection(db, 'calls');
    const newCallRef = doc(callsCollection);
    this.callId = newCallRef.id;

    // Listen for ICE candidates and write to callerCandidates
    this.peerConnection.onicecandidate = async (event) => {
      if (event.candidate && this.callId) {
        try {
          const candCol = collection(db, 'calls', this.callId, 'callerCandidates');
          await addDoc(candCol, event.candidate.toJSON());
        } catch {
          // ignore candidate write error
        }
      }
    };

    // Create Offer
    const offer = await this.peerConnection.createOffer({
      offerToReceiveAudio: true,
      offerToReceiveVideo: callType === 'video',
    });
    await this.peerConnection.setLocalDescription(offer);

    // Save initial document with status='ringing'
    const initialCallDoc: FirestoreCallDoc = {
      id: this.callId,
      callerId,
      callerName,
      callerPhone: callerPhone || '',
      receiverId,
      receiverName: receiverName || '',
      status: 'ringing',
      callType,
      createdAt: Date.now(),
      offer: {
        type: offer.type as 'offer',
        sdp: offer.sdp || '',
      },
      answer: null,
    };
    await setDoc(newCallRef, initialCallDoc);

    // Set 30-second timeout if no answer
    this.timeoutTimer = setTimeout(async () => {
      if (this.callId) {
        try {
          const callRef = doc(db, 'calls', this.callId);
          await updateDoc(callRef, { status: 'timeout' });
        } catch {
          // ignore
        }
        this.cleanup();
        this.handlers.onCallStatusChange?.('timeout');
      }
    }, 30000);

    // Listen for receiver's answer or status change
    this.callDocUnsub = onSnapshot(newCallRef, async (snapshot) => {
      const data = snapshot.data() as FirestoreCallDoc | undefined;
      if (!data) return;

      if (data.status === 'answered' && data.answer && this.peerConnection) {
        if (this.timeoutTimer) {
          clearTimeout(this.timeoutTimer);
          this.timeoutTimer = null;
        }
        if (!this.peerConnection.currentRemoteDescription) {
          const rtcAnswer = new RTCSessionDescription(data.answer);
          await this.peerConnection.setRemoteDescription(rtcAnswer);
        }

        // Listen for receiver candidates
        if (this.callId && !this.candidatesUnsub) {
          const candCol = collection(db, 'calls', this.callId, 'receiverCandidates');
          this.candidatesUnsub = onSnapshot(candCol, (snap) => {
            snap.docChanges().forEach(async (change) => {
              if (change.type === 'added' && this.peerConnection) {
                try {
                  const cand = new RTCIceCandidate(change.doc.data());
                  await this.peerConnection.addIceCandidate(cand);
                } catch {
                  // candidate error
                }
              }
            });
          });
        }
        this.handlers.onCallStatusChange?.('answered');
      } else if (data.status === 'declined' || data.status === 'ended' || data.status === 'timeout') {
        if (this.timeoutTimer) {
          clearTimeout(this.timeoutTimer);
          this.timeoutTimer = null;
        }
        this.cleanup();
        this.handlers.onCallStatusChange?.(data.status);
      }
    });

    return this.callId;
  }

  /**
   * User B answers an incoming call
   */
  async answerCall(incomingCall: FirestoreCallDoc): Promise<void> {
    this.isCaller = false;
    this.callId = incomingCall.id;
    if (this.timeoutTimer) {
      clearTimeout(this.timeoutTimer);
      this.timeoutTimer = null;
    }

    await this.getLocalMedia(incomingCall.callType === 'video');
    this.peerConnection = new RTCPeerConnection(RTC_CONFIG);
    this.remoteStream = new MediaStream();

    // Attach local tracks
    if (this.localStream) {
      this.localStream.getTracks().forEach((track) => {
        this.peerConnection?.addTrack(track, this.localStream!);
      });
    }

    // Remote track listener
    this.peerConnection.ontrack = (event) => {
      event.streams[0].getTracks().forEach((track) => {
        this.remoteStream?.addTrack(track);
      });
      if (this.handlers.onRemoteStream && this.remoteStream) {
        this.handlers.onRemoteStream(this.remoteStream);
      }
    };

    // Write ICE candidates to receiverCandidates
    this.peerConnection.onicecandidate = async (event) => {
      if (event.candidate && this.callId) {
        try {
          const candCol = collection(db, 'calls', this.callId, 'receiverCandidates');
          await addDoc(candCol, event.candidate.toJSON());
        } catch {
          // ignore
        }
      }
    };

    // Set Remote Description from Caller Offer
    if (incomingCall.offer) {
      const rtcOffer = new RTCSessionDescription(incomingCall.offer);
      await this.peerConnection.setRemoteDescription(rtcOffer);
    }

    // Create Answer
    const answer = await this.peerConnection.createAnswer();
    await this.peerConnection.setLocalDescription(answer);

    // Update Firestore call doc: status='answered'
    const callRef = doc(db, 'calls', this.callId);
    await updateDoc(callRef, {
      status: 'answered',
      answeredAt: Date.now(),
      answer: {
        type: answer.type,
        sdp: answer.sdp || '',
      },
    });

    // Listen for caller's ICE candidates
    const candCol = collection(db, 'calls', this.callId, 'callerCandidates');
    this.candidatesUnsub = onSnapshot(candCol, (snap) => {
      snap.docChanges().forEach(async (change) => {
        if (change.type === 'added' && this.peerConnection) {
          try {
            const cand = new RTCIceCandidate(change.doc.data());
            await this.peerConnection.addIceCandidate(cand);
          } catch {
            // ignore
          }
        }
      });
    });

    // Listen to call doc for remote hangup
    this.callDocUnsub = onSnapshot(callRef, (snapshot) => {
      const data = snapshot.data() as FirestoreCallDoc | undefined;
      if (!data) return;
      if (data.status === 'ended' || data.status === 'timeout' || data.status === 'declined') {
        this.cleanup();
        this.handlers.onCallStatusChange?.(data.status);
      }
    });

    this.handlers.onCallStatusChange?.('answered');
  }

  /**
   * Alias for answerCall
   */
  async acceptCall(incomingCall: FirestoreCallDoc): Promise<void> {
    return this.answerCall(incomingCall);
  }

  /**
   * Decline an incoming call
   */
  async declineCall(callId: string): Promise<void> {
    try {
      const callRef = doc(db, 'calls', callId);
      await updateDoc(callRef, {
        status: 'declined',
        endedAt: Date.now(),
      });
    } catch {
      // ignore
    }
    this.cleanup();
  }

  /**
   * End an active call
   */
  async endCall(): Promise<void> {
    if (this.callId) {
      try {
        const callRef = doc(db, 'calls', this.callId);
        await updateDoc(callRef, {
          status: 'ended',
          endedAt: Date.now(),
        });
      } catch {
        // ignore
      }
    }
    this.cleanup();
  }

  /**
   * Toggle microphone audio track
   */
  toggleMute(): boolean {
    if (this.localStream) {
      const audioTracks = this.localStream.getAudioTracks();
      if (audioTracks.length > 0) {
        audioTracks[0].enabled = !audioTracks[0].enabled;
        return !audioTracks[0].enabled; // returns isMuted
      }
    }
    return false;
  }

  /**
   * Clean up WebRTC tracks and Firestore listeners
   */
  cleanup(): void {
    if (this.timeoutTimer) {
      clearTimeout(this.timeoutTimer);
      this.timeoutTimer = null;
    }
    if (this.callDocUnsub) {
      this.callDocUnsub();
      this.callDocUnsub = null;
    }
    if (this.candidatesUnsub) {
      this.candidatesUnsub();
      this.candidatesUnsub = null;
    }
    if (this.localStream) {
      this.localStream.getTracks().forEach((track) => track.stop());
      this.localStream = null;
    }
    if (this.remoteStream) {
      this.remoteStream.getTracks().forEach((track) => track.stop());
      this.remoteStream = null;
    }
    if (this.peerConnection) {
      this.peerConnection.close();
      this.peerConnection = null;
    }
    this.callId = null;
  }
}

/**
 * Real-time listener for incoming calls targeted at a specific receiver Ghosted ID
 */
export function listenForIncomingCalls(
  receiverGhostedId: string,
  onIncomingCall: (call: FirestoreCallDoc | null) => void
): Unsubscribe {
  const callsCol = collection(db, 'calls');
  // Listen for calls where receiverId matches and status is 'ringing'
  const q = query(callsCol, where('receiverId', '==', receiverGhostedId), where('status', '==', 'ringing'));
  return onSnapshot(
    q,
    (snapshot) => {
      if (snapshot.empty) {
        onIncomingCall(null);
        return;
      }
      // Get most recent ringing call
      const docs = snapshot.docs.map((d) => ({ ...d.data(), id: d.id } as FirestoreCallDoc));
      docs.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      onIncomingCall(docs[0] || null);
    },
    (err) => {
      console.warn('Error listening for incoming calls:', err);
      onIncomingCall(null);
    }
  );
}
