/**
 * Ghosted Text & Bad Words Filter
 * Blocks harassment, violence, explicit profanity, and offensive slurs.
 */
const BAD_WORDS_LIST = [
  'nude', 'naked', 'porn', 'sex', 'blowjob', 'boobs', 'penis', 'vagina', 'fuck', 'shit',
  'bitch', 'asshole', 'bastard', 'cunt', 'dick', 'pussy', 'whore', 'slut', 'kill yourself',
  'suicide', 'die', 'murder', 'rape', 'terrorist', 'bomb', 'weapon', 'gun', 'cocaine',
  'heroin', 'weed', 'drugs', 'retard', 'faggot', 'nigger', 'nigga', 'chink', 'spic'
];

export interface BadWordCheckResult {
  isBlocked: boolean;
  flaggedWords: string[];
  cleanText: string;
}

export function checkBadWords(text: string): BadWordCheckResult {
  if (!text) {
    return { isBlocked: false, flaggedWords: [], cleanText: '' };
  }

  const lower = text.toLowerCase();
  const flaggedWords: string[] = [];

  for (const word of BAD_WORDS_LIST) {
    // Regex matching whole word or embedded slurs
    const regex = new RegExp(`\\b${word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
    if (regex.test(lower)) {
      flaggedWords.push(word);
    }
  }

  let cleanText = text;
  for (const word of flaggedWords) {
    const regex = new RegExp(`\\b${word}\\b`, 'gi');
    cleanText = cleanText.replace(regex, '***');
  }

  return {
    isBlocked: flaggedWords.length > 0,
    flaggedWords,
    cleanText,
  };
}
