/**
 * TikTok-style Media Downloader for Ghosted
 * - Handles videos, photos, and text quotes
 * - Adds TikTok-style watermark with Ghosted Ghost logo & Author handle
 * - Provides progress callbacks for the TikTok saving overlay
 */

export interface TikTokDownloadProgress {
  status: 'preparing' | 'downloading' | 'watermarking' | 'saving' | 'completed' | 'error';
  progress: number; // 0 to 100
  message: string;
  error?: string;
}

export async function downloadLikeTikTok(
  post: {
    id: string;
    text?: string;
    mediaUrl?: string;
    mediaType?: string;
    authorName?: string;
    authorId?: string;
    createdAt?: number;
  },
  onProgress: (state: TikTokDownloadProgress) => void
): Promise<boolean> {
  const authorHandle = (post.authorName || 'ghost_user').replace(/\s+/g, '_').toLowerCase();
  const isVideo =
    post.mediaType === 'video' ||
    Boolean(
      post.mediaUrl &&
        (post.mediaUrl.includes('.mp4') ||
          post.mediaUrl.includes('.webm') ||
          post.mediaUrl.includes('.mov') ||
          post.mediaUrl.startsWith('data:video/'))
    );

  try {
    onProgress({
      status: 'preparing',
      progress: 5,
      message: 'Preparing download...',
    });

    if (isVideo && post.mediaUrl) {
      // 1. VIDEO DOWNLOAD WITH TIKTOK PROGRESS
      return await downloadVideoWithProgress(post.mediaUrl, `ghosted_@${authorHandle}_${post.id}.mp4`, onProgress);
    } else if (post.mediaUrl) {
      // 2. IMAGE DOWNLOAD WITH TIKTOK WATERMARK
      return await downloadImageWithWatermark(post.mediaUrl, authorHandle, post.text, `ghosted_@${authorHandle}_${post.id}.png`, onProgress);
    } else {
      // 3. TEXT-ONLY QUOTE: RENDER AS TIKTOK-STYLE WATERMARKED CARD
      return await downloadQuoteCard(post.text || 'Ghosted whisper', authorHandle, `ghosted_@${authorHandle}_${post.id}.png`, onProgress);
    }
  } catch (err) {
    console.warn('TikTok download error:', err);
    onProgress({
      status: 'error',
      progress: 0,
      message: 'Download failed',
      error: String(err),
    });
    return false;
  }
}

async function downloadVideoWithProgress(
  url: string,
  filename: string,
  onProgress: (state: TikTokDownloadProgress) => void
): Promise<boolean> {
  onProgress({
    status: 'downloading',
    progress: 15,
    message: 'Saving video...',
  });

  // Try fetch with simulated/real progressive steps
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

    const contentLength = response.headers.get('content-length');
    const totalBytes = contentLength ? parseInt(contentLength, 10) : 0;

    let blob: Blob;

    if (response.body && totalBytes > 0) {
      const reader = response.body.getReader();
      const chunks: Uint8Array[] = [];
      let receivedBytes = 0;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        if (value) {
          chunks.push(value);
          receivedBytes += value.length;
          const pct = Math.min(90, Math.round(15 + (receivedBytes / totalBytes) * 75));
          onProgress({
            status: 'downloading',
            progress: pct,
            message: `Saving to device... ${pct}%`,
          });
        }
      }

      blob = new Blob(chunks as unknown as BlobPart[], { type: 'video/mp4' });
    } else {
      // Animate progress smoothly
      for (let p = 20; p <= 85; p += 15) {
        onProgress({
          status: 'downloading',
          progress: p,
          message: `Saving to device... ${p}%`,
        });
        await new Promise((r) => setTimeout(r, 120));
      }
      blob = await response.blob();
    }

    onProgress({
      status: 'saving',
      progress: 95,
      message: 'Finishing up...',
    });

    const blobUrl = URL.createObjectURL(blob);
    triggerDownload(blobUrl, filename);
    URL.revokeObjectURL(blobUrl);

    onProgress({
      status: 'completed',
      progress: 100,
      message: 'Video saved to device! 🎬',
    });

    triggerHaptic();
    return true;
  } catch (err) {
    console.warn('Fallback direct download:', err);
    // Fallback: direct download link
    triggerDownload(url, filename);
    onProgress({
      status: 'completed',
      progress: 100,
      message: 'Video saved to device! 🎬',
    });
    triggerHaptic();
    return true;
  }
}

async function downloadImageWithWatermark(
  imageUrl: string,
  authorHandle: string,
  caption: string | undefined,
  filename: string,
  onProgress: (state: TikTokDownloadProgress) => void
): Promise<boolean> {
  onProgress({
    status: 'downloading',
    progress: 25,
    message: 'Loading media...',
  });

  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';

    img.onload = () => {
      onProgress({
        status: 'watermarking',
        progress: 65,
        message: 'Applying TikTok watermark...',
      });

      try {
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth || img.width || 1080;
        canvas.height = img.naturalHeight || img.height || 1350;
        const ctx = canvas.getContext('2d');

        if (!ctx) {
          triggerDownload(imageUrl, filename);
          onProgress({ status: 'completed', progress: 100, message: 'Saved to device! 📸' });
          resolve(true);
          return;
        }

        // 1. Draw main photo
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

        // 2. Add TikTok-style Floating Watermark
        drawTikTokWatermark(ctx, canvas.width, canvas.height, authorHandle);

        onProgress({
          status: 'saving',
          progress: 95,
          message: 'Saving to device...',
        });

        canvas.toBlob((blob) => {
          if (blob) {
            const blobUrl = URL.createObjectURL(blob);
            triggerDownload(blobUrl, filename);
            URL.revokeObjectURL(blobUrl);
          } else {
            triggerDownload(imageUrl, filename);
          }

          onProgress({
            status: 'completed',
            progress: 100,
            message: 'Photo saved to device! 📸',
          });
          triggerHaptic();
          resolve(true);
        }, 'image/png');
      } catch (e) {
        console.warn('Canvas watermark error, fallback:', e);
        triggerDownload(imageUrl, filename);
        onProgress({ status: 'completed', progress: 100, message: 'Saved to device! 📸' });
        triggerHaptic();
        resolve(true);
      }
    };

    img.onerror = () => {
      triggerDownload(imageUrl, filename);
      onProgress({ status: 'completed', progress: 100, message: 'Saved to device! 📸' });
      triggerHaptic();
      resolve(true);
    };

    img.src = imageUrl;
  });
}

async function downloadQuoteCard(
  quoteText: string,
  authorHandle: string,
  filename: string,
  onProgress: (state: TikTokDownloadProgress) => void
): Promise<boolean> {
  onProgress({
    status: 'watermarking',
    progress: 40,
    message: 'Rendering quote card...',
  });

  const canvas = document.createElement('canvas');
  canvas.width = 1080;
  canvas.height = 1350;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    onProgress({ status: 'completed', progress: 100, message: 'Saved!' });
    return true;
  }

  // Dark TikTok Gradient background
  const grad = ctx.createLinearGradient(0, 0, 1080, 1350);
  grad.addColorStop(0, '#0f0c1b');
  grad.addColorStop(0.5, '#18191a');
  grad.addColorStop(1, '#000000');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 1080, 1350);

  // Ghost icon glow
  ctx.font = '72px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('👻', 540, 280);

  // App Title
  ctx.fillStyle = '#1877F2';
  ctx.font = 'bold 36px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto';
  ctx.fillText('GHOSTED', 540, 340);

  // Quote text wrap
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 44px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto';
  wrapText(ctx, `"${quoteText}"`, 540, 520, 920, 64);

  // Author signature
  ctx.fillStyle = '#B0B3B8';
  ctx.font = '600 30px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto';
  ctx.fillText(`— @${authorHandle}`, 540, 980);

  // TikTok Watermark at bottom
  drawTikTokWatermark(ctx, 1080, 1350, authorHandle);

  onProgress({
    status: 'saving',
    progress: 90,
    message: 'Saving quote...',
  });

  return new Promise((resolve) => {
    canvas.toBlob((blob) => {
      if (blob) {
        const url = URL.createObjectURL(blob);
        triggerDownload(url, filename);
        URL.revokeObjectURL(url);
      }
      onProgress({
        status: 'completed',
        progress: 100,
        message: 'Saved to device! ✨',
      });
      triggerHaptic();
      resolve(true);
    }, 'image/png');
  });
}

function drawTikTokWatermark(ctx: CanvasRenderingContext2D, width: number, height: number, authorHandle: string) {
  // TikTok-style dual watermark badge (Top-Left & Bottom-Right)
  const scale = Math.max(1, width / 1080);
  const padding = 36 * scale;
  const fontSize = Math.round(26 * scale);

  // Bottom-Right Watermark Badge
  ctx.save();
  ctx.shadowColor = 'rgba(0, 0, 0, 0.8)';
  ctx.shadowBlur = 12 * scale;
  ctx.shadowOffsetX = 2 * scale;
  ctx.shadowOffsetY = 2 * scale;

  // Background pill
  const text = `👻 @${authorHandle} • Ghosted`;
  ctx.font = `bold ${fontSize}px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto`;
  const metrics = ctx.measureText(text);
  const pillW = metrics.width + 36 * scale;
  const pillH = fontSize + 24 * scale;
  const pillX = width - pillW - padding;
  const pillY = height - pillH - padding;

  ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
  roundRect(ctx, pillX, pillY, pillW, pillH, 12 * scale);
  ctx.fill();

  // Border
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
  ctx.lineWidth = 1.5 * scale;
  roundRect(ctx, pillX, pillY, pillW, pillH, 12 * scale);
  ctx.stroke();

  // Watermark text
  ctx.fillStyle = '#FFFFFF';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, pillX + 18 * scale, pillY + pillH / 2);

  ctx.restore();
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function wrapText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number
) {
  const words = text.split(' ');
  let line = '';
  let currentY = y;

  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + ' ';
    const metrics = ctx.measureText(testLine);
    const testWidth = metrics.width;
    if (testWidth > maxWidth && n > 0) {
      ctx.fillText(line.trim(), x, currentY);
      line = words[n] + ' ';
      currentY += lineHeight;
    } else {
      line = testLine;
    }
  }
  ctx.fillText(line.trim(), x, currentY);
}

function triggerDownload(url: string, filename: string) {
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.target = '_blank';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

function triggerHaptic() {
  if (typeof navigator !== 'undefined' && navigator.vibrate) {
    try {
      navigator.vibrate([35, 40, 35]);
    } catch {}
  }
}
