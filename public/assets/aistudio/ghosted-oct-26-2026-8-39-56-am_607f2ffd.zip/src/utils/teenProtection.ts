import { UserProfile } from '../types';

/**
 * Facebook-style regional age of digital consent / teen protection map by country code.
 * DE: 16, HU: 16, AT: 14, ES: 14, IT: 14, LT: 14, NL: 16, FR: 15, default: 13.
 * Note: No age label is displayed in the UI to prevent stigmatization.
 */
export const REGIONAL_TEEN_AGE_MAP: Record<string, number> = {
  DE: 16, // Germany
  HU: 16, // Hungary
  AT: 14, // Austria
  ES: 14, // Spain
  IT: 14, // Italy
  LT: 14, // Lithuania
  NL: 16, // Netherlands
  FR: 15, // France
  IE: 16, // Ireland
  GR: 15, // Greece
  SI: 15, // Slovenia
  CY: 14, // Cyprus
  PL: 16, // Poland
  NO: 16, // Norway
};

export const DEFAULT_TEEN_AGE_LIMIT = 13;

/**
 * Returns the teen protection age limit for a user's country
 */
export function getCountryTeenAgeLimit(countryCodeOrName?: string): number {
  if (!countryCodeOrName) return DEFAULT_TEEN_AGE_LIMIT;
  const c = countryCodeOrName.trim().toUpperCase();

  // Direct 2-letter lookup
  if (REGIONAL_TEEN_AGE_MAP[c]) {
    return REGIONAL_TEEN_AGE_MAP[c];
  }

  // Country name lookup
  const nameMap: Record<string, number> = {
    GERMANY: 16,
    DEUTSCHLAND: 16,
    HUNGARY: 16,
    AUSTRIA: 14,
    SPAIN: 14,
    ITALY: 14,
    LITHUANIA: 14,
    NETHERLANDS: 16,
    FRANCE: 15,
    IRELAND: 16,
    POLAND: 16,
    NORWAY: 16,
  };

  for (const [key, limit] of Object.entries(nameMap)) {
    if (c.includes(key)) return limit;
  }

  return DEFAULT_TEEN_AGE_LIMIT;
}

export interface TeenSettings {
  messagingControlsEnabled: boolean; // Only Close Friends / Connections
  contentLimitsEnabled: boolean;     // Strict content & language filter
  sleepModeEnabled: boolean;         // 10pm - 7am quiet hours
  dailyTimeLimitMinutes: number;     // 60 minutes
  audienceCloseFriendsOnly: boolean; // Default to close friends only
  canGoLive: boolean;                // Strictly false if age < 16
  parentSupervision: {
    isLinked: boolean;
    parentEmail?: string;
    parentName?: string;
    pairingCode: string;
    lastChecked?: string;
  };
}

/**
 * Check if the user is considered a teen under their regional jurisdiction
 */
export function isUserTeen(user?: UserProfile | null): boolean {
  if (!user) return false;
  const country = user.country || user.stateCountry || user.userCountry || '';
  const limit = getCountryTeenAgeLimit(country);
  const age = typeof user.age === 'number' ? user.age : 21;
  return age < limit;
}

/**
 * Check if the user is eligible for Live Streaming (strictly 16+)
 */
export function canUserGoLive(user?: UserProfile | null): boolean {
  if (!user) return false;
  const age = typeof user.age === 'number' ? user.age : 21;
  return age >= 16;
}

/**
 * Check if current local time is within Sleep Mode (10 PM to 7 AM)
 */
export function isCurrentlySleepModeHours(): boolean {
  const currentHour = new Date().getHours();
  return currentHour >= 22 || currentHour < 7;
}

/**
 * Load or initialize teen settings from localStorage
 */
export function getTeenSettings(userId?: string): TeenSettings {
  const defaultCode = `GH-PARENT-${Math.floor(100000 + Math.random() * 900000)}`;
  if (!userId) {
    return {
      messagingControlsEnabled: true,
      contentLimitsEnabled: true,
      sleepModeEnabled: true,
      dailyTimeLimitMinutes: 60,
      audienceCloseFriendsOnly: true,
      canGoLive: false,
      parentSupervision: {
        isLinked: false,
        pairingCode: defaultCode,
      },
    };
  }

  try {
    const raw = localStorage.getItem(`ghosted_teen_settings_${userId}`);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch {}

  const initial: TeenSettings = {
    messagingControlsEnabled: true,
    contentLimitsEnabled: true,
    sleepModeEnabled: true,
    dailyTimeLimitMinutes: 60,
    audienceCloseFriendsOnly: true,
    canGoLive: false,
    parentSupervision: {
      isLinked: false,
      pairingCode: defaultCode,
    },
  };
  localStorage.setItem(`ghosted_teen_settings_${userId}`, JSON.stringify(initial));
  return initial;
}

/**
 * Save teen settings
 */
export function saveTeenSettings(userId: string, settings: TeenSettings): void {
  localStorage.setItem(`ghosted_teen_settings_${userId}`, JSON.stringify(settings));
}
