// Ghosted ID generator (e.g. GH-8429-1923) and internal in-app number (e.g. +00-GH-84291923)
export function generateGhostedId(): string {
  const segment1 = Math.floor(1000 + Math.random() * 9000);
  const segment2 = Math.floor(1000 + Math.random() * 9000);
  return `GH-${segment1}-${segment2}`;
}

export function generateGhostedNumber(ghostedId: string = ''): string {
  const digits = ghostedId.replace(/[^0-9]/g, '');
  return `+00-GH-${digits || Math.floor(10000000 + Math.random() * 90000000)}`;
}

export function calculateAge(dobString: string): number {
  if (!dobString) return 0;
  const dob = new Date(dobString);
  if (isNaN(dob.getTime())) return 0;
  const today = new Date();
  let age = today.getFullYear() - dob.getFullYear();
  const m = today.getMonth() - dob.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) {
    age--;
  }
  return age;
}
