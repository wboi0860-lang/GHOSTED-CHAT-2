import { Howl } from 'howler';
import { GiftType } from '../types';

let isMuted = false;

// Web Audio synthesizer fallback for gift sounds if external audio files are unavailable
function playSynthSound(type: GiftType | 'smoke_fade') {
  if (isMuted || typeof window === 'undefined') return;
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const now = ctx.currentTime;

    switch (type) {
      case 'little_ghost': {
        // Boo bell ding: high harmonic chime + gentle bell decay
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, now); // A5
        osc.frequency.exponentialRampToValueAtTime(1320, now + 0.1);
        osc.frequency.exponentialRampToValueAtTime(587.33, now + 1.2);
        gain.gain.setValueAtTime(0.35, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 1.5);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 1.5);
        break;
      }
      case 'purple_smoke': {
        // Whoosh chime: sweeping filter noise + ethereal chime
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(320, now);
        osc.frequency.exponentialRampToValueAtTime(960, now + 0.4);
        osc.frequency.exponentialRampToValueAtTime(440, now + 1.8);
        gain.gain.setValueAtTime(0.01, now);
        gain.gain.linearRampToValueAtTime(0.4, now + 0.3);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 2.0);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 2.0);
        break;
      }
      case 'haunted_eye': {
        // Heartbeat thump: dual deep low-frequency sub bass thuds
        const osc1 = ctx.createOscillator();
        const gain1 = ctx.createGain();
        osc1.type = 'sine';
        osc1.frequency.setValueAtTime(85, now);
        osc1.frequency.exponentialRampToValueAtTime(40, now + 0.25);
        gain1.gain.setValueAtTime(0.7, now);
        gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

        const osc2 = ctx.createOscillator();
        const gain2 = ctx.createGain();
        osc2.type = 'sine';
        osc2.frequency.setValueAtTime(95, now + 0.35);
        osc2.frequency.exponentialRampToValueAtTime(38, now + 0.65);
        gain2.gain.setValueAtTime(0.0, now);
        gain2.gain.setValueAtTime(0.65, now + 0.35);
        gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.75);

        osc1.connect(gain1);
        gain1.connect(ctx.destination);
        osc2.connect(gain2);
        gain2.connect(ctx.destination);

        osc1.start(now);
        osc1.stop(now + 0.35);
        osc2.start(now + 0.35);
        osc2.stop(now + 0.8);
        break;
      }
      case 'ghost_fire': {
        // Fire crackle scream: rising distortion sweep + flame frequency
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(260, now);
        osc.frequency.exponentialRampToValueAtTime(740, now + 0.5);
        osc.frequency.linearRampToValueAtTime(350, now + 1.6);
        gain.gain.setValueAtTime(0.05, now);
        gain.gain.linearRampToValueAtTime(0.4, now + 0.4);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 2.2);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 2.2);
        break;
      }
      case 'skull_rain': {
        // Thunder crash: low frequency rumble and crash impact
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(140, now);
        osc.frequency.exponentialRampToValueAtTime(35, now + 1.5);
        gain.gain.setValueAtTime(0.8, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 2.8);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 2.8);
        break;
      }
      case 'ghost_king': {
        // Epic choir king: rich tri-harmonic chord (Root, Major Third, Fifth)
        const freqs = [220, 277.18, 329.63, 440]; // A3 Major chord
        freqs.forEach((f) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(f, now);
          osc.frequency.linearRampToValueAtTime(f * 1.5, now + 1.2);
          gain.gain.setValueAtTime(0.15, now);
          gain.gain.linearRampToValueAtTime(0.25, now + 0.6);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 3.0);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now);
          osc.stop(now + 3.0);
        });
        break;
      }
      case 'smoke_fade': {
        // Soft whoosh smoke at 6 sec
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(480, now);
        osc.frequency.exponentialRampToValueAtTime(160, now + 1.0);
        gain.gain.setValueAtTime(0.02, now);
        gain.gain.linearRampToValueAtTime(0.2, now + 0.2);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 1.2);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 1.2);
        break;
      }
    }
  } catch (err) {
    console.warn('Synth sound error:', err);
  }
}

// Howler sound instances
const giftHowls: Record<string, Howl> = {
  little_ghost: new Howl({
    src: ['/assets/sounds/gifts/ding.mp3'],
    volume: 0.8,
    onloaderror: () => {},
    onplayerror: () => playSynthSound('little_ghost'),
  }),
  purple_smoke: new Howl({
    src: ['/assets/sounds/gifts/chime.mp3'],
    volume: 0.8,
    onloaderror: () => {},
    onplayerror: () => playSynthSound('purple_smoke'),
  }),
  haunted_eye: new Howl({
    src: ['/assets/sounds/gifts/thump.mp3'],
    volume: 0.9,
    onloaderror: () => {},
    onplayerror: () => playSynthSound('haunted_eye'),
  }),
  ghost_fire: new Howl({
    src: ['/assets/sounds/gifts/scream.mp3'],
    volume: 0.85,
    onloaderror: () => {},
    onplayerror: () => playSynthSound('ghost_fire'),
  }),
  skull_rain: new Howl({
    src: ['/assets/sounds/gifts/crash.mp3'],
    volume: 0.9,
    onloaderror: () => {},
    onplayerror: () => playSynthSound('skull_rain'),
  }),
  ghost_king: new Howl({
    src: ['/assets/sounds/gifts/king.mp3'],
    volume: 1.0,
    onloaderror: () => {},
    onplayerror: () => playSynthSound('ghost_king'),
  }),
  smoke_fade: new Howl({
    src: ['/assets/sounds/gifts/smoke.mp3'],
    volume: 0.7,
    onloaderror: () => {},
    onplayerror: () => playSynthSound('smoke_fade'),
  }),
};

export function playGiftSound(giftType: GiftType) {
  if (isMuted) return;
  const howl = giftHowls[giftType];
  if (howl && howl.state() === 'loaded') {
    howl.play();
  } else {
    // If not loaded from network path, play high-fidelity Web Audio synthesis
    playSynthSound(giftType);
  }
}

export function playSmokeFadeSound() {
  if (isMuted) return;
  const howl = giftHowls.smoke_fade;
  if (howl && howl.state() === 'loaded') {
    howl.play();
  } else {
    playSynthSound('smoke_fade');
  }
}

export function setSoundsMuted(muted: boolean) {
  isMuted = muted;
  Object.values(giftHowls).forEach((h) => h.mute(muted));
}

export function getSoundsMuted(): boolean {
  return isMuted;
}
