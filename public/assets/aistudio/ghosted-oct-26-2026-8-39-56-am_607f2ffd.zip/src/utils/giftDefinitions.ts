import { GiftDefinition, GiftType } from '../types';

export const GHOST_GIFTS: GiftDefinition[] = [
  {
    type: 'little_ghost',
    name: 'Little Ghost',
    coins: 10,
    icon: '👻',
    soundKey: 'little_ghost',
    soundFile: '/assets/sounds/gifts/ding.mp3',
    color: '#A855F7',
    description: 'Playful mini phantom with chime bell',
    lottieFile: '/assets/lotties/little_ghost.json',
  },
  {
    type: 'purple_smoke',
    name: 'Purple Smoke',
    coins: 50,
    icon: '💨',
    soundKey: 'purple_smoke',
    soundFile: '/assets/sounds/gifts/chime.mp3',
    color: '#8B5CF6',
    description: 'Dense violet mist rising across the screen',
    lottieFile: '/assets/lotties/purple_smoke.json',
  },
  {
    type: 'haunted_eye',
    name: 'Haunted Eye',
    coins: 100,
    icon: '👁️',
    soundKey: 'haunted_eye',
    soundFile: '/assets/sounds/gifts/thump.mp3',
    color: '#EC4899',
    description: 'Pulsing spectral eye with deep heartbeat',
    lottieFile: '/assets/lotties/haunted_eye.json',
  },
  {
    type: 'ghost_fire',
    name: 'Ghost Fire',
    coins: 500,
    icon: '🔥',
    soundKey: 'ghost_fire',
    soundFile: '/assets/sounds/gifts/scream.mp3',
    color: '#F97316',
    description: 'Hellfire spectral blaze crackling with energy',
    lottieFile: '/assets/lotties/ghost_fire.json',
  },
  {
    type: 'skull_rain',
    name: 'Skull Rain',
    coins: 1000,
    icon: '💀',
    soundKey: 'skull_rain',
    soundFile: '/assets/sounds/gifts/crash.mp3',
    color: '#06B6D4',
    description: 'Thunderous celestial storm of levitating skulls',
    lottieFile: '/assets/lotties/skull_rain.json',
  },
  {
    type: 'ghost_king',
    name: 'Ghost King',
    coins: 5000,
    icon: '👑',
    soundKey: 'ghost_king',
    soundFile: '/assets/sounds/gifts/king.mp3',
    color: '#EAB308',
    description: 'Supreme Ghost Monarch crowned with choral anthem',
    lottieFile: '/assets/lotties/ghost_king.json',
  },
];

export function getGiftDefinition(type: GiftType): GiftDefinition {
  return GHOST_GIFTS.find((g) => g.type === type) || GHOST_GIFTS[0];
}
