export type Gender = 'Male' | 'Female' | 'Non-binary' | 'Prefer not to say';
export type RelationshipType = 'Friend' | 'Family' | 'Ex-Partner' | 'Other';
export type MoodType = 'Apology' | 'Miss You' | 'Closure' | 'Thank You' | 'Just Checking In';
export type IdentityRevealTiming = 'immediate_on_view' | 'manual_reveal_later';
export type DeliveryChannel = 'direct_link' | 'phone_sms' | 'linkedin' | 'email';
export type SubscriptionBillingCycle = 'monthly' | 'yearly';

export interface UserProfile {
  id: string;
  uid?: string;
  name: string;
  firstName?: string;
  lastName?: string;
  fullName?: string;
  displayName?: string;
  email: string;
  avatarUrl?: string;
  photoURL?: string;
  interests?: string[];
  dob?: string;
  age?: number;
  gender?: Gender;
  city?: string;
  stateCountry?: string;
  country?: string;
  userCountry?: string;
  isVIPFree?: boolean;
  isVIP?: boolean;
  vipExpiry?: string;
  hasVIP?: boolean;
  themeCountry?: string;
  primaryRelationship?: RelationshipType;
  bio?: string;
  phone?: string;
  ghostedId: string;       // e.g. GH-8429-1923
  ghostedNumber: string;   // e.g. +00-GH-84291923
  isOnboarded?: boolean;
  onboardingCompleted?: boolean;
  dailySendsRemaining?: number;
  totalSendsToday?: number;
  isPremium?: boolean;
  subscriptionPlan?: 'free' | 'premium';
  subscriptionBillingCycle?: SubscriptionBillingCycle;
  subscriptionAmount?: number;
  premiumExpiresAt?: string;
  createdAt?: string;
  revealPreferences?: {
    allowNameReveal?: boolean;
    allowSocialsReveal?: boolean;
    autoDeclineAnonymous?: boolean;
  };
  passcodeProtected?: boolean;
  referralCode?: string;
  referralCount?: number;
  referralRewardedWeeks?: number;
  trustScore?: number;
  supportiveRatingsCount?: number;
  coins?: number;
  diamonds?: number;
  isLiveBanned?: boolean;
  liveBanExpiresAt?: string;
  liveViolationCount?: number;
}

export interface ReferralFriend {
  id: string;
  name: string;
  joinedAt: string;
}

export interface ReferralInfo {
  referralCode: string;
  referralLink: string;
  referralCount: number;
  targetCount: number; // 3 friends
  rewardedWeeks: number;
  isEligibleForReward: boolean;
  referredFriends: ReferralFriend[];
}

export interface SubscriptionTransaction {
  transactionId: string;
  userId: string;
  billingCycle: SubscriptionBillingCycle;
  amount: number;
  currency: string;
  maskedCard: string;
  cardBrand: string;
  status: 'settled';
  timestamp: string;
  expiresAt: string;
  receiptNumber: string;
}

export interface MemoryAttachment {
  id: string;
  name: string;
  size: number;
  type: string; // 'image/*' or 'video/*'
  dataUrl: string;
}

export interface LetterDraft {
  recipientName: string;
  recipientGhostedId?: string;
  relationship: RelationshipType;
  mood: MoodType;
  letter: string;
  memories: MemoryAttachment[];
  revealIdentity?: boolean;
  revealTiming?: IdentityRevealTiming;
  deliveryChannel: DeliveryChannel;
  recipientPhone?: string;
  recipientLinkedIn?: string;
  recipientEmail?: string;
  isScheduled: boolean;
  scheduledDate: string;
  scheduledTime: string;
}

export interface SafetyCheckResult {
  safe: boolean;
  reason?: string;
  suggestion?: string;
  flags?: string[];
  checkedAt?: string;
}

export interface SavedLetter {
  id: string;
  senderId: string;
  senderGhostedId: string;
  senderName: string;
  senderCity: string;
  senderCountry: string;
  recipientName: string;
  recipientGhostedId?: string;
  relationship: RelationshipType;
  mood: MoodType;
  letter: string;
  memories: MemoryAttachment[];
  revealIdentity?: boolean;
  revealTiming?: IdentityRevealTiming;
  deliveryChannel?: DeliveryChannel;
  recipientPhone?: string;
  recipientLinkedIn?: string;
  recipientEmail?: string;
  isManuallyRevealed?: boolean;
  manualRevealedAt?: string;
  recipientRequestedReveal?: boolean;
  scheduledAt?: string;
  createdAt: string;
  status: 'pending' | 'viewed' | 'declined';
  viewedAt?: string;
  declinedAt?: string;
  uniqueLink: string;
  safetyCheck: SafetyCheckResult;
}

export interface GhostedChatMessage {
  id: string;
  senderGhostedId: string;
  senderName?: string;
  receiverGhostedId: string;
  conversationId?: string;
  recipientPhone?: string;
  channel?: 'in_app' | 'sms' | 'whatsapp';
  text: string;
  timestamp: string;
  isDelivered: boolean;
  isRead: boolean;
  isGroupMessage?: boolean;
}

export interface GhostedConversation {
  id: string;
  name: string;
  targetGhostedId?: string;
  targetPhone?: string;
  isGroup: boolean;
  groupMembers?: { ghostedId: string; name: string }[];
  isFavourite: boolean;
  unreadCount: number;
  lastMessageText: string;
  lastMessageTimestamp: string;
  avatarUrl?: string;
  color?: string;
  updatedAt?: number;
}

export interface CallLog {
  id: string;
  callerGhostedId: string;
  targetNumberOrId: string;
  targetName?: string;
  type: 'cellular' | 'voice' | 'video';
  durationSeconds: number;
  status: 'completed' | 'missed' | 'connected' | 'declined' | 'timeout';
  timestamp: string;
  isIncoming?: boolean;
}

export interface CallSession {
  isActive: boolean;
  type: 'voice' | 'video';
  remoteGhostedId: string;
  remoteName?: string;
  isIncoming: boolean;
  status: 'ringing' | 'connected' | 'ended';
  isMuted: boolean;
  isVideoEnabled: boolean;
  durationSeconds: number;
  isConsentGranted: boolean;
}

export interface FirestoreCallDoc {
  id: string;
  callerId: string;
  callerName: string;
  callerPhone?: string;
  receiverId: string;
  receiverName?: string;
  status: 'ringing' | 'answered' | 'declined' | 'ended' | 'timeout';
  callType: 'voice' | 'video';
  createdAt: number;
  answeredAt?: number;
  endedAt?: number;
  offer?: {
    type: 'offer';
    sdp: string;
  } | null;
  answer?: {
    type: 'answer';
    sdp: string;
  } | null;
}

// ================= GHOST VAULT TYPES =================
export type VaultCategory = 'Heartbreak' | 'Anxiety' | 'Family' | 'Secret';
export type VaultLockType = 'time_lock' | 'trust_lock' | 'one_soul';

export interface VaultKeyRequest {
  id: string;
  requesterId: string;
  requesterGhostedId: string;
  requesterTrustScore: number;
  note?: string;
  requestedAt: string;
  status: 'pending' | 'approved' | 'rejected';
}

export interface GhostVaultDoc {
  id: string;
  authorId: string;
  authorGhostedId: string;
  category: VaultCategory;
  ventText: string; // max 500 chars
  lockType: VaultLockType;
  timeLockDuration?: '1hr' | '24hr';
  isLocked: boolean;
  burnAfterRead: boolean;
  canScreenshot: boolean;
  status: 'locked' | 'unlocked' | 'burned';
  currentListenerId?: string | null;
  currentListenerGhostedId?: string | null;
  unlockedAt?: string | null;
  chatExpiresAt?: string | null; // 15 mins after unlockedAt
  keyRequests?: VaultKeyRequest[];
  createdAt: string;
  expiresAt: string;
}

export interface VaultChatMessage {
  id: string;
  vaultId: string;
  senderId: string;
  senderRole: 'venter' | 'listener';
  senderGhostedId: string;
  text: string;
  createdAt: string;
}

export interface VaultRatingSubmission {
  vaultId: string;
  raterId: string;
  listenerId: string;
  isSupportive: boolean;
  ratingType: 'supportive' | 'neutral' | 'unsupportive';
  feedbackNote?: string;
  createdAt: string;
}

// ================= HOME FEED & GHOST POSTS / COMMENTS TYPES =================
export interface GhostStatus {
  id: string;
  userId?: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  authorGhostedId: string;
  type: 'text' | 'image' | 'video' | 'voice';
  content: string; // text vent, image data URL, video data URL, or audio recording URL/base64
  caption?: string;
  backgroundColor?: string;
  createdAt: any;
  expiresAt: number; // 24h TTL
  seenBy: string[];
  imageUrl?: string;
  isEnhanced?: boolean;
}

export interface GhostPost {
  id: string;
  userId?: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  authorGhostedId: string;
  text: string; // max 100 words (or 300 chars)
  mediaUrl?: string;
  imageUrl?: string;
  videoUrl?: string;
  mediaType?: 'image' | 'video';
  audience?: 'public' | 'private'; // Public = everyone, Private = connections only
  createdAt: any;
  likes?: number;
  likesCount: number;
  likedBy: string[];
  commentsCount: number;
  sharesCount?: number;
  shares_count?: number;
  watchedAt?: number;
  isEnhanced?: boolean;
  isDeleted?: boolean;
}

export interface UserSticker {
  id: string;
  title: string;
  imageUrl: string;
  isLive?: boolean;
  type: 'ghost' | 'custom_image' | 'live';
  createdAt: number;
}

export interface GhostPostComment {
  id: string;
  postId: string;
  isGhost: boolean;
  ghostMode?: boolean; // 👻 Ghost or 👤 Real Name
  realUserId: string;
  realUsername: string;
  realUserAvatar: string;
  originalText: string;
  displayName: string; // "Ghost User" or realUsername
  ghostName?: string;  // "Ghost User"
  revealAt?: number; // Date.now() + 24-48h (optional for real comments)
  revealed: boolean;
  isDeleted: boolean;
  createdAt: number;
  commentExpiresAt?: number; // auto-deletes for post owner after X hours (1h, 6h, 12h, 24h)
  timerDurationHours?: number; // 1, 6, 12, 24
  imageUrl?: string;
  stickerUrl?: string; // GHOST sticker or custom sticker
  stickerType?: 'ghost' | 'custom_image' | 'live';
  stickerTitle?: string;
  mentionedProfileId?: string; // @ link of profile
  mentionedVideoUrl?: string; // video link
}

export interface GhostRevealNotice {
  id: string;
  recipientId: string;
  postId: string;
  commentId: string;
  revealedUsername: string;
  commentText: string;
  type: 'owner_notice' | 'commenter_notice';
  timestamp: number;
}

// ================= LIVE STREAMING & WEBRTC TYPES =================
export interface LiveStreamSession {
  id: string;
  hostId: string;
  hostName: string;
  hostAvatar: string;
  hostGhostedId: string;
  title: string;
  status: 'active' | 'ended';
  viewersCount: number;
  likesCount: number;
  createdAt: number;
  endedAt?: number;
  violationsCount: number;
  isBanned?: boolean;
}

export interface LiveComment {
  id: string;
  liveId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  text: string;
  timestamp: number;
  isSystem?: boolean;
}

export type GiftType =
  | 'little_ghost'
  | 'purple_smoke'
  | 'haunted_eye'
  | 'ghost_fire'
  | 'skull_rain'
  | 'ghost_king';

export interface GiftDefinition {
  type: GiftType;
  name: string;
  coins: number;
  icon: string;
  soundKey: string;
  soundFile: string;
  color: string;
  description: string;
  lottieFile: string;
}

export interface GhostGiftDoc {
  id: string;
  liveId: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  giftType: GiftType;
  coins: number;
  timestamp: number;
  comboCount?: number;
}

export interface CoinPackage {
  id: string;
  coins: number;
  priceNaira?: number;
  priceUsdt?: number;
  badge?: string;
}

export interface CoinTransaction {
  id: string;
  userId: string;
  country: string;
  currency: 'NGN' | 'USDT';
  coins: number;
  amount: number;
  paymentMethod: string;
  timestamp: number;
  status: 'completed' | 'pending';
}

export interface DiamondWithdrawal {
  id: string;
  userId: string;
  diamonds: number;
  payoutAmount: number;
  currency: 'NGN' | 'USDT';
  accountDetails: string;
  timestamp: number;
  status: 'pending' | 'processed';
}

export interface LiveAgreement {
  userId: string;
  agreedAt: number;
  is18Plus: boolean;
  version: string;
}

export interface LiveViolationRecord {
  id: string;
  liveId: string;
  hostId: string;
  reasons: string[];
  timestamp: number;
}

// REAL GHOSTED FIRESTORE DATA MODELS
export interface GhostUserDoc {
  id: string;
  ghost_name: string;
  ghost_id: string; // Auto-generated Ghost#1234
  avatar: string;
  is_public_id: boolean; // default false (PRIVATE by default)
  created_at: string;
  password_hash?: string;
  email?: string | null; // private, never shown
  interests?: string[];
  bio?: string;
  is_online?: boolean;
  last_active?: string;
}

export interface CallRecordDoc {
  id: string;
  caller_id: string;
  receiver_id: string;
  caller_name?: string;
  receiver_name?: string;
  type: 'voice' | 'video';
  duration: number; // in seconds
  time: string;
  status: 'ringing' | 'connected' | 'ended' | 'missed' | 'declined' | 'timeout';
  offer?: any;
  answer?: any;
}

export interface InboxMessageDoc {
  id: string;
  sender_id_hidden: string;
  sender_name_hidden?: string;
  receiver_id: string;
  receiver_name?: string;
  message: string;
  mood?: string;
  relationship?: string;
  is_revealed: boolean;
  timestamp: string;
}

export interface GhostNotificationDoc {
  id: string;
  user_id: string;
  type: 'reveal_requested' | 'whisper_received' | 'call_missed' | 'chat_message';
  title: string;
  body: string;
  timestamp: string;
  read: boolean;
  reference_id?: string;
}

