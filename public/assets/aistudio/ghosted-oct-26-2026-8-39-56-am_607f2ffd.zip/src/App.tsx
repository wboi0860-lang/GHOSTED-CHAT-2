import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, SavedLetter, FirestoreCallDoc } from './types';
import { generateGhostedId, generateGhostedNumber } from './utils/idGenerator';
import { checkIsNigeria, getInitialCountryAndVip } from './utils/countryDetection';
import { APP_THEMES, AppTheme, getActiveCountryTheme, saveCountryTheme, detectDefaultTheme, ThemeId, normalizeThemeId } from './utils/theme';
import { useTheme } from './context/ThemeContext';
import { db, triggerIncomingCallAlert } from './firebase';
import {
  collection,
  doc,
  onSnapshot,
  query,
  where,
  updateDoc,
  Unsubscribe,
} from 'firebase/firestore';
import {
  PhoneRingTonePlayer,
  playConnectedChime,
  playHangupTone,
  stopAllActiveRingtones,
} from './utils/audioTones';
import { HomeFeedTab } from './components/HomeFeedTab';
import { ChatHub } from './components/ChatHub';
import { GhostedCommunicator } from './components/GhostedCommunicator';
import { DraftFeedTab } from './components/DraftFeedTab';
import { FriendsTab } from './components/FriendsTab';
import { ProfileSafetyTab } from './components/ProfileSafetyTab';
import { OnboardingFlow } from './components/OnboardingFlow';
import { RecipientViewModal } from './components/RecipientViewModal';
import { ReportModal } from './components/ReportModal';
import {
  Home,
  MessageSquare,
  Mail,
  Users,
  User,
  Sparkles,
  Bell,
  X,
  ShieldCheck,
  Phone,
  PhoneCall,
  PhoneOff,
  Video,
  Volume2,
  Moon,
  Sun,
} from 'lucide-react';

export type MainTab = 'home' | 'whispers' | 'messages' | 'friends' | 'profile';

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  time: string;
  timestamp: number;
  read: boolean;
  type: 'whisper' | 'call' | 'friend' | 'system';
  targetTab?: MainTab;
}

export default function App() {
  // 1. Initial User Profile Loading & Persistence
  const [user, setUser] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem('ghosted_current_user');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.id) {
          parsed.themeCountry = normalizeThemeId(parsed.themeCountry);
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Error reading stored user:', e);
    }

    const newId = generateGhostedId();
    const newNum = generateGhostedNumber();
    const initialCountryVip = getInitialCountryAndVip(null);

    return {
      id: `usr-${Date.now()}`,
      name: 'Ghost User',
      firstName: 'Ghost',
      lastName: 'User',
      email: 'user@ghosted.network',
      ghostedId: newId,
      ghostedNumber: newNum,
      userCountry: initialCountryVip.userCountry,
      country: initialCountryVip.userCountry,
      stateCountry: initialCountryVip.userCountry,
      isVIP: initialCountryVip.hasVIP,
      isVIPFree: initialCountryVip.isVIPFree,
      hasVIP: initialCountryVip.hasVIP,
      themeCountry: 'ghost',
      isOnboarded: true,
      coins: 150,
      diamonds: 20,
      interests: ['Gaming', 'Heartbreak', 'Music', 'Tech'],
      gender: 'Prefer not to say',
      age: 22,
      dob: '2004-05-14',
      bio: 'Whispering in the ethereal void. Safe & verified reconnects only 🌌✨',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80',
      dailySendsRemaining: 5,
      totalSendsToday: 0,
      trustScore: 98,
      supportiveRatingsCount: 14,
    };
  });

  useEffect(() => {
    try {
      localStorage.setItem('ghosted_current_user', JSON.stringify(user));
    } catch (e) {
      console.warn('Error writing user state:', e);
    }
  }, [user]);

  // Locked to Ghosted Theme
  const isNigeria = checkIsNigeria(user.userCountry || user.country || user.stateCountry);
  const {
    isWhite,
    isBlack,
    isGhost,
    isLight,
    isDark,
    currentTheme,
  } = useTheme();

  // Main navigation tab (No vault!)
  const [activeTab, setActiveTab] = useState<MainTab>('home');

  // Sub-navigation triggers
  const [communicatorContactId, setCommunicatorContactId] = useState<string | undefined>(undefined);
  const [externalCallDoc, setExternalCallDoc] = useState<FirestoreCallDoc | null>(null);

  // Modals state
  const [activeLetterRecipientId, setActiveLetterRecipientId] = useState<string | null>(null);
  const [reportModalTarget, setReportModalTarget] = useState<{ ghostedId?: string; letterId?: string } | null>(null);
  const [toastBanner, setToastBanner] = useState<string | null>(null);

  // Real Notifications State
  const [notifications, setNotifications] = useState<AppNotification[]>(() => {
    try {
      const savedNotifs = localStorage.getItem('ghosted_notifications');
      if (savedNotifs) return JSON.parse(savedNotifs);
    } catch {}
    return [
      {
        id: 'notif-1',
        title: 'New Anonymous Whisper',
        message: 'Tunde sent an encrypted closure whisper to your Ghosted ID.',
        time: '15m ago',
        timestamp: Date.now() - 900000,
        read: false,
        type: 'whisper',
        targetTab: 'whispers',
      },
      {
        id: 'notif-2',
        title: 'Ghosted Network Verified',
        message: 'Your anonymous ID is shielded with zero-knowledge encryption.',
        time: '2h ago',
        timestamp: Date.now() - 7200000,
        read: false,
        type: 'system',
        targetTab: 'profile',
      },
    ];
  });

  const [isNotificationOpen, setIsNotificationOpen] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem('ghosted_notifications', JSON.stringify(notifications));
    } catch {}
  }, [notifications]);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleMarkAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const handleNotificationClick = (notif: AppNotification) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === notif.id ? { ...n, read: true } : n))
    );
    setIsNotificationOpen(false);
    if (notif.targetTab) {
      setActiveTab(notif.targetTab);
    }
  };

  // Letters storage
  const [letters, setLetters] = useState<SavedLetter[]>(() => {
    try {
      const saved = localStorage.getItem('ghosted_saved_letters');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'whisper-welcome-1',
        title: 'An unsaid goodbye from summer',
        content:
          'I wanted to tell you I finally understand why things ended the way they did. I carry no bitterness, only gratitude for the memories we shared. Hope life is treating you gently.',
        mood: 'Closure',
        relationship: 'Ex-Partner',
        recipientName: 'Tunde',
        recipientGhostedId: 'GH-2901-4411',
        createdAt: Date.now() - 86400000 * 2,
        isRead: true,
        isUnlocked: true,
        deliveryChannel: 'direct_link',
        senderGhostedId: user.ghostedId,
        senderGhostedNumber: user.ghostedNumber,
      },
    ];
  });

  useEffect(() => {
    try {
      localStorage.setItem('ghosted_saved_letters', JSON.stringify(letters));
    } catch {}
  }, [letters]);

  // REAL-TIME GLOBAL INCOMING CALL LISTENER & NOTIFICATION
  const ringTonePlayerRef = useRef<PhoneRingTonePlayer>(new PhoneRingTonePlayer());
  const [incomingCall, setIncomingCall] = useState<FirestoreCallDoc | null>(null);
  const [incomingTimeoutRemaining, setIncomingTimeoutRemaining] = useState<number>(30);

  useEffect(() => {
    if (!user?.ghostedId) return;

    // Build list of target identifier variations for this user
    const myIds = [
      user.ghostedId,
      user.ghostedNumber,
      user.id,
      user.ghostedId.replace(/[^a-zA-Z0-9]/g, ''),
      user.ghostedNumber.replace(/[^a-zA-Z0-9]/g, ''),
    ].filter(Boolean);

    const callsCol = collection(db, 'calls');
    const q = query(callsCol, where('status', '==', 'ringing'));

    const unsubscribe: Unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        if (snapshot.empty) {
          if (incomingCall) {
            ringTonePlayerRef.current.stop();
            stopAllActiveRingtones();
            setIncomingCall(null);
          }
          return;
        }

        const now = Date.now();
        const docs = snapshot.docs.map((d) => ({ ...d.data(), id: d.id } as FirestoreCallDoc & { senderId?: string }));

        // Match any ringing call targeted at User B
        const matchingCall = docs.find((call) => {
          if (!call || call.status !== 'ringing') return false;
          // Ignore self-calls initiated by this same device
          if (
            call.callerId === user.ghostedId ||
            call.callerId === user.id ||
            call.senderId === user.ghostedId ||
            call.senderId === user.id
          ) {
            return false;
          }
          // Only process calls created within the last 45 seconds
          if (call.createdAt && now - call.createdAt > 45000) return false;

          const rec = call.receiverId || '';
          const recClean = rec.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();

          return myIds.some((myId) => {
            const myClean = myId.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
            return (
              rec.toLowerCase() === myId.toLowerCase() ||
              recClean === myClean ||
              (myClean.length >= 6 && recClean.includes(myClean)) ||
              (recClean.length >= 6 && myClean.includes(recClean))
            );
          });
        });

        if (matchingCall) {
          if (!incomingCall || incomingCall.id !== matchingCall.id) {
            setIncomingCall(matchingCall);
            setIncomingTimeoutRemaining(30);

            // 1. Play real telephone ringtone
            ringTonePlayerRef.current.start();

            // 2. Trigger vibration & system push notification
            triggerIncomingCallAlert(
              matchingCall.callerName || matchingCall.callerId,
              matchingCall.callerId
            );

            // 3. Register real notification entry so red dot appears
            setNotifications((prev) => [
              {
                id: `call-${matchingCall.id}-${now}`,
                title: `Incoming ${matchingCall.callType === 'video' ? 'Video' : 'Voice'} Call`,
                message: `Call from ${matchingCall.callerName || matchingCall.callerId} (${matchingCall.callerPhone || matchingCall.callerId})`,
                time: 'Just now',
                timestamp: now,
                read: false,
                type: 'call',
                targetTab: 'messages',
              },
              ...prev.filter((n) => !n.id.startsWith(`call-${matchingCall.id}`)),
            ]);
          }
        } else {
          if (incomingCall) {
            ringTonePlayerRef.current.stop();
            stopAllActiveRingtones();
            setIncomingCall(null);
          }
        }
      },
      (err) => {
        console.warn('Error listening for incoming calls globally:', err);
      }
    );

    return () => {
      unsubscribe();
      ringTonePlayerRef.current.stop();
      stopAllActiveRingtones();
    };
  }, [user.ghostedId, user.ghostedNumber, user.id]);

  // 30-second countdown for incoming call
  useEffect(() => {
    if (!incomingCall) return;
    const interval = setInterval(() => {
      setIncomingTimeoutRemaining((prev) => {
        if (prev <= 1) {
          ringTonePlayerRef.current.stop();
          stopAllActiveRingtones();
          setIncomingCall(null);
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [incomingCall]);

  const handleAcceptIncomingCall = async () => {
    if (!incomingCall) return;
    ringTonePlayerRef.current.stop();
    stopAllActiveRingtones();

    try {
      playConnectedChime();
      const callRef = doc(db, 'calls', incomingCall.id);
      await updateDoc(callRef, {
        status: 'answered',
        answeredAt: Date.now(),
        answer: {
          type: 'answer',
          sdp: `v=0\r\no=${user.ghostedId} 654321 2 IN IP4 127.0.0.1\r\ns=Ghosted Answer\r\nt=0 0\r\nm=audio 54312 RTP/AVP 0\r\na=rtpmap:0 PCMU/8000`,
        },
      });
    } catch (e) {
      console.warn('Error answering incoming call:', e);
    }

    setCommunicatorContactId(incomingCall.callerId);
    setExternalCallDoc(incomingCall);
    setIncomingCall(null);
    setActiveTab('messages');
  };

  const handleDeclineIncomingCall = async () => {
    if (!incomingCall) return;
    ringTonePlayerRef.current.stop();
    stopAllActiveRingtones();

    try {
      playHangupTone();
      const callRef = doc(db, 'calls', incomingCall.id);
      await updateDoc(callRef, {
        status: 'declined',
        endedAt: Date.now(),
      });
    } catch (e) {
      console.warn('Error declining call:', e);
    }
    setIncomingCall(null);
  };

  // Check URL query parameters for letter recipient view
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const letterIdParam = params.get('letterId') || params.get('letter');
      if (letterIdParam) {
        setActiveLetterRecipientId(letterIdParam);
      }
    }
  }, []);

  const triggerToast = (msg: string) => {
    setToastBanner(msg);
    setTimeout(() => {
      setToastBanner((curr) => (curr === msg ? null : curr));
    }, 3500);
  };

  const handleUpdateUser = (updated: UserProfile) => {
    setUser(updated);
  };

  const handleLetterCreated = (newLetter: SavedLetter) => {
    setLetters((prev) => [newLetter, ...prev]);
    setUser((prev) => ({
      ...prev,
      dailySendsRemaining: Math.max(0, (prev.dailySendsRemaining ?? 5) - 1),
      totalSendsToday: (prev.totalSendsToday ?? 0) + 1,
    }));
    triggerToast('Anonymous Whisper encrypted and sent safely.');
  };

  const handleLetterUpdated = (updatedLetter: SavedLetter) => {
    setLetters((prev) => prev.map((l) => (l.id === updatedLetter.id ? updatedLetter : l)));
  };

  if (!user.isOnboarded) {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col justify-center items-center p-4">
        <OnboardingFlow
          onComplete={(completedProfile) => {
            setUser({
              ...completedProfile,
              isOnboarded: true,
              themeCountry: 'facebook_light',
            });
            triggerToast('Welcome to Ghosted! Your anonymous identity is secured.');
          }}
        />
      </div>
    );
  }

  return (
    <div
      className={`min-h-screen flex flex-col font-sans transition-colors duration-300 ${
        isWhite
          ? 'bg-white text-black'
          : isBlack
          ? 'bg-black text-white'
          : 'bg-[#5B21B6] text-white'
      }`}
      style={{ backgroundColor: currentTheme.background, color: currentTheme.textOutside }}
    >
      {/* Toast Notification */}
      {toastBanner && (
        <div className={`fixed top-18 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-full text-white text-xs font-bold shadow-xl flex items-center space-x-2 animate-in fade-in slide-in-from-top-2 duration-200 ${
          isGhost
            ? 'bg-gradient-to-r from-[#7C3AED] to-[#00F5FF] shadow-[0_0_20px_rgba(124,58,237,0.5)]'
            : isBlack
            ? 'bg-white text-black'
            : 'bg-black text-white'
        }`}>
          <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin" />
          <span>{toastBanner}</span>
        </div>
      )}

      {/* PROMINENT INCOMING CALL NOTIFICATION MODAL & BANNER */}
      {incomingCall && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in zoom-in-95 duration-200">
          <div className="w-full max-w-sm theme-card rounded-3xl p-6 shadow-2xl text-center space-y-5 relative overflow-hidden">
            {/* Ambient pulsing ring glow */}
            <div className="absolute inset-0 bg-[#00F5FF]/10 pointer-events-none animate-pulse" />

            <div className="relative z-10 flex flex-col items-center">
              {/* Pulsing Avatar */}
              <div className="relative mb-3">
                <div className="w-20 h-20 rounded-full bg-white/10 border-2 border-current flex items-center justify-center text-3xl shadow-lg animate-bounce duration-1000">
                  👻
                </div>
                <div className="absolute -inset-1 rounded-full border-2 border-current animate-ping opacity-60" />
                <span className="absolute bottom-0 right-0 p-1.5 rounded-full bg-[#00F5FF] text-black shadow">
                  {incomingCall.callType === 'video' ? (
                    <Video className="w-3.5 h-3.5" />
                  ) : (
                    <Phone className="w-3.5 h-3.5" />
                  )}
                </span>
              </div>

              <span className="text-[11px] font-bold uppercase tracking-widest flex items-center space-x-1">
                <Volume2 className="w-3.5 h-3.5 animate-pulse" />
                <span>Incoming Ghosted Call</span>
              </span>

              <h3 className="text-xl font-black mt-1">
                {incomingCall.callerName || 'Ghost Caller'}
              </h3>

              <p className="text-xs font-mono opacity-70 mt-0.5">
                {incomingCall.callerId}
              </p>

              <span className="text-[11px] font-semibold opacity-70 mt-2">
                Ringing... {incomingTimeoutRemaining}s
              </span>
            </div>

            {/* ACTION BUTTONS: DECLINE AND ACCEPT */}
            <div className="relative z-10 grid grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                onClick={handleDeclineIncomingCall}
                className="py-3 px-4 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs flex items-center justify-center space-x-2 transition cursor-pointer shadow-md active:scale-95"
              >
                <PhoneOff className="w-4 h-4" />
                <span>Decline</span>
              </button>

              <button
                type="button"
                onClick={handleAcceptIncomingCall}
                className="py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs flex items-center justify-center space-x-2 transition cursor-pointer shadow-md active:scale-95 animate-pulse"
              >
                <PhoneCall className="w-4 h-4" />
                <span>Accept</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TOP APP HEADER: PINNED ONLY ON HOME SCREEN */}
      {activeTab === 'home' && (
        <header
        className={`sticky top-0 z-40 backdrop-blur-md border-b transition-colors duration-300 px-4 py-2.5 ${
          isWhite
            ? 'bg-white text-black border-gray-200 shadow-xs'
            : isBlack
            ? 'bg-black text-white border-zinc-800 shadow-md'
            : 'bg-black/90 text-white border-[#2A2A3F] shadow-md'
        }`}
        style={{
          backgroundColor: currentTheme.headerBg,
          borderColor: currentTheme.headerBorder,
          color: currentTheme.headerText,
        }}
      >
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          {/* GHOSTED AT TOP LEFT */}
          <div
            onClick={() => setActiveTab('home')}
            className="flex items-center space-x-2.5 cursor-pointer select-none group"
            title="Ghosted - Anonymous Reconnection"
          >
            <div className={`relative flex items-center justify-center w-10 h-10 rounded-full transition group-hover:scale-105 shadow-xs ${
              isGhost
                ? 'bg-gradient-to-tr from-[#7C3AED] to-[#00F5FF] text-white shadow-[0_0_15px_rgba(0,245,255,0.4)]'
                : isBlack
                ? 'bg-white text-black shadow-xs'
                : 'bg-black text-white shadow-xs'
            }`}>
              <span className="text-xl">👻</span>
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-current" />
            </div>

            <div className="flex flex-col">
              <h1 className={`text-2xl font-black tracking-tight flex items-center leading-tight ${
                isGhost
                  ? 'text-transparent bg-clip-text bg-gradient-to-r from-[#7C3AED] to-[#00F5FF]'
                  : isBlack
                  ? 'text-white'
                  : 'text-black'
              }`}>
                Ghosted
              </h1>
              <p
                className={`text-[10px] font-semibold tracking-wide ${
                  isGhost ? 'text-purple-200' : isBlack ? 'text-gray-400' : 'text-gray-600'
                }`}
              >
                Safe & Anonymous Connection
              </p>
            </div>
          </div>

          {/* TOP RIGHT: NOTIFICATION BELL */}
          <div className="flex items-center space-x-2 relative">
            {/* NOTIFICATION BELL WITH RED BADGE */}
            <button
              type="button"
              onClick={() => setIsNotificationOpen((prev) => !prev)}
              className={`relative w-10 h-10 rounded-full flex items-center justify-center transition cursor-pointer active:scale-95 ${
                isLight
                  ? 'bg-[#E4E6EB] hover:bg-[#D8DADF] text-[#050505]'
                  : 'bg-[#3A3B3C] hover:bg-[#4E4F50] text-[#E4E6EB]'
              }`}
              title="Notifications"
            >
              <Bell className="w-5 h-5" />
              {/* RED DOT ON REAL NOTIFICATION */}
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-[#E41E3F] rounded-full ring-2 ring-white dark:ring-[#242526] animate-pulse" />
              )}
            </button>

            {/* NOTIFICATION CENTER DROPDOWN */}
            {isNotificationOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setIsNotificationOpen(false)}
                />
                <div
                  className={`absolute right-0 top-full mt-2 z-50 w-80 sm:w-96 rounded-2xl p-4 shadow-2xl animate-in fade-in zoom-in-95 duration-150 border ${
                    isLight
                      ? 'bg-white border-gray-200 text-[#050505] shadow-gray-300/50'
                      : 'bg-[#242526] border-[#393A3B] text-[#E4E6EB] shadow-black/80'
                  }`}
                >
                  <div
                    className={`flex items-center justify-between pb-3 border-b ${
                      isLight ? 'border-gray-100' : 'border-[#393A3B]'
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      <Bell className="w-4 h-4 text-[#1877F2]" />
                      <h3 className="font-bold text-sm">Notifications</h3>
                      {unreadCount > 0 && (
                        <span className="px-2 py-0.5 rounded-full bg-[#E41E3F] text-white text-[10px] font-bold">
                          {unreadCount} new
                        </span>
                      )}
                    </div>
                    {unreadCount > 0 && (
                      <button
                        type="button"
                        onClick={handleMarkAllNotificationsRead}
                        className="text-xs text-[#1877F2] hover:underline font-bold cursor-pointer"
                      >
                        Mark all read
                      </button>
                    )}
                  </div>

                  <div className="py-2 space-y-2 max-h-80 overflow-y-auto">
                    {notifications.length === 0 ? (
                      <div
                        className={`py-8 text-center text-xs font-semibold ${
                          isLight ? 'text-[#65676B]' : 'text-[#B0B3B8]'
                        }`}
                      >
                        No notifications yet. You're all caught up! 🔔
                      </div>
                    ) : (
                      notifications.map((notif) => (
                        <div
                          key={notif.id}
                          onClick={() => handleNotificationClick(notif)}
                          className={`p-3 rounded-xl transition cursor-pointer flex items-start space-x-3 ${
                            !notif.read
                              ? isLight
                                ? 'bg-[#E7F3FF] border border-[#1877F2]/20 text-[#050505]'
                                : 'bg-[#2D88FF]/15 border border-[#2D88FF]/30 text-[#E4E6EB]'
                              : isLight
                              ? 'hover:bg-gray-100 text-[#050505]'
                              : 'hover:bg-[#3A3B3C] text-[#E4E6EB]'
                          }`}
                        >
                          <div className="w-8 h-8 rounded-full bg-[#1877F2] text-white flex items-center justify-center flex-shrink-0 text-xs font-bold">
                            {notif.type === 'whisper' && <Mail className="w-4 h-4" />}
                            {notif.type === 'call' && <PhoneCall className="w-4 h-4" />}
                            {notif.type === 'friend' && <Users className="w-4 h-4" />}
                            {notif.type === 'system' && <ShieldCheck className="w-4 h-4" />}
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <h4 className="text-xs font-bold truncate">
                                {notif.title}
                              </h4>
                              <span
                                className={`text-[10px] font-medium flex-shrink-0 ml-1 ${
                                  isLight ? 'text-[#65676B]' : 'text-[#B0B3B8]'
                                }`}
                              >
                                {notif.time}
                              </span>
                            </div>
                            <p
                              className={`text-[11px] font-normal line-clamp-2 mt-0.5 ${
                                isLight ? 'text-[#65676B]' : 'text-[#B0B3B8]'
                              }`}
                            >
                              {notif.message}
                            </p>
                          </div>

                          {!notif.read && (
                            <span className="w-2.5 h-2.5 rounded-full bg-[#1877F2] flex-shrink-0 mt-1" />
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </header>
      )}

      {/* MAIN TAB CONTENT */}
      <main className="flex-1 max-w-4xl w-full mx-auto pb-24 pt-2">
        {activeTab === 'home' && (
          <HomeFeedTab
            user={user}
            isNigeria={isNigeria}
            onUpdateUser={handleUpdateUser}
            onNavigateToTab={(tab) => {
              if (tab === 'messages' || tab === 'whispers' || tab === 'friends' || tab === 'profile') {
                setActiveTab(tab as MainTab);
              }
            }}
          />
        )}

        {activeTab === 'whispers' && (
          <div className="px-3 sm:px-4">
            <DraftFeedTab
              user={user}
              isNigeria={isNigeria}
              letters={letters}
              dailySendsRemaining={user.dailySendsRemaining ?? 5}
              onLetterCreated={handleLetterCreated}
              onPreviewLetter={(id) => setActiveLetterRecipientId(id)}
              onLetterUpdated={handleLetterUpdated}
            />
          </div>
        )}

        {activeTab === 'messages' && (
          <div className="px-3 sm:px-4">
            <GhostedCommunicator
              user={user}
              letters={letters}
              initialTargetGhostedId={communicatorContactId}
              externalIncomingCallDoc={externalCallDoc}
              onClearExternalIncomingCall={() => setExternalCallDoc(null)}
              onSwitchUser={(updated) => handleUpdateUser(updated)}
            />
          </div>
        )}

        {activeTab === 'friends' && (
          <div className="px-3 sm:px-4">
            <FriendsTab
              user={user}
              isNigeria={isNigeria}
              onNavigateToTab={(t) => setActiveTab(t as MainTab)}
              onOpenChatWithUser={(friendId) => {
                setCommunicatorContactId(friendId);
                setActiveTab('messages');
              }}
              onStartCallWithUser={(friendNum) => {
                setCommunicatorContactId(friendNum);
                setActiveTab('messages');
              }}
            />
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="px-3 sm:px-4">
            <ProfileSafetyTab
              user={user}
              dailySendsRemaining={user.dailySendsRemaining ?? 5}
              onResetOnboarding={() => setUser((p) => ({ ...p, isOnboarded: false }))}
              onProfileUpdated={handleUpdateUser}
            />
          </div>
        )}
      </main>

      {/* BOTTOM NAVIGATION */}
      <nav
        className={`fixed bottom-0 left-0 right-0 z-40 border-t px-2 py-1 transition-colors duration-300 ${
          isWhite
            ? 'bg-white text-black border-gray-200 shadow-xs'
            : isBlack
            ? 'bg-black text-white border-zinc-800 shadow-md'
            : 'bg-black/95 text-white border-[#2A2A3F] shadow-lg'
        }`}
        style={{
          backgroundColor: currentTheme.navBg,
          borderColor: currentTheme.navBorder,
          color: currentTheme.navText,
        }}
      >
        <div className="max-w-md mx-auto flex items-center justify-between">
          <button
            type="button"
            onClick={() => setActiveTab('home')}
            className={`flex flex-col items-center flex-1 py-1.5 transition cursor-pointer relative ${
              activeTab === 'home'
                ? isGhost
                  ? 'text-[#00F5FF] font-bold drop-shadow-[0_0_8px_rgba(0,245,255,0.7)]'
                  : isBlack
                  ? 'text-white font-bold'
                  : 'text-black font-bold'
                : isGhost
                ? 'text-gray-400 hover:text-white'
                : isBlack
                ? 'text-gray-500 hover:text-white'
                : 'text-gray-500 hover:text-black'
            }`}
          >
            <Home className="w-5 h-5 mb-0.5 stroke-[2.2]" />
            <span className="text-[10px] font-bold">Feed</span>
            {activeTab === 'home' && (
              <span
                className="absolute bottom-0 w-8 h-[2.5px] rounded-full"
                style={{ backgroundColor: currentTheme.accent }}
              />
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('whispers')}
            className={`flex flex-col items-center flex-1 py-1.5 transition cursor-pointer relative ${
              activeTab === 'whispers'
                ? isGhost
                  ? 'text-[#00F5FF] font-bold drop-shadow-[0_0_8px_rgba(0,245,255,0.7)]'
                  : isBlack
                  ? 'text-white font-bold'
                  : 'text-black font-bold'
                : isGhost
                ? 'text-gray-400 hover:text-white'
                : isBlack
                ? 'text-gray-500 hover:text-white'
                : 'text-gray-500 hover:text-black'
            }`}
          >
            <Mail className="w-5 h-5 mb-0.5 stroke-[2.2]" />
            <span className="text-[10px] font-bold">Whispers</span>
            {activeTab === 'whispers' && (
              <span
                className="absolute bottom-0 w-8 h-[2.5px] rounded-full"
                style={{ backgroundColor: currentTheme.accent }}
              />
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('messages')}
            className={`flex flex-col items-center flex-1 py-1.5 transition cursor-pointer relative ${
              activeTab === 'messages'
                ? isGhost
                  ? 'text-[#00F5FF] font-bold drop-shadow-[0_0_8px_rgba(0,245,255,0.7)]'
                  : isBlack
                  ? 'text-white font-bold'
                  : 'text-black font-bold'
                : isGhost
                ? 'text-gray-400 hover:text-white'
                : isBlack
                ? 'text-gray-500 hover:text-white'
                : 'text-gray-500 hover:text-black'
            }`}
          >
            <MessageSquare className="w-5 h-5 mb-0.5 stroke-[2.2]" />
            <span className="text-[10px] font-bold">Calls & Chat</span>
            <span className="absolute top-1 right-4 w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            {activeTab === 'messages' && (
              <span
                className="absolute bottom-0 w-8 h-[2.5px] rounded-full"
                style={{ backgroundColor: currentTheme.accent }}
              />
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('friends')}
            className={`flex flex-col items-center flex-1 py-1.5 transition cursor-pointer relative ${
              activeTab === 'friends'
                ? isGhost
                  ? 'text-[#00F5FF] font-bold drop-shadow-[0_0_8px_rgba(0,245,255,0.7)]'
                  : isBlack
                  ? 'text-white font-bold'
                  : 'text-black font-bold'
                : isGhost
                ? 'text-gray-400 hover:text-white'
                : isBlack
                ? 'text-gray-500 hover:text-white'
                : 'text-gray-500 hover:text-black'
            }`}
          >
            <Users className="w-5 h-5 mb-0.5 stroke-[2.2]" />
            <span className="text-[10px] font-bold">Friends</span>
            {activeTab === 'friends' && (
              <span
                className="absolute bottom-0 w-8 h-[2.5px] rounded-full"
                style={{ backgroundColor: currentTheme.accent }}
              />
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('profile')}
            className={`flex flex-col items-center flex-1 py-1.5 transition cursor-pointer relative ${
              activeTab === 'profile'
                ? isGhost
                  ? 'text-[#00F5FF] font-bold drop-shadow-[0_0_8px_rgba(0,245,255,0.7)]'
                  : isBlack
                  ? 'text-white font-bold'
                  : 'text-black font-bold'
                : isGhost
                ? 'text-gray-400 hover:text-white'
                : isBlack
                ? 'text-gray-500 hover:text-white'
                : 'text-gray-500 hover:text-black'
            }`}
          >
            <User className="w-5 h-5 mb-0.5 stroke-[2.2]" />
            <span className="text-[10px] font-bold">Profile</span>
            {activeTab === 'profile' && (
              <span
                className="absolute bottom-0 w-8 h-[2.5px] rounded-full"
                style={{ backgroundColor: currentTheme.accent }}
              />
            )}
          </button>
        </div>
      </nav>

      {/* RECIPIENT LETTER VIEW MODAL */}
      {activeLetterRecipientId && (
        <RecipientViewModal
          letterId={activeLetterRecipientId}
          onClose={() => setActiveLetterRecipientId(null)}
          onReportClick={(targetGhostedId, letterId) => {
            setReportModalTarget({ ghostedId: targetGhostedId, letterId });
          }}
        />
      )}

      {/* SAFETY REPORT MODAL */}
      {reportModalTarget && (
        <ReportModal
          targetGhostedId={reportModalTarget.ghostedId}
          letterId={reportModalTarget.letterId}
          onClose={() => setReportModalTarget(null)}
          onReportSubmitted={() => {
            setReportModalTarget(null);
            triggerToast('Report filed securely. Our safety AI has flagged the event.');
          }}
        />
      )}
    </div>
  );
}
