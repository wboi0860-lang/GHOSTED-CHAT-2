import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  query,
  where,
  onSnapshot,
  orderBy,
  limit,
} from 'firebase/firestore';
import { db, auth } from '../firebase';
import {
  GhostUserDoc,
  CallRecordDoc,
  InboxMessageDoc,
  GhostNotificationDoc,
} from '../types';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
  };
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid,
      email: auth?.currentUser?.email,
    },
    operationType,
    path,
  };
  console.warn('Firestore Warning/Error: ', JSON.stringify(errInfo));
}

// Simple salt + hash for private passwords
export function hashPassword(plain: string): string {
  let hash = 0;
  const salted = `ghost_salt_2026_${plain}`;
  for (let i = 0; i < salted.length; i++) {
    const char = salted.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0; // Convert to 32bit integer
  }
  return `gh_${Math.abs(hash).toString(16)}`;
}

// Generate unique Ghost ID e.g. Ghost#1234
export function generateUniqueGhostId(): string {
  const num = Math.floor(1000 + Math.random() * 9000);
  return `Ghost#${num}`;
}

// Default Seed Users (preserving existing community & demo users)
export const SEED_GHOST_USERS: GhostUserDoc[] = [
  {
    id: 'sug-1',
    ghost_name: 'Phantom_Vision',
    ghost_id: 'Ghost#8902',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80',
    is_public_id: false, // PRIVATE by default
    created_at: new Date(Date.now() - 86400000 * 7).toISOString(),
    password_hash: hashPassword('ghost123'),
    interests: ['Music', 'Heartbreak', 'Tech'],
    bio: 'Whispering in THE VOID 🌌',
    is_online: true,
  },
  {
    id: 'sug-2',
    ghost_name: 'Midnight_Wanderer',
    ghost_id: 'Ghost#3391',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=250&q=80',
    is_public_id: false, // PRIVATE by default
    created_at: new Date(Date.now() - 86400000 * 5).toISOString(),
    password_hash: hashPassword('ghost123'),
    interests: ['Gaming', 'Books', 'Anxiety'],
    bio: 'Late night wanderer 🕯️',
    is_online: true,
  },
  {
    id: 'sug-3',
    ghost_name: 'Cipher_Soul',
    ghost_id: 'Ghost#1092',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=250&q=80',
    is_public_id: false, // PRIVATE by default
    created_at: new Date(Date.now() - 86400000 * 3).toISOString(),
    password_hash: hashPassword('ghost123'),
    interests: ['Crypto', 'Art', 'Memes'],
    bio: 'Encrypted frequencies only ⚡',
    is_online: true,
  },
  {
    id: 'sug-4',
    ghost_name: 'Velvet_Mirage',
    ghost_id: 'Ghost#7718',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=250&q=80',
    is_public_id: false, // PRIVATE by default
    created_at: new Date(Date.now() - 86400000 * 2).toISOString(),
    password_hash: hashPassword('ghost123'),
    interests: ['Fashion', 'Travel', 'Movies'],
    bio: 'Lost in the twilight ✨',
    is_online: false,
  },
  {
    id: 'sug-5',
    ghost_name: 'Echo_Starlight',
    ghost_id: 'Ghost#4412',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=250&q=80',
    is_public_id: false, // PRIVATE by default
    created_at: new Date(Date.now() - 86400000 * 1).toISOString(),
    password_hash: hashPassword('ghost123'),
    interests: ['Studying', 'Football', 'Luxury'],
    bio: 'Listening without judgment 🕊️',
    is_online: true,
  },
];

/* =========================================================================
   1. REAL AUTH - PRIVATE SIGN UP / LOGIN
   ========================================================================= */

// Ensure seed users are saved in Firestore ghost_users
export async function seedGhostUsersIfEmpty(): Promise<void> {
  const path = 'ghost_users';
  try {
    const snap = await getDocs(collection(db, path));
    if (snap.empty) {
      for (const u of SEED_GHOST_USERS) {
        await setDoc(doc(db, path, u.id), u);
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

// Sign Up Real Ghosted User
export async function signUpGhostUser(params: {
  ghost_name: string;
  password: string;
  email?: string;
  avatar?: string;
  interests?: string[];
}): Promise<{ success: boolean; user?: GhostUserDoc; error?: string }> {
  const path = 'ghost_users';
  try {
    const cleanName = params.ghost_name.trim();
    if (!cleanName) {
      return { success: false, error: 'Ghost Name is required.' };
    }
    if (params.password.length < 4) {
      return { success: false, error: 'Password must be at least 4 characters.' };
    }

    // Check unique Ghost Name
    const nameQuery = query(collection(db, path), where('ghost_name', '==', cleanName));
    const existing = await getDocs(nameQuery);
    if (!existing.empty) {
      return { success: false, error: `The Ghost Name "${cleanName}" is already taken. Please choose another.` };
    }

    const newId = `gh_usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const ghostId = generateUniqueGhostId();
    const avatar =
      params.avatar ||
      `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(cleanName)}&backgroundColor=000000,5b21b6`;

    const newUserDoc: GhostUserDoc = {
      id: newId,
      ghost_name: cleanName,
      ghost_id: ghostId,
      avatar,
      is_public_id: false, // PRIVATE by default as specified!
      created_at: new Date().toISOString(),
      password_hash: hashPassword(params.password),
      email: params.email ? params.email.trim() : null, // private, never shown
      interests: params.interests || ['Tech', 'Music', 'Heartbreak'],
      is_online: true,
      last_active: new Date().toISOString(),
    };

    await setDoc(doc(db, path, newId), newUserDoc);
    return { success: true, user: newUserDoc };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Error creating account. Please try again.',
    };
  }
}

// Log In Real Ghosted User
export async function loginGhostUser(
  identifier: string,
  password: string
): Promise<{ success: boolean; user?: GhostUserDoc; error?: string }> {
  const path = 'ghost_users';
  try {
    const cleanId = identifier.trim();
    if (!cleanId || !password) {
      return { success: false, error: 'Ghost Name/ID and Password are required.' };
    }

    // Try finding by ghost_name
    let q = query(collection(db, path), where('ghost_name', '==', cleanId));
    let snap = await getDocs(q);

    // If not found, try by ghost_id
    if (snap.empty) {
      q = query(collection(db, path), where('ghost_id', '==', cleanId));
      snap = await getDocs(q);
    }

    if (snap.empty) {
      // Check local seed list fallback
      const localSeed = SEED_GHOST_USERS.find(
        (u) =>
          u.ghost_name.toLowerCase() === cleanId.toLowerCase() ||
          u.ghost_id.toLowerCase() === cleanId.toLowerCase()
      );
      if (localSeed) {
        if (localSeed.password_hash === hashPassword(password)) {
          return { success: true, user: localSeed };
        }
      }
      return { success: false, error: 'No Ghost user found with that name or ID.' };
    }

    const userDoc = snap.docs[0].data() as GhostUserDoc;
    const expectedHash = hashPassword(password);

    if (userDoc.password_hash && userDoc.password_hash !== expectedHash) {
      return { success: false, error: 'Incorrect password.' };
    }

    // Mark online
    await updateDoc(doc(db, path, userDoc.id), {
      is_online: true,
      last_active: new Date().toISOString(),
    }).catch(() => null);

    return { success: true, user: { ...userDoc, is_online: true } };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Login failed. Please check credentials.',
    };
  }
}

// Subscribe to all real Ghosted users in Firestore
export function subscribeGhostUsers(callback: (users: GhostUserDoc[]) => void): () => void {
  const path = 'ghost_users';
  try {
    const unsub = onSnapshot(
      collection(db, path),
      (snap) => {
        if (snap.empty) {
          callback(SEED_GHOST_USERS);
          return;
        }
        const users = snap.docs.map((d) => d.data() as GhostUserDoc);
        callback(users);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, path);
        callback(SEED_GHOST_USERS);
      }
    );
    return unsub;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    callback(SEED_GHOST_USERS);
    return () => {};
  }
}

// Toggle Privacy Setting in Database
export async function setGhostIdPrivacy(
  userId: string,
  isPublic: boolean
): Promise<boolean> {
  const path = 'ghost_users';
  try {
    await updateDoc(doc(db, path, userId), {
      is_public_id: isPublic,
    });
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${path}/${userId}`);
    return false;
  }
}

/* =========================================================================
   2. REAL CALLS - GHOSTED ONLY, PRIVATE (WebRTC + Firestore Signaling)
   ========================================================================= */

// Start Real Ghosted Call (Voice or Video)
export async function startGhostedPeerCall(params: {
  callerId: string;
  callerName: string;
  receiverId: string;
  receiverName: string;
  type: 'voice' | 'video';
}): Promise<{ callId: string }> {
  const path = 'calls';
  const callId = `call_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const callDoc: CallRecordDoc = {
    id: callId,
    caller_id: params.callerId,
    receiver_id: params.receiverId,
    caller_name: params.callerName,
    receiver_name: params.receiverName,
    type: params.type,
    duration: 0,
    time: new Date().toISOString(),
    status: 'ringing',
  };

  try {
    await setDoc(doc(db, path, callId), callDoc);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `${path}/${callId}`);
  }
  return { callId };
}

// Answer Real Call
export async function answerGhostedPeerCall(callId: string): Promise<void> {
  const path = `calls/${callId}`;
  try {
    await updateDoc(doc(db, 'calls', callId), {
      status: 'connected',
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// End / Decline Call and save history
export async function endGhostedPeerCall(
  callId: string,
  durationSeconds: number,
  finalStatus: 'completed' | 'declined' | 'missed' = 'completed'
): Promise<void> {
  const path = `calls/${callId}`;
  try {
    await updateDoc(doc(db, 'calls', callId), {
      status: finalStatus,
      duration: durationSeconds,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// Subscribe to incoming calls for current user
export function subscribeIncomingGhostCalls(
  currentUserId: string,
  onIncomingCall: (call: CallRecordDoc | null) => void
): () => void {
  const path = 'calls';
  try {
    const q = query(
      collection(db, path),
      where('receiver_id', '==', currentUserId),
      where('status', '==', 'ringing')
    );

    const unsub = onSnapshot(
      q,
      (snap) => {
        if (snap.empty) {
          onIncomingCall(null);
          return;
        }
        const call = snap.docs[0].data() as CallRecordDoc;
        onIncomingCall(call);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, path);
      }
    );
    return unsub;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return () => {};
  }
}

// Subscribe to real call history from database
export function subscribeRealCallHistory(
  userId: string,
  callback: (calls: CallRecordDoc[]) => void
): () => void {
  const path = 'calls';
  try {
    // Listen to recent calls
    const unsub = onSnapshot(
      collection(db, path),
      (snap) => {
        const myCalls = snap.docs
          .map((d) => d.data() as CallRecordDoc)
          .filter((c) => c.caller_id === userId || c.receiver_id === userId)
          .sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime());
        callback(myCalls);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, path);
      }
    );
    return unsub;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return () => {};
  }
}

/* =========================================================================
   3. REAL CHAT & WHISPERS - PRIVATE INBOX & REVEALS
   ========================================================================= */

// Send Anonymous Message to Real Ghosted User
export async function sendUnknownMessage(params: {
  senderId: string;
  senderName: string;
  receiverId: string;
  receiverName?: string;
  message: string;
  mood?: string;
  relationship?: string;
}): Promise<{ success: boolean; id?: string; error?: string }> {
  const path = 'inbox_messages';
  const msgId = `inbox_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const newMsg: InboxMessageDoc = {
    id: msgId,
    sender_id_hidden: params.senderId,
    sender_name_hidden: params.senderName,
    receiver_id: params.receiverId,
    receiver_name: params.receiverName,
    message: params.message.trim(),
    mood: params.mood || 'Miss You',
    relationship: params.relationship || 'Friend',
    is_revealed: false,
    timestamp: new Date().toISOString(),
  };

  try {
    await setDoc(doc(db, path, msgId), newMsg);

    // Send push notification to receiver
    await sendGhostNotification({
      userId: params.receiverId,
      type: 'whisper_received',
      title: 'New Anonymous Whisper 💌',
      body: 'Someone from your circle left an encrypted private message in your Inbox.',
      referenceId: msgId,
    });

    return { success: true, id: msgId };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Failed to send message.',
    };
  }
}

// Reveal Identity on an Inbox Message
export async function revealUnknownMessageIdentity(
  messageId: string,
  revealerName: string
): Promise<{ success: boolean; error?: string }> {
  const path = `inbox_messages/${messageId}`;
  try {
    const msgRef = doc(db, 'inbox_messages', messageId);
    const snap = await getDoc(msgRef);
    if (!snap.exists()) {
      return { success: false, error: 'Message not found.' };
    }
    const data = snap.data() as InboxMessageDoc;

    // Mark revealed
    await updateDoc(msgRef, {
      is_revealed: true,
    });

    // Notify hidden sender that their identity was revealed!
    if (data.sender_id_hidden) {
      await sendGhostNotification({
        userId: data.sender_id_hidden,
        type: 'reveal_requested',
        title: 'Identity Revealed! 🔓',
        body: `${revealerName} has unlocked your identity on your secret whisper!`,
        referenceId: messageId,
      });
    }

    return { success: true };
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Failed to reveal identity.',
    };
  }
}

// Subscribe to incoming inbox messages for user
export function subscribeInboxMessages(
  userId: string,
  callback: (messages: InboxMessageDoc[]) => void
): () => void {
  const path = 'inbox_messages';
  try {
    const q = query(
      collection(db, path),
      where('receiver_id', '==', userId)
    );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const msgs = snap.docs
          .map((d) => d.data() as InboxMessageDoc)
          .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        callback(msgs);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, path);
      }
    );
    return unsub;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return () => {};
  }
}

/* =========================================================================
   4. REAL PUSH NOTIFICATIONS
   ========================================================================= */

export async function sendGhostNotification(params: {
  userId: string;
  type: 'reveal_requested' | 'whisper_received' | 'call_missed' | 'chat_message';
  title: string;
  body: string;
  referenceId?: string;
}): Promise<void> {
  const path = 'notifications';
  const id = `notif_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const notifDoc: GhostNotificationDoc = {
    id,
    user_id: params.userId,
    type: params.type,
    title: params.title,
    body: params.body,
    timestamp: new Date().toISOString(),
    read: false,
    reference_id: params.referenceId,
  };

  try {
    await setDoc(doc(db, path, id), notifDoc);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `${path}/${id}`);
  }
}

export function subscribeRealNotifications(
  userId: string,
  callback: (notifications: GhostNotificationDoc[]) => void
): () => void {
  const path = 'notifications';
  try {
    const q = query(
      collection(db, path),
      where('user_id', '==', userId)
    );

    const unsub = onSnapshot(
      q,
      (snap) => {
        const items = snap.docs
          .map((d) => d.data() as GhostNotificationDoc)
          .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        callback(items);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, path);
      }
    );
    return unsub;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return () => {};
  }
}

export async function markRealNotificationRead(notifId: string): Promise<void> {
  const path = `notifications/${notifId}`;
  try {
    await updateDoc(doc(db, 'notifications', notifId), {
      read: true,
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}
